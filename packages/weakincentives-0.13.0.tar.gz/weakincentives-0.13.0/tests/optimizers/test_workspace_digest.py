# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any, cast, override

import pytest

from weakincentives.adapters._names import OPENAI_ADAPTER_NAME
from weakincentives.adapters.core import (
    PromptEvaluationError,
    PromptResponse,
    ProviderAdapter,
)
from weakincentives.deadlines import Deadline
from weakincentives.optimizers import (
    OptimizationContext,
    OptimizerConfig,
    PersistenceScope,
    WorkspaceDigestOptimizer,
)
from weakincentives.prompt import MarkdownSection, Prompt, PromptTemplate
from weakincentives.prompt.overrides import (
    PromptDescriptor,
    PromptLike,
    PromptOverride,
    PromptOverridesError,
    PromptOverridesStore,
)
from weakincentives.prompt.tool_result import ToolResult
from weakincentives.runtime.events import ToolInvoked
from weakincentives.runtime.session import Session, SessionProtocol
from weakincentives.tools.digests import (
    WorkspaceDigest,
    WorkspaceDigestSection,
    latest_workspace_digest,
    set_workspace_digest,
)
from weakincentives.tools.vfs import VfsToolsSection


@dataclass(slots=True, frozen=True)
class _FakeOptimizationOutput:
    digest: str


@dataclass(slots=True, frozen=True)
class _PromptOutput:
    summary: str = "ok"


@dataclass(slots=True, frozen=True)
class _ToolEventParams:
    value: str = "param"


class _RecordingOverridesStore(PromptOverridesStore):
    def __init__(self) -> None:
        self.calls: list[tuple[PromptTemplate[Any], str, tuple[str, ...], str]] = []

    def resolve(
        self,
        descriptor: PromptDescriptor,
        tag: str = "latest",
    ) -> PromptOverride | None:
        self.calls.append((cast(PromptTemplate[Any], descriptor), tag, (), "resolve"))
        return None

    def upsert(
        self,
        descriptor: PromptLike,
        override: PromptOverride,
    ) -> PromptOverride:
        self.calls.append((cast(PromptTemplate[Any], descriptor), "", (), "upsert"))
        return override

    def delete(
        self,
        *,
        ns: str,
        prompt_key: str,
        tag: str,
    ) -> None:
        self.calls.append(
            (cast(PromptTemplate[Any], object()), tag, (ns, prompt_key), "delete")
        )

    def set_section_override(
        self,
        prompt: PromptTemplate[Any],
        *,
        tag: str = "latest",
        path: tuple[str, ...],
        body: str,
    ) -> PromptOverride:
        self.calls.append((prompt, tag, path, body))
        return cast(PromptOverride, object())

    def seed(
        self,
        prompt: PromptLike,
        *,
        tag: str = "latest",
    ) -> PromptOverride:
        self.calls.append((cast(PromptTemplate[Any], prompt), tag, (), "seed"))
        return cast(PromptOverride, object())


class _FailingSeedOverridesStore(_RecordingOverridesStore):
    def seed(
        self,
        prompt: PromptLike,
        *,
        tag: str = "latest",
    ) -> PromptOverride:
        self.calls.append((cast(PromptTemplate[Any], prompt), tag, (), "seed"))
        raise PromptOverridesError("seed failed")


class _RecordingAdapter(ProviderAdapter):
    def __init__(self, *, mode: str, emit_tool_event: bool = False) -> None:
        self.mode = mode
        self.rendered_prompts: list[Prompt[Any]] = []
        self.sessions: list[SessionProtocol] = []
        self._emit_tool_event = emit_tool_event

    @override
    def evaluate(
        self,
        prompt: Prompt[Any],
        *,
        session: SessionProtocol,
        deadline: Deadline | None = None,
    ) -> PromptResponse[Any]:
        del deadline
        prompt_name = prompt.name or prompt.key
        self.rendered_prompts.append(prompt)
        self.sessions.append(session)

        if self._emit_tool_event:
            event = ToolInvoked(
                prompt_name=prompt_name,
                adapter=OPENAI_ADAPTER_NAME,
                name="optimize-tool",
                params=_ToolEventParams(),
                result=ToolResult(message="ok", value=None),
                session_id=getattr(session, "session_id", None) if session else None,
                created_at=datetime.now(UTC),
            )
            session.event_bus.publish(event)

        digest_value = f"{self.mode}-digest"
        if self.mode == "dataclass":
            output: Any = _FakeOptimizationOutput(digest=digest_value)
            text: str | None = None
        elif self.mode == "string":
            output = digest_value
            text = None
        elif self.mode == "text":
            output = None
            text = digest_value
        else:
            output = None
            text = None

        return PromptResponse(
            prompt_name=prompt.name or prompt.key,
            text=text,
            output=output,
        )


def _build_prompt() -> PromptTemplate[_PromptOutput]:
    session = Session()
    workspace = VfsToolsSection(session=session)
    digest = WorkspaceDigestSection(session=session)
    return PromptTemplate[_PromptOutput](
        ns="tests", key="opt", sections=(workspace, digest)
    )


def _create_optimizer(
    adapter: ProviderAdapter[Any],
    *,
    store_scope: PersistenceScope = PersistenceScope.SESSION,
    overrides_store: PromptOverridesStore | None = None,
    overrides_tag: str = "latest",
    accepts_overrides: bool = True,
    optimization_session: Session | None = None,
) -> WorkspaceDigestOptimizer:
    session = Session()
    context = OptimizationContext(
        adapter=adapter,
        event_bus=session.event_bus,
        overrides_store=overrides_store,
        overrides_tag=overrides_tag,
        optimization_session=optimization_session,
    )
    config = OptimizerConfig(accepts_overrides=accepts_overrides)
    return WorkspaceDigestOptimizer(context, config=config, store_scope=store_scope)


def test_optimize_persists_digest_from_output() -> None:
    adapter = _RecordingAdapter(mode="dataclass")
    optimizer = _create_optimizer(adapter)
    prompt = Prompt(_build_prompt())
    session = Session()

    result = optimizer.optimize(prompt, session=session)

    latest = latest_workspace_digest(session, "workspace-digest")
    assert result.digest == "dataclass-digest"
    assert latest is not None
    assert getattr(latest, "body", None) == "dataclass-digest"


def test_session_clear_slice_removes_entire_digest_slice() -> None:
    session = Session()
    set_workspace_digest(session, "workspace-digest", "value")

    session.mutate(WorkspaceDigest).clear()

    assert latest_workspace_digest(session, "workspace-digest") is None


def test_optimize_handles_string_output() -> None:
    adapter = _RecordingAdapter(mode="string")
    optimizer = _create_optimizer(adapter)
    prompt = Prompt(_build_prompt())
    session = Session()

    result = optimizer.optimize(prompt, session=session)

    assert result.digest == "string-digest"


def test_optimize_falls_back_to_text() -> None:
    adapter = _RecordingAdapter(mode="text")
    optimizer = _create_optimizer(adapter)
    prompt = Prompt(_build_prompt())
    session = Session()

    result = optimizer.optimize(prompt, session=session)

    assert result.digest == "text-digest"


def test_optimize_requires_digest_content() -> None:
    adapter = _RecordingAdapter(mode="none")
    optimizer = _create_optimizer(adapter)
    prompt = Prompt(_build_prompt())
    session = Session()

    with pytest.raises(PromptEvaluationError):
        optimizer.optimize(prompt, session=session)


def test_optimize_updates_global_overrides() -> None:
    adapter = _RecordingAdapter(mode="dataclass")
    overrides_store = _RecordingOverridesStore()
    optimizer = _create_optimizer(
        adapter,
        store_scope=PersistenceScope.GLOBAL,
        overrides_store=overrides_store,
        overrides_tag="tag",
    )
    prompt = Prompt(_build_prompt())
    session = Session()

    result = optimizer.optimize(prompt, session=session)

    assert overrides_store.calls
    recorded_prompt, tag, path, body = next(
        call
        for call in overrides_store.calls
        if call[3] not in {"seed", "resolve", "upsert", "delete"}
    )
    assert recorded_prompt is prompt
    assert tag == "tag"
    assert path[-1] == "workspace-digest"
    assert body == result.digest
    assert latest_workspace_digest(session, "workspace-digest") is None


def test_optimize_global_scope_clears_existing_session_digest() -> None:
    adapter = _RecordingAdapter(mode="dataclass")
    overrides_store = _RecordingOverridesStore()
    optimizer = _create_optimizer(
        adapter,
        store_scope=PersistenceScope.GLOBAL,
        overrides_store=overrides_store,
        overrides_tag="tag",
    )
    prompt = Prompt(_build_prompt())
    session = Session()
    _ = set_workspace_digest(session, "workspace-digest", "stale")

    _ = optimizer.optimize(prompt, session=session)

    assert latest_workspace_digest(session, "workspace-digest") is None


def test_optimize_requires_overrides_inputs_for_global_scope() -> None:
    adapter = _RecordingAdapter(mode="dataclass")
    optimizer = _create_optimizer(
        adapter,
        store_scope=PersistenceScope.GLOBAL,
        overrides_store=None,
        overrides_tag="tag",
    )
    prompt = Prompt(_build_prompt())

    with pytest.raises(PromptEvaluationError):
        optimizer.optimize(prompt, session=Session())


def test_optimize_missing_overrides_inputs_preserves_session_digest() -> None:
    adapter = _RecordingAdapter(mode="dataclass")
    optimizer = _create_optimizer(
        adapter,
        store_scope=PersistenceScope.GLOBAL,
        overrides_store=None,
        overrides_tag="tag",
    )
    prompt = Prompt(_build_prompt())
    session = Session()
    _ = set_workspace_digest(session, "workspace-digest", "existing")

    with pytest.raises(PromptEvaluationError):
        optimizer.optimize(prompt, session=session)

    latest = latest_workspace_digest(session, "workspace-digest")
    assert latest is not None
    assert getattr(latest, "body", None) == "existing"


def test_optimize_seeds_internal_prompt_overrides() -> None:
    adapter = _RecordingAdapter(mode="dataclass")
    overrides_store = _RecordingOverridesStore()
    optimizer = _create_optimizer(adapter, overrides_store=overrides_store)
    prompt = Prompt(_build_prompt())

    _ = optimizer.optimize(prompt, session=Session())

    assert any(call[3] == "seed" for call in overrides_store.calls)


def test_optimize_raises_when_internal_prompt_seeding_fails() -> None:
    adapter = _RecordingAdapter(mode="dataclass")
    overrides_store = _FailingSeedOverridesStore()
    optimizer = _create_optimizer(adapter, overrides_store=overrides_store)
    prompt = Prompt(_build_prompt())

    with pytest.raises(PromptEvaluationError):
        optimizer.optimize(prompt, session=Session())


def test_optimize_skips_overrides_when_disabled() -> None:
    adapter = _RecordingAdapter(mode="dataclass")
    overrides_store = _RecordingOverridesStore()
    optimizer = _create_optimizer(
        adapter, overrides_store=overrides_store, accepts_overrides=False
    )
    prompt = Prompt(_build_prompt())

    _ = optimizer.optimize(prompt, session=Session())

    assert not overrides_store.calls


def test_optimize_requires_workspace_section() -> None:
    adapter = _RecordingAdapter(mode="dataclass")
    optimizer = _create_optimizer(adapter)
    digest_only_prompt = PromptTemplate[_PromptOutput](
        ns="tests",
        key="opt",
        sections=(WorkspaceDigestSection(session=Session()),),
    )

    with pytest.raises(PromptEvaluationError):
        optimizer.optimize(Prompt(digest_only_prompt), session=Session())


def test_optimize_requires_digest_section() -> None:
    adapter = _RecordingAdapter(mode="dataclass")
    optimizer = _create_optimizer(adapter)
    workspace_only_prompt = PromptTemplate[_PromptOutput](
        ns="tests",
        key="opt",
        sections=(VfsToolsSection(session=Session()),),
    )

    with pytest.raises(PromptEvaluationError):
        optimizer.optimize(Prompt(workspace_only_prompt), session=Session())


def test_optimize_validates_digest_section_type() -> None:
    @dataclass(slots=True)
    class _Params:
        value: str = "v"

    adapter = _RecordingAdapter(mode="dataclass")
    optimizer = _create_optimizer(adapter)
    workspace = VfsToolsSection(session=Session())
    fake_digest = MarkdownSection[_Params](
        title="Digest",
        template="${value}",
        key="workspace-digest",
        default_params=_Params(),
    )
    prompt = PromptTemplate[_PromptOutput](
        ns="tests", key="opt", sections=(workspace, fake_digest)
    )

    with pytest.raises(PromptEvaluationError):
        optimizer.optimize(Prompt(prompt), session=Session())


def test_find_section_path_raises_for_missing_section() -> None:
    adapter = _RecordingAdapter(mode="dataclass")
    optimizer = _create_optimizer(adapter)
    prompt = Prompt(_build_prompt())

    with pytest.raises(PromptEvaluationError):
        optimizer._find_section_path(prompt, "missing")


def test_optimize_uses_isolated_session() -> None:
    adapter = _RecordingAdapter(mode="dataclass")
    optimizer = _create_optimizer(adapter)
    prompt = Prompt(_build_prompt())
    outer_session = Session()

    _ = optimizer.optimize(prompt, session=outer_session)

    assert adapter.sessions
    inner_session = adapter.sessions[0]
    assert isinstance(inner_session, Session)
    assert inner_session is not outer_session


def test_optimize_accepts_provided_session() -> None:
    adapter = _RecordingAdapter(mode="dataclass")
    provided_session = Session()
    optimizer = _create_optimizer(adapter, optimization_session=provided_session)
    prompt = Prompt(_build_prompt())
    outer_session = Session()

    _ = optimizer.optimize(prompt, session=outer_session)

    assert adapter.sessions
    assert adapter.sessions[0] is provided_session


def test_workspace_digest_result_has_correct_scope() -> None:
    adapter = _RecordingAdapter(mode="dataclass")
    optimizer = _create_optimizer(adapter, store_scope=PersistenceScope.SESSION)
    prompt = Prompt(_build_prompt())
    session = Session()

    result = optimizer.optimize(prompt, session=session)

    assert result.scope == PersistenceScope.SESSION
    assert result.section_key == "workspace-digest"


def test_optimizer_config_defaults() -> None:
    config = OptimizerConfig()
    assert config.accepts_overrides is True
