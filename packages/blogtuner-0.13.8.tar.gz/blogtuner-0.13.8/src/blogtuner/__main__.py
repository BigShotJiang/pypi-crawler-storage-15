from blogtuner.cli import app


app()
