"""Based on httpx's default transport: https://github.com/encode/httpx/blob/master/httpx/_transports/default.py."""

import importlib.util
import ssl
import threading
from collections.abc import Callable, Iterable
from random import SystemRandom
from types import TracebackType

import h2
import httpcore
import httpx
from typing_extensions import Self

random = SystemRandom()


class RandomizingTransport(httpx.BaseTransport):
    """Randomizing transport."""

    def __init__(
        self,
        cert: httpx._types.CertTypes | None = None,
        proxy: httpx._types.ProxyTypes | None = None,
        uds: str | None = None,
        local_address: str | None = None,
        retries: int = 0,
        socket_options: Iterable[httpx._transports.default.SOCKET_OPTION] | None = None,
        *,
        verify: ssl.SSLContext | str | bool = True,
        trust_env: bool = True,
        http1: bool = False,
        http2: bool = True,
        limits: httpx._config.Limits = httpx._config.DEFAULT_LIMITS,
    ) -> None:
        proxy = httpx._config.Proxy(url=proxy) if isinstance(proxy, (str, httpx._urls.URL)) else proxy
        ssl_context = httpx._config.create_ssl_context(verify=verify, cert=cert, trust_env=trust_env)

        ssl_context = self._patch_ssl_context(ssl_context)
        self.h2_settings = h2.settings.Settings(
            client=True,
            initial_values={
                h2.settings.SettingCodes.INITIAL_WINDOW_SIZE: random.randint(16384, 65535),
                h2.settings.SettingCodes.HEADER_TABLE_SIZE: random.randint(4000, 5000),
                h2.settings.SettingCodes.MAX_FRAME_SIZE: random.randint(16384, 65535),
                h2.settings.SettingCodes.MAX_CONCURRENT_STREAMS: random.randint(100, 200),
                h2.settings.SettingCodes.MAX_HEADER_LIST_SIZE: random.randint(65500, 66500),
                h2.settings.SettingCodes.ENABLE_CONNECT_PROTOCOL: random.randint(0, 1),
                h2.settings.SettingCodes.ENABLE_PUSH: random.randint(0, 1),
            },
        )

        if proxy is None:
            self._pool = httpcore.ConnectionPool(
                ssl_context=ssl_context,
                max_connections=limits.max_connections,
                max_keepalive_connections=limits.max_keepalive_connections,
                keepalive_expiry=limits.keepalive_expiry,
                http1=http1,
                http2=http2,
                uds=uds,
                local_address=local_address,
                retries=retries,
                socket_options=socket_options,
            )
        elif proxy.url.scheme in ("http", "https"):
            self._pool = httpcore.HTTPProxy(
                proxy_url=httpcore.URL(
                    scheme=proxy.url.raw_scheme,
                    host=proxy.url.raw_host,
                    port=proxy.url.port,
                    target=proxy.url.raw_path,
                ),
                proxy_auth=proxy.raw_auth,
                proxy_headers=proxy.headers.raw,
                ssl_context=ssl_context,
                proxy_ssl_context=proxy.ssl_context,
                max_connections=limits.max_connections,
                max_keepalive_connections=limits.max_keepalive_connections,
                keepalive_expiry=limits.keepalive_expiry,
                http1=http1,
                http2=http2,
                socket_options=socket_options,
            )
        elif proxy.url.scheme in ("socks5", "socks5h"):
            try:
                importlib.util.find_spec("socksio")
            except ImportError:
                msg = """Using SOCKS proxy, but the 'socksio' package is not installed.
                    Make sure to install httpx using `pip install httpx[socks]`."""
                raise ImportError(msg) from None

            self._pool = httpcore.SOCKSProxy(
                proxy_url=httpcore.URL(
                    scheme=proxy.url.raw_scheme,
                    host=proxy.url.raw_host,
                    port=proxy.url.port,
                    target=proxy.url.raw_path,
                ),
                proxy_auth=proxy.raw_auth,
                ssl_context=ssl_context,
                max_connections=limits.max_connections,
                max_keepalive_connections=limits.max_keepalive_connections,
                keepalive_expiry=limits.keepalive_expiry,
                http1=http1,
                http2=http2,
            )
        else:
            msg = (
                f"Proxy protocol must be either 'http', 'https', 'socks5', or 'socks5h', but got {proxy.url.scheme!r}."
            )
            raise ValueError(msg)

    def __enter__(self) -> Self:
        """Open the transport."""
        self._pool.__enter__()
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None = None,
        exc_value: BaseException | None = None,
        traceback: TracebackType | None = None,
    ) -> None:
        """Close the transport."""
        with httpx._transports.default.map_httpcore_exceptions():
            self._pool.__exit__(exc_type, exc_value, traceback)

    def handle_request(
        self,
        request: httpx.Request,
    ) -> httpx.Response:
        """Send a request and return a response."""
        with Patch(self.h2_settings):
            assert isinstance(request.stream, httpx.SyncByteStream)  # noqa: S101

            req = httpcore.Request(
                method=request.method,
                url=httpcore.URL(
                    scheme=request.url.raw_scheme,
                    host=request.url.raw_host,
                    port=request.url.port,
                    target=request.url.raw_path,
                ),
                headers=request.headers.raw,
                content=request.stream,
                extensions=request.extensions,
            )
            with httpx._transports.default.map_httpcore_exceptions():
                resp = self._pool.handle_request(req)

            assert isinstance(resp.stream, Iterable)  # noqa: S101

            return httpx.Response(
                status_code=resp.status,
                headers=resp.headers,
                stream=httpx._transports.default.ResponseStream(resp.stream),
                extensions=resp.extensions,
            )

    def close(self) -> None:
        """Close the transport."""
        self._pool.close()

    def _patch_ssl_context(self, ssl_context: ssl.SSLContext) -> ssl.SSLContext:
        default_ciphers = [  # https://developers.cloudflare.com/ssl/reference/cipher-suites/recommendations/
            "TLS_AES_128_GCM_SHA256", "TLS_AES_256_GCM_SHA384", "TLS_CHACHA20_POLY1305_SHA256",
            # Modern
            "ECDHE-ECDSA-AES128-GCM-SHA256", "ECDHE-ECDSA-CHACHA20-POLY1305", "ECDHE-RSA-AES128-GCM-SHA256", "ECDHE-RSA-CHACHA20-POLY1305", "ECDHE-ECDSA-AES256-GCM-SHA384", "ECDHE-RSA-AES256-GCM-SHA384",  # noqa: E501
            # Compatible
            "ECDHE-ECDSA-AES128-SHA256", "ECDHE-RSA-AES128-SHA256", "ECDHE-ECDSA-AES256-SHA384", "ECDHE-RSA-AES256-SHA384",  # noqa: E501
            # Legacy
            "ECDHE-ECDSA-AES128-SHA", "ECDHE-RSA-AES128-SHA", "AES128-GCM-SHA256", "AES128-SHA256", "AES128-SHA", "ECDHE-RSA-AES256-SHA", "AES256-GCM-SHA384", "AES256-SHA256", "AES256-SHA", "DES-CBC3-SHA",  # noqa: E501
        ]  # fmt: skip
        ciphers = default_ciphers[: random.randint(9, len(default_ciphers))]
        shuffled_ciphers = random.sample(ciphers[9:], len(ciphers) - 9)
        ssl_context.set_ciphers(":".join(ciphers[:9] + shuffled_ciphers))
        commands: list[None | Callable[[ssl.SSLContext], None]] = [
            None,
            lambda context: setattr(context, "maximum_version", ssl.TLSVersion.TLSv1_2),
            lambda context: setattr(context, "minimum_version", ssl.TLSVersion.TLSv1_3),
            lambda context: setattr(context, "options", context.options | ssl.OP_NO_TICKET),
        ]
        if random_command := random.choice(commands):
            random_command(ssl_context)
        return ssl_context


class Patch:
    """Patch the HTTP2Connection._send_connection_init method."""

    _lock = threading.Lock()
    _original_send_connection_init = None

    def __init__(self, h2_settings: h2.settings.Settings) -> None:
        self.h2_settings = h2_settings

    def __enter__(self) -> None:
        def _send_connection_init(self2: httpcore._sync.http2.HTTP2Connection, request: httpcore.Request) -> None:
            self2._h2_state.local_settings = self.h2_settings
            self2._h2_state.initiate_connection()
            self2._h2_state.increment_flow_control_window(2**24)
            self2._write_outgoing_data(request)

        with Patch._lock:
            if Patch._original_send_connection_init is None:
                Patch._original_send_connection_init = httpcore._sync.http2.HTTP2Connection._send_connection_init
            httpcore._sync.http2.HTTP2Connection._send_connection_init = _send_connection_init  # type: ignore[assignment]

    def __exit__(
        self,
        exc_type: type[BaseException] | None = None,
        exc_val: BaseException | None = None,
        exc_tb: TracebackType | None = None,
    ) -> None:
        with Patch._lock:
            if Patch._original_send_connection_init is not None:
                httpcore._sync.http2.HTTP2Connection._send_connection_init = Patch._original_send_connection_init  # type: ignore[method-assign]
