![Python >= 3.10](https://img.shields.io/badge/python->=3.10-red.svg) [![](https://badgen.net/github/release/deedy5/httpx_rt)](https://github.com/deedy5/httpx_rt/releases) [![](https://badge.fury.io/py/httpx_rt.svg)](https://pypi.org/project/httpx_rt) [![pre-commit](https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit)](https://github.com/pre-commit/pre-commit)

# httpx-rt

The `httpx-rt` package provides randomizing transport for the httpx library.

## Installation

```bash
pip install httpx-rt
```

## Usage

```python
import httpx
from httpx_rt import RandomizingTransport

client = httpx.Client(transport=RandomizingTransport())
```

## Disclaimer

This package is for educational purposes only. Use at your own risk.
