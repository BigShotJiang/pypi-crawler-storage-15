from yklib_diff_getter import main

if __name__ == "__main__":
    main()
