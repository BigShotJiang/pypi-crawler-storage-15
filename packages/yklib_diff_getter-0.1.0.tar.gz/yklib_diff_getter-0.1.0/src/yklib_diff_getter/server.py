import sys


def main():
    if len(sys.argv) > 1:
        print("Arguments passed:", sys.argv[1:])

if __name__ == "__main__":
    main()