def main():
    print("Hello from uv-project-name!")


if __name__ == "__main__":
    main()
