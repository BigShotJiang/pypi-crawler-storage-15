"""
Unit tests for nanohub-dashboards library.
"""
