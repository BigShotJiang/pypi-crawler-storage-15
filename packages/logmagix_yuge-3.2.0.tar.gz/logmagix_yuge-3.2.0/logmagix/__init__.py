# logmagix/__init__.py

from .logger import Logger, Loader, MultiLineLoader, Home, LogLevel
from .updater import AutoUpdater

__all__ = ["Logger", "Loader", "MultiLineLoader", "Home", "AutoUpdater", "LogLevel", "__version__"]
