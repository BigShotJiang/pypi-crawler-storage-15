import datetime
import time
import shutil
import sys
import threading
from dataclasses import dataclass
from threading import Condition, Event, RLock, Thread
from itertools import cycle
from typing import List, Optional
from colorama import Fore, Style
import os
import getpass
from .font import *
from pystyle import Write, System, Colors
from enum import Enum
import re

# Repository info tracking at module level
_repository_info_displayed = False

class LogLevel(Enum):
    DEBUG = 1
    INFO = 2
    WARNING = 3
    SUCCESS = 4
    FAILURE = 5
    CRITICAL = 6

class LoaderLineStatus(Enum):
    IDLE = "idle"
    RUNNING = "running"
    SUCCESS = "success"
    FAILURE = "failure"
    WARNING = "warning"

class Logger:
    def __new__(cls, style: int = 1, *args, **kwargs):
        if cls is Logger:
            if style == 2:
                return SimpleLogger(*args, **kwargs)
            return ColorLogger(*args, **kwargs)
        return super().__new__(cls)
        
    def __init__(self, style: int = 1, prefix: str | None = "discord.cyberious.xyz", github_repository: str = None, level: LogLevel = LogLevel.DEBUG, log_file: str | None = None):
        global _repository_info_displayed
        
        self.level = level
        self.repo_url = github_repository
        self.log_file = log_file
        self.prefix = prefix

        if log_file:
            os.makedirs(os.path.dirname(log_file), exist_ok=True)
            self._write_to_log(f"=== Logging started at {datetime.datetime.now()} ===\n")
        
        from .updater import AutoUpdater
        updater = AutoUpdater("logmagix", self)
        updater.check_for_updates()

    def _extract_github_username(self, url: str) -> str | None:
        url = url.replace('https://', '').replace('http://', '').replace('www.', '')
        patterns = [
            r'^github\.com/([^/]+)(?:/.*)?$',  # github.com/username or username/repo
            r'^([^/]+)(?:/.*)?$',              # username or username/repo
            r'^@(.+)$'                         # @username
        ]
        for pattern in patterns:
            if match := re.search(pattern, url):
                return match.group(1).rstrip('/ \t\n\r')
            
        return None

    def _write_to_log(self, message: str) -> None:
        if self.log_file:
            try:
                with open(self.log_file, 'a', encoding='utf-8') as f:
                    clean_message = self._strip_ansi(message)
                    f.write(clean_message + '\n')
            except Exception as e:
                print(f"Error writing to log file: {e}")

    def _strip_ansi(self, text: str) -> str:
        ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
        return ansi_escape.sub('', text)

    def get_time(self) -> str:
        return datetime.datetime.now().strftime("%H:%M:%S")

    def _should_log(self, message_level: LogLevel) -> bool:
        return message_level.value >= self.level.value
        
    def display_repo_info(self):
        global _repository_info_displayed
        
        if self.repo_url and not _repository_info_displayed:
            username = self._extract_github_username(self.repo_url)
            if username:
                self.info(f"Developed by {username} - {self.repo_url}")
            else:
                self.info(f"GitHub Repository: {self.repo_url}")
            _repository_info_displayed = True

class ColorLogger(Logger):
    def __init__(self, *args, **kwargs):
        self.WHITE = "\u001b[37m"
        self.MAGENTA = "\033[38;5;97m"
        self.BRIGHT_MAGENTA = "\033[38;2;157;38;255m"
        self.LIGHT_CORAL = "\033[38;5;210m"
        self.RED = "\033[38;5;196m"
        self.GREEN = "\033[38;5;40m"
        self.YELLOW = "\033[38;5;220m"
        self.BLUE = "\033[38;5;21m"
        self.PINK = "\033[38;5;176m"
        self.CYAN = "\033[96m"
        super().__init__(*args, **kwargs)
        self.prefix = f"{self.PINK}[{self.MAGENTA}{self.prefix}{self.PINK}] " if self.prefix else f"{self.PINK}"
        
        # Display repo info after initializing colors
        self.display_repo_info()

    def message3(self, level: str, message: str, start: int = None, end: int = None) -> str:
        current_time = self.get_time()
        return f"{self.prefix}[{self.BRIGHT_MAGENTA}{current_time}{self.PINK}] {self.PINK}[{self.CYAN}{level}{self.PINK}] -> {self.CYAN}{message}{Fore.RESET}"

    def success(self, message: str, start: int = None, end: int = None, level: str = "Success") -> None:
        if self._should_log(LogLevel.SUCCESS):
            timer = f" {self.BRIGHT_MAGENTA}In{self.WHITE} -> {self.BRIGHT_MAGENTA}{str(end - start)[:5]} Seconds {Fore.RESET}" if start and end else ""
            log_message = self.message3(f"{self.GREEN}{level}", f"{self.GREEN}{message}", start, end) + timer
            print(log_message)
            self._write_to_log(log_message)

    def failure(self, message: str, start: int = None, end: int = None, level: str = "Failure") -> None:
        if self._should_log(LogLevel.FAILURE):
            timer = f" {self.BRIGHT_MAGENTA}In{self.WHITE} -> {self.BRIGHT_MAGENTA}{str(end - start)[:5]} Seconds {Fore.RESET}" if start and end else ""
            log_message = self.message3(f"{self.RED}{level}", f"{self.RED}{message}", start, end) + timer
            print(log_message)
            self._write_to_log(log_message)
    
    def error(self, message: str, start: int = None, end: int = None, level: str = "Error") -> None:
        if self._should_log(LogLevel.FAILURE):
            timer = f" {self.BRIGHT_MAGENTA}In{self.WHITE} -> {self.BRIGHT_MAGENTA}{str(end - start)[:5]} Seconds {Fore.RESET}" if start and end else ""
            log_message = self.message3(f"{self.RED}{level}", f"{self.RED}{message}", start, end) + timer
            print(log_message)
            self._write_to_log(log_message)
    
    def warning(self, message: str, start: int = None, end: int = None, level: str = "Warning") -> None:
        if self._should_log(LogLevel.WARNING):
            timer = f" {self.BRIGHT_MAGENTA}In{self.WHITE} -> {self.BRIGHT_MAGENTA}{str(end - start)[:5]} Seconds {Fore.RESET}" if start and end else ""
            log_message = self.message3(f"{self.YELLOW}{level}", f"{self.YELLOW}{message}", start, end) + timer
            print(log_message)
            self._write_to_log(log_message)

    def message(self, level: str, message: str, start: int = None, end: int = None) -> None:
        timer = f" {self.BRIGHT_MAGENTA}In{self.WHITE} -> {self.BRIGHT_MAGENTA}{str(end - start)[:5]} Seconds {Fore.RESET}" if start and end else ""
        log_message = f"{self.prefix}[{self.BRIGHT_MAGENTA}{self.get_time()}{self.PINK}] [{self.CYAN}{level}{self.PINK}] -> [{self.CYAN}{message}{self.PINK}]{timer}"
        print(log_message)
        self._write_to_log(log_message)
    
    def message2(self, level: str, message: str, start: int = None, end: int = None) -> None: 
        if start and end:
            print(f"{self.prefix}[{self.BRIGHT_MAGENTA}{self.get_time()}{self.PINK}] {self.PINK}[{self.CYAN}{level}{self.PINK}] -> {Fore.RESET} {self.CYAN}{message}{Fore.RESET} [{Fore.CYAN}{end - start}s{Style.RESET_ALL}]", end="\r")
        else:
            print(f"{self.prefix}[{self.BRIGHT_MAGENTA}{self.get_time()}{self.PINK}] {self.PINK}[{Fore.BLUE}{level}{self.PINK}] -> {Fore.RESET} {self.CYAN}{message}{Fore.RESET}", end="\r")

    def question(self, message: str, start: int = None, end: int = None) -> None:
        question_message = f"{self.prefix}[{self.BRIGHT_MAGENTA}{self.get_time()}{self.PINK}]{Fore.RESET} {self.PINK}[{Fore.BLUE}?{self.PINK}] -> {Fore.RESET} {self.CYAN}{message}{Fore.RESET}"
        print(question_message, end='')
        i = input()
        self._write_to_log(f"{question_message}")
        self._write_to_log(f"User Answer: {i}")
        
        return i

    def critical(self, message: str, start: int = None, end: int = None, level: str = "CRITICAL", exit_code: int = 1) -> None:
        if self._should_log(LogLevel.CRITICAL):
            timer = f" {self.BRIGHT_MAGENTA}In{self.WHITE} -> {self.BRIGHT_MAGENTA}{str(end - start)[:5]} Seconds {Fore.RESET}" if start and end else ""
            log_message = f"{self.prefix}[{self.BRIGHT_MAGENTA}{self.get_time()}{self.PINK}]{Fore.RESET} {self.PINK}[{self.RED}{level}{self.PINK}] -> {self.LIGHT_CORAL}{message}{Fore.RESET}" + timer
            print(log_message)
            input()
            self._write_to_log(log_message)
            self._write_to_log(f"=== Program terminated with exit code {exit_code} at {datetime.datetime.now()} ===")
            exit(exit_code)

    def info(self, message: str, start: int = None, end: int = None) -> None:
        if self._should_log(LogLevel.INFO):
            timer = f" {self.BRIGHT_MAGENTA}In{self.WHITE} -> {self.BRIGHT_MAGENTA}{str(end - start)[:5]} Seconds {Fore.RESET}" if start and end else ""
            log_message = f"{self.prefix}[{self.BRIGHT_MAGENTA}{self.get_time()}{self.PINK}]{Fore.RESET} {self.PINK}[{Fore.BLUE}!{self.PINK}] -> {Fore.RESET} {self.CYAN}{message}{Fore.RESET}" + timer
            print(log_message)
            self._write_to_log(log_message)
    
    def debug(self, message: str, start: int = None, end: int = None) -> None:
        if self._should_log(LogLevel.DEBUG):
            timer = f" {self.BRIGHT_MAGENTA}In{self.WHITE} -> {self.BRIGHT_MAGENTA}{str(end - start)[:5]} Seconds {Fore.RESET}" if start and end else ""
            log_message = f"{self.prefix}[{self.BRIGHT_MAGENTA}{self.get_time()}{self.PINK}]{Fore.RESET} {self.PINK}[{Fore.YELLOW}DEBUG{self.PINK}] -> {Fore.RESET} {self.GREEN}{message}{Fore.RESET}" + timer
            print(log_message)
            self._write_to_log(log_message)

class SimpleLogger(Logger):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.prefix = f"{Fore.BLACK}{self.get_time()} » {Fore.RESET}"
        
        # Display repo info after initializing prefix
        self.display_repo_info()

    def success(self, message: str, start: int = None, end: int = None, level: str = "SUCCESS") -> None:
        if self._should_log(LogLevel.SUCCESS):
            timer = f" (In {str(end - start)[:5]}s)" if start and end else ""
            log_message = f"{self.prefix}{Fore.LIGHTGREEN_EX}{level} {Fore.BLACK}➔ {Fore.RESET} {message}{timer}"
            print(log_message)
            self._write_to_log(log_message)

    def failure(self, message: str, start: int = None, end: int = None, level: str = "FAILURE") -> None:
        if self._should_log(LogLevel.FAILURE):
            timer = f" (In {str(end - start)[:5]}s)" if start and end else ""
            log_message = f"{self.prefix}{Fore.LIGHTRED_EX}{level} {Fore.BLACK}  ➔ {Fore.RESET} {message}{timer}"
            print(log_message)
            self._write_to_log(log_message)

    def error(self, message: str, start: int = None, end: int = None, level: str = "ERROR") -> None:
        if self._should_log(LogLevel.FAILURE):
            timer = f" (In {str(end - start)[:5]}s)" if start and end else ""
            log_message = f"{self.prefix}{Fore.LIGHTRED_EX}{level} {Fore.BLACK}  ➔ {Fore.RESET} {message}{timer}"
            print(log_message)
            self._write_to_log(log_message)

    def warning(self, message: str, start: int = None, end: int = None, level: str = "WARNING") -> None:
        if self._should_log(LogLevel.WARNING):
            timer = f" (In {str(end - start)[:5]}s)" if start and end else ""
            log_message = f"{self.prefix}{Fore.LIGHTYELLOW_EX}{level} {Fore.BLACK}➔ {Fore.RESET} {message}{timer}"
            print(log_message)
            self._write_to_log(log_message)
    
    def message(self, message: str, start: int = None, end: int = None, level: str = "MESSAGE") -> None:
        if self._should_log(LogLevel.WARNING):
            timer = f" (In {str(end - start)[:5]}s)" if start and end else ""
            log_message = f"{self.prefix}{Fore.LIGHTMAGENTA_EX}{level} {Fore.BLACK}➔ {Fore.RESET} {message}{timer}"
            print(log_message)
            self._write_to_log(log_message)

    def info(self, message: str, start: int = None, end: int = None, level: str = "INFO") -> None:
        if self._should_log(LogLevel.INFO):
            timer = f" (In {str(end - start)[:5]}s)" if start and end else ""
            log_message = f"{self.prefix}{Fore.LIGHTBLUE_EX}{level} {Fore.BLACK}   ➔ {Fore.RESET} {message}{timer}"
            print(log_message)
            self._write_to_log(log_message)

    def debug(self, message: str, start: int = None, end: int = None) -> None:
        if self._should_log(LogLevel.DEBUG):
            timer = f" (In {str(end - start)[:5]}s)" if start and end else ""
            log_message = f"{self.prefix}{Fore.GREEN}[{Fore.YELLOW}DEBUG{Fore.GREEN}] {Fore.BLACK}➔ {Fore.RESET} {message}{timer}"
            print(log_message)
            self._write_to_log(log_message)

    def question(self, message: str, level: str = "QUESTION") -> None:
        question_message = f"{self.prefix}{Fore.LIGHTCYAN_EX}{level} {Fore.BLACK}➔ {Fore.RESET} {message}"
        print(question_message, end='')
        i = input()
        self._write_to_log(f"{question_message}")
        self._write_to_log(f"User Answer: {i}")
        return i

@dataclass
class _SlotState:
    handle_id: Optional[int] = None
    label: str = ""
    message: str = ""
    status: LoaderLineStatus = LoaderLineStatus.IDLE
    active: bool = False
    started_at: Optional[datetime.datetime] = None
    revision: int = 0
    creation_index: Optional[int] = None

class _SequentialHandle:
    def __init__(self, logger: Logger, label: str):
        self._logger = logger
        self._label = self._sanitize_message(label)
        self._closed = False

    def update(self, message: str) -> None:
        if self._closed:
            return
        sanitized = self._sanitize_message(message)
        self._logger.info(f"{self._label}: {sanitized}")

    def done(self, message: Optional[str] = None) -> None:
        self._emit_completion(message or "Completed", "success")

    def fail(self, message: Optional[str] = None) -> None:
        self._emit_completion(message or "Failed", "failure")

    def warn(self, message: Optional[str] = None) -> None:
        self._emit_completion(message or "Warning", "warning")

    def _emit_completion(self, message: str, mode: str) -> None:
        if self._closed:
            return
        sanitized = self._sanitize_message(message)
        if mode == "success":
            self._logger.success(f"{self._label}: {sanitized}")
        elif mode == "failure":
            self._logger.failure(f"{self._label}: {sanitized}")
        else:
            self._logger.warning(f"{self._label}: {sanitized}")
        self._closed = True

    @staticmethod
    def _sanitize_message(message: str) -> str:
        """清理消息中的特殊字符"""
        if not message:
            return ""
        import re
        message = message.replace('\n', ' ').replace('\r', ' ').replace('\t', ' ')
        message = ''.join(char if ord(char) >= 32 or char == ' ' else ' ' for char in message)
        message = re.sub(r'\s+', ' ', message)
        return message.strip()

class MultiLineHandle:
    def __init__(self, loader: "MultiLineLoader", slot_index: int, handle_id: int, label: str):
        self._loader = loader
        self._slot_index = slot_index
        self._handle_id = handle_id
        self._label = label
        self._closed = False

    @property
    def label(self) -> str:
        return self._label

    def update(self, message: str) -> None:
        if self._closed:
            return
        self._loader._update_slot(self._slot_index, self._handle_id, message)

    def done(self, message: Optional[str] = None) -> None:
        self._finalize(LoaderLineStatus.SUCCESS, message or "Completed")

    def fail(self, message: Optional[str] = None) -> None:
        self._finalize(LoaderLineStatus.FAILURE, message or "Failed")

    def warn(self, message: Optional[str] = None) -> None:
        self._finalize(LoaderLineStatus.WARNING, message or "Warning")

    def _finalize(self, status: LoaderLineStatus, message: str) -> None:
        if self._closed:
            return
        self._loader._finalize_slot(self._slot_index, self._handle_id, status, message)
        self._closed = True

class MultiLineLoader:
    SPINNER_FRAMES = ("⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧")
    STATUS_ICONS = {
        LoaderLineStatus.SUCCESS: "✓",
        LoaderLineStatus.FAILURE: "✗",
        LoaderLineStatus.WARNING: "⚠",
    }
    STATUS_COLORS = {
        LoaderLineStatus.RUNNING: "GREEN",
        LoaderLineStatus.SUCCESS: "GREEN",
        LoaderLineStatus.FAILURE: "RED",
        LoaderLineStatus.WARNING: "YELLOW",
    }

    def __init__(
        self,
        slots: int = 5,
        prefix: str = "discord.cyberious.xyz",
        refresh_rate: float = 0.1,
        auto_collapse: bool = False,
        auto_expand: bool = True,
        max_height_ratio: float = 0.8,
        logger: Optional[Logger] = None,
        fixed_slots: bool = False,
    ):
        self.prefix = prefix
        self.slots_requested = max(1, slots)
        self.refresh_rate = max(0.05, refresh_rate)
        self.auto_collapse = auto_collapse
        self.auto_expand = auto_expand
        self.max_height_ratio = max(0.1, min(max_height_ratio, 0.95))
        self.logger = logger if logger is not None else Logger()
        self.fixed_slots = fixed_slots
        self._state_lock = RLock()
        self._condition = Condition(self._state_lock)
        self._render_event = Event()
        self._stop_event = Event()
        self._slots: List[_SlotState] = []
        self._history_lines: List[str] = []
        self._render_thread: Optional[Thread] = None
        self._handle_counter = 0
        self._creation_counter = 0
        self._running = False
        self._supports_dynamic = self._stdout_is_tty()
        self._max_visible_lines = 0
        self._cursor_hidden = False
        self._rendered_lines = 0
        self._spinner_index = 0
        self._collapse_requested = False
        self._collapse_timestamp: Optional[float] = None
        self._tty_warning_emitted = False
        self._fallback_last_snapshot = []
        self._colors = {}
        self._prefix_block = ""
        self._update_terminal_bounds()

    def __enter__(self):
        return self.start()

    def __exit__(self, exc_type, exc_value, traceback):
        self.stop()

    def start(self):
        if self._running:
            return self
        self._running = True

        self._colors = {
            "PINK": getattr(self.logger, "PINK", Fore.MAGENTA),
            "MAGENTA": getattr(self.logger, "MAGENTA", Fore.MAGENTA),
            "BRIGHT_MAGENTA": getattr(self.logger, "BRIGHT_MAGENTA", Fore.MAGENTA),
            "CYAN": getattr(self.logger, "CYAN", Fore.CYAN),
            "GREEN": getattr(self.logger, "GREEN", Fore.GREEN),
            "YELLOW": getattr(self.logger, "YELLOW", Fore.YELLOW),
            "RED": getattr(self.logger, "RED", Fore.RED),
            "RESET": Fore.RESET,
        }
        self._prefix_block = f"{self._colors['PINK']}[{self._colors['MAGENTA']}{self.prefix}{self._colors['PINK']}]"

        if not self._supports_dynamic:
            if not self._tty_warning_emitted:
                self.logger.warning("MultiLineLoader fallback: stdout is not a TTY, using sequential logging.")
                self._tty_warning_emitted = True
            return self

        with self._state_lock:
            if not self._slots:
                self._reset_slots_locked()

        self._stop_event.clear()
        self._render_event.clear()
        self._render_thread = Thread(target=self._render_loop, daemon=True)
        self._render_thread.start()
        return self

    def stop(self, interrupt_message: Optional[str] = None):
        if not self._running:
            return
        self._running = False

        with self._state_lock:
            for index, slot in enumerate(self._slots):
                if slot.active and slot.handle_id is not None:
                    fallback_message = interrupt_message or slot.message or "Stopped"
                    self._finalize_slot(index, slot.handle_id, LoaderLineStatus.WARNING, fallback_message)

        self._stop_event.set()
        self._render_event.set()

        if self._render_thread:
            self._render_thread.join()

        if self._supports_dynamic:
            if self.auto_collapse or not self._history_lines:
                self._collapse_requested = True
                self._render_frame(force=True)

        self._show_cursor()

    def reserve(self, label: Optional[str] = None, wait: bool = True, timeout: Optional[float] = None):
        if not self._running:
            raise RuntimeError("MultiLineLoader must be started before reserving slots.")

        resolved_label = label or getattr(threading.current_thread(), "name", None) or f"Task-{self._handle_counter + 1}"

        if not self._supports_dynamic:
            return _SequentialHandle(self.logger, resolved_label)

        slot_index, handle_id = self._acquire_slot(resolved_label, wait=wait, timeout=timeout)
        return MultiLineHandle(self, slot_index, handle_id, resolved_label)

    def _acquire_slot(self, label: str, wait: bool, timeout: Optional[float]) -> tuple:
        deadline = None if timeout is None else time.time() + timeout

        with self._condition:
            while True:
                slot_index = self._first_available_slot()
                if slot_index is None:
                    if self.auto_expand and self._maybe_expand_locked():
                        continue

                    if not wait:
                        raise RuntimeError("No slot available for MultiLineLoader.")

                    if deadline is not None:
                        remaining = deadline - time.time()
                        if remaining <= 0:
                            raise TimeoutError("Timed out waiting for a free MultiLineLoader slot.")
                        self._condition.wait(remaining)
                    else:
                        self._condition.wait()
                    continue

                slot = self._slots[slot_index]
                if slot.active:
                    if not wait:
                        raise RuntimeError("No slot available for MultiLineLoader.")

                    if deadline is not None:
                        remaining = deadline - time.time()
                        if remaining <= 0:
                            raise TimeoutError("Timed out waiting for a free MultiLineLoader slot.")
                        self._condition.wait(remaining)
                    else:
                        self._condition.wait()
                    continue

                self._handle_counter += 1
                handle_id = self._handle_counter
                slot.active = True
                if self.fixed_slots and slot.creation_index is None:
                    self._creation_counter += 1
                    slot.creation_index = self._creation_counter
                slot.handle_id = handle_id
                slot.label = self._sanitize_message(label)
                slot.message = ""
                slot.status = LoaderLineStatus.RUNNING
                slot.started_at = datetime.datetime.now()

                # Cancel pending collapse since we have active work again
                self._collapse_timestamp = None
                self._collapse_requested = False

                self._render_event.set()
                return slot_index, handle_id

    def _maybe_expand_locked(self) -> bool:
        self._update_terminal_bounds()
        if len(self._slots) < self._max_visible_lines:
            self._slots.append(_SlotState())
            return True
        return False

    def _reset_slots_locked(self) -> bool:
        # Only reset if no slots are active
        if not any(slot.active for slot in self._slots):
            self._slots = [_SlotState() for _ in range(self.slots_requested)]
            self._creation_counter = 0
            return True
        return False

    def _first_available_slot(self) -> Optional[int]:
        for index, slot in enumerate(self._slots):
            if self.fixed_slots:
                # Fixed slots mode: only use slots that have never been assigned
                if slot.creation_index is None and not slot.active:
                    return index
            else:
                # Normal mode: reuse slots that are not currently active
                if not slot.active:
                    return index
        return None

    def _update_slot(self, slot_index: int, handle_id: int, message: str) -> None:
        with self._state_lock:
            if not self._slot_matches(slot_index, handle_id):
                return
            slot = self._slots[slot_index]
            slot.message = self._sanitize_message(message)
            slot.status = LoaderLineStatus.RUNNING
            slot.revision += 1
        self._render_event.set()

    def _finalize_slot(self, slot_index: int, handle_id: int, status: LoaderLineStatus, message: str) -> None:
        with self._condition:
            if not self._slot_matches(slot_index, handle_id):
                return

            slot = self._slots[slot_index]
            sanitized_message = self._sanitize_message(message)
            final_line = self._format_line(
                status=status,
                icon=self.STATUS_ICONS.get(status),
                label=slot.label,
                message=sanitized_message,
            )
            self._history_lines.append(final_line)
            self._trim_history_locked()

            slot.active = False
            slot.handle_id = None
            if self.fixed_slots:
                # Fixed slots mode: keep status and message for display
                slot.status = status
                slot.message = sanitized_message
            else:
                # Normal mode: clear slot for reuse
                slot.message = ""
                slot.status = LoaderLineStatus.IDLE
            slot.started_at = None

            self._condition.notify_all()

            all_inactive = not any(s.active for s in self._slots)

            if self.auto_collapse and all_inactive:
                self._collapse_timestamp = time.time() + 0.5

        self._render_event.set()

    def _slot_matches(self, slot_index: int, handle_id: int) -> bool:
        return 0 <= slot_index < len(self._slots) and self._slots[slot_index].handle_id == handle_id

    def _trim_history_locked(self) -> None:
        self._update_terminal_bounds()
        while len(self._history_lines) > self._max_visible_lines:
            dropped = self._history_lines.pop(0)
            self.logger.info(self._strip_ansi_if_needed(dropped))

    def _strip_ansi_if_needed(self, text: str) -> str:
        if hasattr(self.logger, "_strip_ansi"):
            return self.logger._strip_ansi(text)
        return text

    def _sanitize_message(self, message: str) -> str:
        """
        清理消息中的特殊字符,防止破坏多行显示
        - 移除换行符 (\n, \r)
        - 移除制表符 (\t)
        - 移除其他控制字符
        - 将多个空格压缩为单个空格
        """
        if not message:
            return ""

        # 替换换行符和回车符为空格
        message = message.replace('\n', ' ').replace('\r', ' ')

        # 替换制表符为空格
        message = message.replace('\t', ' ')

        # 移除其他控制字符 (ASCII 0-31,除了空格)
        message = ''.join(char if ord(char) >= 32 or char == ' ' else ' ' for char in message)

        # 将多个连续空格压缩为单个空格
        import re
        message = re.sub(r'\s+', ' ', message)

        # 去除首尾空格
        return message.strip()

    def _render_loop(self) -> None:
        try:
            while not self._stop_event.is_set():
                self._render_frame()
                triggered = self._render_event.wait(self.refresh_rate)
                if triggered:
                    self._render_event.clear()
            self._render_frame(force=True)
        finally:
            self._show_cursor()

    def _render_frame(self, force: bool = False) -> None:
        with self._state_lock:
            self._update_terminal_bounds()

            if self._collapse_timestamp is not None and time.time() >= self._collapse_timestamp:
                self._history_lines.clear()
                self._collapse_requested = True
                self._collapse_timestamp = None

            if self._collapse_requested:
                self._history_lines.clear()
                self._collapse_requested = False
                if self._reset_slots_locked():
                    combined_lines: List[str] = []
                else:
                    # Cannot reset yet, keep current state
                    self._collapse_requested = True
                    combined_lines = []
            else:
                if self.fixed_slots:
                    # Fixed slots mode: show all assigned slots in order
                    combined_lines = []
                    for slot in self._slots:
                        if slot.creation_index is not None:
                            combined_lines.append(
                                self._format_line(
                                    LoaderLineStatus.RUNNING if slot.active else slot.status,
                                    None if slot.active else self.STATUS_ICONS.get(slot.status),
                                    slot.label,
                                    slot.message,
                                )
                            )
                else:
                    # Normal mode: show history + active slots
                    running_lines = [
                        self._format_line(LoaderLineStatus.RUNNING, None, slot.label, slot.message)
                        for slot in self._slots if slot.active
                    ]
                    combined_lines = self._history_lines + running_lines

                if len(combined_lines) > self._max_visible_lines:
                    combined_lines = combined_lines[-self._max_visible_lines:]

            supports_dynamic = self._supports_dynamic

        if not supports_dynamic:
            # In fallback mode, print any lines that have changed since last snapshot
            if combined_lines != self._fallback_last_snapshot:
                # Print only the new/changed lines
                for i, line in enumerate(combined_lines):
                    if i >= len(self._fallback_last_snapshot) or line != self._fallback_last_snapshot[i]:
                        print(self._strip_ansi_if_needed(line))
                self._fallback_last_snapshot = combined_lines.copy()
            return

        if not combined_lines:
            if self._rendered_lines:
                self._clear_rendered_block()
            self._rendered_lines = 0
            if force:
                sys.stdout.flush()
            return

        self._hide_cursor()
        prev_lines = self._rendered_lines
        frame_lines = combined_lines
        max_lines = max(prev_lines, len(frame_lines))

        output = []
        if prev_lines:
            output.append(f"\x1b[{prev_lines}F")

        for index in range(max_lines):
            line = frame_lines[index] if index < len(frame_lines) else ""
            output.append("\r\x1b[2K")
            output.append(line)
            if index < max_lines - 1:
                output.append("\n")

        output.append("\n")
        sys.stdout.write("".join(output))
        sys.stdout.flush()

        self._rendered_lines = len(frame_lines)
        self._spinner_index = (self._spinner_index + 1) % len(self.SPINNER_FRAMES)

    def _hide_cursor(self) -> None:
        if not self._cursor_hidden:
            sys.stdout.write("\x1b[?25l")
            sys.stdout.flush()
            self._cursor_hidden = True

    def _show_cursor(self) -> None:
        if self._cursor_hidden:
            sys.stdout.write("\x1b[?25h")
            sys.stdout.flush()
            self._cursor_hidden = False

    def _clear_rendered_block(self) -> None:
        if not self._rendered_lines:
            return

        sys.stdout.write(f"\x1b[{self._rendered_lines}F")
        for index in range(self._rendered_lines):
            sys.stdout.write("\r\x1b[2K")
            if index < self._rendered_lines - 1:
                sys.stdout.write("\n")
        sys.stdout.write("\r\x1b[2K")
        sys.stdout.flush()

    def _format_line(self, status: LoaderLineStatus, icon: Optional[str], label: str, message: str) -> str:
        timestamp = datetime.datetime.now().strftime("%H:%M:%S")
        color_attr = self.STATUS_COLORS.get(status, "CYAN")
        color = self._colors.get(color_attr, Fore.WHITE)
        symbol = icon or self.SPINNER_FRAMES[self._spinner_index]

        cyan = self._colors["CYAN"]
        pink = self._colors["PINK"]
        bright_magenta = self._colors["BRIGHT_MAGENTA"]
        reset = self._colors["RESET"]

        return (
            f"{self._prefix_block} [{bright_magenta}{timestamp}{pink}] "
            f"[{color}{symbol}{pink}] [{cyan}{label}{pink}] {color}{message}{reset}"
        )

    def _update_terminal_bounds(self) -> None:
        size = shutil.get_terminal_size(fallback=(80, 24))
        max_lines = max(1, int(size.lines * self.max_height_ratio))

        if max_lines <= 2 and self._supports_dynamic:
            self._supports_dynamic = False
            self.logger.warning("MultiLineLoader fallback: terminal height too small for dynamic rendering.")

        self._max_visible_lines = max(self.slots_requested, max_lines)

    def _stdout_is_tty(self) -> bool:
        stream = getattr(sys, "stdout", None)
        return bool(stream and hasattr(stream, "isatty") and stream.isatty())

log = Logger()

class Loader:
    def __init__(self, prefix: str = "discord.cyberious.xyz", desc="Loading...", end="\r", timeout=0.1):
        self.desc = desc
        self.end = end
        self.prefix = prefix
        self.timeout = timeout
        self.time = None  # Remove time initialization
        self.start_time = datetime.datetime.now()

        self._thread = Thread(target=self._animate, daemon=True)
        self.steps = ["⢿", "⣻", "⣽", "⣾", "⣷", "⣯", "⣟", "⡿"]
        self.done = False

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.stop()

    def start(self):
        self._thread.start()
        return self

    def _animate(self):
        for c in cycle(self.steps):
            if self.done:
                break
            current_time = datetime.datetime.now().strftime("%H:%M:%S")  # Get current time each iteration
            loader_message = f"\r{log.PINK}[{log.MAGENTA}{self.prefix}{log.PINK}] [{log.BRIGHT_MAGENTA}{current_time}{log.PINK}] [{log.GREEN}{self.desc}{log.PINK}]{Fore.RESET} {c}"
            print(loader_message, flush=True, end="")
            time.sleep(self.timeout)

    def stop(self):
        self.done = True
        if (self.end != "\r"):
            current_time = datetime.datetime.now().strftime("%H:%M:%S")  # Get current time for stop message
            end_message = f"\n{log.PINK}[{log.MAGENTA}{self.prefix}{log.PINK}] [{log.BRIGHT_MAGENTA}{current_time}{log.PINK}] {log.GREEN} {self.end} {Fore.RESET}"
            print(end_message, flush=True)
        else:
            print(self.end, flush=True)

class Home:
    def __init__(self, text, align="left", adinfo1=None, adinfo2=None, credits=None, clear=True):
        self.text = text
        self.align = align
        self.adinfo1 = adinfo1
        self.adinfo2 = adinfo2
        self.credits = credits
        self.clear = clear
        self.username = getpass.getuser()

    def _get_char_art(self):
        char_arts = []
        max_height = 8

        for char in self.text:
            char_art = ascii_art.get(char, [" " * 8] * 8)

            if char.islower() and len(char_art) == 6:
                char_art = [" " * 8] * 1 + char_art

            char_arts.append(char_art)

        return char_arts, max_height

    def _align_text(self, lines, terminal_width, alignment, block_width):
        aligned_result = []
        for line in lines:
            stripped_line = line.rstrip()
            if alignment == "center":
                padding = max(0, (terminal_width - block_width) // 2)
                aligned_line = " " * padding + stripped_line
            elif alignment == "right":
                padding = max(0, terminal_width - block_width)
                aligned_line = " " * padding + stripped_line
            else:
                aligned_line = stripped_line
            aligned_result.append(aligned_line)
        return aligned_result

    def _clear(self):
        os.system('cls' if os.name == 'nt' else 'clear')

    def display(self):
        char_arts, max_height = self._get_char_art()
        result = [""] * max_height

        for i in range(max_height):
            line = "".join([char_art[i] if i < len(char_art) else " " * 8 for char_art in char_arts])
            result[i] = line

        max_line_width = max(len(line) for line in result)

        try:
            terminal_width = os.get_terminal_size().columns
        except OSError:
            terminal_width = 80
        
        aligned_result = self._align_text(result, terminal_width, self.align, max_line_width)
        if self.clear:
            self._clear()

        for line in aligned_result:
            Write.Print(line + "\n", Colors.red_to_blue, interval=0.000)

        self._display_adinfo(aligned_result, terminal_width)
        self._display_welcome(terminal_width, max_line_width)

    def _display_adinfo(self, aligned_result, terminal_width):
        if not (self.adinfo1 or self.adinfo2):
            return

        ascii_art_width = max(len(line.rstrip()) for line in aligned_result)
        adinfo_text = self._construct_adinfo_text(ascii_art_width)
        adinfo_block_width = len(adinfo_text)
        aligned_adinfo = self._align_text([adinfo_text], terminal_width, self.align, adinfo_block_width)

        for line in aligned_adinfo:
            Write.Print(line + "\n", Colors.red_to_blue, interval=0.000)

    def _construct_adinfo_text(self, ascii_art_width):
        if self.adinfo1 and self.adinfo2:
            total_adinfo_length = len(self.adinfo1) + len(self.adinfo2)
            remaining_space = ascii_art_width - total_adinfo_length
            if (remaining_space > 0):
                padding_between = '  ' * (remaining_space // 3)
                return self.adinfo1 + padding_between + self.adinfo2
            else:
                return self.adinfo1 + '   ' + self.adinfo2
        return self.adinfo1 or self.adinfo2 or ''

    def _display_welcome(self, terminal_width, block_width):
        welcome_message = f"Welcome {self.username}"
        if self.credits:
            welcome_message += f" | {self.credits}"

        welcome_message_with_tildes = f"    {welcome_message}    "
        tilde_line = "~" * len(welcome_message_with_tildes)

        welcome_padding = max(0, (terminal_width - len(welcome_message_with_tildes)) // 2)
        tilde_padding = max(0, (terminal_width - len(tilde_line)) // 2)

        welcome_line = " " * welcome_padding + welcome_message_with_tildes
        tilde_line_aligned = " " * tilde_padding + tilde_line

        Write.Print(f"{welcome_line}\n", Colors.red_to_blue, interval=0.000)
        Write.Print(f"{tilde_line_aligned}\n", Colors.red_to_blue, interval=0.000)

        equals_line = "═" * terminal_width
        Write.Print(f"{equals_line}\n", Colors.red_to_blue, interval=0.000)
