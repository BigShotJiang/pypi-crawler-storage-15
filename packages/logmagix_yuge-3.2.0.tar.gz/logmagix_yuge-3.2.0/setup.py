from setuptools import setup, find_packages
import os

# Read version from version.py without importing the package
version = {}
version_file = os.path.join(os.path.dirname(__file__), 'logmagix', 'version.py')
with open(version_file) as f:
    exec(f.read(), version)

setup(
    name="logmagix-yuge",
    version=version['__version__'],
    packages=find_packages(),
    install_requires=["colorama", "pystyle", "packaging"],
    author="Yuge",
    author_email="bwuuuuu@gmail.com",
    description="Beautiful & Simple Python Logger with Multi-threaded Multi-line Dynamic Logging Support",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/yuge/logmagix-yuge",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: System :: Logging",
    ],
    python_requires=">=3.8",
    keywords="logger logging colorful multi-threaded dynamic progress",
)
