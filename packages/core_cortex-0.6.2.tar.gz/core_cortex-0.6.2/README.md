# CORE.Cortex

## Summary
This is a Python API for CORE.Cortex, a machine learning framework developed by CORE Studio at Thornton Tomasetti. This package will let you interface with our tracking servers, as well as perform model-related operations, such as promoting a run to production or deploying a model as a REST endpoint.