"""Simple, single building project with no custom configuration."""
