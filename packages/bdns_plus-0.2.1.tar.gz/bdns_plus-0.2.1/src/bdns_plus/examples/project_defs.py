from bdns_plus import GenExampleProject

single_volume_4_levels = GenExampleProject(
    name="Single Volume 4 Levels",
    level_min=-1,
    level_max=3,
    no_volumes=1,
)
