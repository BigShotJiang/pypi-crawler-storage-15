## [2.0.20] - 2025-12-03

### Added
- Add get_columns_data by @cmancone in [#39](https://github.com/clearskies-py/clearskies/pull/39)
- Add get_columns_data

### Fixed
- Key error on api mapping
- Lastrowid and autocommit for sqlite by @cmancone in [#38](https://github.com/clearskies-py/clearskies/pull/38)
- Lastrowid and autocommit for sqlite
- Column_equals_with_placeholder missing the escape after column name

