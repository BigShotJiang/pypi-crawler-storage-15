from .parameter import Parameter


class URLPath(Parameter):
    location = "url_path"
    in_body = False
