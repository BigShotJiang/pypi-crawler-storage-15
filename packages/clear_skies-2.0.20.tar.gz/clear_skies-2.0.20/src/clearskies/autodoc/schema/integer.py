from .schema import Schema


class Integer(Schema):
    _type = "integer"
    _format = "int32"
