#
# BSD 3-Clause License

"""CodeIOs."""

__version__ = "0.0.1"
