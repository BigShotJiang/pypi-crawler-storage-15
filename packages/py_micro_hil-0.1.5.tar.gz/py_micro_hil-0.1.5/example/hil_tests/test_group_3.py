# group3_tests.py
from py_micro_hil.assertions import *
from py_micro_hil.framework_API import *

def setup_group():
    TEST_INFO_MESSAGE("Setting up Group3")

def teardown_group():
    TEST_INFO_MESSAGE("Tearing down Group3")

def test_sample_test_1():
    TEST_ASSERT_EQUAL(0,0)

def test_sample_test_2():
    TEST_ASSERT_EQUAL(0,0)

def test_sample_test_3():
    TEST_ASSERT_EQUAL(0,0)
