"""EvalView - Testing framework for multi-step AI agents."""

__version__ = "0.1.0"
