VERSION = "2.8.4"

from .p4cmd import P4Client
from .p4file import P4File
from .p4errors import *