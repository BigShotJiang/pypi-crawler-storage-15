"""Echo JS fetcher module."""

from .fetcher import EchoJSFetcher

__all__ = ["EchoJSFetcher"]
