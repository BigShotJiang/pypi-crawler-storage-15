"""npm packages fetcher."""

from .fetcher import NPMFetcher

__all__ = ["NPMFetcher"]
