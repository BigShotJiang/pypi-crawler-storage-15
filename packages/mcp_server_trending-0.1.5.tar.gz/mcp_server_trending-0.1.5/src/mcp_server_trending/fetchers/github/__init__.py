"""GitHub fetchers package."""

from .fetcher import GitHubTrendingFetcher

__all__ = ["GitHubTrendingFetcher"]
