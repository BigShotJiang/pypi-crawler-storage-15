"""OpenReview fetcher module."""

from .fetcher import OpenReviewFetcher

__all__ = ["OpenReviewFetcher"]
