"""dev.to fetcher package."""

from .fetcher import DevToFetcher

__all__ = ["DevToFetcher"]
