"""Replicate fetcher module."""

from .fetcher import ReplicateFetcher

__all__ = ["ReplicateFetcher"]

