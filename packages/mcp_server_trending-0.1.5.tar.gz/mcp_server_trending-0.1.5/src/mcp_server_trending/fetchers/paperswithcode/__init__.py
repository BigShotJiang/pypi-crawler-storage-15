"""Papers with Code fetcher module."""

from .fetcher import PapersWithCodeFetcher

__all__ = ["PapersWithCodeFetcher"]

