"""Lobsters fetcher module."""

from .fetcher import LobstersFetcher

__all__ = ["LobstersFetcher"]
