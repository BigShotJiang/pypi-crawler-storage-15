"""Aggregation analysis fetcher."""

from .fetcher import AggregationFetcher

__all__ = ["AggregationFetcher"]
