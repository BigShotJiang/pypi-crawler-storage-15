"""ModelScope (魔塔社区) fetcher package."""

from .fetcher import ModelScopeFetcher

__all__ = ["ModelScopeFetcher"]
