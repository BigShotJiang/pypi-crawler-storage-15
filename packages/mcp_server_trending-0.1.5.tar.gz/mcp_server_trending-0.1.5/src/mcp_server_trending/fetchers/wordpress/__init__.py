"""WordPress plugins fetcher."""

from .fetcher import WordPressFetcher

__all__ = ["WordPressFetcher"]
