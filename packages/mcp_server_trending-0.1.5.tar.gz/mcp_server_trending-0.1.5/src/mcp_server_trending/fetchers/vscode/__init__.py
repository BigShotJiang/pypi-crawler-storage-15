"""VS Code Marketplace fetcher."""

from .fetcher import VSCodeMarketplaceFetcher

__all__ = ["VSCodeMarketplaceFetcher"]
