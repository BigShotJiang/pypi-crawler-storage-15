"""Product Hunt fetchers package."""

from .fetcher import ProductHuntFetcher

__all__ = ["ProductHuntFetcher"]
