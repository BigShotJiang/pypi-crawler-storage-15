"""Chrome Web Store fetcher."""

from .fetcher import ChromeWebStoreFetcher

__all__ = ["ChromeWebStoreFetcher"]
