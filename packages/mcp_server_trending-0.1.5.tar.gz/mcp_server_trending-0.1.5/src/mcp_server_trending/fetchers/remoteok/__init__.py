"""RemoteOK jobs fetcher."""

from .fetcher import RemoteOKFetcher

__all__ = ["RemoteOKFetcher"]
