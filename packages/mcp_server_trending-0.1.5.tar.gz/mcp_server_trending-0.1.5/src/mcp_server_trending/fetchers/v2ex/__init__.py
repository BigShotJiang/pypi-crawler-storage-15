"""V2EX fetcher package."""

from .fetcher import V2EXFetcher

__all__ = ["V2EXFetcher"]
