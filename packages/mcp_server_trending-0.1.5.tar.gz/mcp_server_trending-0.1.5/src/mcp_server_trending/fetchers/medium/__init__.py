"""Medium fetcher exports."""

from .fetcher import MediumFetcher

__all__ = ["MediumFetcher"]
