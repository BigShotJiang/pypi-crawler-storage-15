"""Semantic Scholar fetcher module."""

from .fetcher import SemanticScholarFetcher

__all__ = ["SemanticScholarFetcher"]
