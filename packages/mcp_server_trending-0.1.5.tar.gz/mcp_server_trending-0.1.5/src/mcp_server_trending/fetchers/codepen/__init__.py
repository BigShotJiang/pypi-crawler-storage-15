"""CodePen fetcher exports."""

from .fetcher import CodePenFetcher

__all__ = ["CodePenFetcher"]
