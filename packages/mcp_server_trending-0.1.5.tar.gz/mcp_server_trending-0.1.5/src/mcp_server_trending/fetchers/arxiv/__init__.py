"""arXiv fetcher module."""

from .fetcher import ArxivFetcher

__all__ = ["ArxivFetcher"]
