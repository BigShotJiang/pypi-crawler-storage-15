"""PyPI packages fetcher."""

from .fetcher import PyPIFetcher

__all__ = ["PyPIFetcher"]
