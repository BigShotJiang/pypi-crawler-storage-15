"""TrustMRR fetchers package."""

from .fetcher import TrustMRRFetcher

__all__ = ["TrustMRRFetcher"]
