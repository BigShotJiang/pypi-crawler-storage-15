"""AlternativeTo fetcher module."""

from .fetcher import AlternativeToFetcher

__all__ = ["AlternativeToFetcher"]

