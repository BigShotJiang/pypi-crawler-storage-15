"""Betalist fetcher module."""

from .fetcher import BetalistFetcher

__all__ = ["BetalistFetcher"]

