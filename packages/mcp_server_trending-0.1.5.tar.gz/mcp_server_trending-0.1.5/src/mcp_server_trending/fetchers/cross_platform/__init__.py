"""Cross-platform search and summary fetcher."""

from .fetcher import CrossPlatformFetcher

__all__ = ["CrossPlatformFetcher"]

