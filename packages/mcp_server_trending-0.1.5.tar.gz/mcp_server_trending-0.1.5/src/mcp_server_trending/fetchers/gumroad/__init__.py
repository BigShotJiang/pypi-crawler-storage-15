"""Gumroad fetcher module."""

from .fetcher import GumroadFetcher

__all__ = ["GumroadFetcher"]

