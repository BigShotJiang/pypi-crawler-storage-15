"""We Work Remotely fetcher module."""

from .fetcher import WeWorkRemotelyFetcher

__all__ = ["WeWorkRemotelyFetcher"]
