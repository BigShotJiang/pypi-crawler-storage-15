"""Twitter/X fetcher module."""

from .fetcher import TwitterFetcher

__all__ = ["TwitterFetcher"]

