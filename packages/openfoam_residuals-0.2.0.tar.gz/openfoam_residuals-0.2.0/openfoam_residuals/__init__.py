"""A package for handling OpenFOAM residual analysis."""

__version__ = "0.2.0"
