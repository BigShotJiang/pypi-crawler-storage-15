.. _examples:

Example notebooks
=================

.. toctree::
   :maxdepth: 4

   notebooks/example.ipynb
   notebooks/cavities_reference_phase.ipynb
