chopper module
=====================================

.. automodule:: lightwin.core.commands.chopper
   :members:
   :undoc-members:
   :show-inheritance:
