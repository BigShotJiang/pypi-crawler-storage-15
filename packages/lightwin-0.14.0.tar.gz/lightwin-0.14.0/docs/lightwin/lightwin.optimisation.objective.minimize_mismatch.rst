minimize\_mismatch module
=========================================================

.. automodule:: lightwin.optimisation.objective.minimize_mismatch
   :members:
   :undoc-members:
   :show-inheritance:
