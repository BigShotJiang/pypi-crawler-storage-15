edge module
==================================

.. automodule:: lightwin.core.elements.edge
   :members:
   :undoc-members:
   :show-inheritance:
