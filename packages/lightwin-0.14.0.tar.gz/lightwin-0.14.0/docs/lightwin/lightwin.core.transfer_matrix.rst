transfer\_matrix package
======================================

.. automodule:: lightwin.core.transfer_matrix
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 5

   lightwin.core.transfer_matrix.factory
   lightwin.core.transfer_matrix.transfer_matrix
