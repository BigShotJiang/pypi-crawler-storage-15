beam\_specs module
================================

.. automodule:: lightwin.core.beam_specs
   :members:
   :undoc-members:
   :show-inheritance:
