ellipse module
=====================================

.. automodule:: lightwin.visualization.ellipse
   :members:
   :undoc-members:
   :show-inheritance:
