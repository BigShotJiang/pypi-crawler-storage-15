cavity\_settings\_factory module
===================================================================

.. automodule:: lightwin.core.elements.field_maps.cavity_settings_factory
   :members:
   :undoc-members:
   :show-inheritance:
