particle module
=============================

.. automodule:: lightwin.core.particle
   :members:
   :undoc-members:
   :show-inheritance:
