wtf\_specs module
=======================================

.. automodule:: lightwin.optimisation.wtf_specs
   :members:
   :undoc-members:
   :show-inheritance:
