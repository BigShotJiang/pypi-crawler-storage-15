compare\_beam\_calculators module
==================================================

.. automodule:: lightwin.scripts.compare_beam_calculators
   :members:
   :undoc-members:
   :show-inheritance:
