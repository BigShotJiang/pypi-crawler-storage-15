physics package
========================

.. automodule:: lightwin.physics
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 5

   lightwin.physics.acceptance
   lightwin.physics.converters
   lightwin.physics.phases
   lightwin.physics.synchronous_phases
