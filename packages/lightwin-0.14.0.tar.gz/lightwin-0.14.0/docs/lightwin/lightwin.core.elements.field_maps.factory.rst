factory module
=================================================

.. automodule:: lightwin.core.elements.field_maps.factory
   :members:
   :undoc-members:
   :show-inheritance:
