aperture module
======================================

.. automodule:: lightwin.core.elements.aperture
   :members:
   :undoc-members:
   :show-inheritance:
