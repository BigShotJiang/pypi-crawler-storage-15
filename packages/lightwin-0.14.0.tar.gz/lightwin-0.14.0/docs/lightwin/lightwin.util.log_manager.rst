log\_manager module
=================================

.. automodule:: lightwin.util.log_manager
   :members:
   :undoc-members:
   :show-inheritance:
