acceptance module
==================================

.. automodule:: lightwin.physics.acceptance
   :members:
   :undoc-members:
   :show-inheritance:
