diagnostic module
========================================

.. automodule:: lightwin.core.elements.diagnostic
   :members:
   :undoc-members:
   :show-inheritance:
