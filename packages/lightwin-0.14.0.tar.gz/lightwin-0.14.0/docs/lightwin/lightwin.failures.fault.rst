fault module
==============================

.. automodule:: lightwin.failures.fault
   :members:
   :undoc-members:
   :show-inheritance:
