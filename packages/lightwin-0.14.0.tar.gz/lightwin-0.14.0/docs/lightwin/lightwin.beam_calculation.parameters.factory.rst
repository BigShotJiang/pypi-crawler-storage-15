factory module
====================================================

.. automodule:: lightwin.beam_calculation.parameters.factory
   :members:
   :undoc-members:
   :show-inheritance:
