optimization\_history module
=============================================

.. automodule:: lightwin.scripts.optimization_history
   :members:
   :undoc-members:
   :show-inheritance:
