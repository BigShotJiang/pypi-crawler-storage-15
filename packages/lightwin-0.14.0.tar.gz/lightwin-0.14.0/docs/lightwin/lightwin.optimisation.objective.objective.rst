objective module
================================================

.. automodule:: lightwin.optimisation.objective.objective
   :members:
   :undoc-members:
   :show-inheritance:
