design\_space module
========================================================

.. automodule:: lightwin.optimisation.design_space.design_space
   :members:
   :undoc-members:
   :show-inheritance:
