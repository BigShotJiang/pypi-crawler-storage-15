beam\_parameters\_factory module
========================================================================

.. automodule:: lightwin.beam_calculation.envelope_1d.beam_parameters_factory
   :members:
   :undoc-members:
   :show-inheritance:
