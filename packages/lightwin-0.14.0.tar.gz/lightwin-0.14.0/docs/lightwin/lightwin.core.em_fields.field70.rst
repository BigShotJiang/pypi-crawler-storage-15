field70 module
=======================================

.. automodule:: lightwin.core.em_fields.field70
   :members:
   :undoc-members:
   :show-inheritance:
