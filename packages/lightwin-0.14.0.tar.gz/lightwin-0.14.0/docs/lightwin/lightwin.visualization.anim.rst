anim module
==================================

.. automodule:: lightwin.visualization.anim
   :members:
   :undoc-members:
   :show-inheritance:
