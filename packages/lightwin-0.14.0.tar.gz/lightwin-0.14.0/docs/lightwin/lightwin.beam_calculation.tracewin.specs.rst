specs module
================================================

.. automodule:: lightwin.beam_calculation.tracewin.specs
   :members:
   :undoc-members:
   :show-inheritance:
