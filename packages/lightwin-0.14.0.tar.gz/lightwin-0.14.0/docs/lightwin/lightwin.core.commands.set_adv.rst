set\_adv module
======================================

.. automodule:: lightwin.core.commands.set_adv
   :members:
   :undoc-members:
   :show-inheritance:
