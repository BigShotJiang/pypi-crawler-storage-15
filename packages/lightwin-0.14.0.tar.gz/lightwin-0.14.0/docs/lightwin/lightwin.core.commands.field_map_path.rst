field\_map\_path module
==============================================

.. automodule:: lightwin.core.commands.field_map_path
   :members:
   :undoc-members:
   :show-inheritance:
