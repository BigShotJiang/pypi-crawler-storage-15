"""Define class objects that can create and handle plots."""
