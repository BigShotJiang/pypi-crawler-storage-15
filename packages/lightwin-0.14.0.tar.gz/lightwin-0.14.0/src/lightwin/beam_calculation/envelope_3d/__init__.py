"""Define modules for the :class:`.Envelope3D` beam calculator.

It is a 3d envelope calculator, only implemented in Python for now.

"""
