"""Define functions to integrate the motion."""
