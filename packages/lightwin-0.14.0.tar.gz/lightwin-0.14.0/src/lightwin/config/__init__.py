"""Define functions to test the configuration file and assists its creation."""
