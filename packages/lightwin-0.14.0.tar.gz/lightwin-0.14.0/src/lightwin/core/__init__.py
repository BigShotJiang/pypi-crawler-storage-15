"""
This module holds the most central modules and subpackages.

They define the structure of the accelerator, the elements, the main parameters
of the beam.

"""
