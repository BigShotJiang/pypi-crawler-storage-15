"""Define objects for ``FIELD_MAP`` command.

The base FieldMap object is subclassed into a specific object according to the
structure of the field map file.
"""
