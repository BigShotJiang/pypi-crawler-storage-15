class MarshallError(Exception):
    pass
