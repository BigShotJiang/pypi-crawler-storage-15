from datetime import datetime
import requests
from dateutil.relativedelta import relativedelta

runtime = "python3.11"
expiration_date = "2026-06-30"
threshold_months = 6

DISCORD_WEBHOOK_URL = "https://discord.com/api/webhooks/1409523158637084722/fsb1MO4KwECrv4XakaVhZJmQ1YI4HXS4jprHEvkfqtWVNI-V4sX_tecP8EOChwd12dP7"

def check_runtime_expiration(runtime_name, end_date_str, threshold_months=6):
    end_date = datetime.strptime(end_date_str, "%Y-%m-%d").date()
    today = datetime.today().date()

    threshold_date = end_date - relativedelta(months=threshold_months)

    if today == threshold_date:
        return (
            f"Le runtime **{runtime_name}** expire dans **{threshold_months} mois** "
            f"(le {end_date}) !"
        )
    return None

def send_discord_message(content: str):
    try:
        data = {"content": content}
        response = requests.post(DISCORD_WEBHOOK_URL, json=data)
        if response.status_code == 204:
            print(" Message envoyé sur Discord")
        else:
            print(f" Erreur Discord : {response.status_code} - {response.text}")
    except Exception as e:
        print("Exception lors de l'envoi sur Discord :", e)

if __name__ == "__main__":
    message = check_runtime_expiration(runtime, expiration_date, threshold_months)
    if message:
        send_discord_message(message)
    else:
        valid_msg = f" Le runtime **{runtime}** n’est pas encore à 6 mois de l’expiration (expire le {expiration_date})."
        print(valid_msg)
