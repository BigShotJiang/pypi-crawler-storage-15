""" Skill for Vader Sentiment Analysis

Author: Dennis Zyska, Nils Dycke
"""

from brokerio.skills.SkillModel import SkillModel


class Model(SkillModel):
    pass
