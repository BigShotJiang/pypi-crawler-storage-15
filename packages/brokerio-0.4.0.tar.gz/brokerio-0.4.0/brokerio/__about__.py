__version__ = "0.4.0"
__author__ = "Dennis Zyska, Nils Dycke"
__credits__ = ["Dennis Zyska", "Nils Dycke"]
__license__ = "Apache 2.0"
