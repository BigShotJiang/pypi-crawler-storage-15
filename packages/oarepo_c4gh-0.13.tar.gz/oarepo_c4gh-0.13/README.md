
Crypt4GH Processing
===================

A Crypt4GH container processing library.

Copyright (c) 2024 Dominik Pantůček <dominik.pantucek@trustica.cz>

Distributed under MIT license - see LICENSE for details.

For usage instructions, see the [generated
documentation](https://oarepo.github.io/oarepo-c4gh/).

The [test coverage
report](https://oarepo.github.io/oarepo-c4gh/cov_html/) is also
available.
