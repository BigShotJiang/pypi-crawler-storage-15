class DuplicationError(Exception):
    """
    Exception raised for issues that arise during duplication.

    Attributes:
        message(str): Explanation of the error.
    """

    def __init__(self, message):
        self.message = message
        super().__init__(self.message)
