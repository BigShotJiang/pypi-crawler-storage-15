#!/usr/bin/env python
"""
This module is used for running unit tests.
"""
import pytest

if __name__ == "__main__":
    pytest.main(["-ra -s", "./smoothglue"])
