from django.urls import include, path
from rest_framework import routers

import smoothglue.authentication.urls
import smoothglue.tracker.urls

router = routers.DefaultRouter()

router_registries = [
    smoothglue.tracker.urls.ROUTER.registry,
    smoothglue.authentication.urls.ROUTER.registry,
]

for router_registry in router_registries:
    router.registry.extend(router_registry)

urlpatterns = [
    path("", include(router.urls)),
]
