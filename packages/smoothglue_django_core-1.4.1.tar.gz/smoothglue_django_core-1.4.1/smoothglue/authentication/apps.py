from django.apps import AppConfig


class AuthenticationConfig(AppConfig):
    name = "smoothglue.authentication"
    verbose_name = "SmoothGlue Authentication"
