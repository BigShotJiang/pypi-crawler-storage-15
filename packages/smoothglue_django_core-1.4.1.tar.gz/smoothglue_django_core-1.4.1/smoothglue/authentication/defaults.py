"""
Default values for SmoothGlue Authentication
"""

ENABLE_SINGLE_USER_MODE = False
SINGLE_USER_DEFAULT_EMAIL = "unknownuser@smoothglue.com"
ROOT_ADMIN_USERNAME = ""
ROOT_ADMIN_PASSWORD = None
