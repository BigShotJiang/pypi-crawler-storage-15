1 / 0


def main():
    pass


if __name__ == "__main__":
    main()
