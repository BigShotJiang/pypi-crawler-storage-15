def main():
    print("Hello from packpack.lib")
