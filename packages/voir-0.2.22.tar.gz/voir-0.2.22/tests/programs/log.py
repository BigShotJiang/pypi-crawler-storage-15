from voir import log

if __name__ == "__main__":
    for i in range(5):
        log(task="cool", value=i)
