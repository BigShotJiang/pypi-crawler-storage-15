def main():
    greeting = "hello"
    print(f"{greeting} world")


def alt():
    greeting = "love you,"
    print(f"{greeting} world")


if __name__ == "__main__":
    main()
