import sys


def main():
    sys.stdout.buffer.write(b"\xc3\x28")


if __name__ == "__main__":
    main()
