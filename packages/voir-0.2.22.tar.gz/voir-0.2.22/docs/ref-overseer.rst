
voir.overseer
=============

.. automodule:: voir.overseer
    :members:
    :exclude-members: Overseer

    .. autoclass:: Overseer

        **Attributes**

        .. autoattribute:: argparser
        .. autoattribute:: given
        .. autoattribute:: log
        .. autoattribute:: logfile
        .. autoattribute:: options
        .. autoattribute:: phases

        **Methods**

        .. automethod:: __call__
        .. automethod:: abort
        .. automethod:: give
        .. automethod:: probe
        .. automethod:: queue
        .. automethod:: require
        .. automethod:: run_phase
        .. automethod:: stop
