
voir.argparse_ext
=================

.. automodule:: voir.argparse_ext

    .. autoclass:: ExtendedArgumentParser
        :members:
