
voir.instruments
================

.. automodule:: voir.instruments
    :members:

.. autofunction:: voir.instruments.log

.. autofunction:: voir.instruments.dash

.. autofunction:: voir.instruments.early_stop

.. autofunction:: voir.instruments.rate

.. autofunction:: voir.instruments.gpu_monitor
