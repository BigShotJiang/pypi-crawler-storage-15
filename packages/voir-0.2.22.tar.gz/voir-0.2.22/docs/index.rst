
Welcome to ptera's documentation!
=================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   intro.rst
   guide.rst
   reference.rst


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
