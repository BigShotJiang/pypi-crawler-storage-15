
# Advanced Digit Counter

A high-performance, precision-controlled Python library for counting digits in **integers**, **floats**, **strings**, and **Decimal** numbers — with caching, batch processing, unified API, logging, and CLI support.

---

## 🌟 Features

- 🔢 **Unified API** — A single method handles all number types  
- ⚡ **High Performance**  
  - LRU caching  
  - Optimized integer digit counting  
  - Fast float/decimal parsing  
  - Efficient batch processing  
- 🎯 **Precision Control** — Up to **50 decimal digits**
- 🛡 **Robust Error Handling** — Clear exceptions & validation
- 📜 **Logging Support** — Configurable logging levels
- 💻 **CLI Tool** — `digit-counter` command
- 🧪 **Type Hints** — Strong typing for IDEs
- 🚀 **Production Ready** — Scalable, reliable, lightweight

---

## 📦 Installation

### Stable release
```bash
pip install advanced-digit-counter
````

### Development + tools

```bash
pip install advanced-digit-counter[dev]
```

### Performance extensions

```bash
pip install advanced-digit-counter[performance]
```

### Install all extras

```bash
pip install advanced-digit-counter[all]
```

---

## 🚀 Quick Start

```python
from digit_counter import DigitCounter

# Initialize with custom precision
counter = DigitCounter(precision=15)

# Count digits
result = counter.count_digits(123.456, mode="all")

print("Total digits:", result.total_digits)
print("Before decimal:", result.before_decimal)
print("After decimal:", result.after_decimal)
```

---

## 📚 Counting Modes

| Mode     | Description                                   |
| -------- | --------------------------------------------- |
| `total`  | Total digits excluding sign                   |
| `before` | Digits before decimal point                   |
| `after`  | Digits after decimal (trimmed zeros)          |
| `all`    | Complete metadata object (`DigitCountResult`) |

---

## 📊 Batch Processing

```python
values = [123, 45.67, -890.123]

result = counter.batch_process(values, mode="total")

print(result.summary())
```

Output example:

```
Processed 3 items | Success: 3 | Failed: 0 | Success rate: 100% | Avg time: 0.120ms
```

---

## 🧰 Command Line Usage

### Count digits for a number

```bash
digit-counter count 123.456
```

### Count specific mode

```bash
digit-counter count 123.456 --mode before
```

### Batch process a file

```bash
digit-counter batch values.txt --output results.json
```

### Show statistics

```bash
digit-counter stats
```

### Full help

```bash
digit-counter --help
```



## 📘 Logging Example

```python
counter = DigitCounter(log_level="DEBUG")
counter.count_digits(123.456)
```

---

## 📝 License

This project is licensed under the **MIT License**.
See the [`LICENSE`](LICENSE) file for details.

---

## 🤝 Contributing

Contributions are welcome!
Please read the guidelines in **CONTRIBUTING.md** before submitting PRs.
