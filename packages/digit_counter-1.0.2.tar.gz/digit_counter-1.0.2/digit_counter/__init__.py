"""
Advanced Digit Counter
======================

A high-performance Python package for counting digits in integers and floats.
"""

__version__ = "1.0.2"
__author__ = "Kishor Kumar K"
__license__ = "MIT"

from .core import DigitCounter
from .exceptions import DigitCounterError
from .types import DigitCountResult, BatchResult, CountingMode, LogLevel
from .utils import create_digit_counter, measure_performance
from .constants import DEFAULT_PRECISION, MAX_PRECISION, CACHE_SIZE

__all__ = [
    "DigitCounter",
    "DigitCounterError",
    "DigitCountResult",
    "BatchResult",
    "CountingMode",
    "LogLevel",
    "create_digit_counter",
    "measure_performance",
    "DEFAULT_PRECISION",
    "MAX_PRECISION",
    "CACHE_SIZE",
]
