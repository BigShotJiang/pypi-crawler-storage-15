"""
Constants for the digit counter package.
"""

from typing import Final

# Default configuration
DEFAULT_PRECISION: Final[int] = 15
MAX_PRECISION: Final[int] = 50
CACHE_SIZE: Final[int] = 1000
DEFAULT_LOG_LEVEL: Final[str] = "INFO"

# Performance thresholds (milliseconds)
PERFORMANCE_WARNING_THRESHOLD: Final[float] = 10.0
PERFORMANCE_CRITICAL_THRESHOLD: Final[float] = 100.0

# String constants
SCIENTIFIC_NOTATION_CHARS = frozenset({"e", "E"})
DECIMAL_POINT: Final[str] = "."
ZERO_STR: Final[str] = "0"
