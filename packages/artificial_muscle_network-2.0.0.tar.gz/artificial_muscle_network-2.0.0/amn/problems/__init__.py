"""Problem templates for AMN."""
