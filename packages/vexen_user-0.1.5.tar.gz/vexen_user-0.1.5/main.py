import asyncio


async def main():
	print("Hello from user!")


if __name__ == "__main__":
	asyncio.run(main())
