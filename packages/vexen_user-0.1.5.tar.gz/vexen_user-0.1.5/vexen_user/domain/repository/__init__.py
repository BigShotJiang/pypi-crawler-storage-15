"""Domain repository ports."""

from .user_repository_port import IUserRepositoryPort

__all__ = ["IUserRepositoryPort"]
