"""Shared resources for vexen-user."""
