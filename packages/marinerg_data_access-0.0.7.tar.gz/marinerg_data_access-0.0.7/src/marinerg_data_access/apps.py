from django.apps import AppConfig


class MarinergDataAccessConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "marinerg_data_access"
