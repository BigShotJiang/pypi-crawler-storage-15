from .prime import is_prime

__version__ = "0.1.0"