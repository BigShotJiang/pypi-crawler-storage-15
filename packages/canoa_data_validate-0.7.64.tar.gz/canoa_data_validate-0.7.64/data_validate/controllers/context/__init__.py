#  Copyright (c) 2025 Mário Carvalho (https://github.com/MarioCarvalhoBr).
