#  Copyright (c) 2025.
from data_validate.middleware.bootstrap import Bootstrap

__all__ = [
    "Bootstrap",
]
