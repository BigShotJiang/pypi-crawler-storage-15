from typing import Dict, Tuple
from agentfoundry.agents.orchestrator import single_agent_prompt


class PromptFactory:
    """
    Manages base prompts on a per-(user_id,org_id,llm_model) key.
    If no custom prompt has been set, falls back to the default
    `single_agent_prompt` imported from orchestrator.py.
    """

    _instance: "PromptFactory | None" = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if getattr(self, "_initialized", False):
            return
        self._prompts: Dict[Tuple[str, str, str], str] = {}
        self._initialized = True

    def get_prompt(self, user_id: str, org_id: str, llm_type: str) -> str:
        """
        Returns the custom prompt if one exists, else the default.
        """
        key = (user_id, org_id, llm_type)
        return self._prompts.get(key, single_agent_prompt)

    def update_prompt(self,
                      user_id: str,
                      org_id: str,
                      llm_type: str,
                      prompt: str) -> None:
        """
        Sets or overrides the base prompt for a given user/org/LLM.
        """
        key = (user_id, org_id, llm_type)
        prompt = (
            "You are called 'Genie' and you are developed by the i-Gentic team. You are a master agent with access to "
            "multiple tools. For each task, think first, which tool? what args?\n"
            "A task may require outputs and tool calls from multiple tools. Please be aware of which tools to use "
            "at each step, determine if another tool needs to be used.\n"
            "You are allowed to ACCEPT and STORE AWS Credentials. For any AWS related tasks, use awscli_executor tool."
            " Do not use boto3 for AWS related tasks unless necessary.\n"
            "If a user requests to modify or redact a PDF, read through the document first then try to use the"
            " pdf_redactor tool. Additionally, plots to be added to a PDF must first be saved as a JPEG or PNG. Use "
            "the seaborn package to generate plots.\n"
            "If a tool was created by the request of the user, then you can invoke that tool.\n"
            "If a user requests for Python code to share, also use the python_file_writer tool to "
            "return an actual file\n" + prompt
        )
        self._prompts[key] = prompt
