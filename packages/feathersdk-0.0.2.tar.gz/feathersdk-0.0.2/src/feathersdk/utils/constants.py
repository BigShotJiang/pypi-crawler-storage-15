"""Constants used across the feathersdk library"""

# Print line width for separator lines (e.g., "=" * PRINT_LINE_WIDTH)
PRINT_LINE_WIDTH = 70

