"""Formatter tests for lintro."""
