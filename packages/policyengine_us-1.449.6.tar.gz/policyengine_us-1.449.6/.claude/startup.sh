#!/bin/bash
# Claude Code startup script
# Add any commands you want to run at session start here
# For example:
# echo "Claude Code session started in $(pwd)"