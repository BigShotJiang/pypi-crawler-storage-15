import conset
import time

l: list[dict[str, dict[str, None | bool | str | dict[str, int]]]] = [
    {
        "mouse": {
            "pos": {
                "y": 0, # int
                "x": 0 # int
            },
            "button": None, # None, "left", "right"
            "flag": None # None, "move", "double", "wheel", "hwheel"
        },
        "keyboard": {
            "keydown": False, # False, True
            "keyname": None,  # None, str(keyname)
        },
        "control": {
            "ralt": False,  # False, True
            "lalt": False,  # False, True
            "rctrl": False, # False, True
            "lctrl": False, # False, True
            "shift": False, # False, True
            "numlock": False,    # False, True
            "scrolllock": False, # False, True
            "capslock": False,    # False, True
            "enhanced_key": False # False, True
        }
    }
]

conset.coninit()

while True:
    time.sleep(0.1)
    l = conset.conin()
    if l:
        print("\033[2J\033[0;0H", l)