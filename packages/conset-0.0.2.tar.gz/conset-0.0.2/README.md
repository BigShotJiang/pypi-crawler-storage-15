# Console Set

控制台设置/集。可更改控制台设置，或获取控制台输入流

## 系统要求

### 支持的平台
- **操作系统**: Windows 10/11 (64位)
- **架构**: x64/AMD64
- **Python**: 3.14+

### 不支持的平台
- 32位 Windows 系统
- Linux 或 macOS
- ARM 架构 Windows
- Python 2.x

## 安装

### 从`PyPI`安装（推荐）
```bash
pip install conset
```

## 快速开始

### 基础使用
```python
import conset

# 获取输入
conin = conset.conin()

if conin:
    # 鼠标
    print("鼠标位置: y = ", conin[-1]["mouse"]["pos"]["y"], ", x = ", conin[-1]["mouse"]["pos"]["y"])

    # 键盘
    if conin[-1]["keyboard"]["keydown"]:
        print("按键: ", conin[-1]["keyboard"]["keyname"])
```

## API 参考

### `conin()`
`conin()`会返回一个列表，长度为控制台接收到的操作数量。
列表内的每个元素都是一个固定结构的字典，具体结构如下
```python
{
    "mouse": {
        "pos": {
            "y": 0, # int
            "x": 0 # int
        },
        "button": None, # None, "left", "right"
        "flag": None # None, "move", "double", "wheel", "hwheel"
    },
    "keyboard": {
        "keydown": False, # False, True
        "keyname": None,  # None, str([keyname])
    },
    "control": {
        "ralt": False,  # False, True
        "lalt": False,  # False, True
        "rctrl": False, # False, True
        "lctrl": False, # False, True
        "shift": False, # False, True
        "numlock": False,    # False, True
        "scrolllock": False, # False, True
        "capslock": False,    # False, True
        "enhanced_key": False # False, True
    }
}
```

## 许可证

这是专有软件。请查看 LICENSE 文件了解详细条款。  
**重要**: 使用本软件即表示您同意遵守许可证条款。