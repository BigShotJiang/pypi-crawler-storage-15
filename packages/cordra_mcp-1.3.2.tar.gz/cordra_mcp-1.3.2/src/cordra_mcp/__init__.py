"""MCP server for Cordra digital object repository."""

__version__ = "1.3.2"
