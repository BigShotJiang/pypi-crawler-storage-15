# DICOM Medical Sequential Images to Video Converter

Simple script to convert DICOM medical sequential images to video.

Just run it by executing the following command:

```sh
uvx dicom-to-video
```
