from .core.suggester import QuerySuggester

__all__ = ["QuerySuggester"]
__version__ = "0.1.1"
