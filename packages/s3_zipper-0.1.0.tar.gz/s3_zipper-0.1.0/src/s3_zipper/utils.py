def debug(msg):
    print("[DEBUG]", msg)
