#ifndef _CIFFY_LOOKUP_H
#define _CIFFY_LOOKUP_H

#include <string.h>

struct _LOOKUP {
    const char *name;
    int value;
};

#endif
