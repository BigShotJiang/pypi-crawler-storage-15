from __future__ import annotations

from kabukit.domain.base import Base


class List(Base):
    pass
