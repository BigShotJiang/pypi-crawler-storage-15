"""
Reserved namespace for future clockworkangels video builder for Mixture-of-Models outputs.
"""
__version__ = "0.0.1"
