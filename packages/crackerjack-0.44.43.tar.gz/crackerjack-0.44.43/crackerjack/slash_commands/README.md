> Crackerjack Docs: [Main](<../../README.md>) | [Crackerjack Package](<../README.md>) | [Slash Commands](<./README.md>)

# Slash Commands

Slash command handlers and related routing.

## Related

- [Crackerjack Package](<../README.md>) - Parent package
- [MCP](<../mcp/README.md>) - MCP server slash command integration
- [CLI](<../cli/README.md>) - Command-line interface handlers
