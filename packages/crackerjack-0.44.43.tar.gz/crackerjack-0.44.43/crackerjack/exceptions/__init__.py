"""Custom exceptions for crackerjack."""

from .tool_execution_error import ToolExecutionError

__all__ = ["ToolExecutionError"]
