"""CLI interface for drift."""

from drift.cli.main import main

__all__ = ["main"]
