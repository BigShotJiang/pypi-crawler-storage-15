import sys
import os
import runpy
from pathlib import Path
# from retracesoftware.install.phases import *
import pkgutil
import tomllib
import retracesoftware.functional as functional
import builtins
import importlib
import _imp
import importlib._bootstrap_external as _bootstrap_external
import atexit
import threading
import retracesoftware.utils as utils
from retracesoftware.install.patcher import patch_module, create_patcher
from retracesoftware.proxy.startthread import patch_thread_start

thread_states = [
    "disabled", # Default state when retrace is disabled for a thread
    "internal", # Default state when retrace is disabled for a thread
    "external", # When target thread is running outside the python system to be recorded
    "retrace", # When target thread is running outside the retrace system
    "importing", # When target thread is running outside the retrace system
    "gc", # When the target thread is running inside the pyton garbage collector
]

class ImmutableTypes(set):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def __contains__(self, item):
        assert isinstance(item, type)

        if super().__contains__(item):
            return True

        for elem in self:
            if issubclass(item, elem):
                self.add(item)
                return True

        return False            

def load_module_config(filename):
    data = pkgutil.get_data("retracesoftware", filename)
    assert data is not None
    return tomllib.loads(data.decode("utf-8"))

def wait_for_non_daemon_threads(timeout=None):
    """
    Wait for all non-daemon threads to finish, just like Python does on exit.
    
    Args:
        timeout (float, optional): Max seconds to wait. None = wait forever.
    
    Returns:
        bool: True if all threads finished, False if timeout exceeded.
    """
    import threading
    import time

    start_time = time.time()
    main_thread = threading.main_thread()

    while True:
        # Get all active threads
        active = threading.enumerate()

        # Filter: non-daemon and not the main thread
        non_daemon_threads = [
            t for t in active
            if t is not main_thread and not t.daemon
        ]

        if not non_daemon_threads:
            return True  # All done!

        # Check timeout
        if timeout is not None:
            elapsed = time.time() - start_time
            if elapsed >= timeout:
                print(f"Timeout: {len(non_daemon_threads)} thread(s) still alive")
                return False

        # Sleep briefly to avoid busy-wait
        time.sleep(0.1)

def run_python_command(argv):
    """
    Run a Python app from a command list using runpy.

    Supports:
        ['-m', 'module', 'arg1', ...]     → like `python -m module arg1 ...`
        ['script.py', 'arg1', ...]        → like `python script.py arg1 ...`

    Args:
        argv: List of command-line arguments (first item is either '-m' or script path)

    Returns:
        Exit code (0 on success, 1+ on error)
    """
    if not argv:
        print("Error: No command provided", file=sys.stderr)
        return 1

    original_argv = sys.argv[:]
    original_cwd = os.getcwd()

    try:
        if argv[0] == '-m':
            if len(argv) < 2:
                print("Error: -m requires a module name", file=sys.stderr)
                return 1
            module_name = argv[1]
            module_args = argv[2:]
            sys.argv = ['-m', module_name] + module_args
            runpy.run_module(module_name, run_name="__main__")
            return 0

        else:
            script_path = argv[0]
            script_args = argv[1:]
            path = Path(script_path)

            if not path.exists():
                print(f"Error: Script not found: {script_path}", file=sys.stderr)
                return 1

            if path.suffix != ".py":
                print(f"Error: Not a Python script: {script_path}", file=sys.stderr)
                return 1

            full_path = str(path.resolve())
            sys.argv = [full_path] + script_args

            # Change to script's directory
            os.chdir(path.parent)

            runpy.run_path(full_path, run_name="__main__")
            return 0

    except ModuleNotFoundError:
        print(f"Error: No module named '{argv[1]}'", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    finally:
        sys.argv = original_argv
        os.chdir(original_cwd)

def patch_import(thread_state, patcher, sync):
    # builtins.__import__ = thread_state.dispatch(builtins.__import__, internal = sync(thread_state.wrap('importing', builtins.__import__)))
    # bi = builtins.__import__
    # def foo(*args, **kwargs):
    #     print(f'in patched __import__: {thread_state.value} {args[0]}')
    #     if thread_state.value == 'internal':
    #         with thread_state.select('importing'):
    #             return bi(*args, **kwargs)
    #     else:
    #         return bi(*args, **kwargs)
        
    # builtins.__import__ = foo

    builtins.__import__ = thread_state.dispatch(builtins.__import__, internal = thread_state.wrap('importing', builtins.__import__))

    def exec(source, globals = None, locals = None):
        res = builtins.exec(source, globals, locals)
        patcher(globals, False)
        return res

    _imp.exec_dynamic = thread_state.dispatch(_imp.exec_dynamic, 
        importing = functional.juxt(
                        thread_state.wrap('internal', _imp.exec_dynamic), 
                        lambda module: patcher(module.__dict__, False)))
    # _imp.exec_dynamic = lambda mod: utils.sigtrap(f'{thread_state.value} - {mod}')
    # _imp.exec_builtin = lambda mod: utils.sigtrap(f'{thread_state.value} - {mod}')

    _imp.exec_builtin = thread_state.dispatch(_imp.exec_builtin, 
        importing = functional.juxt(
                        thread_state.wrap('internal', _imp.exec_builtin), 
                        lambda module: patcher(module.__dict__, False)))

    # def runpy_exec(source, globals = None, locals = None):
    #     print(f'In runpy exec!!!!!')
    #     return builtins.exec(source, globals, locals)
    
    # utils.update(runpy, "_run_code",
    #              utils.wrap_func_with_overrides,
    #              exec = runpy_exec)

    utils.update(_bootstrap_external._LoaderBasics, "exec_module", 
                 utils.wrap_func_with_overrides,
                 exec = thread_state.dispatch(builtins.exec, importing = thread_state.wrap('internal', sync(exec))))

preload = [
    "logging",
    "pathlib",
    "_signal",
    "_posixsubprocess",
    "socket",
    "select",
    "ssl",
    "random",
    "email",
    "email.errors",
    "http.client",

    "json",
    "typing",
    "queue",
    "mimetypes",
    "tempfile",
    "zipfile",
    "importlib.resources",
    "encodings.idna"

    # "http.client",
    # "queue",
    # "mimetypes",
    # "encodings.idna",
    # "hmac",
    # "ipaddress",
    # "tempfile",
    # "zipfile",
    # "importlib.resources",
    # "importlib.metadata",
    # "atexit",
    # "weakref"
  ]

# def debugger_is_active():
#     return sys.gettrace() and 'debugpy' in sys.modules

def install(system):

    for name in preload:
        importlib.import_module(name)

    if 'pydevd' in sys.modules:
        utils.update(sys.modules['pydevd'].PyDB, 'enable_tracing', system.disable_for)

    for function in utils.stack_functions():
        system.exclude_from_stacktrace(function)

    def recursive_disable(func):
        if not callable(func):
            return func
        
        def wrapped(*args, **kwargs):
            with system.thread_state.select('disabled'):
                return recursive_disable(func(*args, **kwargs))
        
        return wrapped

    sys.settrace = functional.sequence(recursive_disable, sys.settrace)
    sys.setprofile = functional.sequence(recursive_disable, sys.setprofile)
    threading.settrace = functional.sequence(recursive_disable, threading.settrace)

    sys.settrace(sys.gettrace())
    sys.setprofile(sys.getprofile())

    system.checkpoint('About to install retrace system')

    module_config = load_module_config('modules.toml')

    patcher = functional.partial(patch_module, create_patcher(system), system.checkpoint, module_config)
    
    system.checkpoint('Started installing system 1')
    
    for modname in module_config.keys():
        if modname in sys.modules:
            patcher(sys.modules[modname].__dict__, True)

    system.checkpoint('About to patch threading')

    patch_thread_start(system.thread_state)
    threading.current_thread().__retrace__ = system

    system.checkpoint('About to patch import')
    patch_import(thread_state = system.thread_state, patcher = patcher, sync = system.sync)

    # print(f'MODULES: {list(sys.modules.keys())}')

    importlib.import_module = \
        system.thread_state.dispatch(system.disable_for(importlib.import_module),
                              internal = system.thread_state.wrap('importing', importlib.import_module))


    system.checkpoint('About to patch preload libraries')

    system.checkpoint('system patched...')

def run_with_retrace(system, argv, trace_shutdown = False):
    def runpy_exec(source, globals = None, locals = None):
        with system.thread_state.select('internal'):
            return builtins.exec(source, globals, locals)
    
    utils.update(runpy, "_run_code",
                 utils.wrap_func_with_overrides,
                 exec = runpy_exec)

    try:
        run_python_command(argv)
    finally:
        wait_for_non_daemon_threads()
        try:
            if trace_shutdown:
                with system.thread_state.select('internal'):
                    atexit._run_exitfuncs()
            else:
                atexit._run_exitfuncs()
        except Exception as e:
            print(f"Error in atexit hook: {e}", file=sys.stderr)
