import sys
import runpy
import os
import argparse
from typing import Tuple, List
import retracesoftware.utils as utils
from retracesoftware.stackdifference import on_stack_difference
from pathlib import Path
from retracesoftware.proxy.record import RecordProxySystem
from retracesoftware.proxy.replay import ReplayProxySystem
import retracesoftware.stream as stream
from retracesoftware.proxy.startthread import thread_id
import datetime
import json
from shutil import copy2
import threading
import time

from retracesoftware.run import install, run_with_retrace, ImmutableTypes, thread_states

def expand_recording_path(path):
    return datetime.datetime.now().strftime(path.format(pid = os.getpid()))

def load_json(file):
    with open(file, "r", encoding="utf-8") as f:
        return json.load(f)

def dump_as_json(path, obj):
    with open(path, 'w') as f:
        json.dump(obj, f, indent=2)

vscode_workspace = {
    "folders": [{ 'path': '.' }],
    "settings": {
        "python.defaultInterpreterPath": sys.executable,
    },
    "launch": {
        "version": "0.2.0",
        "configurations": [{
            "name": "replay",
            "type": "debugpy",
            "request": "launch",
            
            "python": sys.executable,
            "module": "retracesoftware",
            "args": [
                "--recording", 
                ".."
            ],
            
            "cwd": "${workspaceFolder}/run",
            
            "console": "integratedTerminal",
            "justMyCode": False
        }]
    },
}

def scriptname(argv):
    return argv[1] if argv[0] == "-m" else argv[0]



def record(options, args):
    
    path = Path(expand_recording_path(options.recording))
    # ensure the path exists
    path.mkdir(parents=True, exist_ok=True) 

    # write various recording files to directory
    dump_as_json(path / 'settings.json', {
        'argv': args,
        'magic_markers': options.magic_markers,
        'trace_inputs': options.trace_inputs,
        'trace_shutdown': options.trace_shutdown,
    })

    rundir = path / 'run'
    rundir.mkdir(exist_ok=True)

    script = Path(scriptname(args))
    if script.exists():
        copy2(script, rundir)

    dump_as_json(path / 'replay.code-workspace', vscode_workspace)

    with stream.writer(path = path / 'trace.bin',
                       thread = thread_id, 
                       verbose = options.verbose, 
                       stacktraces = options.stacktraces, 
                       magic_markers = options.magic_markers) as writer:

        # flusher = threading.Timer(5.0, periodic_task)
        # flusher.start()

        writer.exclude_from_stacktrace(record)
        writer.exclude_from_stacktrace(main)

        thread_state = utils.ThreadState(*thread_states)

        tracing_config = {}

        system = RecordProxySystem(
            writer = writer,
            thread_state = thread_state,
            immutable_types = ImmutableTypes(), 
            tracing_config = tracing_config,
            tracecalls = options.trace_inputs)

        install(system)

        run_with_retrace(system, args, options.trace_shutdown)

def replay(args):
    path = Path(args.recording)

    if not path.exists():
        raise Exception(f"Recording path: {path} does not exist")

    settings = load_json(path / "settings.json")

    thread_state = utils.ThreadState(*thread_states)

    with stream.reader(path = path / 'trace.bin',
                       thread = thread_id, 
                       timeout_seconds = args.timeout,
                       verbose = args.verbose,
                       on_stack_difference = thread_state.wrap('disabled', on_stack_difference),
                       magic_markers = settings['magic_markers']) as reader:

        # to_exclude = [('debugpy', '__main__'),
        #               ('debugpy.server.cli', 'main'),
        #               ('debugpy.server.cli', 'run_module'),
        #               ('_pydevd_bundle.pydevd_runpy', '_run_module_as_main'),
        #               ('_pydevd_bundle.pydevd_runpy', '_run_code')]

        # for module,func in to_exclude:
        #     if module in sys.modules and hasattr(sys.modules[module], func):
        #         reader.exclude_from_stacktrace(getattr(sys.modules[module], func))
    
        # reader.exclude_from_stacktrace(replay)
        # reader.exclude_from_stacktrace(main)

        tracing_config = {}

        system = ReplayProxySystem(
            reader = reader,
            thread_state = thread_state,
            immutable_types = ImmutableTypes(), 
            tracing_config = tracing_config,
            tracecalls = settings['trace_inputs'])

        install(system)

        if args.debugpy:
            import debugpy
            debugpy.listen(("0.0.0.0", args.port))
            print(f'DEBUG_PORT_LISTENING={args.port}')
            print('Listening for debug client')
            # debugpy.listen(("127.0.0.1", args.port))
            debugpy.wait_for_client()

        run_with_retrace(system, settings['argv'], settings['trace_shutdown'])

def main():
    parser = argparse.ArgumentParser(
        prog="python -m retracesoftware",
        description="Run a Python module with debugging, logging, etc."
    )

    parser.add_argument(
        '--verbose', 
        action='store_true', 
        help='Enable verbose output'
    )

    parser.add_argument(
        '--recording',   # or '-r'
        type = str,      # ensures it's a string (optional, but safe)
        default = '.',    # default value if not provided
        help = 'the directory to place the recording files'
    )

    if '--' in sys.argv:
        parser.add_argument(
            '--stacktraces', 
            action='store_true', 
            help='Capture stacktrace for every event'
        )

        parser.add_argument(
            '--magic_markers', 
            action='store_true', 
            help='Write magic markers to tracefile, used for debugging'
        )

        parser.add_argument(
            '--trace_shutdown',
            action='store_true', 
            help='Whether to trace system shutdown and cleanup hooks'
        )

        parser.add_argument(
            '--trace_inputs', 
            action='store_true', 
            help='Whether to write call parameters, used for debugging'
        )

        parser.add_argument('rest', nargs = argparse.REMAINDER, help='target application and arguments')

        args = parser.parse_args()

        record(args, args.rest[1:])
    else:

        parser.add_argument(
            '--debugpy',   # or '-r'
            action='store_true',
            help = 'whether to enable debugpy'
        )

        parser.add_argument(
            '--port',   # or '-r'
            type = int,
            default = 1977,
            help = 'whether to enable debugpy'
        )

        parser.add_argument(
            '--timeout',   # or '-r'
            type = int,      # ensures it's a string (optional, but safe)
            default = 60,    # default value if not provided
            help = 'the directory to place the recording files'
        )

        replay(parser.parse_args())

if __name__ == "__main__":
    main()