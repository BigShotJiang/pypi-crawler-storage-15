tests package
=============

Submodules
----------

tests.basetest module
---------------------

.. automodule:: tests.basetest
   :members:
   :undoc-members:
   :show-inheritance:

tests.testEntityManager module
------------------------------

.. automodule:: tests.testEntityManager
   :members:
   :undoc-members:
   :show-inheritance:

tests.testJson module
---------------------

.. automodule:: tests.testJson
   :members:
   :undoc-members:
   :show-inheritance:

tests.testPandas module
-----------------------

.. automodule:: tests.testPandas
   :members:
   :undoc-members:
   :show-inheritance:

tests.testSPARQL module
-----------------------

.. automodule:: tests.testSPARQL
   :members:
   :undoc-members:
   :show-inheritance:

tests.testSqlite3 module
------------------------

.. automodule:: tests.testSqlite3
   :members:
   :undoc-members:
   :show-inheritance:

tests.testTrulyTabular module
-----------------------------

.. automodule:: tests.testTrulyTabular
   :members:
   :undoc-members:
   :show-inheritance:

tests.test\_Plot module
-----------------------

.. automodule:: tests.test_Plot
   :members:
   :undoc-members:
   :show-inheritance:

tests.test\_Tabulate module
---------------------------

.. automodule:: tests.test_Tabulate
   :members:
   :undoc-members:
   :show-inheritance:

tests.test\_csv module
----------------------

.. automodule:: tests.test_csv
   :members:
   :undoc-members:
   :show-inheritance:

tests.test\_docstring\_parser module
------------------------------------

.. automodule:: tests.test_docstring_parser
   :members:
   :undoc-members:
   :show-inheritance:

tests.test\_linkml module
-------------------------

.. automodule:: tests.test_linkml
   :members:
   :undoc-members:
   :show-inheritance:

tests.test\_linkml\_schema module
---------------------------------

.. automodule:: tests.test_linkml_schema
   :members:
   :undoc-members:
   :show-inheritance:

tests.test\_lod module
----------------------

.. automodule:: tests.test_lod
   :members:
   :undoc-members:
   :show-inheritance:

tests.test\_queries module
--------------------------

.. automodule:: tests.test_queries
   :members:
   :undoc-members:
   :show-inheritance:

tests.test\_rdf module
----------------------

.. automodule:: tests.test_rdf
   :members:
   :undoc-members:
   :show-inheritance:

tests.test\_samples module
--------------------------

.. automodule:: tests.test_samples
   :members:
   :undoc-members:
   :show-inheritance:

tests.test\_sync module
-----------------------

.. automodule:: tests.test_sync
   :members:
   :undoc-members:
   :show-inheritance:

tests.test\_yamlable module
---------------------------

.. automodule:: tests.test_yamlable
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: tests
   :members:
   :undoc-members:
   :show-inheritance:
