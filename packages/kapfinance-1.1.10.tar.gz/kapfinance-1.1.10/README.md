# kap-finance

`kapfinance` Python paketi, KAP (Kamuyu Aydınlatma Platformu) üzerinden indirilen
`.xls` finansal tablo dosyalarını okuyup pivotlanmış DataFrame’lere dönüştürür.

## Kurulum

```bash
pip install kapfinance
