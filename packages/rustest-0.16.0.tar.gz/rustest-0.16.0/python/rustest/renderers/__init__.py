"""Event consumers for rendering test execution progress."""

from __future__ import annotations

__all__ = ["RichRenderer"]

from .rich_renderer import RichRenderer
