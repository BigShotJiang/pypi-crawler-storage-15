"""Pytest compatibility for rustest example tests.

This conftest is intentionally minimal because pytest compatibility
is handled by the main tests/conftest.py file at the repository root.
"""

# No configuration needed - tests/conftest.py handles pytest compatibility
