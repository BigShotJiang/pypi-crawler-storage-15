"""Tests for vexen-core."""
