### pvblocks

Package to control pvblocks modules directly

requires packages:

pyserial