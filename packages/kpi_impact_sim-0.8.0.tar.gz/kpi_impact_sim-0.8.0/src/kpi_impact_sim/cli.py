import argparse
import pandas as pd

from .preprocessing import preprocess_dataframe
from .ridge_model import fit_ridge_model
from .simulate import apply_simulation
from .utils import tipo_variable


def run_cli():
    parser = argparse.ArgumentParser(
        description="Entrena un Ridge y simula impacto sobre un KPI usando kpi-impact-sim."
    )

    parser.add_argument("--data", required=True, help="Ruta al CSV de entrada.")
    parser.add_argument("--target", required=True, help="Nombre del KPI objetivo.")
    parser.add_argument(
        "--increment",
        type=float,
        required=True,
        help="Incremento deseado (puntos o % según tipo de variable).",
    )
    parser.add_argument(
        "--output",
        default="simulacion_resultado.csv",
        help="Ruta para guardar la simulación (CSV).",
    )

    args = parser.parse_args()

    print("🔹 Cargando dataset...")
    df = pd.read_csv(args.data)

    print("🔹 Preprocesando...")
    df_proc = preprocess_dataframe(df)
    df_num = df_proc.select_dtypes(include="number")

    if args.target not in df_num.columns:
        raise ValueError(f"El target '{args.target}' no existe en el dataset.")

    X = df_num.drop(columns=[args.target])
    y = df_num[args.target]

    if len(df_num) < 30:
        raise ValueError("El dataset debe tener al menos 30 filas para entrenar un modelo confiable.")

    print("🔹 Entrenando modelo Ridge...")
    model_res = fit_ridge_model(X, y)

    print("🔹 Ejecutando simulación...")
    sim = apply_simulation(
        coef_series=model_res["coefs"],
        df_mes=df_num,
        target=args.target,
        incremento_pts=args.increment,
        tipo_variable_func=tipo_variable,
        save_path=args.output,
    )

    print(f"✔ SIMULACIÓN COMPLETADA. Archivo guardado en: {args.output}")
    print(sim["candidates"].head(10))
