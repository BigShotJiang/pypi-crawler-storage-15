"""
Explicabilidad simple del modelo Ridge:
- coef
- betas estandarizados
- correlación con el target
- varianza de cada feature
- ranking de importancia
"""

import numpy as np
import pandas as pd


def explain_kpi_model(
    X: pd.DataFrame,
    y: pd.Series,
    coefs: pd.Series,
    top: int = 10,
) -> pd.DataFrame:
    """
    Devuelve DataFrame con columnas:
    ['feature','coef','beta_std','abs_beta','corr_with_target','variance','importance_score','rank']
    """
    # Alinear coefs y X
    common = [c for c in X.columns if c in coefs.index]
    if not common:
        return pd.DataFrame(
            columns=[
                "feature",
                "coef",
                "beta_std",
                "abs_beta",
                "corr_with_target",
                "variance",
                "importance_score",
                "rank",
            ]
        )

    Xc = X[common].copy()
    coefs = coefs[common]

    std_x = Xc.std(ddof=0)
    std_y = y.std(ddof=0) + 1e-12

    beta_std = coefs * (std_x / std_y)
    abs_beta = beta_std.abs()

    corr = Xc.apply(lambda col: np.corrcoef(col, y)[0, 1] if col.std(ddof=0) > 0 else 0.0)
    variance = Xc.var(ddof=0)

    importance = abs_beta * corr.abs()

    df_imp = pd.DataFrame(
        {
            "feature": common,
            "coef": coefs.values,
            "beta_std": beta_std.values,
            "abs_beta": abs_beta.values,
            "corr_with_target": corr.values,
            "variance": variance.values,
            "importance_score": importance.values,
        }
    )

    df_imp = df_imp.sort_values(by="importance_score", ascending=False).reset_index(drop=True)
    df_imp["rank"] = np.arange(1, len(df_imp) + 1)

    if top is not None and top > 0:
        df_imp = df_imp.head(top).reset_index(drop=True)

    return df_imp

