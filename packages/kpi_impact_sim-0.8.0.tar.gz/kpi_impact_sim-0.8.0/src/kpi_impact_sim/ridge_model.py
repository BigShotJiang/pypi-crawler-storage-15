import numpy as np
import pandas as pd
from sklearn.linear_model import RidgeCV
from sklearn.model_selection import RepeatedKFold
from sklearn.preprocessing import StandardScaler


def fit_ridge_model(
    X: pd.DataFrame,
    y: pd.Series,
    alphas=None,
    cv_splits: int = 5,
    n_repeats: int = 3,
):
    """
    Entrena RidgeCV con RepeatedKFold y devuelve:
    - model   : modelo entrenado
    - scaler  : StandardScaler usado
    - coefs   : coeficientes desescalados en unidades originales
    - scores  : matriz de scores de CV si está disponible
    """
    if alphas is None:
        alphas = np.logspace(-3, 3, 25)

    rkf = RepeatedKFold(n_splits=cv_splits, n_repeats=n_repeats, random_state=1)

    scaler = StandardScaler()
    Xs = scaler.fit_transform(X)

    model = RidgeCV(alphas=alphas, cv=rkf, scoring="r2")
    model.fit(Xs, y)

    coef_unscaled = pd.Series(model.coef_, index=X.columns) / scaler.scale_

    scores = getattr(model, "cv_values_", None)

    return {
        "model": model,
        "scaler": scaler,
        "coefs": coef_unscaled,
        "scores": scores,
    }

