"""
Pipeline de alto nivel para:
1. Preprocesar DataFrame
2. Entrenar Ridge
3. Simular impacto
4. Explicar modelo
"""

import pandas as pd

from .preprocessing import preprocess_dataframe
from .ridge_model import fit_ridge_model
from .simulate import apply_simulation
from .utils import tipo_variable
from .explain import explain_kpi_model


def run_kpi_analysis(
    df: pd.DataFrame,
    target: str,
    incremento: float,
    top_n: int = 5,
    save_prefix: str = None,
):
    """
    Ejecuta pipeline completo y devuelve un dict con:
    - 'ridge'       : salida de fit_ridge_model
    - 'simulation'  : salida de apply_simulation
    - 'explanation' : DataFrame de explain_kpi_model
    """
    # 1. Preprocesar
    df_proc = preprocess_dataframe(df)
    df_num = df_proc.select_dtypes(include="number")

    if target not in df_num.columns:
        raise ValueError(f"El target '{target}' no existe en el DataFrame procesado.")

    X = df_num.drop(columns=[target])
    y = df_num[target].astype(float)

    # 2. Ridge
    ridge_res = fit_ridge_model(X, y)
    coefs = ridge_res["coefs"]

    # 3. Simulación
    sim = apply_simulation(
        coef_series=coefs,
        df_mes=df_num,
        target=target,
        incremento_pts=incremento,
        tipo_variable_func=tipo_variable,
    )

    # 4. Explicabilidad
    exp = explain_kpi_model(
        X=X,
        y=y,
        coefs=coefs,
        top=top_n,
    )

    if save_prefix:
        sim["candidates"].to_csv(f"{save_prefix}_sim.csv", index=False)
        exp.to_csv(f"{save_prefix}_exp.csv", index=False)

    return {
        "ridge": ridge_res,
        "simulation": sim,
        "explain": exp,
    }

