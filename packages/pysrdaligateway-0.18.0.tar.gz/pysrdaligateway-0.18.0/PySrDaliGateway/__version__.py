"""Version information for PySrDaliGateway."""
# pylint: disable=invalid-name

__version__ = "0.18.0"
