"""IO package initialization"""
