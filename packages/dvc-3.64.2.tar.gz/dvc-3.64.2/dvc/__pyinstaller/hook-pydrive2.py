# ruff: noqa: N999
from PyInstaller.utils.hooks import copy_metadata

datas = copy_metadata("pydrive2")
