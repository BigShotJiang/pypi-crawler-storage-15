#!/bin/bash
apk add --no-cache git
