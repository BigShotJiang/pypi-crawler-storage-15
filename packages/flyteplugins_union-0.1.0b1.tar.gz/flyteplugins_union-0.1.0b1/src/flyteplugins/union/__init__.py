"""Union SDK - Proprietary extensions for Flyte.

This package provides Union-specific functionality on top of the open-source Flyte SDK.
"""
