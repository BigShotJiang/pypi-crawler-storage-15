"""Pattern tests."""
