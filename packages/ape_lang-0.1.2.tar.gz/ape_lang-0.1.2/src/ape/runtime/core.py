"""
Ape Runtime Core

Minimal runtime support for Ape flows and tasks.
This will be extended with logging, determinism tracking, etc.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Dict, Any


@dataclass
class RunContext:
    """
    Runtime context for Ape flows.
    
    Provides execution context and metadata for flow orchestration.
    Future extensions may include:
    - Logging and tracing
    - Determinism enforcement
    - Resource management
    - Error handling
    """
    tenant_id: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
