"""
Ape Package

Main package for the Ape compiler.
"""

__version__ = "0.1.0"
