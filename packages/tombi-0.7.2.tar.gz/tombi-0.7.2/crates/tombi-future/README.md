# Future

This crate is a utility library for cross-platform `BoxFuture` compatibility.

It provides unified Future boxing that works across both WASM and native environments by automatically selecting the appropriate Future type based on feature flags.
