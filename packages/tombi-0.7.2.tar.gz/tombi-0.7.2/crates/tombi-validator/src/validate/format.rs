pub mod email;
pub mod hostname;
pub mod uri;
pub mod uuid;
