# Validator

This crate provides the schema validation for TOML.
