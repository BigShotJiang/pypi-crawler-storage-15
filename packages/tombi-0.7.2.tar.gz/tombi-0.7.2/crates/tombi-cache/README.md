# tombi-cache

This crate provides file-based caching functionality with TTL (Time To Live) support.

The primary targets for caching with this library are schema files, especially those managed in the JSON Schema Store.
