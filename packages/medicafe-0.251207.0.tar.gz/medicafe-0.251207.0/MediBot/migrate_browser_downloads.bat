@echo off
setlocal enabledelayedexpansion

:: Check for silent mode parameter
set "SILENT_MODE=0"
if /i "%1"=="/silent" set "SILENT_MODE=1"

:: Expects these to be set by caller (MediBot.bat):
:: %source_folder% %config_file%

if "%SILENT_MODE%"=="0" (
    echo ========================================
    echo Browser Downloads Migration Processor
    echo ========================================
    echo.
)

:: Validate required variables
if not defined source_folder (
    echo [ERROR] source_folder variable not set
    if "%SILENT_MODE%"=="0" pause
    exit /b 1
)

if not defined config_file (
    echo [ERROR] config_file variable not set
    if "%SILENT_MODE%"=="0" pause
    exit /b 1
)

if not exist "%config_file%" (
    echo [ERROR] Config file not found: %config_file%
    if "%SILENT_MODE%"=="0" pause
    exit /b 1
)

:: Convert config_file to absolute path to handle paths with spaces correctly
for %%F in ("%config_file%") do set "config_file=%%~fF"
:: Verify conversion succeeded (variable should still be defined and non-empty)
if "%config_file%"=="" (
    echo [ERROR] Failed to resolve config_file path
    if "%SILENT_MODE%"=="0" pause
    exit /b 1
)

:: Check if Python is available
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python is not available
    if "%SILENT_MODE%"=="0" pause
    exit /b 1
)

:: Check if migration script exists and normalize to absolute path
set "migration_script=%~dp0migrate_browser_downloads.py"
:: Convert to absolute path to handle paths with spaces correctly
for %%F in ("%migration_script%") do set "migration_script=%%~fF"
:: Verify conversion succeeded
if "%migration_script%"=="" (
    echo [ERROR] Failed to resolve migration_script path
    if "%SILENT_MODE%"=="0" pause
    exit /b 1
)
if not exist "%migration_script%" (
    echo [ERROR] Migration script not found: %migration_script%
    if "%SILENT_MODE%"=="0" pause
    exit /b 1
)

:: Check if update utility exists and normalize to absolute path
set "update_script=%~dp0update_downloaded_email.py"
:: Convert to absolute path to handle paths with spaces correctly
for %%F in ("%update_script%") do set "update_script=%%~fF"
if "%update_script%"=="" (
    :: Reset to original if conversion failed
    set "update_script=%~dp0update_downloaded_email.py"
)
if not exist "%update_script%" (
    echo [WARNING] Update utility not found: %update_script%
    echo Continuing without updating downloaded_emails.txt...
)

if "%SILENT_MODE%"=="0" (
    echo Scanning %source_folder% for browser downloads...
)

:: Call Python script to analyze files and get actions
set "processed_count=0"
set "removed_count=0"
set "moved_count=0"
set "kept_count=0"

for /f "tokens=1,2,* delims=|" %%a in ('python "%migration_script%" --config "%config_file%" --source-folder "%source_folder%"') do (
    set "action=%%a"
    set "source_path=%%b"
    set "dest_path=%%c"

    if "!action!"=="ERROR" (
        echo [ERROR] %%b %%c
        goto :error_exit
    )

    if "!action!"=="REMOVE" (
        if exist "!source_path!" (
            if "%SILENT_MODE%"=="0" (
                echo Removing duplicate: !source_path!
            )
            del /f /q "!source_path!" 2>nul
            if errorlevel 1 (
                echo [WARNING] Failed to remove: !source_path!
            ) else (
                set /a "removed_count+=1"
            )
        )
    )

    if "!action!"=="KEEP" (
        if "%SILENT_MODE%"=="0" (
            echo Keeping file: !source_path!
        )
        set /a "kept_count+=1"
    )

    if "!action!"=="MOVE" (
        if exist "!source_path!" (
            :: Extract filename from source_path before move (for downloaded_emails.txt update)
            for %%f in ("!source_path!") do set "moved_filename=%%~nxf"
            
            :: Ensure destination directory exists
            for %%d in ("!dest_path!") do mkdir "%%~dpd" 2>nul

            if "%SILENT_MODE%"=="0" (
                echo Moving to: !dest_path!
            )
            move "!source_path!" "!dest_path!" >nul 2>&1
            if errorlevel 1 (
                echo [WARNING] Failed to move: !source_path! to !dest_path!
            ) else (
                set /a "moved_count+=1"
                :: Update downloaded_emails.txt for successfully moved DOCX files
                :: Check if this is a DOCX file (CSV files are handled by process_csvs.bat)
                echo !moved_filename! | findstr /i /R "\.docx$" >nul
                if not errorlevel 1 (
                    :: Verify file exists at destination before updating
                    if exist "!dest_path!" (
                        if exist "%update_script%" (
                            python "%update_script%" --config "%config_file%" --filename "!moved_filename!" --verify-path "!dest_path!" >nul 2>&1
                            if errorlevel 1 (
                                if "%SILENT_MODE%"=="0" (
                                    echo [WARNING] Failed to update downloaded_emails.txt for !moved_filename!
                                )
                            )
                        )
                    )
                )
            )
        )
    )

    set /a "processed_count+=1"
)

if "%SILENT_MODE%"=="0" (
    echo.
    echo Migration Summary:
    echo   Files processed: %processed_count%
    echo   Files removed (duplicates): %removed_count%
    echo   Files moved: %moved_count%
    echo   Files kept: %kept_count%
    echo.
    echo Browser downloads migration complete.
) else (
    :: Silent mode - only show summary if files were processed
    if %processed_count% gtr 0 (
        echo [INFO] Browser downloads: %removed_count% removed, %moved_count% moved, %kept_count% kept
    )
)

goto :success_exit

:error_exit
if "%SILENT_MODE%"=="0" pause
exit /b 1

:success_exit
exit /b 0