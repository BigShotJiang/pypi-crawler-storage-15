#!/usr/bin/env python
"""
High-level MediCafe launcher implemented in Python so that the legacy
MediBot.bat wrapper can remain tiny while all meaningful logic is handled
in one place.

The implementation focuses on:
  - Parsing the same flags that MediBot.bat understands today
  - Detecting XP production (F:\ based) versus Win11/dev environments
  - Handling the debug gates, migrations, CSV bootstrap, and menu routing
  - Delegating work to existing MediCafe/MediBot/MediLink modules
  - Providing a single failure wrapper that can trigger error bundles
    and rollback without duplicating the work already done inside the
    deeper scripts such as MediBot.py

Only Python 3.4 compatible language features are used so that the exact
same file can run on both XP SP3 and the Win11 dev workstation.
"""
from __future__ import print_function

import argparse
import hashlib
import json
import os
import sys
import subprocess
import tempfile
import shutil
import time

try:
    from collections import OrderedDict
except ImportError:
    OrderedDict = dict

try:
    # These helpers already exist inside MediCafe and should be reused
    from MediCafe.error_reporter import collect_support_bundle, submit_support_bundle_email
except Exception:
    collect_support_bundle = None
    submit_support_bundle_email = None

try:
    from MediCafe.core_utils import check_internet_connection
except Exception:
    check_internet_connection = None


class LauncherError(Exception):
    """Base class for launcher-specific failures."""


class LauncherArgumentError(LauncherError):
    """Raised when CLI arguments cannot be parsed."""


class LauncherConfigError(LauncherError):
    """Raised when configuration validation fails."""


class LauncherArgumentParser(argparse.ArgumentParser):
    """Argument parser that raises instead of exiting so we can handle errors."""

    def error(self, message):
        raise LauncherArgumentError(message)


class SessionConfig(object):
    """Container for CLI + environment derived options."""

    def __init__(self, args):
        self.skip_startup_csv = args.skip_csv
        self.direct_action = args.direct_action
        self.debug_mode = args.debug_mode
        self.auto_menu_choice = args.auto_choice
        self.auto_menu_source = None

        allow_auto = os.environ.get('MEDICAFE_ALLOW_AUTO')
        env_choice = os.environ.get('MEDICAFE_AUTO_CHOICE')
        if (not self.auto_menu_choice) and allow_auto == '1' and env_choice:
            self.auto_menu_choice = env_choice.strip()
            self.auto_menu_source = 'ENV'
        elif self.auto_menu_choice:
            self.auto_menu_source = 'CLI'


class ErrorBundleCoordinator(object):
    """Centralize bundle creation to avoid duplicates and capture context."""

    def __init__(self):
        self.bundle_path = None
        self.bundle_signature = None

    def collect_once(self, context):
        if collect_support_bundle is None:
            return None
        signature = self._compute_signature(context)
        if signature and self.bundle_path and self.bundle_signature == signature and os.path.exists(self.bundle_path):
            return self.bundle_path
        if signature:
            last_sig = os.environ.get('MEDICAFE_LAST_ERROR_SIGNATURE')
            last_path = os.environ.get('MEDICAFE_LAST_BUNDLE_PATH')
            if last_sig == signature and last_path and os.path.exists(last_path):
                self.bundle_signature = signature
                self.bundle_path = last_path
                return last_path
        try:
            bundle = collect_support_bundle(include_traceback=True, extra_meta=context or {})
        except Exception as err:
            print('Failed to build support bundle: {0}'.format(err))
            return None
        if bundle:
            self.bundle_path = bundle
            self.bundle_signature = signature
            if signature:
                os.environ['MEDICAFE_LAST_ERROR_SIGNATURE'] = signature
            os.environ['MEDICAFE_LAST_BUNDLE_PATH'] = bundle
        return bundle

    def _compute_signature(self, context):
        if not context:
            return None
        try:
            serialized = json.dumps(context, sort_keys=True, default=str)
        except Exception:
            serialized = repr(context)
        return hashlib.sha1(serialized.encode('utf-8', 'ignore')).hexdigest()


def build_arg_parser():
    parser = LauncherArgumentParser(
        description='Python MediCafe UI orchestrator',
        prefix_chars='-/'  # Support both legacy /switch and modern --switch styles
    )
    parser.add_argument('--skip-csv', '/skip-csv', dest='skip_csv', action='store_true',
                        help='Skip automatic CSV processing on startup')
    parser.add_argument('--no-csv', '/no-csv', dest='skip_csv', action='store_true',
                        help='Alias for --skip-csv')
    parser.add_argument('--rollback', '/rollback', dest='direct_action', action='store_const',
                        const='rollback', help='Jump directly to rollback flow')
    parser.add_argument('--troubleshooting', '/troubleshooting', dest='direct_action',
                        action='store_const', const='troubleshooting',
                        help='Jump directly to troubleshooting menu')
    parser.add_argument('--auto-choice', '/auto-choice', dest='auto_choice', default=None,
                        help='Provide a menu choice non-interactively (single use)')
    parser.add_argument('--debug', '/debug', dest='debug_mode', action='store_true',
                        help='Open the debug gate immediately')
    parser.set_defaults(skip_csv=False, debug_mode=False, direct_action=None)
    return parser


class MediCafeOrchestrator(object):
    """Encapsulates startup, menu routing, and failure handling."""

    def __init__(self, session_config):
        self.session = session_config
        # New path calculation (file is now in MediCafe/)
        current_dir = os.path.dirname(os.path.abspath(__file__))
        self.repo_root = os.path.dirname(current_dir)
        self.medibot_dir = os.path.join(self.repo_root, 'MediBot')
        self.cmd_exe = os.environ.get('COMSPEC', 'cmd.exe')
        self.python_exe = os.environ.get('MEDICAFE_PYTHON', sys.executable)
        self.startup_notices = []
        self.bundle_coordinator = ErrorBundleCoordinator()
        
        # Concern #1: Set working directory for consistent relative paths
        # This ensures all relative paths resolve correctly regardless of where
        # the script was invoked from (matches batch file behavior)
        os.chdir(self.repo_root)
        
        self.environment = self._resolve_environment()
        self.update_script = self.environment.get('upgrade_medicafe')
        self.update_available_version = None
        self.medicafe_version = None
        self.prepared = False
        self.failure_bundle_path = None

    # ------------------------------------------------------------------ #
    # Bootstrap helpers
    # ------------------------------------------------------------------ #
    def _resolve_environment(self):
        """Determine directory layout based on legacy F: drive availability."""
        env = {}
        env['source_folder'] = r'C:\MEDIANSI\MediCare'
        env['target_folder'] = r'C:\MEDIANSI\MediCare\CSV'
        env['python_script'] = r'C:\Python34\Lib\site-packages\MediBot\update_json.py'
        env['python_script2'] = r'C:\Python34\Lib\site-packages\MediBot\MediBot.py'
        env['medicafe_package'] = 'medicafe'

        local_upgrade = os.path.join(self.medibot_dir, 'update_medicafe.py')
        legacy_upgrade = r'F:\Medibot\update_medicafe.py'
        env['upgrade_medicafe_local'] = local_upgrade
        env['upgrade_medicafe_legacy'] = legacy_upgrade
        env['upgrade_medicafe'] = None

        env['local_storage_legacy'] = r'F:\Medibot\DOWNLOADS'
        env['local_storage_local'] = os.path.join('MediBot', 'DOWNLOADS')
        env['config_file_legacy'] = r'F:\Medibot\json\config.json'
        env['config_file_local'] = os.path.join('MediBot', 'json', 'config.json')
        env['temp_file_legacy'] = r'F:\Medibot\last_update_timestamp.txt'
        env['temp_file_local'] = os.path.join('MediBot', 'last_update_timestamp.txt')

        # Concern #3: Fixed F: drive detection
        # Check for F: drive existence explicitly, then create folder if needed
        f_drive_exists = os.path.exists(r'F:\\')
        legacy_folder_exists = os.path.exists(r'F:\Medibot')
        
        if f_drive_exists and not legacy_folder_exists:
            try:
                os.makedirs(r'F:\Medibot')
                legacy_folder_exists = True
            except OSError:
                pass  # Might not have permission, continue with local paths

        if legacy_folder_exists:
            env['local_storage_path'] = env['local_storage_legacy']
            env['config_file'] = env['config_file_legacy']
            env['temp_file'] = env['temp_file_legacy']
            
            # Only use legacy updater if it exists
            if os.path.exists(legacy_upgrade):
                env['upgrade_medicafe'] = legacy_upgrade
            elif os.path.exists(local_upgrade):
                env['upgrade_medicafe'] = local_upgrade
            else:
                env['upgrade_medicafe'] = None
        else:
            env['local_storage_path'] = env['local_storage_local']
            env['config_file'] = env['config_file_local']
            env['temp_file'] = env['temp_file_local']
            env['upgrade_medicafe'] = local_upgrade if os.path.exists(local_upgrade) else None

        return env

    def _ensure_directories(self):
        """Make sure relative fallback directories exist."""
        json_dir = os.path.join(self.repo_root, 'MediBot', 'json')
        dl_dir = os.path.join(self.repo_root, 'MediBot', 'DOWNLOADS')
        try:
            if not os.path.exists(json_dir):
                os.makedirs(json_dir)
            if not os.path.exists(dl_dir):
                os.makedirs(dl_dir)
        except Exception as exc:
            self._record_notice('WARNING', 'Failed to create fallback directories: {0}'.format(exc))

    def _record_notice(self, level, message):
        self.startup_notices.append((level, message))
        print('[{0}] {1}'.format(level, message))

    def _copy_update_script_to_legacy(self):
        """Copy update script to F: drive if available."""
        local_path = self.environment.get('upgrade_medicafe_local')
        legacy_path = self.environment.get('upgrade_medicafe_legacy')
        if not local_path or not os.path.exists(local_path):
            return
        
        # Check if F: drive exists
        if not os.path.exists(r'F:\\'):
            return
            
        try:
            legacy_dir = os.path.dirname(legacy_path)
            if not os.path.exists(legacy_dir):
                os.makedirs(legacy_dir)
            shutil.copy2(local_path, legacy_path)
            self.environment['upgrade_medicafe'] = legacy_path
        except Exception as exc:
            self._record_notice('WARNING', 'Could not copy updater to legacy path: {0}'.format(exc))

    def _validate_config(self):
        """Concern #5: Validate config file exists, prompt if missing."""
        config_file = self.environment.get('config_file')
        if not config_file:
            raise LauncherConfigError('Configuration file path could not be resolved.')
            
        if os.path.exists(config_file):
            return
            
        # Config file missing - prompt user
        print('')
        print('Configuration file missing.')
        print('')
        print('Expected configuration file path: {0}'.format(config_file))
        print('')
        print('Would you like to provide an alternate path for the configuration file?')
        choice = self._prompt("Enter 'Y' to provide alternate path, or any other key to exit: ")
        
        if choice and choice.strip().upper() == 'Y':
            while True:
                print('')
                print('Please enter the full path to your configuration file.')
                print('Example: C:\\MediBot\\config\\config.json')
                print('Example with spaces: "G:\\My Drive\\MediBot\\config\\config.json"')
                print('')
                print('Note: If your path contains spaces, please include quotes around the entire path.')
                print('')
                alt_path = self._prompt('Enter configuration file path: ')
                # Remove any surrounding quotes from user input
                alt_path = alt_path.strip().strip('"').strip("'")
                
                if os.path.exists(alt_path):
                    print('Configuration file found at: {0}'.format(alt_path))
                    self.environment['config_file'] = alt_path
                    return True
                else:
                    print('Configuration file not found at: {0}'.format(alt_path))
                    retry = self._prompt('Would you like to try another path? (Y/N): ')
                    if not retry or retry.strip().upper() != 'Y':
                        break
        raise LauncherConfigError('Configuration file is required but was not located: {0}'.format(config_file))

    def _determine_medicafe_version(self):
        try:
            cmd = [sys.executable, '-c',
                   'import pkg_resources; '
                   'print("MediCafe=="+pkg_resources.get_distribution("medicafe").version)']
            temp = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=self.repo_root)
            stdout, _ = temp.communicate()
            if stdout:
                decoded = stdout.decode('ascii', 'ignore').strip()
                parts = decoded.split('==')
                if len(parts) == 2:
                    self.medicafe_version = parts[1]
        except Exception:
            self.medicafe_version = 'unknown'

    def _check_for_updates(self):
        script_path = self.environment.get('upgrade_medicafe')
        if not script_path or not os.path.exists(script_path):
            return
        temp_file = None
        try:
            temp_file = tempfile.NamedTemporaryFile(delete=False)
            temp_file.close()
            cmd = [self.python_exe, script_path, '--check-only']
            with open(temp_file.name, 'w+b') as handle:
                proc = subprocess.Popen(cmd, stdout=handle, stderr=subprocess.PIPE, cwd=self.repo_root)
                _, stderr = proc.communicate()
                if proc.returncode != 0 and stderr:
                    self._record_notice('WARNING', 'Update check failed: {0}'.format(stderr))
            with open(temp_file.name, 'r') as reader:
                for line in reader:
                    line = line.strip()
                    if line.startswith('UPDATE_AVAILABLE:'):
                        self.update_available_version = line.split(':', 1)[1].strip()
        except Exception as exc:
            self._record_notice('WARNING', 'Unable to perform update check: {0}'.format(exc))
        finally:
            if temp_file and os.path.exists(temp_file.name):
                os.unlink(temp_file.name)

    def prepare(self):
        """Run one-time bootstrap steps."""
        if self.prepared:
            return
        if os.name != 'nt':
            self._record_notice('WARNING', 'This launcher expects Windows. Some features are disabled.')
        self._ensure_directories()
        self._copy_update_script_to_legacy()
        # Concern #5: Validate config before proceeding
        self._validate_config()
        self._determine_medicafe_version()
        self._check_for_updates()
        self.prepared = True

    # ------------------------------------------------------------------ #
    # Main entry routing
    # ------------------------------------------------------------------ #
    def run(self):
        try:
            self.prepare()
            if self.session.direct_action == 'rollback':
                self.forced_version_rollback()
                return
            if self.session.direct_action == 'troubleshooting':
                self.troubleshooting_menu()
                return
            if self.session.debug_mode:
                self.debug_menu()
                return
            self.start_normal_mode()
        except KeyboardInterrupt:
            print('\nUser interrupted execution.')
        except Exception as exc:
            # Concern #9: Only bundle on orchestrator exceptions, not subprocess failures
            self.handle_fatal_error(exc)

    def start_normal_mode(self):
        self._run_startup_tasks()
        self.main_menu_loop()

    def _run_startup_tasks(self):
        self._run_download_migration()
        if not self.session.skip_startup_csv:
            self._launch_startup_csv()
        else:
            self._record_notice('INFO', 'Startup CSV processing skipped by flag.')

    # ------------------------------------------------------------------ #
    # Debug / Troubleshooting
    # ------------------------------------------------------------------ #
    def debug_menu(self):
        print('')
        print('========================================')
        print('       MEDICAFE DEBUG OPTIONS          ')
        print('========================================')
        print('1. Normal Mode (continue)')
        print('2. Run interactive debug suite')
        print('3. Run non-interactive debug suite')
        print('4. Emergency rollback')
        print('5. Troubleshooting toolkit')
        choice = raw_input('Choose an option (1-5): ') if sys.version_info[0] < 3 else input('Choose an option (1-5): ')
        if choice == '2':
            self._call_batch('full_debug_suite.bat', ['/interactive'])
        elif choice == '3':
            self._call_batch('full_debug_suite.bat', [])
        elif choice == '4':
            self.forced_version_rollback()
            return
        elif choice == '5':
            self.troubleshooting_menu()
            return
        self.start_normal_mode()

    def troubleshooting_menu(self):
        while True:
            self._clear_console()
            self._print_legacy_banner('MediCafe Troubleshooting Toolkit', width=40)
            self._print_troubleshooting_group('Reporting & Logs', [
                '1)  Submit error report (email)',
                '2)  View latest run log',
                '3)  View WinSCP transfer logs',
            ])
            self._print_troubleshooting_group('Logging Controls', [
                '4)  Toggle performance logging (session)',
                '5)  Toggle verbose logging (session)',
            ])
            self._print_troubleshooting_group('Cache & Token Maintenance', [
                '6)  Manage Python cache',
                '7)  Reset Gmail OAuth token',
            ])
            self._print_troubleshooting_group('Data Intake', [
                '8)  Force CSV intake (includes deductible cache build)',
            ])
            self._print_troubleshooting_group('Safety & Recovery', [
                '9)  Emergency MediCafe rollback',
            ])
            self._print_troubleshooting_group('Advanced Tools', [
                '10) Launch config editor',
            ])
            print('Navigation')
            print(' 11) Return to Main Menu')
            print('')
            choice = self._prompt('Enter your choice: ')
            if choice == '1':
                self.run_medicafe_command('send_error_report')
            elif choice == '2':
                self.open_latest_log()
            elif choice == '3':
                self.open_winscp_logs()
            elif choice == '4':
                self.toggle_session_flag('MEDICAFE_PERFORMANCE_LOGGING')
            elif choice == '5':
                self.toggle_session_flag('MEDICAFE_VERBOSE_LOGGING')
            elif choice == '6':
                self.clear_cache_menu()
            elif choice == '7':
                self.force_gmail_reauth()
            elif choice == '8':
                self.process_csvs()
            elif choice == '9':
                self.forced_version_rollback()
            elif choice == '10':
                self._call_batch('config_editor.bat', [])
            elif choice == '11':
                return
            else:
                print('Invalid choice.')

    # ------------------------------------------------------------------ #
    # Menu + options
    # ------------------------------------------------------------------ #
    def main_menu_loop(self):
        while True:
            self._clear_console()
            self._print_legacy_banner('MediCafe Launcher')
            self._print_version_details()
            self._print_welcome_block()
            self._print_main_menu_options()
            choice = self._get_menu_choice()

            if choice == '1':
                self.run_update_flow()
            elif choice == '2':
                self.download_emails()
            elif choice == '3':
                self.run_medicafe_command('medilink')
            elif choice == '4':
                self.run_medicafe_command('claims_status')
            elif choice == '5':
                self.run_medicafe_command('deductible')
            elif choice == '6':
                self.run_medicafe_command('medibot')
            elif choice == '7':
                self.troubleshooting_menu()
            elif choice == '8':
                print('Exiting MediCafe UI.')
                return
            else:
                print('Invalid choice.')
                time.sleep(1.5)

    def _prompt(self, message):
        if sys.version_info[0] < 3:
            return raw_input(message)
        return input(message)

    def _clear_console(self):
        command = 'cls' if os.name == 'nt' else 'clear'
        try:
            os.system(command)
        except Exception:
            pass

    # ------------------------------------------------------------------ #
    # Feature actions
    # ------------------------------------------------------------------ #
    def run_update_flow(self):
        script_path = self.environment.get('upgrade_medicafe')
        if not script_path or not os.path.exists(script_path):
            self._record_notice('ERROR', 'Update script not found.')
            return
        runner_path = self._build_update_runner(script_path)
        if not runner_path:
            self._record_notice('ERROR', 'Unable to create update runner.')
            return
        print('Launching MediCafe updater...')
        subprocess.Popen([self.cmd_exe, '/c', runner_path], cwd=self.repo_root)
        sys.exit(0)

    def _build_update_runner(self, script_path):
        """Build temporary batch script to run updater. Concerns #4 and #6."""
        temp_dir = os.environ.get('TEMP') or self.repo_root
        if not os.path.exists(temp_dir):
            try:
                os.makedirs(temp_dir)
            except Exception:
                temp_dir = self.repo_root
        runner = os.path.join(temp_dir, 'medicafe_update_runner_{0}.cmd'.format(os.getpid()))
        try:
            # Quote python_exe to handle paths with spaces
            python_exe_quoted = '"{0}"'.format(self.python_exe)
            script_path_quoted = '"{0}"'.format(script_path)
            batch_path_quoted = '"{0}"'.format(self._batch_path())
            
            with open(runner, 'w') as handle:
                handle.write('@echo off\n')
                handle.write('setlocal enabledelayedexpansion\n')
                handle.write('set "MEDIBOT_PATH={0}"\n'.format(batch_path_quoted))
                handle.write('ping 127.0.0.1 -n 3 >nul\n')
                # Concern #4: Use resolved python path, not literal 'python'
                handle.write('{0} {1}\n'.format(python_exe_quoted, script_path_quoted))
                handle.write('if errorlevel 1 goto failure\n')
                handle.write('if exist !MEDIBOT_PATH! start "" !MEDIBOT_PATH!\n')
                handle.write('exit /b 0\n')
                handle.write(':failure\n')
                handle.write('echo Update failed. Press any key to close...\n')
                handle.write('pause >nul\n')
                handle.write('exit /b 1\n')
            return runner
        except Exception as exc:
            self._record_notice('ERROR', 'Failed to write runner script: {0}'.format(exc))
            return None

    def download_emails(self):
        self.run_medicafe_command('download_emails')
        self.process_csvs(silent=True)

    def run_medicafe_command(self, command, extra_args=None):
        """Run a MediCafe CLI command. Concern #9: Don't bundle on subprocess failures."""
        args = [sys.executable, '-m', 'MediCafe', command]
        if extra_args:
            args.extend(extra_args)
        # Concern #9: Subprocess failures are expected, just log them
        rc = subprocess.call(args, cwd=self.repo_root)
        if rc != 0:
            self._record_notice('ERROR', 'Command {0} failed with code {1}'.format(command, rc))
        return rc

    def process_csvs(self, silent=False):
        flag = '/silent' if silent else ''
        args = [arg for arg in [flag] if arg]
        self._call_batch('process_csvs.bat', args)

    def _run_download_migration(self):
        self._call_batch('migrate_browser_downloads.bat', ['/silent'])

    def _launch_startup_csv(self):
        """Launch CSV processing in background. Concern #7: Visibility is acceptable parity."""
        script = os.path.join(self.medibot_dir, 'process_csvs.bat')
        if not os.path.exists(script):
            self._record_notice('WARNING', 'process_csvs.bat not found.')
            return
        if os.name != 'nt':
            self._record_notice('INFO', 'Non-Windows platform: running CSV inline.')
            self.process_csvs(silent=True)
            return
        try:
            # Use explicit quoting so paths with spaces survive cmd.exe parsing.
            script_quoted = '"{0}"'.format(script)
            cmd = [self.cmd_exe, '/c', 'start', '""', '/MIN', script_quoted, '/silent']
            subprocess.Popen(cmd, cwd=self.repo_root)
        except Exception:
            self._record_notice('WARNING', 'Failed to start CSV window. Running inline.')
            self.process_csvs(silent=True)

    def open_latest_log(self):
        logs_dir = self.environment.get('local_storage_path')
        if not logs_dir:
            print('Log directory unknown.')
            return
        logs_dir = self._make_absolute(logs_dir)
        if not os.path.exists(logs_dir):
            print('Log directory missing: {0}'.format(logs_dir))
            return
        latest = None
        for item in sorted(os.listdir(logs_dir), reverse=True):
            if item.lower().endswith('.log'):
                latest = os.path.join(logs_dir, item)
                break
        if not latest:
            print('No log files found in {0}'.format(logs_dir))
            return
        self._launch_viewer(latest)

    def open_winscp_logs(self):
        base = self.environment.get('local_storage_path')
        if not base:
            return
        base = self._make_absolute(base)
        download = os.path.join(base, 'winscp_download.log')
        upload = os.path.join(base, 'winscp_upload.log')
        opened = False
        for path in [download, upload]:
            if os.path.exists(path):
                self._launch_viewer(path)
                opened = True
        if not opened:
            print('No WinSCP logs found at {0}'.format(base))

    def clear_cache_menu(self):
        print('')
        print('1. Quick clear (compileall + delete __pycache__)')
        print('2. Deep clear (update_medicafe.py)')
        print('3. Back')
        choice = self._prompt('Choice: ')
        if choice == '1':
            self._call_batch('clear_cache.bat', ['--quick'])
        elif choice == '2':
            self._call_batch('clear_cache.bat', ['--deep'])

    def force_gmail_reauth(self):
        candidates = [
            os.path.join(self.repo_root, 'MediLink', 'token.json'),
            os.path.join(self.repo_root, 'token.json')
        ]
        cleared = False
        for path in candidates:
            if os.path.exists(path):
                try:
                    os.remove(path)
                    print('[OK] Removed {0}'.format(path))
                    cleared = True
                except Exception as exc:
                    print('[WARN] Could not remove {0}: {1}'.format(path, exc))
        if not cleared:
            print('No Gmail tokens found to remove.')

    def toggle_session_flag(self, env_var):
        current = os.environ.get(env_var, '0')
        new_value = '0' if current == '1' else '1'
        os.environ[env_var] = new_value
        print('{0} set to {1} for this session.'.format(env_var, new_value))

    # ------------------------------------------------------------------ #
    # Rollback + error handling
    # ------------------------------------------------------------------ #
    def forced_version_rollback(self, version='0.251120.0'):
        package = self.environment.get('medicafe_package', 'medicafe')
        target = '{0}=={1}'.format(package, version)
        print('Forcing reinstall of {0}'.format(target))
        rc = subprocess.call([self.python_exe, '-m', 'pip', 'install',
                              '--no-deps', '--force-reinstall', target], cwd=self.repo_root)
        if rc != 0:
            print('force-reinstall not supported, attempting uninstall/install fallback.')
            subprocess.call([self.python_exe, '-m', 'pip', 'uninstall', '-y', package], cwd=self.repo_root)
            rc = subprocess.call([self.python_exe, '-m', 'pip', 'install', '--no-deps', target], cwd=self.repo_root)
        if rc == 0:
            print('Rollback complete.')
        else:
            print('Rollback failed. Check logs for details.')

    def handle_fatal_error(self, exc):
        """Handle fatal orchestrator errors. Concern #9: Only bundle orchestrator exceptions."""
        print('=' * 60)
        print('MEDICAFE ORCHESTRATOR FAILURE')
        print('=' * 60)
        if isinstance(exc, LauncherConfigError):
            print('Configuration error: {0}'.format(exc))
            print('Please update your config file path or restore the expected file.')
        else:
            print('Error: {0}'.format(exc))
        print('=' * 60)
        context = self._build_bundle_context(exc)
        self.failure_bundle_path = self._collect_error_bundle(context)
        print('Choose how to proceed:')
        print('1. Attempt rollback')
        print('2. Exit without changes')
        choice = self._prompt('Selection: ')
        if choice == '1':
            self.forced_version_rollback()
        else:
            print('Exiting without rollback.')

    def _collect_error_bundle(self, context):
        """Collect error bundle for orchestrator failures only."""
        bundle = self.bundle_coordinator.collect_once(context)
        if not bundle:
            return None
        print('Error bundle available at {0}'.format(bundle))
        if submit_support_bundle_email and check_internet_connection:
            try:
                if check_internet_connection():
                    sent = submit_support_bundle_email(bundle)
                    if sent:
                        os.remove(bundle)
                    else:
                        print('Bundle send failed; file retained.')
            except Exception:
                print('Bundle transmission error; file retained.')
        return bundle

    def _build_bundle_context(self, exc):
        """Assemble structured metadata for the error bundle."""
        try:
            session_info = {
                'skip_startup_csv': bool(self.session.skip_startup_csv),
                'direct_action': self.session.direct_action,
                'debug_mode': bool(self.session.debug_mode),
                'auto_choice_source': self.session.auto_menu_source,
            }
        except Exception:
            session_info = {}
        env_snapshot = {
            'config_file': self.environment.get('config_file'),
            'local_storage_path': self.environment.get('local_storage_path'),
            'temp_file': self.environment.get('temp_file'),
            'upgrade_script': self.environment.get('upgrade_medicafe'),
            'repo_root': self.repo_root,
        }
        launcher_state = {
            'medicafe_version': self.medicafe_version,
            'update_available_version': self.update_available_version,
            'python_executable': sys.executable,
            'cwd': os.getcwd(),
            'time': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        }
        notices = ['[{0}] {1}'.format(level, msg) for level, msg in self.startup_notices]
        context = {
            'exception_type': exc.__class__.__name__,
            'exception_message': str(exc),
            'session': session_info,
            'environment': env_snapshot,
            'launcher_state': launcher_state,
            'startup_notices': notices
        }
        return context

    # ------------------------------------------------------------------ #
    # Utility helpers
    # ------------------------------------------------------------------ #
    def _batch_path(self):
        """Get path to MediBot.bat file."""
        return os.path.join(self.medibot_dir, 'MediBot.bat')

    def _call_batch(self, script_name, args):
        """Call a batch script. Concern #2: Quote paths for spaces."""
        script = os.path.join(self.medibot_dir, script_name)
        if not os.path.exists(script):
            self._record_notice('WARNING', '{0} not found.'.format(script_name))
            return
        # Quote script path so cmd.exe treats it as a single argument even with spaces.
        script_quoted = '"{0}"'.format(script)
        command = [self.cmd_exe, '/c', 'call', script_quoted]
        if args:
            command.extend(args)
        # Always run from repo_root for consistent working directory
        subprocess.call(command, cwd=self.repo_root)

    def _make_absolute(self, path_value):
        """Convert relative path to absolute using repo_root."""
        if os.path.isabs(path_value):
            return path_value
        return os.path.abspath(os.path.join(self.repo_root, path_value))

    def _launch_viewer(self, path):
        """Launch default text viewer for a file."""
        if os.name != 'nt':
            print('File: {0}'.format(path))
            return
        try:
            subprocess.Popen(['notepad.exe', path])
        except Exception:
            subprocess.Popen(['write.exe', path])

    # ------------------------------------------------------------------ #
    # Console rendering helpers (legacy ASCII parity)
    # ------------------------------------------------------------------ #
    def _print_legacy_banner(self, title, width=39):
        line = '=' * width
        print(line)
        print(title.center(width))
        print(line)
        print('')

    def _print_welcome_block(self):
        width = 62
        separator = '-' * width
        welcome = './/*  Welcome to MediCafe  *\\\\.'
        print(separator)
        print(welcome.center(width))
        print(separator)
        print('')

    def _print_version_details(self):
        print('Version: {0}'.format(self.medicafe_version or 'unknown'))
        if self.update_available_version:
            print('[UPDATE AVAILABLE] {0}'.format(self.update_available_version))
        if self.startup_notices:
            print('')
            for level, msg in self.startup_notices:
                print('[{0}] {1}'.format(level, msg))
            print('-' * 60)
        print('')

    def _print_main_menu_options(self):
        options = [
            ('1', 'Update MediCafe'),
            ('2', 'Download Email de Carol'),
            ('3', 'MediLink Claims'),
            ('4', '[United] Claims Status'),
            ('5', '[United] Deductible'),
            ('6', 'Run MediBot'),
            ('7', 'Troubleshooting'),
            ('8', 'Exit'),
        ]
        print('Please select an option:')
        print('')
        for number, label in options:
            print(' {0}. {1}'.format(number, label))
            print('')

    def _get_menu_choice(self):
        if self.session.auto_menu_choice:
            choice = self.session.auto_menu_choice
            source = self.session.auto_menu_source or 'CLI'
            print('[AUTO source={0}] Using menu choice {1}'.format(source, choice))
            self.session.auto_menu_choice = None
            self.session.auto_menu_source = None
            return choice
        return self._prompt('Enter your choice: ')

    def _print_troubleshooting_group(self, heading, lines):
        print(heading)
        for entry in lines:
            print('  {0}'.format(entry))
        print('')


def main():
    """Main entry point for launcher."""
    parser = build_arg_parser()
    try:
        args, unknown = parser.parse_known_args(sys.argv[1:])
    except LauncherArgumentError as err:
        print('')
        print('[LAUNCHER] Invalid option: {0}'.format(err))
        print('Please review the supported flags below and try again.')
        print('')
        parser.print_help()
        return 2
    if unknown:
        print('')
        print('[LAUNCHER] Ignoring unsupported option(s): {0}'.format(', '.join(unknown)))
        print('         Use --help for the list of accepted flags.')
        print('')
    session = SessionConfig(args)
    orchestrator = MediCafeOrchestrator(session)
    orchestrator.run()


if __name__ == '__main__':
    main()
