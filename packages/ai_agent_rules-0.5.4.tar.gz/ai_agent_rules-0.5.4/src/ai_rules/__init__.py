"""AI Rules - Manage AI agent configurations through symlinks."""

__version__ = "0.4.1"
