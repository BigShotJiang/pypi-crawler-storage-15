### Added
- **Sanitize command**
  - Added `--exclude` flag to run all sanitization actions except specified ones (e.g., `--actions all --exclude standardize_folder_names set_first_page_as_active`)
  - Added `collapse_filter_pane` action to collapse the filter pane
  - Added `reset_filter_pane_width` action to reset filter pane width on all pages