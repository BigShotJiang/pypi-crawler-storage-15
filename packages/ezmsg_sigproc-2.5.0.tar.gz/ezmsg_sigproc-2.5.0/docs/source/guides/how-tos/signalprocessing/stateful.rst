How to implement a stateful signal processor in ezmsg?
###############################################################

(under construction)