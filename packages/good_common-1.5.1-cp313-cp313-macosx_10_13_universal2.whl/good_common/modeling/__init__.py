from ._typing import TypeInfo

__all__ = [
    "TypeInfo",
]
