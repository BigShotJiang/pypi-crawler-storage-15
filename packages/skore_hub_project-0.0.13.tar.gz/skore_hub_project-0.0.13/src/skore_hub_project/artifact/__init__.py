"""Class definition of the payload used to upload and send an artifact to ``hub``."""
