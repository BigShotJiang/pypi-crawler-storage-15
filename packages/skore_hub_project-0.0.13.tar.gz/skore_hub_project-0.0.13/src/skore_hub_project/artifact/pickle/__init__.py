"""Definition of the payload used to associate the pickled report with the report."""

from .pickle import Pickle

__all__ = ["Pickle"]
