# CrossCompute Macros

Here are reusable functions and classes that are primarily used by the CrossCompute Software Development Kit and CrossCompute Platform.
