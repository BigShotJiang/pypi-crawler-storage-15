# Administration

This section contains information on managing your Synapse homeserver. This includes:

* Managing users, rooms and media via the Admin API.
* Setting up metrics and monitoring to give you insight into your homeserver's health.
* Configuring structured logging.