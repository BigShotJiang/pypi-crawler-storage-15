This directory contains changelogs for previous years.
