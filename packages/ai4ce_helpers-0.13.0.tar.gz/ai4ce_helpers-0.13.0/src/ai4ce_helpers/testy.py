import toml
import httpx

def get_toml_from_url(url: str) -> dict:
    """
    Get a TOML file from a URL.
    """
    with httpx.Client() as client:
        response = client.get(url)
        response.raise_for_status()
        return toml.loads(response.text)

def get_universal_sysarch_comp_mapping() -> dict:

    url = "https://gitlab.com/ai4ce/AI4CE/-/raw/main/ai4ce/system_tags.toml?ref_type=heads"
    system_tags: dict = get_toml_from_url(url=url)

    response: dict = {}
    response["cubesat"] = {}

    for key, value in system_tags["CubeSat"].items():
        if key.isupper():  # subsystems are all uppercase
            response["cubesat"][key] = value


    pass
print(get_universal_sysarch_comp_mapping())