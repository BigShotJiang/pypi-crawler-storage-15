from __future__ import annotations

from typing import Any, TYPE_CHECKING

from wisent.core.contrastive_pairs.core.pair import ContrastivePair
from wisent.core.contrastive_pairs.core.response import NegativeResponse, PositiveResponse
from wisent.core.contrastive_pairs.lm_eval_pairs.atoms import LMEvalBenchmarkExtractor
from wisent.core.cli_logger import setup_logger, bind

if TYPE_CHECKING:
    from lm_eval.api.task import ConfigurableTask


__all__ = ["AfrimgsmExtractor"]
_LOG = setup_logger(__name__)

task_names = ("afrimgsm_direct_amh",)

evaluator_name = "generation"


class AfrimgsmExtractor(LMEvalBenchmarkExtractor):
    """Extractor for Afrimgsm benchmark - math word problems with numeric answers."""

    def extract_contrastive_pairs(
        self,
        lm_eval_task_data: ConfigurableTask,
        limit: int | None = None,
        preferred_doc: str | None = None,
    ) -> list[ContrastivePair]:
        log = bind(_LOG, task=getattr(lm_eval_task_data, "NAME", "unknown"))
        max_items = self._normalize_limit(limit)
        docs = self.load_docs(lm_eval_task_data, max_items, preferred_doc=preferred_doc)
        pairs: list[ContrastivePair] = []
        log.info("Extracting contrastive pairs", extra={"doc_count": len(docs)})

        for doc in docs:
            pair = self._extract_pair_from_doc(doc)
            if pair is not None:
                pairs.append(pair)
                if max_items is not None and len(pairs) >= max_items:
                    break

        if not pairs:
            task_name = getattr(lm_eval_task_data, "NAME", type(lm_eval_task_data).__name__)
            log.warning("No valid pairs extracted", extra={"task": task_name})

        return pairs

    def _extract_pair_from_doc(self, doc: dict[str, Any]) -> ContrastivePair | None:
        """
        Extract contrastive pair from Afrimgsm doc.
        Schema: {'question': str, 'answer_number': int/float, 'answer': None, 'equation_solution': None}
        """
        log = bind(_LOG, doc_id=doc.get("id", "unknown"))

        try:
            question = doc.get("question", "").strip()

            # Get the correct numeric answer
            answer_number = doc.get("answer_number")

            if not question or answer_number is None:
                log.debug("Skipping doc due to missing/invalid fields", extra={"doc": doc})
                return None

            # Convert answer to string
            correct = str(answer_number)

            # Generate an incorrect answer (different from correct)
            # Try multiple strategies to ensure the incorrect answer is different
            try:
                num_val = float(answer_number)
                if num_val == 0:
                    incorrect = "1"
                elif num_val > 0:
                    incorrect = str(int(num_val + 1))
                else:
                    incorrect = str(int(num_val - 1))
            except (ValueError, TypeError):
                # If not a valid number, use a generic wrong answer
                incorrect = "0"

            # Ensure incorrect is actually different
            if incorrect == correct:
                incorrect = str(int(float(correct)) * 2) if float(correct) != 0 else "1"

            metadata = {"label": "afrimgsm"}

            return self._build_pair(
                question=question,
                correct=correct,
                incorrect=incorrect,
                metadata=metadata,
            )

        except Exception as exc:
            log.error("Error extracting pair from doc", exc_info=exc, extra={"doc": doc})
            return None

    @staticmethod
    def _build_pair(
        question: str,
        correct: str,
        incorrect: str,
        metadata: dict[str, Any] | None = None,
    ) -> ContrastivePair:
        positive_response = PositiveResponse(model_response=correct)
        negative_response = NegativeResponse(model_response=incorrect)
        return ContrastivePair(prompt=question, positive_response=positive_response, negative_response=negative_response, label=metadata.get("label"))
