# Copyright (c) Subzero Labs, Inc.
# SPDX-License-Identifier: Apache-2.0

"""
Type definitions and stubs for the Rialo Python CDK.
"""

from typing import Any, Awaitable, Dict, List, Optional, Tuple, Union
from typing_extensions import Protocol

class KeypairProtocol(Protocol):
    """Protocol for objects that can act as keypairs."""
    
    def sign(self, message: bytes) -> bytes:
        """Sign a message."""
        ...
    
    def public_key(self) -> bytes:
        """Get the public key."""
        ...

class WalletProviderProtocol(Protocol):
    """Protocol for wallet providers."""
    
    async def create(self, name: str, password: str) -> Any:
        """Create a new wallet."""
        ...
    
    async def load(self, name: str, password: str) -> Any:
        """Load an existing wallet."""
        ...
    
    async def exists(self, name: str) -> bool:
        """Check if a wallet exists."""
        ...
    
    async def list(self) -> List[str]:
        """List all wallet names."""
        ...

class RpcClientProtocol(Protocol):
    """Protocol for RPC clients."""

    async def get_balance(self, pubkey: Any) -> int:
        """Get account balance."""
        ...

    async def send_transaction(self, transaction: Any, config: Optional[Dict[str, Any]] = None) -> Any:
        """Send a transaction."""
        ...

# Type aliases
Pubkey = Union[str, bytes]
HashValue = Union[str, bytes]
SignatureValue = Union[str, bytes]
Kelvin = int  # Amount in kelvin (smallest unit)
RLO = Union[int, float]  # Amount in RLO