"""
Edge TTS provider implementation
"""

from vixio.providers.edge_tts.provider import EdgeTTSProvider

__all__ = ["EdgeTTSProvider"]

