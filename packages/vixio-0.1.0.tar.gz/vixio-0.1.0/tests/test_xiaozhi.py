"""
Xiaozhi protocol specific tests
"""

import pytest

# TODO: Implement Xiaozhi protocol tests

