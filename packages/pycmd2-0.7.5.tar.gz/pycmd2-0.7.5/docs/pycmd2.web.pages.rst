pycmd2.web.pages package
========================

Submodules
----------

pycmd2.web.pages.main\_page module
----------------------------------

.. automodule:: pycmd2.web.pages.main_page
   :members:
   :undoc-members:
   :show-inheritance:

pycmd2.web.pages.settings\_page module
--------------------------------------

.. automodule:: pycmd2.web.pages.settings_page
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: pycmd2.web.pages
   :members:
   :undoc-members:
   :show-inheritance:
