pycmd2.web.apps.demos package
=============================

Submodules
----------

pycmd2.web.apps.demos.dbtable module
------------------------------------

.. automodule:: pycmd2.web.apps.demos.dbtable
   :members:
   :undoc-members:
   :show-inheritance:

pycmd2.web.apps.demos.downloader module
---------------------------------------

.. automodule:: pycmd2.web.apps.demos.downloader
   :members:
   :undoc-members:
   :show-inheritance:

pycmd2.web.apps.demos.mandelbrot module
---------------------------------------

.. automodule:: pycmd2.web.apps.demos.mandelbrot
   :members:
   :undoc-members:
   :show-inheritance:

pycmd2.web.apps.demos.wavegraph module
--------------------------------------

.. automodule:: pycmd2.web.apps.demos.wavegraph
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: pycmd2.web.apps.demos
   :members:
   :undoc-members:
   :show-inheritance:
