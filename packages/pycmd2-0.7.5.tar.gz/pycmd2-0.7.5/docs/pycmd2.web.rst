pycmd2.web package
==================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   pycmd2.web.apps
   pycmd2.web.components
   pycmd2.web.pages

Submodules
----------

pycmd2.web.cli module
---------------------

.. automodule:: pycmd2.web.cli
   :members:
   :undoc-members:
   :show-inheritance:

pycmd2.web.component module
---------------------------

.. automodule:: pycmd2.web.component
   :members:
   :undoc-members:
   :show-inheritance:

pycmd2.web.config module
------------------------

.. automodule:: pycmd2.web.config
   :members:
   :undoc-members:
   :show-inheritance:

pycmd2.web.routes module
------------------------

.. automodule:: pycmd2.web.routes
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: pycmd2.web
   :members:
   :undoc-members:
   :show-inheritance:
