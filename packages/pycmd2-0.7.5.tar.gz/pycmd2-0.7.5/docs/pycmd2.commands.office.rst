pycmd2.commands.office package
==============================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   pycmd2.commands.office.mindnote
   pycmd2.commands.office.pdftools
   pycmd2.commands.office.tests
   pycmd2.commands.office.todo

Submodules
----------

pycmd2.commands.office.doc\_diff module
---------------------------------------

.. automodule:: pycmd2.commands.office.doc_diff
   :members:
   :undoc-members:
   :show-inheritance:

pycmd2.commands.office.image\_gray module
-----------------------------------------

.. automodule:: pycmd2.commands.office.image_gray
   :members:
   :undoc-members:
   :show-inheritance:

pycmd2.commands.office.image\_to\_pdf module
--------------------------------------------

.. automodule:: pycmd2.commands.office.image_to_pdf
   :members:
   :undoc-members:
   :show-inheritance:

pycmd2.commands.office.llama\_client module
-------------------------------------------

.. automodule:: pycmd2.commands.office.llama_client
   :members:
   :undoc-members:
   :show-inheritance:

pycmd2.commands.office.llama\_quantize module
---------------------------------------------

.. automodule:: pycmd2.commands.office.llama_quantize
   :members:
   :undoc-members:
   :show-inheritance:

pycmd2.commands.office.llama\_server module
-------------------------------------------

.. automodule:: pycmd2.commands.office.llama_server
   :members:
   :undoc-members:
   :show-inheritance:

pycmd2.commands.office.pdf\_crypt module
----------------------------------------

.. automodule:: pycmd2.commands.office.pdf_crypt
   :members:
   :undoc-members:
   :show-inheritance:

pycmd2.commands.office.pdf\_merge module
----------------------------------------

.. automodule:: pycmd2.commands.office.pdf_merge
   :members:
   :undoc-members:
   :show-inheritance:

pycmd2.commands.office.pdf\_split module
----------------------------------------

.. automodule:: pycmd2.commands.office.pdf_split
   :members:
   :undoc-members:
   :show-inheritance:

pycmd2.commands.office.video\_converter module
----------------------------------------------

.. automodule:: pycmd2.commands.office.video_converter
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: pycmd2.commands.office
   :members:
   :undoc-members:
   :show-inheritance:
