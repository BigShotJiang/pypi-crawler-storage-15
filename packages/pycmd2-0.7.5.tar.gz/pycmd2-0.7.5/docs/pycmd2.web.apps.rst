pycmd2.web.apps package
=======================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   pycmd2.web.apps.demos
   pycmd2.web.apps.help
   pycmd2.web.apps.lscopt
   pycmd2.web.apps.office

Module contents
---------------

.. automodule:: pycmd2.web.apps
   :members:
   :undoc-members:
   :show-inheritance:
