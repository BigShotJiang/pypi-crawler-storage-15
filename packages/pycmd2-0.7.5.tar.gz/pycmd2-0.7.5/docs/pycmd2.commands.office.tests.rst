pycmd2.commands.office.tests package
====================================

Submodules
----------

pycmd2.commands.office.tests.test\_image\_gray module
-----------------------------------------------------

.. automodule:: pycmd2.commands.office.tests.test_image_gray
   :members:
   :undoc-members:
   :show-inheritance:

pycmd2.commands.office.tests.test\_image\_to\_pdf module
--------------------------------------------------------

.. automodule:: pycmd2.commands.office.tests.test_image_to_pdf
   :members:
   :undoc-members:
   :show-inheritance:

pycmd2.commands.office.tests.test\_pdf\_crypt module
----------------------------------------------------

.. automodule:: pycmd2.commands.office.tests.test_pdf_crypt
   :members:
   :undoc-members:
   :show-inheritance:

pycmd2.commands.office.tests.test\_pdf\_merge module
----------------------------------------------------

.. automodule:: pycmd2.commands.office.tests.test_pdf_merge
   :members:
   :undoc-members:
   :show-inheritance:

pycmd2.commands.office.tests.test\_todo module
----------------------------------------------

.. automodule:: pycmd2.commands.office.tests.test_todo
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: pycmd2.commands.office.tests
   :members:
   :undoc-members:
   :show-inheritance:
