from __future__ import annotations

import logging
import shutil
import subprocess
import threading
from concurrent.futures import ThreadPoolExecutor
from contextlib import suppress
from time import perf_counter
from typing import Any
from typing import Callable
from typing import ClassVar
from typing import IO
from typing import List
from typing import Optional
from typing import Sequence

logger = logging.getLogger(__name__)


class Runner:
    """空执行器."""

    def run(self) -> None:
        """执行操作."""
        logger.info(f"调用Runner: [green b]{type(self).__name__}")


class DescriptionRunnerMixin(Runner):
    """描述执行器."""

    DESCRIPTION: str = ""

    def run(self) -> None:
        """执行操作."""
        super().run()

        if self.DESCRIPTION:
            logger.info(f"功能描述: [green b]{self.DESCRIPTION}")


class SequenceRunnerMixin(Runner):
    """序列执行器."""

    def run_before(self) -> None:
        """执行前操作."""

    def run_after(self) -> None:
        """执行后操作."""

    def run(self) -> None:
        """执行操作."""
        self.run_before()
        super().run()
        self.run_after()


class CommandRunnerMixin(Runner):
    """字符串命令执行器."""

    def run(
        self,
        command: str,
        executable: str | None = None,
        env: dict[str, str] | None = None,
    ) -> None:
        """执行操作."""
        super().run()

        if not shutil.which(command):
            logger.warning(f"找不到命令: {command}")
            return

        t0 = perf_counter()
        logger.info(f"调用命令: [green bold]{command}")
        try:
            subprocess.run(
                command,  # 直接使用 Shell 语法
                shell=True,
                check=True,  # 检查命令是否成功
                executable=executable,
                env=env,
            )
        except subprocess.CalledProcessError as e:
            msg = f"命令执行失败, 返回码: {e.returncode}"
            logger.exception(msg)
        else:
            total = perf_counter() - t0
            logger.info(f"调用命令成功, 用时: [green bold]{total:.4f}s.")


class MultiCommandRunnerMixin(Runner):
    """字符串命令执行器."""

    @staticmethod
    def _safe_log_stream(stream: IO[bytes], logger_func: Callable[[str], None]) -> None:
        """安全地记录流数据, 处理各种异常情况.

        Args:
            stream: 字节流
            logger_func: 日志记录函数
        """
        if not stream:
            return

        try:
            # 读取字节流直到结束
            while True:
                try:
                    line_bytes = stream.readline()
                    if not line_bytes:  # 空字节表示流结束
                        break

                    try:
                        # 尝试UTF-8解码
                        line = line_bytes.decode("utf-8").strip()
                    except UnicodeDecodeError:
                        # 尝试GBK解码并替换错误字符
                        line = line_bytes.decode("gbk", errors="replace").strip()

                    if line:
                        logger_func(line)
                except (ValueError, AttributeError, OSError):
                    # 流可能已关闭或出现其他错误
                    logger.exception("读取流时出错")
                    break
        except Exception:
            logger.exception("日志流处理异常")

    def run(self, commands: List[str]) -> None:
        """执行操作.

        Raises:
            FileNotFoundError: 找不到命令
        """
        super().run()

        t0 = perf_counter()
        logger.info(f"调用命令: [green bold]{commands}")

        proc_path = shutil.which(commands[0])
        if not proc_path:
            msg = f"找不到命令: {commands[0]}"
            raise FileNotFoundError(msg)

        # 启动子进程
        proc = subprocess.Popen(
            [proc_path, *commands[1:]],
            stdin=None,  # 继承父进程的stdin, 允许用户输入
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=False,  # 手动解码
        )

        # 创建并启动记录线程
        threads = []
        for stream, log_func in [
            (proc.stdout, logging.info),
            (proc.stderr, logging.warning),
        ]:
            thread = threading.Thread(
                target=self._safe_log_stream,
                args=(stream, log_func),
                daemon=True,  # 设置为守护线程，主程序退出时自动终止
            )
            thread.start()
            threads.append(thread)

        try:
            # 等待进程结束
            proc.wait(timeout=300)  # 添加超时防止无限等待
        except subprocess.TimeoutExpired:
            # 先尝试优雅终止进程
            proc.terminate()
            try:
                # 等待进程优雅退出
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                # 如果进程不响应终止信号，强制杀死
                proc.kill()
                proc.wait()  # 确保进程彻底结束
            logger.exception("命令执行超时, 已强制终止")
            raise
        finally:
            # 等待所有输出处理完成
            for thread in threads:
                thread.join(timeout=2)  # 减少等待时间，因为线程已经是守护线程

            # 安全地关闭流
            for stream in [proc.stdout, proc.stderr]:
                if stream:
                    with suppress(Exception):  # 忽略异常
                        stream.close()

        # 检查返回码
        if proc.returncode != 0:
            logger.error(f"命令执行失败, 返回码: {proc.returncode}")

        logger.info(f"用时: [green bold]{perf_counter() - t0:.4f}s.")


class SubcommandRunnerMixin(MultiCommandRunnerMixin, Runner):
    """子命令执行器."""

    CHILD_RUNNERS: ClassVar[dict[str, Runner]] = {}
    SUBCOMMANDS: ClassVar[list[list[str] | str | Callable[..., Any]]] = []

    def run(self) -> None:
        """执行子命令."""
        if not self.SUBCOMMANDS:
            logger.error("子命令为空, 退出")
            return

        for subcommand in self.SUBCOMMANDS:
            if isinstance(subcommand, str):
                if subcommand.lower() not in self.CHILD_RUNNERS:
                    logger.error(f"未找到执行器: {subcommand}")
                    continue

                logger.info(f"执行子命令: {subcommand}")
                self.CHILD_RUNNERS[subcommand.lower()].run()
            elif isinstance(subcommand, list):
                super().run(subcommand)
            elif isinstance(subcommand, Callable):
                logger.info(f"执行可调用对象: [purple b]{subcommand.__name__}")
                subcommand()
            else:
                logger.error(f"未知子命令: {subcommand}")


class ParallelRunnerMixin(Runner):
    """并行执行器."""

    def run(
        self,
        func: Callable[..., Any],
        args: Optional[List[Any]] = None,
        max_workers: int = 10,
    ) -> Sequence[Any]:
        """执行操作.

        Returns:
            List[Any]: 执行结果
        """
        super().run()

        if not callable(func):
            logger.error(f"func 必须是一个可调用对象: {func=}")
            return []

        func_name = func.__name__ if hasattr(func, "__name__") else "Unknown"
        logger.info(f"调用: {func_name}({args=})")

        if not args:
            logger.info("没有参数, 取消多线程...")
            return [func()]

        if not isinstance(args, List):
            logger.error(f"args 必须是一个列表: {args=}")
            return []

        if len(args) == 1:
            logger.info("只有一个参数, 取消多线程...")
            return [func(args[0])]

        t0 = perf_counter()
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            results = list(executor.map(func, args))

        logger.info(
            f"调用: {func_name}(args: {args!s})({max_workers}个线程), "
            f"耗时: {perf_counter() - t0:.4f}s",
        )
        return results


class CommandRunner(CommandRunnerMixin, Runner):
    """默认字符串命令执行器."""


class MultiCommandRunner(MultiCommandRunnerMixin, Runner):
    """默认字符串命令执行器."""


class SubcommandRunner(SubcommandRunnerMixin, Runner):
    """默认执行器."""


class DescSubcommandRunner(DescriptionRunnerMixin, SubcommandRunner, Runner):
    """默认执行器."""


class SequenceRunner(SequenceRunnerMixin, Runner):
    """默认序列执行器."""


class SequenceSubcommandRunner(SequenceRunnerMixin, SubcommandRunner, Runner):
    """默认序列执行器."""


class ParallelRunner(ParallelRunnerMixin, Runner):
    """默认并行执行器."""
