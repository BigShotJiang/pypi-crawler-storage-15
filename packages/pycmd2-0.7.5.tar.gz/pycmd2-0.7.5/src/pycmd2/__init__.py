"""pycmd2 顶级包."""

__author__ = """gooker_young"""
__email__ = "gooker_young@qq.com"
__version__ = "0.7.5"
__build_date__ = "2025-12-02"
