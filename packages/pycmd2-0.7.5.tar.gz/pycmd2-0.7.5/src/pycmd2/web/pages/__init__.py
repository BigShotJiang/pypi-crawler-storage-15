__all__ = ["MainPage", "SettingsPage"]

from .main_page import MainPage
from .settings_page import SettingsPage
