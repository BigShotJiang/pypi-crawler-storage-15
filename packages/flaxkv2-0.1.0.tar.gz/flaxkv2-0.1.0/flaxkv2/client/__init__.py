"""
FlaxKV2 客户端模块
"""

from flaxkv2.client.zmq_client import RemoteDBDict

__all__ = ["RemoteDBDict"] 