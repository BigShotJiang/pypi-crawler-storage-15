"""Quantitative analysis extension for CapInvest Platform."""
