# CapInvest QA Extension

This extension provides Quantitative Analysis (QA) tools for the CapInvest Platform.

Features of the QA extension include various statistical tools and models.

This extension works nicely with a companion `capinvest-charting` extension

 

