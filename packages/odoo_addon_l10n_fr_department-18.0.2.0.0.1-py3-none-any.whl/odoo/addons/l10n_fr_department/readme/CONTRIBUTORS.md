- Sylvain LE GAL ([Twitter](https://twitter.com/legalsylvain)), GRAP
  (Groupement Régional Alimentaire de Proximité)
- Alexis de Lattre \<<alexis.delattre@akretion.com>\>
- Nicolas JEUDY \<<https://github.com/njeudy>\>
