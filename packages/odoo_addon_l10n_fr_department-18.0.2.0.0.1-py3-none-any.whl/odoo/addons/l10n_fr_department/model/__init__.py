from . import res_country_state
from . import res_country_department
from . import res_partner
