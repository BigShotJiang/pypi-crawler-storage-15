.. _resample:

========
resample
========

Spatial Resampling
==================

The ``resample`` module contains functions to convert gridded data to different
spatial resolutions.