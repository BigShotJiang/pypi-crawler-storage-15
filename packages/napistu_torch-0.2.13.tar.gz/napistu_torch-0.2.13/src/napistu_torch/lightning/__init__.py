"""Lightning integration for napistu-torch.

This subpackage provides integration with PyTorch Lightning for training and evaluating models.
"""
