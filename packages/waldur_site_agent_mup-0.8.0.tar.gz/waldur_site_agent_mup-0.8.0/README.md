# MUP plugin for Waldur Site Agent

This plugin provides MUP (Portuguese project allocation portal) integration capabilities for Waldur Site Agent.

## Installation

See the main [Installation Guide](../../docs/installation.md) for platform-specific installation instructions.
