# Utility functions for envseal
