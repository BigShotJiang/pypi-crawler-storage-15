from tacotoolbox.tortilla.extensions.geoenrich import GeoEnrich
from tacotoolbox.tortilla.extensions.majortom import MajorTOM
from tacotoolbox.tortilla.extensions.spatial_grouping import SpatialGrouping
