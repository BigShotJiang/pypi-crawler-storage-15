"""Event types for streaming."""

from dataclasses import dataclass
from typing import Any, Dict, Literal, Optional


@dataclass
class StdoutEvent:
    """Stdout event."""
    data: str
    type: Literal['stdout'] = 'stdout'


@dataclass
class ContentEvent:
    """Parsed content event (ACP-style).

    Unified event format across all agents (Claude, Codex, Gemini).
    Use this instead of parsing raw stdout JSONL yourself.

    Attributes:
        session_id: Optional session identifier
        update: The session update payload with discriminated union on 'sessionUpdate' field

    Update types (update['sessionUpdate']):
        - 'agent_message_chunk': Text/image from agent
        - 'agent_thought_chunk': Reasoning/thinking (Codex/Claude)
        - 'user_message_chunk': User message echo (Gemini)
        - 'tool_call': Tool started (status: pending/in_progress)
        - 'tool_call_update': Tool finished (status: completed/failed)
        - 'plan': TodoWrite updates

    Example:
        >>> swarmkit.on('content', lambda event: handle_content(event))
        >>>
        >>> def handle_content(event: ContentEvent):
        ...     match event.update.get('sessionUpdate'):
        ...         case 'agent_message_chunk':
        ...             print(event.update['content']['text'], end='')
        ...         case 'tool_call':
        ...             print(f"Tool: {event.update['title']}")
        ...         case 'tool_call_update':
        ...             print(f"Status: {event.update['status']}")
    """
    update: Dict[str, Any]
    session_id: Optional[str] = None
    type: Literal['content'] = 'content'


@dataclass
class StderrEvent:
    """Stderr event."""
    data: str
    type: Literal['stderr'] = 'stderr'


@dataclass
class UpdateEvent:
    """Update event (JSON metadata)."""
    data: str
    type: Literal['update'] = 'update'


@dataclass
class ErrorEvent:
    """Error event."""
    error: str
    type: Literal['error'] = 'error'


@dataclass
class CompleteEvent:
    """Stream completion event.

    Note: For background commands, exit_code=0 indicates the command started successfully (not completed).
    """
    status: Literal['success', 'error']
    exit_code: Optional[int]
    sandbox_id: Optional[str]
    error: Optional[str] = None
    type: Literal['complete'] = 'complete'


# Union type for all events
Event = StdoutEvent | ContentEvent | StderrEvent | UpdateEvent | ErrorEvent | CompleteEvent
