# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
from .sapiens_tokenizer import *
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
