- This module will not work properly if used in a multicompany context
  with product prices depending on the company.
