"""
Rendering subsystem for GrepMap.

This module provides multiple rendering strategies for displaying ranked tags:

- base.Renderer: Protocol defining the renderer interface
- TreeRenderer: Code snippet view with syntax highlighting
- DirectoryRenderer: Hierarchical symbol overview
- StatsRenderer: Compact statistics view (LOC, def counts)
- syntax helpers: Color and icon utilities

Each renderer takes ranked tags and produces formatted output optimized for
different use cases (code inspection vs. architectural overview vs. complexity assessment).
"""

from grepmap.rendering.base import Renderer
from grepmap.rendering.tree import TreeRenderer
from grepmap.rendering.directory import DirectoryRenderer
from grepmap.rendering.stats import StatsRenderer
from grepmap.rendering.clusters import ClusterRenderer, should_use_clusters
from grepmap.rendering.syntax import (
    get_token_color,
    get_symbol_icon,
    get_symbol_color
)

__all__ = [
    'Renderer',
    'TreeRenderer',
    'DirectoryRenderer',
    'StatsRenderer',
    'ClusterRenderer',
    'should_use_clusters',
    'get_token_color',
    'get_symbol_icon',
    'get_symbol_color',
]
