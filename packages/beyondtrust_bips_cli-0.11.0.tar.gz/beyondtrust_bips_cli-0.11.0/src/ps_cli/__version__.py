# This file is auto-generated during build
__version__ = "v0.11.0"
