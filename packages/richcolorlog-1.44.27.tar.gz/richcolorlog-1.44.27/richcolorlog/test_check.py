from logger import _is_ipython, RICH_AVAILABLE, console
print("RICH_AVAILABLE:", RICH_AVAILABLE)
print("console:", console)
print("_is_ipython():", _is_ipython())