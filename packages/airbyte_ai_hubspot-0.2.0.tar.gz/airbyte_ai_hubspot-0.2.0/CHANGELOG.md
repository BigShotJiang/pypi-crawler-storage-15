# Changelog

## [0.2.0] - 2025-12-02
- Updated connector definition (YAML version 1.0.0)
- Source commit: 7153780a
- SDK version: 0.1.0

## [0.1.0] - 2025-12-02
- Updated connector definition (YAML version 1.0.0)
- Source commit: 01f71cad
- SDK version: 0.1.0
