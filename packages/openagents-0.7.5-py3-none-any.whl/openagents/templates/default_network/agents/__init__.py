# Agent templates
