# Default network template
