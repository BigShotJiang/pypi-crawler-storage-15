import enum


class DatasetPassMode(enum.Enum):
    MODE_TRAIN = 0
    MODE_EVALUATE = 1
