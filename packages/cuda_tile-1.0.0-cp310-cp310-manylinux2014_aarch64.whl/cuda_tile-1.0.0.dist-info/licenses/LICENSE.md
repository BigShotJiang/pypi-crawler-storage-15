<!--- SPDX-FileCopyrightText: Copyright (c) <2025> NVIDIA CORPORATION & AFFILIATES. All rights reserved. -->
<!--- SPDX-License-Identifier: Apache-2.0 -->

cuTile-Python is under Apache 2.0 license. See the [LICENSES](LICENSES/) folder for the full license text.
