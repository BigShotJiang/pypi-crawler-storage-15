# aihelper_akshay1

A simple helper library for using Google Gemini API in Python and Flask.

## Installation

```bash
pip install aihelper_akshay1
