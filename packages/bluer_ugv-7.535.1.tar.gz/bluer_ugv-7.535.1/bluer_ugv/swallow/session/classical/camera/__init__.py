from bluer_ugv.swallow.session.classical.camera.generic import (
    ClassicalCamera,
)
from bluer_ugv.swallow.session.classical.camera.navigation import (
    ClassicalNavigationCamera,
)
from bluer_ugv.swallow.session.classical.camera.tracking import (
    ClassicalTrackingCamera,
)
from bluer_ugv.swallow.session.classical.camera.void import (
    ClassicalVoidCamera,
)
from bluer_ugv.swallow.session.classical.camera.yolo import (
    ClassicalYoloCamera,
)
