def main():
    print("Hello from styletext!")


if __name__ == "__main__":
    main()
