"""
Settings modules for BioSynth.
""" 