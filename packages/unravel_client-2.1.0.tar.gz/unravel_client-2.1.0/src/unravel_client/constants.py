WEBSITE = "https://unravel.finance"
BASEAPI = f"{WEBSITE}/api/v1"
