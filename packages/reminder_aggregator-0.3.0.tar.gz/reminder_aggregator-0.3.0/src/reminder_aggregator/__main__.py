if __name__ == "__main__":
    from reminder_aggregator.cli import cli

    cli()
