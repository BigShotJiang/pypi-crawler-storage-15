"""Tests for cppvector package"""
