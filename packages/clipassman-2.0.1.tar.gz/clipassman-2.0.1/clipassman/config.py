# Copyright © 2025, Alexander Suvorov


class Config:
    name = 'Smart Password Manager CLI v2.0.1'
    url = 'https://github.com/smartlegionlab/clipassman'
    help_url = 'https://github.com/smartlegionlab/smartpasslib'
    info = 'Copyright © 2025, Alexander Suvorov'
