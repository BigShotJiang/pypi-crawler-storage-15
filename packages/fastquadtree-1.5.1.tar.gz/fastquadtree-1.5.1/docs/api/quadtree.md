# fastquadtree.QuadTree
::: fastquadtree.QuadTree
    options:
        inherited_members: true
