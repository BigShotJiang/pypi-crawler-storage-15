from . import version  # type: ignore[attr-defined]

__version__ = version.version
