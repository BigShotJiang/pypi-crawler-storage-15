"""Address normalization utilities."""

from .normalize import normalize_address

__all__ = ["normalize_address"]
