"""
Shared constants used across HumanMint modules.

Kept small and domain-specific to avoid bloating individual modules with
large literal lists or sets.
"""

