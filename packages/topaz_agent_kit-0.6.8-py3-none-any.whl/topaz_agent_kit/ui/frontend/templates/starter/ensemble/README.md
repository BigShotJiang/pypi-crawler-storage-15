Topaz Starter Ensemble Template

This directory contains the scaffold used to create new projects. Place your sample files here and the app will copy them when scaffolding a project.

Expected structure (you can add more files/folders as needed):

📁 project-home-folder
  ├── 📁 config
  │   ├── 📄 ui_manifest.yml
  │   ├── 📄 pipeline.yml
  │   ├── 📁 agents
  │   ├── 📁 pipelines
  │   └── 📁 ui_manifests
  ├── 📁 library
  ├── 📁 prompts
  ├── 📁 ui
  │   └── 📁 static
  │       └── 📁 assets
  │           └── 🖼️ topaz-logo.png
  ├── 📁 utils
  │   └── 🐍 chroma_db.py
  ├── 📄 README.md
  └── 📄 .project.json
