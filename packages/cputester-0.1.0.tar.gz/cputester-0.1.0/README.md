# cputester

Author: 2AM mimo!
Real Name: A***** R*****
Email: fearmimo2012@gmail.com
GitHub: Archit-web-29

Ultimate CPU Stress Testing Library and CLI Application

## Installation

```bash
pip install cputester
