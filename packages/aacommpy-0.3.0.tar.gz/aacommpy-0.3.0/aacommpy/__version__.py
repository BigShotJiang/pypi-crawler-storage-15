
__title__ = 'aacommpy'
__description__ = 'aacommpy - AAComm nuget package wrapper'
__version__ = '0.3.0'
__author__ = 'HIEU and DB'
__author_email__ = 'daniel.brousser@akribis-sys.com'
__license__ = 'MIT'
# fake url
__url__ = 'https://github.com/BoJl4apa/aacommpy'
