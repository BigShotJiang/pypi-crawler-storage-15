from ._keishis_sandbox import mysum


def mysub(a: int, b: int) -> int:
    return a - b


__all__ = ["mysum", "mysub"]
