from .linalg import expm

__all__ = ("expm",)
