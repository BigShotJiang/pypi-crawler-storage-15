# Installation

Just use:

```bash
pip install -U .
```

or:
```bash
pip install --no-deps -U -e .
```
