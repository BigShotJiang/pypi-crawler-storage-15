# Poetry Workspaces Plugin

A Poetry plugin for managing monorepos, styled after Yarn workspaces.
