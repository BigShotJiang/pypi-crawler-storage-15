# Generated domain models

from .ProfileDimension import ProfileDimension, ProfileDimensionRepoImpl
from .Customer import Customer, CustomerRepoImpl
from .CustomerCategory import CustomerCategory, CustomerCategoryRepoImpl
from .CustomerProfile import CustomerProfile, CustomerProfileRepoImpl
from .CategoryRequirement import CategoryRequirement, CategoryRequirementRepoImpl
