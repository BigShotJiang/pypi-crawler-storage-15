"""FFmpeg common utilities package."""
