"""
Tests for health-check command (Story 4, EPIC-BETA-001).

Verifies that the health-check command correctly validates:
1. Python version (>= 3.12)
2. Configuration file validity
3. API/Database connectivity
4. Claude Code CLI availability
"""

import sys
from pathlib import Path
from unittest.mock import MagicMock, mock_open, patch

import pytest
import yaml
from typer.testing import CliRunner

from obra_client.cli import app
from obra_client.exceptions import APIError, ConfigurationError

runner = CliRunner()


class TestHealthCheckCommand:
    """Test health-check command scenarios."""

    @pytest.fixture
    def valid_config(self, tmp_path):
        """Valid configuration with all required fields."""
        config = {
            "api_base_url": "https://us-central1-obra-205b0.cloudfunctions.net",
            "license_key": "OBRA-test-license-key",
            "user_id": "test_user",
            "claude_code_path": "/usr/local/bin/claude-code",
        }
        config_path = tmp_path / "client-config.yaml"
        with open(config_path, "w") as f:
            yaml.dump(config, f)
        return config_path

    @pytest.fixture
    def incomplete_config(self, tmp_path):
        """Config missing required fields."""
        config = {
            "api_base_url": "https://us-central1-obra-205b0.cloudfunctions.net",
            # Missing: license_key, user_id
        }
        config_path = tmp_path / "client-config.yaml"
        with open(config_path, "w") as f:
            yaml.dump(config, f)
        return config_path

    def test_health_check_all_pass(self, valid_config):
        """
        Test health-check when all checks pass.

        Expected:
        - Python version OK
        - Config valid
        - API reachable
        - Claude Code found
        - Exit code 0
        """
        # Create a proper version_info mock
        version_mock = MagicMock()
        version_mock.major = 3
        version_mock.minor = 12
        version_mock.micro = 0
        version_mock.__ge__ = lambda self, other: (self.major, self.minor) >= other

        with (
            patch("obra_client.cli.load_config") as mock_load_config,
            patch("obra_client.cli.APIClient") as mock_api_client,
            patch("shutil.which") as mock_which,
            patch("subprocess.run") as mock_run,
            patch("obra_client.cli.sys.version_info", version_mock),
        ):
            # Setup mocks
            with open(valid_config) as f:
                config = yaml.safe_load(f)
            mock_load_config.return_value = config

            # Mock API health check
            mock_client = MagicMock()
            mock_client.health_check.return_value = {
                "status": "healthy",
                "firestore": "connected",
            }
            mock_api_client.return_value = mock_client

            # Mock Claude Code found
            mock_which.return_value = "/usr/local/bin/claude-code"
            mock_run.return_value = MagicMock(
                returncode=0, stdout="claude-code 1.0.0", stderr=""
            )

            # Run health-check
            result = runner.invoke(app, ["health-check"])

            # Assertions
            assert result.exit_code == 0
            assert "✓ Python 3.12.0" in result.stdout
            assert "✓ Config valid" in result.stdout
            assert "✓ API reachable" in result.stdout
            assert "✓ Claude Code found" in result.stdout
            assert "All checks passed" in result.stdout

    def test_health_check_python_version_too_old(self):
        """
        Test health-check when Python version < 3.12.

        Expected:
        - Python version check fails
        - Exit code 1
        """
        # Create version_info mock for Python 3.11
        version_mock = MagicMock()
        version_mock.major = 3
        version_mock.minor = 11
        version_mock.micro = 5
        version_mock.__ge__ = lambda self, other: (self.major, self.minor) >= other

        with (
            patch("obra_client.cli.sys.version_info", version_mock),
            patch("obra_client.cli.load_config") as mock_load_config,
            patch("obra_client.cli.APIClient") as mock_api_client,
            patch("shutil.which") as mock_which,
            patch("subprocess.run") as mock_run,
        ):
            # Mock config to avoid skipping checks
            mock_load_config.return_value = {
                "api_base_url": "https://test.com",
                "license_key": "test",
                "user_id": "test",
            }

            # Mock API client (for subsequent checks)
            mock_client = MagicMock()
            mock_client.health_check.return_value = {"status": "healthy"}
            mock_api_client.return_value = mock_client

            # Mock Claude Code found (to avoid multiple failures)
            mock_which.return_value = "/usr/local/bin/claude-code"
            mock_run.return_value = MagicMock(returncode=0, stdout="claude-code 1.0.0", stderr="")

            # Run health-check
            result = runner.invoke(app, ["health-check"])

            # Assertions
            assert result.exit_code == 1
            assert "✗ Python 3.11.5 (requires 3.12+)" in result.stdout
            assert "Some checks failed" in result.stdout

    def test_health_check_config_missing(self):
        """
        Test health-check when config file doesn't exist.

        Expected:
        - Config check fails
        - Exit code 1
        """
        # Create version_info mock
        version_mock = MagicMock()
        version_mock.major = 3
        version_mock.minor = 12
        version_mock.micro = 0
        version_mock.__ge__ = lambda self, other: (self.major, self.minor) >= other

        with (
            patch("obra_client.cli.load_config") as mock_load_config,
            patch("obra_client.cli.sys.version_info", version_mock),
        ):
            # Mock config missing
            mock_load_config.side_effect = ConfigurationError(
                "Configuration file not found"
            )

            # Run health-check
            result = runner.invoke(app, ["health-check"])

            # Assertions
            assert result.exit_code == 1
            assert "✗ Config error" in result.stdout
            assert "Configuration file not found" in result.stdout
            assert "obra-client setup" in result.stdout

    def test_health_check_config_incomplete(self, incomplete_config):
        """
        Test health-check when config is missing required fields.

        Expected:
        - Config check fails (missing fields)
        - Exit code 1
        """
        # Create version_info mock
        version_mock = MagicMock()
        version_mock.major = 3
        version_mock.minor = 12
        version_mock.micro = 0
        version_mock.__ge__ = lambda self, other: (self.major, self.minor) >= other

        with (
            patch("obra_client.cli.load_config") as mock_load_config,
            patch("obra_client.cli.sys.version_info", version_mock),
        ):
            # Load incomplete config
            with open(incomplete_config) as f:
                config = yaml.safe_load(f)
            mock_load_config.return_value = config

            # Run health-check
            result = runner.invoke(app, ["health-check"])

            # Assertions
            assert result.exit_code == 1
            assert "✗ Config incomplete" in result.stdout
            assert "license_key" in result.stdout or "user_id" in result.stdout

    def test_health_check_api_unreachable(self, valid_config):
        """
        Test health-check when API is unreachable.

        Expected:
        - API connectivity check fails
        - Exit code 1
        """
        # Create version_info mock
        version_mock = MagicMock()
        version_mock.major = 3
        version_mock.minor = 12
        version_mock.micro = 0
        version_mock.__ge__ = lambda self, other: (self.major, self.minor) >= other

        with (
            patch("obra_client.cli.load_config") as mock_load_config,
            patch("obra_client.cli.APIClient") as mock_api_client,
            patch("obra_client.cli.sys.version_info", version_mock),
            patch("shutil.which") as mock_which,
        ):
            # Setup mocks
            with open(valid_config) as f:
                config = yaml.safe_load(f)
            mock_load_config.return_value = config

            # Mock API unreachable
            mock_client = MagicMock()
            mock_client.health_check.side_effect = APIError(
                "Connection refused", status_code=None
            )
            mock_api_client.return_value = mock_client

            # Mock Claude Code found (to isolate API failure)
            mock_which.return_value = "/usr/local/bin/claude-code"

            # Run health-check
            result = runner.invoke(app, ["health-check"])

            # Assertions
            assert result.exit_code == 1
            assert "✗ API unreachable" in result.stdout
            assert "Connection refused" in result.stdout

    def test_health_check_claude_code_not_found(self, valid_config):
        """
        Test health-check when Claude Code CLI is not in PATH.

        Expected:
        - Claude Code check fails
        - Exit code 1
        """
        # Create version_info mock
        version_mock = MagicMock()
        version_mock.major = 3
        version_mock.minor = 12
        version_mock.micro = 0
        version_mock.__ge__ = lambda self, other: (self.major, self.minor) >= other

        with (
            patch("obra_client.cli.load_config") as mock_load_config,
            patch("obra_client.cli.APIClient") as mock_api_client,
            patch("obra_client.cli.sys.version_info", version_mock),
            patch("shutil.which") as mock_which,
        ):
            # Setup mocks
            with open(valid_config) as f:
                config = yaml.safe_load(f)
            mock_load_config.return_value = config

            # Mock API OK
            mock_client = MagicMock()
            mock_client.health_check.return_value = {"status": "healthy"}
            mock_api_client.return_value = mock_client

            # Mock Claude Code not found
            mock_which.return_value = None

            # Run health-check
            result = runner.invoke(app, ["health-check"])

            # Assertions
            assert result.exit_code == 1
            assert "⚠ Claude Code not found" in result.stdout
            assert "Install:" in result.stdout

    def test_health_check_api_unhealthy_status(self, valid_config):
        """
        Test health-check when API returns unhealthy status.

        Expected:
        - API check warns but doesn't fail completely
        - Exit code 1
        """
        # Create version_info mock
        version_mock = MagicMock()
        version_mock.major = 3
        version_mock.minor = 12
        version_mock.micro = 0
        version_mock.__ge__ = lambda self, other: (self.major, self.minor) >= other

        with (
            patch("obra_client.cli.load_config") as mock_load_config,
            patch("obra_client.cli.APIClient") as mock_api_client,
            patch("obra_client.cli.sys.version_info", version_mock),
            patch("shutil.which") as mock_which,
        ):
            # Setup mocks
            with open(valid_config) as f:
                config = yaml.safe_load(f)
            mock_load_config.return_value = config

            # Mock API returns unhealthy
            mock_client = MagicMock()
            mock_client.health_check.return_value = {"status": "degraded"}
            mock_api_client.return_value = mock_client

            # Mock Claude Code found
            mock_which.return_value = "/usr/local/bin/claude-code"

            # Run health-check
            result = runner.invoke(app, ["health-check"])

            # Assertions
            assert result.exit_code == 1
            assert "⚠ API status: degraded" in result.stdout

    def test_health_check_claude_code_version_timeout(self, valid_config):
        """
        Test health-check when Claude Code --version times out.

        Expected:
        - Warns about timeout but doesn't fail
        """
        # Create version_info mock
        version_mock = MagicMock()
        version_mock.major = 3
        version_mock.minor = 12
        version_mock.micro = 0
        version_mock.__ge__ = lambda self, other: (self.major, self.minor) >= other

        with (
            patch("obra_client.cli.load_config") as mock_load_config,
            patch("obra_client.cli.APIClient") as mock_api_client,
            patch("obra_client.cli.sys.version_info", version_mock),
            patch("shutil.which") as mock_which,
            patch("subprocess.run") as mock_run,
        ):
            # Setup mocks
            with open(valid_config) as f:
                config = yaml.safe_load(f)
            mock_load_config.return_value = config

            # Mock API OK
            mock_client = MagicMock()
            mock_client.health_check.return_value = {"status": "healthy"}
            mock_api_client.return_value = mock_client

            # Mock Claude Code found but --version times out
            mock_which.return_value = "/usr/local/bin/claude-code"
            from subprocess import TimeoutExpired

            mock_run.side_effect = TimeoutExpired("claude-code", 5)

            # Run health-check
            result = runner.invoke(app, ["health-check"])

            # Should still find Claude Code despite timeout
            assert "Claude Code found but --version timed out" in result.stdout

    def test_health_check_command_exists(self):
        """
        Test that health-check command is registered.
        """
        result = runner.invoke(app, ["--help"])

        assert result.exit_code == 0
        assert "health-check" in result.stdout
