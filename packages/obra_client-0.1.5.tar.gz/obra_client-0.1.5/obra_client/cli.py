"""CLI entry point for Obra Client."""

import json
import os
import sys
import time
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.prompt import Prompt

from obra_client import __version__
from obra_client.api_client import APIClient
from obra_client.config import (
    PRIVACY_VERSION,
    TERMS_VERSION,
    get_license_key,
    is_terms_accepted,
    load_config,
    needs_reacceptance,
    save_config,
    save_terms_acceptance,
)
from obra_client.exceptions import (
    APIError,
    ConfigurationError,
    ExecutionError,
    TermsNotAcceptedError,
)
from obra_client.executor import ClaudeCodeExecutor
from obra_client.legal import get_terms_summary
from obra_client.prompt_enricher import PromptEnricher
from obra_client.session_manager import SessionManager

app = typer.Typer(
    name="obra-client",
    help="Obra SaaS Client - LLM Proxy with prompt enrichment for Cloud Functions orchestration",
    add_completion=False,
)

console = Console()


def require_config() -> dict:
    """Load configuration and verify it exists.

    Returns:
        Configuration dictionary

    Raises:
        ConfigurationError: If config file doesn't exist or is invalid
    """
    from obra_client.config import CONFIG_PATH

    config = load_config()
    if not config:
        raise ConfigurationError(
            f"Configuration file not found: {CONFIG_PATH}\n"
            "Run 'obra-client setup' to create it."
        )
    return config


def require_terms_accepted() -> None:
    """Check if terms have been accepted, exit if not.

    This is a HARD STOP GATE - commands cannot proceed without terms acceptance.

    Raises:
        typer.Exit: If terms not accepted (exit code 1)
    """
    if not is_terms_accepted():
        console.print("\n[red]Terms not accepted.[/red]")
        console.print("Run 'obra-client setup' first to accept the Beta Terms.")
        raise typer.Exit(1)

    # Check for version mismatch (re-acceptance needed)
    if needs_reacceptance():
        console.print("\n[yellow]Terms have been updated (v{TERMS_VERSION}).[/yellow]")
        console.print("Run 'obra-client setup' to accept the updated terms.")
        raise typer.Exit(1)


@app.command()
def setup() -> None:
    """Run first-time setup with REQUIRED terms acceptance.

    This command MUST be run before using any other obra-client commands.
    It performs three steps:

    1. Terms Acceptance (REQUIRED): Display and accept Beta Terms + Privacy Policy
    2. API Configuration: Set up API endpoint and license key
    3. Verification: Test API connectivity

    The terms acceptance is a legal requirement - you cannot use obra-client
    without accepting the terms.

    Creates ~/.obra/client-config.yaml with configuration and acceptance state.
    """
    import yaml

    from obra_client.config import CONFIG_PATH

    console.print(f"\n[bold]OBRA CLIENT SETUP[/bold] [dim]v{__version__}[/dim]")
    console.print("=" * 70)

    # Check if already set up
    existing_config = load_config()
    existing_acceptance = is_terms_accepted()

    if existing_config and existing_acceptance:
        console.print(f"\n[green]✓[/green] Configuration exists: {CONFIG_PATH}")
        console.print(f"[green]✓[/green] Terms v{TERMS_VERSION} already accepted")
        console.print("\n[dim]To reconfigure, delete ~/.obra/client-config.yaml and run setup again.[/dim]")
        raise typer.Exit(0)

    # Check if re-acceptance needed (version change)
    if needs_reacceptance():
        console.print("\n[yellow]Terms have been updated. Re-acceptance required.[/yellow]")

    # =========================================================================
    # STEP 1: Terms Acceptance (REQUIRED - HARD STOP GATE)
    # =========================================================================
    console.print("\n[bold red]STEP 1: TERMS ACCEPTANCE (REQUIRED)[/bold red]")
    console.print("-" * 70)
    console.print()

    # Display Plain Language Summary
    terms_summary = get_terms_summary()
    console.print(Panel(
        terms_summary,
        title="[bold red]PLAIN LANGUAGE SUMMARY[/bold red]",
        border_style="red",
    ))

    console.print()
    console.print("[bold]Full documents:[/bold]")
    console.print("  Terms:   [link=https://obra.dev/terms]https://obra.dev/terms[/link]")
    console.print("  Privacy: [link=https://obra.dev/privacy]https://obra.dev/privacy[/link]")
    console.print()

    # Display acceptance confirmations (12 items from BETA_TERMS.md v2.1)
    console.print("[bold]BY TYPING \"I ACCEPT\", YOU CONFIRM THAT:[/bold]")
    console.print()
    confirmations = [
        "You have READ and UNDERSTAND all terms in their entirety",
        "You AGREE to be legally bound by all terms",
        "You are using this as an INDIVIDUAL on personal equipment",
        "You are NOT using any Employer Systems or corporate equipment",
        "You are NOT using this for any business or organizational purpose",
        "You MEET all requirements in Section 3 (Tester Representations)",
        "You ACCEPT all risks described in Section 15 (Assumption of Risk)",
        "You AGREE to BINDING ARBITRATION (Section 23, with exceptions)",
        "You WAIVE your right to participate in class actions (Section 25)",
        "You WAIVE your right to a jury trial (Section 25)",
        "You UNDERSTAND certain provisions survive termination (Section 21)",
        "You had OPPORTUNITY TO CONSULT WITH LEGAL COUNSEL before accepting",
    ]
    for i, conf in enumerate(confirmations, 1):
        console.print(f"  [bold]{i:2}.[/bold] {conf}")

    console.print()
    console.print("[bold yellow]Type \"I ACCEPT\" to accept all terms, or \"EXIT\" to abort.[/bold yellow]")
    console.print()

    # Get user input
    user_input = typer.prompt("Your response").strip()

    if user_input.upper() == "EXIT":
        console.print("\n[dim]Setup aborted. You must accept the terms to use obra-client.[/dim]")
        raise typer.Exit(0)

    if user_input.upper() != "I ACCEPT":
        console.print("\n[red]Invalid response. You must type exactly \"I ACCEPT\" to proceed.[/red]")
        console.print("[dim]Run 'obra-client setup' again to retry.[/dim]")
        raise typer.Exit(1)

    console.print("\n[green]✓[/green] Terms acceptance recorded")

    # =========================================================================
    # STEP 2: License Key & User ID
    # =========================================================================
    console.print("\n[bold]STEP 2: LICENSE KEY & USER ID[/bold]")
    console.print("-" * 70)

    # License key
    console.print("\n[dim]Your license key was provided in your beta invitation email.[/dim]")
    license_key = typer.prompt(
        "License Key",
        hide_input=True,
    )

    # User ID (email)
    console.print("\n[dim]Use the email address associated with your beta invitation.[/dim]")
    user_id = typer.prompt(
        "Email Address",
    )

    # Use fixed API URL (users should never change this)
    api_base_url = "https://us-central1-obra-205b0.cloudfunctions.net"

    # Build configuration (sensible defaults for optional fields)
    config = {
        "api_base_url": api_base_url,
        "license_key": license_key,
        "user_id": user_id,
        "project_id": None,  # Default project
        "claude_code_path": None,  # Auto-detect
    }

    # Save configuration (BEFORE terms acceptance - config needed for API calls)
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    save_config(config)
    console.print(f"\n[green]✓[/green] Configuration saved to: {CONFIG_PATH}")

    # =================================================================
    # REGISTER TERMS ACCEPTANCE WITH SERVER (REQUIRED - Phase 2)
    # Server-side enforcement means we MUST successfully register.
    # Local file is just a cache to avoid re-prompting.
    # =================================================================
    console.print("\n[bold]Registering terms acceptance with server...[/bold]")
    try:
        api_client = APIClient(
            base_url=api_base_url,
            auth_token=None,
        )
        server_logged = api_client.log_terms_acceptance(
            license_key=license_key,
            terms_version=TERMS_VERSION,
            privacy_version=PRIVACY_VERSION,
            client_version=__version__,
            source="cli_setup",
        )
        if not server_logged:
            console.print("\n[red]Failed to register terms acceptance with server.[/red]")
            console.print("[dim]The server must record your acceptance before you can use the service.[/dim]")
            console.print("[dim]Please check your network connection and try again.[/dim]")
            raise typer.Exit(1)

        console.print("[green]✓[/green] Terms acceptance registered with server")

    except typer.Exit:
        raise  # Re-raise Exit exceptions
    except Exception as e:
        console.print(f"\n[red]Failed to connect to server: {e}[/red]")
        console.print("[dim]The server must record your acceptance before you can use the service.[/dim]")
        console.print("[dim]Please check your network connection and try again.[/dim]")
        raise typer.Exit(1)

    # Save terms acceptance LOCALLY (cache to avoid re-prompting)
    save_terms_acceptance(TERMS_VERSION, PRIVACY_VERSION)
    console.print(f"[green]✓[/green] Local acceptance cache saved (v{TERMS_VERSION})")

    # =========================================================================
    # STEP 3: Verification
    # =========================================================================
    console.print("\n[bold]STEP 3: VERIFICATION[/bold]")
    console.print("-" * 70)

    try:
        api_client = APIClient(
            base_url=api_base_url,
            auth_token=None,
        )

        # Check health
        health = api_client.health_check()
        console.print(f"[green]✓[/green] API reachable (status: {health['status']})")

        # Check version
        version_info = api_client.get_version()
        console.print(f"[green]✓[/green] API version: {version_info['api_version']}")

        # Check client compatibility
        min_version = version_info.get("min_client_version", "0.1.0")
        if __version__ < min_version:
            console.print(
                f"\n[yellow]⚠ Warning: Client version ({__version__}) "
                f"below minimum ({min_version})[/yellow]"
            )
            console.print("[dim]Consider: pip install --upgrade obra-client[/dim]")

    except APIError as e:
        console.print(f"[yellow]⚠[/yellow] Could not verify API: {e}")
        console.print("[dim]You can still use the client, check API URL if issues persist.[/dim]")

    # =========================================================================
    # Complete
    # =========================================================================
    console.print("\n" + "=" * 70)
    console.print("[bold green]SETUP COMPLETE[/bold green]")
    console.print("=" * 70)

    console.print("\n[bold]Required Environment Variable:[/bold]")
    console.print("  Set ANTHROPIC_API_KEY before using Obra:")
    console.print("    export ANTHROPIC_API_KEY='your-api-key'")  # pragma: allowlist secret

    console.print("\n[bold]Quick Start (Human Users):[/bold]")
    console.print("  obra-client interactive          # Start REPL for iterative work")
    console.print("  obra-client orchestrate \"task\"   # One-shot task execution")
    console.print("  obra-client health-check         # Verify installation")

    console.print("\n[bold]For LLM Agents (Claude Code, etc.):[/bold]")
    console.print("  obra-client docs onboarding      # Agent setup guide")
    console.print("  obra-client docs examples        # Usage patterns & templates")
    console.print()
    console.print("  [dim]Hint: Have your LLM agent run 'obra-client docs onboarding'[/dim]")
    console.print("  [dim]to read the getting-started guide before orchestrating tasks.[/dim]")

    console.print("\n[bold]Troubleshooting:[/bold]")
    console.print("  obra-client health-check         # Diagnose issues")
    console.print("  obra-client version              # Check compatibility")

    console.print(f"\n[dim]Config saved to: {CONFIG_PATH}[/dim]")
    console.print("[dim]To reconfigure: delete config file and run 'obra-client setup' again[/dim]")


@app.command()
def orchestrate(
    objective: str,
    project_dir: Optional[str] = None,
    task_type: str = "feature",
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show detailed debug output"),
) -> None:
    """Start orchestration session with Cloud Functions.

    Args:
        objective: Task objective (e.g., "Add user authentication")
        project_dir: Project directory (default: current directory)
        task_type: Type of task (feature, bug_fix, refactor, etc.)
        verbose: Show detailed debug output including server responses

    Example:
        obra-client orchestrate "Add rate limiting to API"
        obra-client orchestrate "Fix login bug" --task-type bug_fix
        obra-client orchestrate "Add feature" --verbose
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    try:
        # Load configuration
        config = require_config()

        # Determine project directory
        working_dir = Path(project_dir or os.getcwd()).resolve()

        if not working_dir.exists():
            console.print(f"[red]❌ Project directory not found: {working_dir}[/red]")
            raise typer.Exit(1)

        console.print(f"\n[bold]🚀 Starting Orchestration[/bold]")
        console.print(f"[dim]Objective:[/dim] {objective}")
        console.print(f"[dim]Project:[/dim] {working_dir}")
        console.print(f"[dim]Type:[/dim] {task_type}\n")

        # Initialize components
        # Use from_config() to enable automatic license key exchange
        api_client = APIClient.from_config()

        enricher = PromptEnricher()

        executor = ClaudeCodeExecutor(
            claude_code_path=config.get("claude_code_path"),
        )

        session_manager = SessionManager()

        # Step 1: Start orchestration session
        console.print("[bold]📡 Contacting server...[/bold]")

        session_response = api_client.orchestrate(
            user_id=config["user_id"],
            project_id=config.get("project_id", "default"),
            working_dir=str(working_dir),
            objective=objective,
            task_type=task_type,
        )

        session_id = session_response["session_id"]
        base_prompt = session_response["base_prompt"]

        console.print(f"[green]✓[/green] Session created: [dim]{session_id}[/dim]\n")

        if verbose:
            console.print("[dim]─── Server Response ───[/dim]")
            console.print(f"[dim]  Status: {session_response.get('status', 'N/A')}[/dim]")
            console.print(f"[dim]  Base prompt: {len(base_prompt)} chars[/dim]")
            if session_response.get("metadata"):
                console.print(f"[dim]  Metadata: {json.dumps(session_response['metadata'], indent=2)}[/dim]")
            console.print("[dim]───────────────────────[/dim]\n")

        # Save checkpoint for resume capability
        session_manager.save_checkpoint(
            session_id=session_id,
            objective=objective,
            task_type=task_type,
            project_dir=str(working_dir),
            iteration=1,
            status="active",
        )

        # Orchestration loop
        iteration = 1
        max_iterations = 20  # Safety limit

        while iteration <= max_iterations:
            iteration_start = time.time()
            console.print(f"[bold]🔄 Iteration {iteration}[/bold]")

            # Step 2: Enrich prompt with local context
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                task = progress.add_task("Enriching prompt with local context...", total=None)
                enriched_prompt = enricher.enrich_prompt(base_prompt, str(working_dir))
                progress.update(task, completed=True)

            console.print(f"[green]✓[/green] Prompt enriched (~{len(enriched_prompt)} chars)\n")

            if verbose:
                console.print(f"[dim]  Base prompt: {len(base_prompt)} chars[/dim]")
                console.print(f"[dim]  Enriched prompt: {len(enriched_prompt)} chars[/dim]")
                console.print(f"[dim]  Context added: +{len(enriched_prompt) - len(base_prompt)} chars[/dim]")

            # Step 3: Execute LLM
            console.print("[bold]🤖 Executing with Claude Code...[/bold]")

            result = executor.execute(
                prompt=enriched_prompt,
                working_dir=working_dir,
            )

            if not result.success:
                console.print(f"[red]❌ LLM execution failed (exit code {result.exit_code})[/red]")
                console.print(f"[dim]{result.stderr}[/dim]")

                # Submit failure to server
                api_client.llm_result(
                    session_id=session_id,
                    result=result.stdout or result.stderr,
                    status="failure",
                )
                raise typer.Exit(1)

            console.print(f"[green]✓[/green] LLM execution complete\n")

            # Step 4: Submit result to server
            console.print("[bold]📤 Submitting result...[/bold]")

            server_response = api_client.llm_result(
                session_id=session_id,
                result=result.stdout,
                status="success",
            )

            action = server_response["action"]
            iteration_time = time.time() - iteration_start

            if verbose:
                console.print("[dim]─── Server Response ───[/dim]")
                console.print(f"[dim]  Action: {action}[/dim]")
                console.print(f"[dim]  Iteration: {server_response.get('iteration', 'N/A')}[/dim]")
                if server_response.get("feedback"):
                    console.print(f"[dim]  Feedback: {server_response['feedback']}[/dim]")
                if action == "continue" and server_response.get("base_prompt"):
                    console.print(f"[dim]  Next prompt: {len(server_response['base_prompt'])} chars[/dim]")
                console.print(f"[dim]  Iteration time: {iteration_time:.1f}s[/dim]")
                console.print("[dim]───────────────────────[/dim]")

            # Handle server response
            if action == "complete":
                console.print("\n[bold green]✨ Task completed successfully![/bold green]")
                console.print(f"[dim]{server_response.get('message', '')}[/dim]")
                if verbose:
                    console.print(f"[dim]Total iterations: {iteration}[/dim]")
                # Clear checkpoint on successful completion
                session_manager.clear_checkpoint()
                raise typer.Exit(0)

            elif action == "continue":
                # Server wants another iteration
                base_prompt = server_response["base_prompt"]
                console.print(f"[yellow]→[/yellow] Continuing to iteration {iteration + 1}...\n")
                iteration += 1
                # Update checkpoint with new iteration
                session_manager.update_iteration(iteration)

            elif action == "error":
                console.print(f"\n[red]❌ Server error:[/red] {server_response.get('message', 'Unknown error')}")
                raise typer.Exit(1)

            else:
                console.print(f"\n[red]❌ Unknown server action:[/red] {action}")
                raise typer.Exit(1)

        # Max iterations reached
        console.print(f"\n[yellow]⚠️  Maximum iterations ({max_iterations}) reached[/yellow]")
        console.print("[dim]Task may be incomplete. Check session status.[/dim]")
        raise typer.Exit(1)

    except ConfigurationError as e:
        console.print(f"\n[red]❌ Configuration Error:[/red] {e}")
        raise typer.Exit(1)

    except TermsNotAcceptedError as e:
        # Server rejected request because terms not accepted
        # This can happen if local cache is out of sync or terms version changed
        console.print(f"\n[red]❌ Terms Not Accepted:[/red] {e}")
        console.print(f"[bold]{e.action}[/bold]")
        if e.required_version:
            console.print(f"[dim]Required version: {e.required_version}[/dim]")
        console.print(f"[dim]Terms: {e.terms_url}[/dim]")
        # Clear local cache since it's out of sync
        from obra_client.config import clear_terms_acceptance
        clear_terms_acceptance()
        raise typer.Exit(1)

    except APIError as e:
        console.print(f"\n[red]❌ API Error:[/red] {e}")
        if e.status_code:
            console.print(f"[dim]Status code: {e.status_code}[/dim]")
        raise typer.Exit(1)

    except ExecutionError as e:
        console.print(f"\n[red]❌ Execution Error:[/red] {e}")
        raise typer.Exit(1)

    except KeyboardInterrupt:
        console.print("\n\n[yellow]⚠️  Interrupted by user[/yellow]")
        console.print(f"[dim]Session {session_id} is still active on server[/dim]")
        console.print(f"[dim]Resume with: obra-client resume {session_id}[/dim]")
        raise typer.Exit(130)

    except typer.Exit:
        # Re-raise typer.Exit without treating it as an error
        # (typer.Exit inherits from RuntimeError, so it's caught by Exception)
        raise

    except Exception as e:
        console.print(f"\n[red]❌ Unexpected Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def status(session_id: str) -> None:
    """Query orchestration session status.

    Args:
        session_id: Session ID from /orchestrate call

    Example:
        obra-client status abc123-def456-ghi789
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    try:
        config = require_config()

        # Use from_config() to enable automatic license key exchange
        api_client = APIClient.from_config()

        console.print(f"\n[bold]📊 Session Status[/bold]")
        console.print(f"[dim]Session ID:[/dim] {session_id}\n")

        response = api_client.get_status(session_id)

        console.print(f"[bold]Status:[/bold] {response['status']}")
        console.print(f"[bold]Iteration:[/bold] {response['current_iteration']}")
        console.print(f"[bold]Objective:[/bold] {response['objective']}")
        console.print(f"[bold]Type:[/bold] {response['task_type']}")

        raise typer.Exit(0)

    except ConfigurationError as e:
        console.print(f"\n[red]❌ Configuration Error:[/red] {e}")
        raise typer.Exit(1)

    except APIError as e:
        console.print(f"\n[red]❌ API Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def resume(session_id: Optional[str] = None) -> None:
    """Resume interrupted orchestration session.

    Args:
        session_id: Session ID to resume (optional, will use last checkpoint if not provided)

    Example:
        obra-client resume                    # Resume last session
        obra-client resume abc123-def456      # Resume specific session
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    try:
        config = require_config()
        session_manager = SessionManager()

        # Load checkpoint
        checkpoint = session_manager.load_checkpoint()

        if not checkpoint:
            console.print("[yellow]⚠️  No saved session found[/yellow]")
            console.print("[dim]Run 'obra-client orchestrate' to start a new session[/dim]")
            raise typer.Exit(1)

        # Use provided session_id or checkpoint's session_id
        target_session_id = session_id or checkpoint.session_id

        # Initialize API client
        # Use from_config() to enable automatic license key exchange
        api_client = APIClient.from_config()

        # Check if session can be resumed
        console.print(f"\n[bold]🔄 Resuming Session[/bold]")
        console.print(f"[dim]Session ID:[/dim] {target_session_id}")
        console.print(f"[dim]Objective:[/dim] {checkpoint.objective}")
        console.print(f"[dim]Last Iteration:[/dim] {checkpoint.iteration}\n")

        # Verify session is still active
        try:
            status_response = api_client.get_status(target_session_id)

            if status_response["status"] != "active":
                console.print(
                    f"[yellow]⚠️  Session is {status_response['status']}, cannot resume[/yellow]"
                )
                session_manager.clear_checkpoint()
                raise typer.Exit(1)

        except APIError as e:
            console.print(f"[red]❌ Session not found on server:[/red] {e}")
            session_manager.clear_checkpoint()
            raise typer.Exit(1)

        # Ask user to confirm resume
        confirm = typer.confirm("Resume this session?", default=True)
        if not confirm:
            console.print("[dim]Resume cancelled[/dim]")
            raise typer.Exit(0)

        console.print("[green]✓[/green] Resuming session...\n")

        # Get continuation prompt from server
        console.print("[bold]📡 Fetching continuation prompt...[/bold]")
        resume_response = api_client.resume(target_session_id)

        base_prompt = resume_response["base_prompt"]
        iteration = resume_response.get("iteration", checkpoint.iteration)

        console.print(f"[green]✓[/green] Got continuation prompt (iteration {iteration})\n")

        # Initialize executor and enricher
        enricher = PromptEnricher()
        executor = ClaudeCodeExecutor(
            claude_code_path=config.get("claude_code_path"),
        )

        # Get working directory from checkpoint
        working_dir = Path(checkpoint.project_dir).resolve()

        # Orchestration loop (same as orchestrate command)
        max_iterations = 20  # Safety limit

        while iteration <= max_iterations:
            iteration_start = time.time()
            console.print(f"[bold]🔄 Iteration {iteration}[/bold]")

            # Enrich prompt with local context
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                task = progress.add_task("Enriching prompt with local context...", total=None)
                enriched_prompt = enricher.enrich_prompt(base_prompt, str(working_dir))
                progress.update(task, completed=True)

            console.print(f"[green]✓[/green] Prompt enriched (~{len(enriched_prompt)} chars)\n")

            # Execute LLM
            console.print("[bold]🤖 Executing with Claude Code...[/bold]")

            result = executor.execute(
                prompt=enriched_prompt,
                working_dir=working_dir,
            )

            if not result.success:
                console.print(f"[red]❌ LLM execution failed (exit code {result.exit_code})[/red]")
                console.print(f"[dim]{result.stderr}[/dim]")

                # Submit failure to server
                api_client.llm_result(
                    session_id=target_session_id,
                    result=result.stdout or result.stderr,
                    status="failure",
                )
                raise typer.Exit(1)

            console.print(f"[green]✓[/green] LLM execution complete\n")

            # Submit result to server
            console.print("[bold]📤 Submitting result...[/bold]")

            server_response = api_client.llm_result(
                session_id=target_session_id,
                result=result.stdout,
                status="success",
            )

            action = server_response["action"]
            iteration_time = time.time() - iteration_start

            console.print(f"[dim]  Iteration time: {iteration_time:.1f}s[/dim]")

            # Handle server response
            if action == "complete":
                console.print("\n[bold green]✨ Task completed successfully![/bold green]")
                console.print(f"[dim]{server_response.get('message', '')}[/dim]")
                # Clear checkpoint on successful completion
                session_manager.clear_checkpoint()
                raise typer.Exit(0)

            elif action == "continue":
                # Server wants another iteration
                base_prompt = server_response["base_prompt"]
                console.print(f"[yellow]→[/yellow] Continuing to iteration {iteration + 1}...\n")
                iteration += 1
                # Update checkpoint with new iteration
                session_manager.update_iteration(iteration)

            elif action == "error":
                console.print(f"\n[red]❌ Server error:[/red] {server_response.get('message', 'Unknown error')}")
                raise typer.Exit(1)

            else:
                console.print(f"\n[red]❌ Unknown server action:[/red] {action}")
                raise typer.Exit(1)

        # Max iterations reached
        console.print(f"\n[yellow]⚠️  Maximum iterations ({max_iterations}) reached[/yellow]")
        console.print("[dim]Task may be incomplete. Check session status.[/dim]")
        raise typer.Exit(1)

    except ConfigurationError as e:
        console.print(f"\n[red]❌ Configuration Error:[/red] {e}")
        raise typer.Exit(1)

    except TermsNotAcceptedError as e:
        # Server rejected request because terms not accepted
        console.print(f"\n[red]❌ Terms Not Accepted:[/red] {e}")
        console.print(f"[bold]{e.action}[/bold]")
        if e.required_version:
            console.print(f"[dim]Required version: {e.required_version}[/dim]")
        console.print(f"[dim]Terms: {e.terms_url}[/dim]")
        from obra_client.config import clear_terms_acceptance
        clear_terms_acceptance()
        raise typer.Exit(1)

    except APIError as e:
        console.print(f"\n[red]❌ API Error:[/red] {e}")
        if e.status_code:
            console.print(f"[dim]Status code: {e.status_code}[/dim]")
        raise typer.Exit(1)

    except ExecutionError as e:
        console.print(f"\n[red]❌ Execution Error:[/red] {e}")
        raise typer.Exit(1)

    except KeyboardInterrupt:
        console.print("\n\n[yellow]⚠️  Interrupted by user[/yellow]")
        console.print(f"[dim]Session {target_session_id} is still active on server[/dim]")
        console.print(f"[dim]Resume with: obra-client resume {target_session_id}[/dim]")
        raise typer.Exit(130)

    except typer.Exit:
        # Re-raise typer.Exit without treating it as an error
        raise

    except Exception as e:
        console.print(f"\n[red]❌ Unexpected Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def version() -> None:
    """Display Obra Client version and check server compatibility."""
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    console.print(f"[bold]Obra Client[/bold] v{__version__}\n")

    try:
        config = require_config()

        # Use from_config() to enable automatic license key exchange
        api_client = APIClient.from_config()

        console.print("[bold]Checking server compatibility...[/bold]")
        server_version = api_client.get_version()

        console.print(f"[green]✓[/green] Server API Version: {server_version['api_version']}")
        console.print(f"[dim]Min Client Version:[/dim] {server_version['min_client_version']}")
        console.print(f"[dim]Features:[/dim] {', '.join(server_version['features'])}")

    except ConfigurationError:
        console.print("[yellow]⚠️  No configuration found (run 'obra-client setup')[/yellow]")

    except APIError as e:
        console.print(f"[red]❌ Server unreachable:[/red] {e}")

    raise typer.Exit(0)


@app.command(name="health-check")
def health_check() -> None:
    """Verify Obra installation and configuration.

    Checks:
        - Python version (>= 3.12)
        - Configuration file validity
        - API/Database connectivity
        - Claude Code CLI availability

    Example:
        obra-client health-check
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    import shutil
    import subprocess

    console.print("\n[bold]🏥 Obra Health Check[/bold]")
    console.print("=" * 50)

    all_passed = True

    # Check 1: Python Version
    console.print("\n[bold]1. Python Version[/bold]")
    python_version = sys.version_info
    version_str = f"{python_version.major}.{python_version.minor}.{python_version.micro}"

    if python_version >= (3, 12):
        console.print(f"   [green]✓[/green] Python {version_str}")
    else:
        console.print(f"   [red]✗[/red] Python {version_str} (requires 3.12+)")
        console.print(f"   [dim]→ Upgrade Python: https://www.python.org/downloads/[/dim]")
        all_passed = False

    # Check 2: Configuration
    console.print("\n[bold]2. Configuration[/bold]")
    try:
        config = load_config()

        # Validate required fields
        required_fields = ["api_base_url", "license_key", "user_id"]
        missing_fields = [f for f in required_fields if not config.get(f)]

        if missing_fields:
            console.print(f"   [red]✗[/red] Config incomplete (missing: {', '.join(missing_fields)})")
            console.print(f"   [dim]→ Run: obra-client setup[/dim]")
            all_passed = False
        else:
            console.print("   [green]✓[/green] Config valid")

    except ConfigurationError as e:
        console.print(f"   [red]✗[/red] Config error: {e}")
        console.print(f"   [dim]→ Run: obra-client setup[/dim]")
        all_passed = False

    # Check 3: API/Database Connectivity
    console.print("\n[bold]3. API/Database Connectivity[/bold]")
    try:
        config = load_config()

        # Create API client without auth for health check
        api_client = APIClient(
            base_url=config["api_base_url"],
            auth_token=None,
        )

        # Check health endpoint
        health = api_client.health_check()

        if health.get("status") == "healthy":
            console.print(f"   [green]✓[/green] API reachable (Firestore: {health.get('firestore', 'unknown')})")
        else:
            console.print(f"   [yellow]⚠[/yellow] API status: {health.get('status', 'unknown')}")
            all_passed = False

    except ConfigurationError:
        console.print("   [yellow]⚠[/yellow] Skipped (no config)")
        all_passed = False

    except APIError as e:
        console.print(f"   [red]✗[/red] API unreachable: {e}")
        console.print(f"   [dim]→ Check network connection and API URL[/dim]")
        all_passed = False

    except Exception as e:
        console.print(f"   [red]✗[/red] Connection error: {e}")
        console.print(f"   [dim]→ Verify API base URL in config[/dim]")
        all_passed = False

    # Check 4: Claude Code CLI
    console.print("\n[bold]4. Claude Code CLI[/bold]")
    try:
        config = load_config()
        claude_code_path = config.get("claude_code_path") or "claude-code"

        # Check if Claude Code is in PATH or at specified location
        if shutil.which(claude_code_path):
            # Try to get version
            try:
                result = subprocess.run(
                    [claude_code_path, "--version"],
                    capture_output=True,
                    text=True,
                    timeout=5,
                    check=False,
                )

                if result.returncode == 0:
                    version_output = result.stdout.strip() or result.stderr.strip()
                    console.print(f"   [green]✓[/green] Claude Code found ({version_output})")
                else:
                    console.print(f"   [green]✓[/green] Claude Code found at: {shutil.which(claude_code_path)}")

            except subprocess.TimeoutExpired:
                console.print(f"   [yellow]⚠[/yellow] Claude Code found but --version timed out")

        else:
            console.print(f"   [yellow]⚠[/yellow] Claude Code not found in PATH")
            console.print(f"   [dim]→ Install: https://docs.anthropic.com/claude-code[/dim]")
            console.print(f"   [dim]→ Or specify path in config: claude_code_path[/dim]")
            all_passed = False

    except ConfigurationError:
        console.print("   [yellow]⚠[/yellow] Skipped (no config)")
        all_passed = False

    # Summary
    console.print("\n" + "=" * 50)

    if all_passed:
        console.print("[bold green]✨ All checks passed![/bold green]")
        console.print("\n[dim]Your Obra installation is ready to use.[/dim]")
        console.print("[dim]Next: obra-client orchestrate \"your task\"[/dim]")
        raise typer.Exit(0)
    else:
        console.print("[bold yellow]⚠  Some checks failed[/bold yellow]")
        console.print("\n[dim]Fix the issues above, then run health-check again.[/dim]")
        raise typer.Exit(1)


def _run_orchestration(
    objective: str,
    working_dir: Path,
    task_type: str,
    config: dict,
    verbose: bool = False,
) -> tuple[bool, Optional[str], Optional[str]]:
    """Run orchestration and return result (for REPL use).

    Returns:
        Tuple of (success, session_id, error_message)
    """
    try:
        # Initialize components
        api_client = APIClient.from_config()
        enricher = PromptEnricher()
        executor = ClaudeCodeExecutor(claude_code_path=config.get("claude_code_path"))
        session_manager = SessionManager()

        # Start orchestration session
        console.print("[bold]📡 Contacting server...[/bold]")

        session_response = api_client.orchestrate(
            user_id=config["user_id"],
            project_id=config.get("project_id", "default"),
            working_dir=str(working_dir),
            objective=objective,
            task_type=task_type,
        )

        session_id = session_response["session_id"]
        base_prompt = session_response["base_prompt"]

        console.print(f"[green]✓[/green] Session created: [dim]{session_id}[/dim]\n")

        # Save checkpoint
        session_manager.save_checkpoint(
            session_id=session_id,
            objective=objective,
            task_type=task_type,
            project_dir=str(working_dir),
            iteration=1,
            status="active",
        )

        # Orchestration loop
        iteration = 1
        max_iterations = 20

        while iteration <= max_iterations:
            console.print(f"[bold]🔄 Iteration {iteration}[/bold]")

            # Enrich prompt
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                task = progress.add_task("Enriching prompt...", total=None)
                enriched_prompt = enricher.enrich_prompt(base_prompt, str(working_dir))
                progress.update(task, completed=True)

            console.print(f"[green]✓[/green] Prompt enriched (~{len(enriched_prompt)} chars)\n")

            # Execute LLM
            console.print("[bold]🤖 Executing with Claude Code...[/bold]")
            result = executor.execute(prompt=enriched_prompt, working_dir=working_dir)

            if not result.success:
                console.print(f"[red]❌ LLM execution failed[/red]")
                api_client.llm_result(
                    session_id=session_id,
                    result=result.stdout or result.stderr,
                    status="failure",
                )
                return False, session_id, "LLM execution failed"

            console.print(f"[green]✓[/green] LLM execution complete\n")

            # Submit result
            console.print("[bold]📤 Submitting result...[/bold]")
            server_response = api_client.llm_result(
                session_id=session_id,
                result=result.stdout,
                status="success",
            )

            action = server_response["action"]

            if action == "complete":
                console.print("\n[bold green]✨ Task completed successfully![/bold green]")
                session_manager.clear_checkpoint()
                return True, session_id, None

            elif action == "continue":
                base_prompt = server_response["base_prompt"]
                console.print(f"[yellow]→[/yellow] Continuing to iteration {iteration + 1}...\n")
                iteration += 1
                session_manager.update_iteration(iteration)

            elif action == "error":
                msg = server_response.get("message", "Unknown error")
                console.print(f"\n[red]❌ Server error:[/red] {msg}")
                return False, session_id, msg

            else:
                console.print(f"\n[red]❌ Unknown action:[/red] {action}")
                return False, session_id, f"Unknown action: {action}"

        console.print(f"\n[yellow]⚠️  Max iterations ({max_iterations}) reached[/yellow]")
        return False, session_id, "Max iterations reached"

    except ConfigurationError as e:
        console.print(f"\n[red]❌ Configuration Error:[/red] {e}")
        return False, None, str(e)

    except TermsNotAcceptedError as e:
        console.print(f"\n[red]❌ Terms Not Accepted:[/red] {e}")
        from obra_client.config import clear_terms_acceptance
        clear_terms_acceptance()
        return False, None, str(e)

    except APIError as e:
        console.print(f"\n[red]❌ API Error:[/red] {e}")
        return False, None, str(e)

    except ExecutionError as e:
        console.print(f"\n[red]❌ Execution Error:[/red] {e}")
        return False, None, str(e)

    except KeyboardInterrupt:
        console.print("\n[yellow]⚠️  Interrupted[/yellow]")
        return False, None, "Interrupted by user"


def _repl_help() -> None:
    """Show REPL help."""
    console.print("\n[bold]Available Commands:[/bold]")
    console.print("  [cyan]/help[/cyan]           Show this help message")
    console.print("  [cyan]/status[/cyan]         Show last session status")
    console.print("  [cyan]/history[/cyan]        Show command history")
    console.print("  [cyan]/project[/cyan] [path] Show or change working directory")
    console.print("  [cyan]/clear[/cyan]          Clear screen")
    console.print("  [cyan]/exit[/cyan]           Exit interactive mode")
    console.print()
    console.print("[bold]Orchestration:[/bold]")
    console.print("  Type any text without / prefix to orchestrate a task.")
    console.print("  Example: [dim]Add user authentication[/dim]")
    console.print()


@app.command()
def interactive() -> None:
    """Start interactive orchestration mode.

    Interactive mode provides a REPL-like interface for orchestration,
    allowing you to iteratively work through development tasks with
    real-time feedback.

    Commands:
        /help      Show available commands
        /status    Show last session status
        /history   Show command history
        /project   Show or change working directory
        /clear     Clear screen
        /exit      Exit interactive mode

    Example:
        obra-client interactive
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    try:
        config = require_config()
    except ConfigurationError as e:
        console.print(f"\n[red]❌ Configuration Error:[/red] {e}")
        raise typer.Exit(1)

    # State
    working_dir = Path.cwd().resolve()
    history: list[str] = []
    last_session_id: Optional[str] = None
    last_objective: Optional[str] = None
    last_success: Optional[bool] = None

    # Welcome banner
    console.print()
    console.print(f"[bold]OBRA INTERACTIVE MODE[/bold] [dim]v{__version__}[/dim]")
    console.print("═" * 70)
    console.print(f"[dim]Project:[/dim] {working_dir}")
    console.print("[dim]Type objectives to orchestrate, or /help for commands.[/dim]")
    console.print()

    # Main REPL loop
    while True:
        try:
            # Get input
            user_input = Prompt.ask("[bold cyan]obra[/bold cyan]")
            user_input = user_input.strip()

            # Skip empty input
            if not user_input:
                continue

            # Add to history
            history.append(user_input)

            # Handle commands
            if user_input.startswith("/"):
                cmd_parts = user_input[1:].split(maxsplit=1)
                cmd = cmd_parts[0].lower()
                cmd_arg = cmd_parts[1] if len(cmd_parts) > 1 else None

                if cmd in ("exit", "quit", "q"):
                    console.print("\n[dim]Goodbye![/dim]")
                    break

                elif cmd == "help":
                    _repl_help()

                elif cmd == "clear":
                    console.clear()
                    console.print(f"[bold]OBRA INTERACTIVE MODE[/bold] [dim]v{__version__}[/dim]")
                    console.print("═" * 70)

                elif cmd == "status":
                    if last_session_id:
                        status_str = "[green]completed[/green]" if last_success else "[red]failed[/red]"
                        console.print(f"\n[bold]Last Session:[/bold]")
                        console.print(f"  Session ID: [dim]{last_session_id}[/dim]")
                        console.print(f"  Objective: {last_objective}")
                        console.print(f"  Status: {status_str}")
                        console.print()
                    else:
                        console.print("\n[dim]No session yet. Run an orchestration first.[/dim]\n")

                elif cmd == "history":
                    if history:
                        console.print("\n[bold]Command History:[/bold]")
                        for i, h in enumerate(history[-10:], 1):
                            console.print(f"  {i}. {h}")
                        console.print()
                    else:
                        console.print("\n[dim]No history yet.[/dim]\n")

                elif cmd == "project":
                    if cmd_arg:
                        new_path = Path(cmd_arg).expanduser().resolve()
                        if new_path.exists() and new_path.is_dir():
                            working_dir = new_path
                            console.print(f"[green]✓[/green] Project directory: {working_dir}")
                        else:
                            console.print(f"[red]❌ Directory not found:[/red] {cmd_arg}")
                    else:
                        console.print(f"[bold]Project:[/bold] {working_dir}")

                else:
                    console.print(f"[red]Unknown command:[/red] /{cmd}")
                    console.print("[dim]Type /help for available commands.[/dim]")

            else:
                # Treat as orchestration objective
                console.print()
                success, session_id, error = _run_orchestration(
                    objective=user_input,
                    working_dir=working_dir,
                    task_type="feature",
                    config=config,
                )
                last_session_id = session_id
                last_objective = user_input
                last_success = success
                console.print()

        except KeyboardInterrupt:
            console.print("\n[dim]Use /exit to quit.[/dim]")
            continue

        except EOFError:
            # Ctrl+D
            console.print("\n[dim]Goodbye![/dim]")
            break

    raise typer.Exit(0)


# Create docs sub-app for documentation commands
docs_app = typer.Typer(
    name="docs",
    help="View bundled documentation and guides.",
)
app.add_typer(docs_app, name="docs")


@docs_app.command(name="onboarding")
def docs_onboarding() -> None:
    """Display agent onboarding documentation.

    Shows the getting-started guide for using obra-client,
    including setup instructions and key commands.

    Example:
        obra-client docs onboarding
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    from obra_client.docs import get_onboarding

    console.print(get_onboarding())


@docs_app.command(name="examples")
def docs_examples() -> None:
    """Display usage examples and common workflows.

    Shows copy-paste examples for common Obra operations
    and best practices.

    Example:
        obra-client docs examples
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    from obra_client.docs import get_usage_examples

    console.print(get_usage_examples())


@docs_app.command(name="terms")
def docs_terms() -> None:
    """Display full Beta Software Agreement.

    Shows the complete terms and conditions for using Obra.

    Example:
        obra-client docs terms
    """
    # Note: terms display does NOT require acceptance gate
    # Users should be able to read terms before deciding

    from obra_client.legal import get_full_terms

    console.print(get_full_terms())


if __name__ == "__main__":
    app()
