"""Configuration management for Obra Client.

Handles terms acceptance state and client configuration stored in
~/.obra/client-config.yaml.
"""

from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

import yaml

# Legal document versions - must match bundled documents
TERMS_VERSION = "2.1"
PRIVACY_VERSION = "1.3"

# Config file path
CONFIG_PATH = Path.home() / ".obra" / "client-config.yaml"


def get_config_path() -> Path:
    """Get path to client configuration file.

    Returns:
        Path to ~/.obra/client-config.yaml
    """
    return CONFIG_PATH


def load_config() -> dict[str, Any]:
    """Load configuration from ~/.obra/client-config.yaml.

    Returns:
        Configuration dictionary, empty dict if file doesn't exist
    """
    if not CONFIG_PATH.exists():
        return {}

    try:
        with open(CONFIG_PATH) as f:
            return yaml.safe_load(f) or {}
    except Exception:
        return {}


def save_config(config: dict[str, Any]) -> None:
    """Save configuration to ~/.obra/client-config.yaml.

    Args:
        config: Configuration dictionary to save

    Raises:
        OSError: If unable to write config file
    """
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)

    with open(CONFIG_PATH, "w") as f:
        yaml.safe_dump(config, f, default_flow_style=False, sort_keys=False)


def get_terms_acceptance() -> Optional[dict[str, Any]]:
    """Get stored terms acceptance data.

    Returns:
        Dictionary with terms acceptance info, or None if not accepted:
        {
            "version": "2.1",
            "privacy_version": "1.3",
            "accepted_at": "2025-12-03T12:00:00+00:00"
        }
    """
    config = load_config()
    return config.get("terms_accepted")


def is_terms_accepted() -> bool:
    """Check if current terms version has been accepted.

    Returns:
        True if terms are accepted and version matches current,
        False otherwise
    """
    acceptance = get_terms_acceptance()

    if not acceptance:
        return False

    # Check if accepted version matches current version
    accepted_version = acceptance.get("version")
    if accepted_version != TERMS_VERSION:
        return False

    return True


def needs_reacceptance() -> bool:
    """Check if terms need to be re-accepted due to version change.

    Returns:
        True if terms were previously accepted but version changed,
        False if never accepted or current version is accepted
    """
    acceptance = get_terms_acceptance()

    if not acceptance:
        return False  # Never accepted, not "re-acceptance"

    accepted_version = acceptance.get("version")
    return accepted_version != TERMS_VERSION


def save_terms_acceptance(
    version: str = TERMS_VERSION,
    privacy_version: str = PRIVACY_VERSION,
) -> None:
    """Save terms acceptance to config file.

    Args:
        version: Terms version being accepted (default: current TERMS_VERSION)
        privacy_version: Privacy policy version (default: current PRIVACY_VERSION)
    """
    config = load_config()

    config["terms_accepted"] = {
        "version": version,
        "privacy_version": privacy_version,
        "accepted_at": datetime.now(timezone.utc).isoformat(),
    }

    save_config(config)


def clear_terms_acceptance() -> None:
    """Clear stored terms acceptance (for testing/reset)."""
    config = load_config()

    if "terms_accepted" in config:
        del config["terms_accepted"]
        save_config(config)


def get_license_key() -> Optional[str]:
    """Get stored license key from config.

    Returns:
        License key string or None if not configured
    """
    config = load_config()
    return config.get("license_key")
