"""
A Django extension for Open edX that enables POK certificates management."""

__version__ = '1.0.3'
