# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListInstanceHistoryResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'lists': 'list[TicsJobInstanceVo]',
        'total': 'int'
    }

    attribute_map = {
        'lists': 'lists',
        'total': 'total'
    }

    def __init__(self, lists=None, total=None):
        r"""ListInstanceHistoryResponse

        The model defined in huaweicloud sdk

        :param lists: 实例集合
        :type lists: list[:class:`huaweicloudsdktics.v1.TicsJobInstanceVo`]
        :param total: 总记录数
        :type total: int
        """
        
        super().__init__()

        self._lists = None
        self._total = None
        self.discriminator = None

        if lists is not None:
            self.lists = lists
        if total is not None:
            self.total = total

    @property
    def lists(self):
        r"""Gets the lists of this ListInstanceHistoryResponse.

        实例集合

        :return: The lists of this ListInstanceHistoryResponse.
        :rtype: list[:class:`huaweicloudsdktics.v1.TicsJobInstanceVo`]
        """
        return self._lists

    @lists.setter
    def lists(self, lists):
        r"""Sets the lists of this ListInstanceHistoryResponse.

        实例集合

        :param lists: The lists of this ListInstanceHistoryResponse.
        :type lists: list[:class:`huaweicloudsdktics.v1.TicsJobInstanceVo`]
        """
        self._lists = lists

    @property
    def total(self):
        r"""Gets the total of this ListInstanceHistoryResponse.

        总记录数

        :return: The total of this ListInstanceHistoryResponse.
        :rtype: int
        """
        return self._total

    @total.setter
    def total(self, total):
        r"""Sets the total of this ListInstanceHistoryResponse.

        总记录数

        :param total: The total of this ListInstanceHistoryResponse.
        :type total: int
        """
        self._total = total

    def to_dict(self):
        import warnings
        warnings.warn("ListInstanceHistoryResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListInstanceHistoryResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
