#!/usr/bin/env python3
"""Event-study preprocessing utilities.

This script reads a parquet dataset and adds the high-level categorizations used
throughout the project.  It consolidates the R-based logic from the
`PYTHON/r-categorization` helpers into a lightweight Python CLI:

* Employment category from `SOCIO13`
* Education category from `ISCED`
* Ethnicity category from `PARENT_OPR_LAND`, `CHILD_OPR_LAND`, `CHILD_IE_TYPE`
* Cohabitation category from `FAMILIE_TYPE`, `CIVST`, `CIV_VFRA`
* Winsorised versions of `PERINDKIALT_13` and `LOENMV_13`

Example
-------

```
uv run python PYTHON/preprocessing.py \
  --input data/raw_dataset.parquet \
  --output data/preprocessed_dataset.parquet
```
"""

from __future__ import annotations

import argparse
import logging
from pathlib import Path
from typing import Dict, List, Optional, Sequence

import numpy as np
import pandas as pd

LOGGER = logging.getLogger(__name__)

# Sets replicated from the R categorisation helpers
DANISH_COUNTRY_CODES = {"5100", "5101", "5115", "5901", "5902"}
WESTERN_COUNTRY_CODES = {
    "5104",
    "5105",
    "5106",
    "5107",
    "5108",
    "5109",
    "5110",
    "5111",
    "5116",
    "5120",
    "5124",
    "5126",
    "5128",
    "5129",
    "5130",
    "5134",
    "5140",
    "5142",
    "5150",
    "5153",
    "5154",
    "5156",
    "5158",
    "5159",
    "5160",
    "5164",
    "5170",
    "5174",
    "5176",
    "5180",
    "5182",
    "5184",
    "5314",
    "5390",
    "5397",
    "5399",
    "5422",
    "5502",
    "5514",
    "5607",
    "5609",
    "5611",
    "5750",
    "5752",
    "5776",
    "5778",
}
REGION_PREFIX_MAP = {
    "01": "danish_origin",
    "02": "western",
    "03": "non_western",
}

FAMILIE_TYPE_COHABITING = {1, 2, 3, 4, 7, 8}
FAMILIE_TYPE_ALONE = {5, 9, 10}
CIVST_MARRIED = {"G", "P"}
CIVST_NOT_MARRIED = {"U", "F", "O", "E", "L"}

SOCIO13_WORKING = {110, 111, 112, 113, 114, 120, 131, 132, 133, 134, 135, 139, 310}
SOCIO13_UNEMPLOYED = {210}
SOCIO13_SICK_OR_PARENTAL_LEAVE = {220}
SOCIO13_OUTSIDE = {330, 321}
SOCIO13_RETIRED = {323, 322}
SOCIO13_TEMPORARILY_UNEMPLOYED = SOCIO13_UNEMPLOYED | SOCIO13_SICK_OR_PARENTAL_LEAVE

DEFAULT_CPI_BASE_YEAR = 2015

ANNUAL_CPI_INDEX = {
    2000: 76.2167,
    2001: 78.0250,
    2002: 79.9167,
    2003: 81.5750,
    2004: 82.5167,
    2005: 84.0167,
    2006: 85.6333,
    2007: 87.0833,
    2008: 90.0583,
    2009: 91.2333,
    2010: 93.3417,
    2011: 95.9167,
    2012: 98.2167,
    2013: 98.9917,
    2014: 99.5500,
    2015: 100.0000,
    2016: 100.2500,
    2017: 101.4000,
    2018: 102.2250,
    2019: 103.0000,
    2020: 103.4333,
    2021: 105.3500,
    2022: 113.4583,
    2023: 117.2083,
    2024: 118.8167,
    2025: 120.9900,
}

DKK_PER_EUR = 7.45  # Fixed conversion rate to report amounts in EUR
REPO_ROOT = Path(__file__).resolve().parents[2]
GEOGRAPHIC_DIR = REPO_ROOT / "geographic-categorization"

_MUN_TRANSLATION_CACHE: Optional[dict[int, int]] = None
_MUN2007_TO_LAN: Optional[dict[int, str]] = None
_MUN2007_TO_REG: Optional[dict[int, str]] = None

# Municipality merge map from kommuner_regioner.R (legacy KOM codes -> 2007 municipality name)
KOM_MERGE_TO_2007_NAME: Dict[int, str] = {
    165: "Albertslund",
    201: "Alleroed",
    151: "Ballerup",
    400: "Bornholm",
    401: "Bornholm",
    403: "Bornholm",
    405: "Bornholm",
    407: "Bornholm",
    409: "Bornholm",
    153: "Broendby",
    155: "Dragoer",
    240: "Egedal",
    171: "Egedal",
    235: "Egedal",
    237: "Egedal",
    210: "Fredensborg",
    208: "Fredensborg",
    227: "Fredensborg",
    147: "Frederiksberg",
    250: "Frederikssund",
    209: "Frederikssund",
    233: "Frederikssund",
    229: "Frederikssund",
    225: "Frederikssund",
    260: "Halsnaes",
    211: "Halsnaes",
    221: "Halsnaes",
    190: "Furesoe",
    207: "Furesoe",
    189: "Furesoe",
    157: "Gentofte",
    159: "Gladsaxe",
    161: "Glostrup",
    270: "Gribskov",
    213: "Gribskov",
    215: "Gribskov",
    217: "Helsingoer",
    163: "Herlev",
    219: "Hilleroed",
    231: "Hilleroed",
    167: "Hvidovre",
    169: "Hoeje-Taastrup",
    223: "Hoersholm",
    183: "Ishoej",
    101: "Koebenhavn",
    173: "Lyngby-Taarbaek",
    230: "Rudersdal",
    181: "Rudersdal",
    205: "Rudersdal",
    175: "Roedovre",
    185: "Taarnby",
    187: "Vallensbaek",
    320: "Faxe",
    313: "Faxe",
    351: "Faxe",
    385: "Faxe",
    253: "Greve",
    376: "Guldborgsund",
    369: "Guldborgsund",
    371: "Guldborgsund",
    375: "Guldborgsund",
    387: "Guldborgsund",
    391: "Guldborgsund",
    395: "Guldborgsund",
    316: "Holbaek",
    315: "Holbaek",
    321: "Holbaek",
    339: "Holbaek",
    341: "Holbaek",
    345: "Holbaek",
    326: "Kalundborg",
    301: "Kalundborg",
    309: "Kalundborg",
    317: "Kalundborg",
    319: "Kalundborg",
    323: "Kalundborg",
    259: "Koege",
    267: "Koege",
    350: "Lejre",
    251: "Lejre",
    257: "Lejre",
    261: "Lejre",
    360: "Lolland",
    367: "Lolland",
    381: "Lolland",
    379: "Lolland",
    359: "Lolland",
    363: "Lolland",
    383: "Lolland",
    355: "Lolland",
    370: "Naestved",
    307: "Naestved",
    353: "Naestved",
    357: "Naestved",
    373: "Naestved",
    393: "Naestved",
    306: "Odsherred",
    305: "Odsherred",
    327: "Odsherred",
    343: "Odsherred",
    329: "Ringsted",
    265: "Roskilde",
    255: "Roskilde",
    263: "Roskilde",
    330: "Slagelse",
    311: "Slagelse",
    325: "Slagelse",
    331: "Slagelse",
    333: "Slagelse",
    269: "Solroed",
    340: "Soroe",
    303: "Soroe",
    335: "Soroe",
    337: "Soroe",
    336: "Stevns",
    271: "Stevns",
    389: "Stevns",
    390: "Vordingborg",
    361: "Vordingborg",
    365: "Vordingborg",
    377: "Vordingborg",
    397: "Vordingborg",
    420: "Assens",
    421: "Assens",
    433: "Assens",
    437: "Assens",
    485: "Assens",
    491: "Assens",
    499: "Assens",
    530: "Billund",
    551: "Billund",
    565: "Billund",
    480: "Nordfyns",
    423: "Nordfyns",
    471: "Nordfyns",
    483: "Nordfyns",
    561: "Esbjerg",
    557: "Esbjerg",
    571: "Esbjerg",
    563: "Fanoe",
    607: "Fredericia",
    430: "Faaborg-Midtfyn",
    425: "Faaborg-Midtfyn",
    431: "Faaborg-Midtfyn",
    473: "Faaborg-Midtfyn",
    477: "Faaborg-Midtfyn",
    497: "Faaborg-Midtfyn",
    510: "Haderslev",
    511: "Haderslev",
    515: "Haderslev",
    543: "Haderslev",
    440: "Kerteminde",
    439: "Kerteminde",
    441: "Kerteminde",
    447: "Kerteminde",
    621: "Kolding",
    509: "Kolding",
    629: "Kolding",
    623: "Kolding",
    482: "Langeland",
    475: "Langeland",
    481: "Langeland",
    487: "Langeland",
    410: "Middelfart",
    429: "Middelfart",
    445: "Middelfart",
    451: "Middelfart",
    450: "Nyborg",
    449: "Nyborg",
    489: "Nyborg",
    495: "Nyborg",
    461: "Odense",
    479: "Svendborg",
    427: "Svendborg",
    435: "Svendborg",
    540: "Soenderborg",
    501: "Soenderborg",
    507: "Soenderborg",
    513: "Soenderborg",
    523: "Soenderborg",
    537: "Soenderborg",
    533: "Soenderborg",
    535: "Soenderborg",
    550: "Toender",
    505: "Toender",
    517: "Toender",
    521: "Toender",
    525: "Toender",
    531: "Toender",
    541: "Toender",
    573: "Varde",
    553: "Varde",
    555: "Varde",
    567: "Varde",
    577: "Varde",
    575: "Vejen",
    527: "Vejen",
    559: "Vejen",
    569: "Vejen",
    630: "Vejle",
    603: "Vejle",
    605: "Vejle",
    611: "Vejle",
    617: "Vejle",
    631: "Vejle",
    492: "Aeroe",
    443: "Aeroe",
    493: "Aeroe",
    580: "Aabenraa",
    503: "Aabenraa",
    519: "Aabenraa",
    529: "Aabenraa",
    539: "Aabenraa",
    545: "Aabenraa",
    710: "Favrskov",
    767: "Favrskov",
    709: "Favrskov",
    713: "Favrskov",
    711: "Favrskov",
    766: "Hedensted",
    613: "Hedensted",
    619: "Hedensted",
    627: "Hedensted",
    657: "Herning",
    651: "Herning",
    677: "Herning",
    685: "Herning",
    661: "Holstebro",
    679: "Holstebro",
    683: "Holstebro",
    615: "Horsens",
    601: "Horsens",
    609: "Horsens",
    756: "Ikast-Brande",
    625: "Ikast-Brande",
    653: "Ikast-Brande",
    663: "Ikast-Brande",
    665: "Lemvig",
    673: "Lemvig",
    707: "Norddjurs",
    725: "Norddjurs",
    735: "Norddjurs",
    747: "Norddjurs",
    727: "Odder",
    730: "Randers",
    717: "Randers",
    723: "Randers",
    729: "Randers",
    731: "Randers",
    760: "Ringkoebing-Skjern",
    659: "Ringkoebing-Skjern",
    655: "Ringkoebing-Skjern",
    667: "Ringkoebing-Skjern",
    669: "Ringkoebing-Skjern",
    681: "Ringkoebing-Skjern",
    741: "Samsoe",
    740: "Silkeborg",
    705: "Silkeborg",
    743: "Silkeborg",
    749: "Silkeborg",
    771: "Silkeborg",
    746: "Skanderborg",
    703: "Skanderborg",
    715: "Skanderborg",
    737: "Skanderborg",
    745: "Skanderborg",
    779: "Skive",
    777: "Skive",
    781: "Skive",
    783: "Skive",
    671: "Struer",
    675: "Struer",
    706: "Syddjurs",
    701: "Syddjurs",
    721: "Syddjurs",
    733: "Syddjurs",
    739: "Syddjurs",
    791: "Viborg",
    761: "Viborg",
    763: "Viborg",
    769: "Viborg",
    775: "Viborg",
    789: "Viborg",
    751: "Aarhus",
    810: "Broenderslev",
    805: "Broenderslev",
    807: "Broenderslev",
    813: "Frederikshavn",
    841: "Frederikshavn",
    847: "Frederikshavn",
    860: "Hjoerring",
    819: "Hjoerring",
    821: "Hjoerring",
    829: "Hjoerring",
    839: "Hjoerring",
    849: "Jammerbugt",
    803: "Jammerbugt",
    811: "Jammerbugt",
    835: "Jammerbugt",
    825: "Laesoe",
    846: "Mariagerfjord",
    801: "Mariagerfjord",
    815: "Mariagerfjord",
    823: "Mariagerfjord",
    719: "Mariagerfjord",
    773: "Morsoe",
    840: "Rebild",
    833: "Rebild",
    843: "Rebild",
    845: "Rebild",
    787: "Thisted",
    765: "Thisted",
    785: "Thisted",
    820: "Vesthimmerlands",
    793: "Vesthimmerlands",
    809: "Vesthimmerlands",
    827: "Vesthimmerlands",
    861: "Vesthimmerlands",
    851: "Aalborg",
    817: "Aalborg",
    831: "Aalborg",
    837: "Aalborg",
}

# 2007 municipality codes to LAN/REG groupings (hard-coded to avoid external files)
KOM2LAN_2007: Dict[int, str] = {
    101: "Byen København",
    147: "Byen København",
    151: "Københavns omegn",
    153: "Københavns omegn",
    155: "Byen København",
    157: "Københavns omegn",
    159: "Københavns omegn",
    161: "Københavns omegn",
    163: "Københavns omegn",
    165: "Københavns omegn",
    167: "Københavns omegn",
    169: "Københavns omegn",
    173: "Københavns omegn",
    175: "Københavns omegn",
    183: "Københavns omegn",
    185: "Byen København",
    187: "Københavns omegn",
    190: "Nordsjælland",
    201: "Nordsjælland",
    210: "Nordsjælland",
    217: "Nordsjælland",
    219: "Nordsjælland",
    223: "Nordsjælland",
    230: "Nordsjælland",
    240: "Nordsjælland",
    250: "Nordsjælland",
    253: "Østsjælland",
    259: "Østsjælland",
    260: "Nordsjælland",
    265: "Østsjælland",
    269: "Østsjælland",
    270: "Nordsjælland",
    306: "Vest- og Sydsjælland",
    316: "Vest- og Sydsjælland",
    320: "Vest- og Sydsjælland",
    326: "Vest- og Sydsjælland",
    329: "Vest- og Sydsjælland",
    330: "Vest- og Sydsjælland",
    336: "Vest- og Sydsjælland",
    340: "Vest- og Sydsjælland",
    350: "Østsjælland",
    360: "Vest- og Sydsjælland",
    370: "Vest- og Sydsjælland",
    376: "Vest- og Sydsjælland",
    390: "Vest- og Sydsjælland",
    400: "Bornholm",
    410: "Fyn",
    411: "Bornholm",
    420: "Fyn",
    430: "Fyn",
    440: "Fyn",
    450: "Fyn",
    461: "Fyn",
    479: "Fyn",
    480: "Fyn",
    482: "Fyn",
    492: "Fyn",
    510: "Sydjylland",
    530: "Sydjylland",
    540: "Sydjylland",
    550: "Sydjylland",
    561: "Sydjylland",
    563: "Sydjylland",
    573: "Sydjylland",
    575: "Sydjylland",
    580: "Sydjylland",
    607: "Sydjylland",
    615: "Østjylland",
    621: "Sydjylland",
    630: "Sydjylland",
    657: "Vestjylland",
    661: "Vestjylland",
    665: "Vestjylland",
    671: "Vestjylland",
    706: "Østjylland",
    707: "Østjylland",
    710: "Østjylland",
    727: "Østjylland",
    730: "Østjylland",
    740: "Østjylland",
    741: "Østjylland",
    746: "Østjylland",
    751: "Østjylland",
    756: "Vestjylland",
    760: "Vestjylland",
    766: "Østjylland",
    773: "Nordjylland",
    779: "Vestjylland",
    787: "Nordjylland",
    791: "Vestjylland",
    810: "Nordjylland",
    813: "Nordjylland",
    820: "Nordjylland",
    825: "Nordjylland",
    840: "Nordjylland",
    846: "Nordjylland",
    849: "Nordjylland",
    851: "Nordjylland",
    860: "Nordjylland",
}

KOM2REG_2007: Dict[int, str] = {
    101: "Hovedstaden",
    147: "Hovedstaden",
    151: "Hovedstaden",
    153: "Hovedstaden",
    155: "Hovedstaden",
    157: "Hovedstaden",
    159: "Hovedstaden",
    161: "Hovedstaden",
    163: "Hovedstaden",
    165: "Hovedstaden",
    167: "Hovedstaden",
    169: "Hovedstaden",
    173: "Hovedstaden",
    175: "Hovedstaden",
    183: "Hovedstaden",
    185: "Hovedstaden",
    187: "Hovedstaden",
    190: "Hovedstaden",
    201: "Hovedstaden",
    210: "Hovedstaden",
    217: "Hovedstaden",
    219: "Hovedstaden",
    223: "Hovedstaden",
    230: "Hovedstaden",
    240: "Hovedstaden",
    250: "Hovedstaden",
    253: "Sjælland",
    259: "Sjælland",
    260: "Hovedstaden",
    265: "Sjælland",
    269: "Sjælland",
    270: "Hovedstaden",
    306: "Sjælland",
    316: "Sjælland",
    320: "Sjælland",
    326: "Sjælland",
    329: "Sjælland",
    330: "Sjælland",
    336: "Sjælland",
    340: "Sjælland",
    350: "Sjælland",
    360: "Sjælland",
    370: "Sjælland",
    376: "Sjælland",
    390: "Sjælland",
    400: "Hovedstaden",
    410: "Syddanmark",
    411: "Hovedstaden",
    420: "Syddanmark",
    430: "Syddanmark",
    440: "Syddanmark",
    450: "Syddanmark",
    461: "Syddanmark",
    479: "Syddanmark",
    480: "Syddanmark",
    482: "Syddanmark",
    492: "Syddanmark",
    510: "Syddanmark",
    530: "Syddanmark",
    540: "Syddanmark",
    550: "Syddanmark",
    561: "Syddanmark",
    563: "Syddanmark",
    573: "Syddanmark",
    575: "Syddanmark",
    580: "Syddanmark",
    607: "Syddanmark",
    615: "Midtjylland",
    621: "Syddanmark",
    630: "Syddanmark",
    657: "Midtjylland",
    661: "Midtjylland",
    665: "Midtjylland",
    671: "Midtjylland",
    706: "Midtjylland",
    707: "Midtjylland",
    710: "Midtjylland",
    727: "Midtjylland",
    730: "Midtjylland",
    740: "Midtjylland",
    741: "Midtjylland",
    746: "Midtjylland",
    751: "Midtjylland",
    756: "Midtjylland",
    760: "Midtjylland",
    766: "Midtjylland",
    773: "Nordjylland",
    779: "Midtjylland",
    787: "Nordjylland",
    791: "Midtjylland",
    810: "Nordjylland",
    813: "Nordjylland",
    820: "Nordjylland",
    825: "Nordjylland",
    840: "Nordjylland",
    846: "Nordjylland",
    849: "Nordjylland",
    851: "Nordjylland",
    860: "Nordjylland",
}
# Municipality code/name maps embedded to avoid external file reads
KOM_MAP_2003: Dict[int, str] = {
    101: "København",
    147: "Frederiksberg",
    151: "Ballerup",
    153: "Brøndby",
    155: "Dragør",
    157: "Gentofte",
    159: "Gladsaxe",
    161: "Glostrup",
    163: "Herlev",
    165: "Albertslund",
    167: "Hvidovre",
    169: "Høje Taastrup",
    171: "Ledøje-Smørum",
    173: "Lyngby-Taarbæk",
    175: "Rødovre",
    181: "Søllerød",
    183: "Ishøj",
    185: "Tårnby",
    187: "Vallensbæk",
    189: "Værløse",
    201: "Allerød",
    205: "Birkerød",
    207: "Farum",
    208: "Fredensborg-Humlebæk",
    209: "Frederikssund",
    211: "Frederiksværk",
    213: "Græsted-Gilleleje",
    215: "Helsinge",
    217: "Helsingør",
    219: "Hillerød",
    221: "Hundested",
    223: "Hørsholm",
    225: "Jægerspris",
    227: "Karlebo",
    229: "Skibby",
    231: "Skævinge",
    233: "Slangerup",
    235: "Stenløse",
    237: "Ølstykke",
    251: "Bramsnæs",
    253: "Greve",
    255: "Gundsø",
    257: "Hvalsø",
    259: "Køge",
    261: "Lejre",
    263: "Ramsø",
    265: "Roskilde",
    267: "Skovbo",
    269: "Solrød",
    271: "Vallø",
    301: "Bjergsted",
    303: "Dianalund",
    305: "Dragsholm",
    307: "Fuglebjerg",
    309: "Gørlev",
    311: "Hashøj",
    313: "Haslev",
    315: "Holbæk",
    317: "Hvidebæk",
    319: "Høng",
    321: "Jernløse",
    323: "Kalundborg",
    325: "Korsør",
    327: "Nykøbing-Rørvig",
    329: "Ringsted",
    331: "Skælskør",
    333: "Slagelse",
    335: "Sorø",
    337: "Stenlille",
    339: "Svinninge",
    341: "Tornved",
    343: "Trundholm",
    345: "Tølløse",
    351: "Fakse",
    353: "Fladså",
    355: "Holeby",
    357: "Holmegaard",
    359: "Højreby",
    361: "Langebæk",
    363: "Maribo",
    365: "Møn",
    367: "Nakskov",
    369: "Nykøbing F.",
    371: "Nysted",
    373: "Næstved",
    375: "Nr. Alslev",
    377: "Præstø",
    379: "Ravnsborg",
    381: "Rudbjerg",
    383: "Rødby",
    385: "Rønnede",
    387: "Sakskøbing",
    389: "Stevns",
    391: "Stubbekøbing",
    393: "Suså",
    395: "Sydfalster",
    397: "Vordingborg",
    401: "Allinge-Gudhjem",
    403: "Hasle",
    405: "Nexø",
    407: "Rønne",
    409: "Aakirkeby",
    411: "Christiansø",
    421: "Assens",
    423: "Bogense",
    425: "Broby",
    427: "Egebjerg",
    429: "Ejby",
    431: "Faaborg",
    433: "Glamsbjerg",
    435: "Gudme",
    437: "Haarby",
    439: "Kerteminde",
    441: "Langeskov",
    443: "Marstal",
    445: "Middelfart",
    447: "Munkebo",
    449: "Nyborg",
    451: "Nørre Aaby",
    461: "Odense",
    471: "Otterup",
    473: "Ringe",
    475: "Rudkøbing",
    477: "Ryslinge",
    479: "Svendborg",
    481: "Sydlangeland",
    483: "Søndersø",
    485: "Tommerup",
    487: "Tranekær",
    489: "Ullerslev",
    491: "Vissenbjerg",
    493: "Ærøskøbing",
    495: "Ørbæk",
    497: "Årslev",
    499: "Aarup",
    501: "Augustenborg",
    503: "Bov",
    505: "Bredebro",
    507: "Broager",
    509: "Christiansfeld",
    511: "Gram",
    513: "Gråsten",
    515: "Haderslev",
    517: "Højer",
    519: "Lundtoft",
    521: "Løgumkloster",
    523: "Nordborg",
    525: "Nr. Rangstrup",
    527: "Rødding",
    529: "Rødekro",
    531: "Skærbæk",
    533: "Sundeved",
    535: "Sydals",
    537: "Sønderborg",
    539: "Tinglev",
    541: "Tønder",
    543: "Vojens",
    545: "Aabenraa",
    551: "Billund",
    553: "Blåbjerg",
    555: "Blåvandshuk",
    557: "Bramming",
    559: "Brørup",
    561: "Esbjerg",
    563: "Fanø",
    565: "Grindsted",
    567: "Helle",
    569: "Holsted",
    571: "Ribe",
    573: "Varde",
    575: "Vejen",
    577: "Ølgod",
    601: "Brædstrup",
    603: "Børkop",
    605: "Egtved",
    607: "Fredericia",
    609: "Gedved",
    611: "Give",
    613: "Hedensted",
    615: "Horsens",
    617: "Jelling",
    619: "Juelsminde",
    621: "Kolding",
    623: "Lunderskov",
    625: "Nr. Snede",
    627: "Tørring-Uldum",
    629: "Vamdrup",
    631: "Vejle",
    651: "Aulum-Haderup",
    653: "Brande",
    655: "Egvad",
    657: "Herning",
    659: "Holmsland",
    661: "Holstebro",
    663: "Ikast",
    665: "Lemvig",
    667: "Ringkøbing",
    669: "Skjern",
    671: "Struer",
    673: "Thyborøn-Harboøre",
    675: "Thyholm",
    677: "Trehøje",
    679: "Ulfborg-Vemb",
    681: "Videbæk",
    683: "Vinderup",
    685: "Åskov",
    701: "Ebeltoft",
    703: "Galten",
    705: "Gjern",
    707: "Grenaa",
    709: "Hadsten",
    711: "Hammel",
    713: "Hinnerup",
    715: "Hørning",
    717: "Langå",
    719: "Mariager",
    721: "Midtdjurs",
    723: "Nørhald",
    725: "Nørre Djurs",
    727: "Odder",
    729: "Purhus",
    731: "Randers",
    733: "Rosenholm",
    735: "Rougsø",
    737: "Ry",
    739: "Rønde",
    741: "Samsø",
    743: "Silkeborg",
    745: "Skanderborg",
    747: "Sønderhald",
    749: "Them",
    751: "Århus",
    761: "Bjerringbro",
    763: "Fjends",
    765: "Hanstholm",
    767: "Hvorslev",
    769: "Karup",
    771: "Kjellerup",
    773: "Morsø",
    775: "Møldrup",
    777: "Sallingsund",
    779: "Skive",
    781: "Spøttrup",
    783: "Sundsøre",
    785: "Sydthy",
    787: "Thisted",
    789: "Tjele",
    791: "Viborg",
    793: "Aalestrup",
    801: "Arden",
    803: "Brovst",
    805: "Brønderslev",
    807: "Dronninglund",
    809: "Farsø",
    811: "Fjerritslev",
    813: "Frederikshavn",
    815: "Hadsund",
    817: "Hals",
    819: "Hirtshals",
    821: "Hjørring",
    823: "Hobro",
    825: "Læsø",
    827: "Løgstør",
    829: "Løkken-Vrå",
    831: "Nibe",
    833: "Nørager",
    835: "Pandrup",
    837: "Sejlflod",
    839: "Sindal",
    841: "Skagen",
    843: "Skørping",
    845: "Støvring",
    847: "Sæby",
    849: "Aabybro",
    851: "Aalborg",
    861: "Aars",
    901: "Christianshåb",
    903: "Egedesminde",
    905: "Frederikshåb",
    907: "Godhavn",
    909: "Godthåb",
    911: "Holsteinsborg",
    913: "Ivigtut",
    915: "Jakobshavn",
    917: "Julianehåb",
    919: "Kangatsiaq",
    921: "Nanortalik",
    923: "Narssaq",
    925: "Sukkertoppen",
    927: "Umanak",
    929: "Upernavik",
    941: "Thule",
    951: "Angmagssalik",
    953: "Scoresbysund",
    961: "Udenfor kommunal inddeling",
}


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--input", required=True, help="Path to the input parquet dataset."
    )
    parser.add_argument(
        "--output", required=True, help="Path to the output parquet dataset."
    )
    parser.add_argument(
        "--winsor-lower",
        type=float,
        default=0.01,
        help="Lower tail probability for winsorisation (default: 0.01).",
    )
    parser.add_argument(
        "--winsor-upper",
        type=float,
        default=0.99,
        help="Upper tail probability for winsorisation (default: 0.99).",
    )
    parser.add_argument(
        "--cpi-base-year",
        type=int,
        default=None,
        help="Reference year for CPI deflation (default: latest year available).",
    )
    parser.add_argument(
        "--log-level",
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
        help="Logging verbosity (default: INFO).",
    )
    return parser.parse_args(argv)


def configure_logging(level: str) -> None:
    logging.basicConfig(
        level=getattr(logging, level),
        format="[%(levelname)s] %(message)s",
    )


def categorize_employment(series: pd.Series) -> pd.Series:
    codes = pd.to_numeric(series, errors="coerce")
    categories = pd.Series("Missing/other", index=series.index, dtype="string")

    categories[codes.isin(list(SOCIO13_WORKING))] = "Working/Student"
    categories[codes.isin(list(SOCIO13_TEMPORARILY_UNEMPLOYED))] = (
        "Temporarily unemployed"
    )
    categories[codes.isin(list(SOCIO13_OUTSIDE))] = "Outside workforce"
    categories[codes.isin(list(SOCIO13_RETIRED))] = "Retired"

    return categories.astype("string")


def categorize_education(series: pd.Series) -> pd.Series:
    levels = pd.to_numeric(series, errors="coerce")
    categories = pd.Series("Unknown", index=series.index, dtype="string")

    categories[levels <= 2] = "Short education"
    categories[levels.isin([3, 4])] = "Medium education"
    categories[levels >= 5] = "Long education"
    categories[levels == 9] = "Unknown"

    categories[pd.isna(levels)] = "Unknown"
    return categories.astype("string")


def _normalise_country_code(value: object) -> Optional[str]:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return None
    text = str(value).strip().upper()
    if not text:
        return None
    text = text.replace(" ", "")
    if text.startswith("D") and len(text) > 1 and text[1:].isdigit():
        text = text[1:]
    return text


def _parse_code_name_file(path: Path) -> Dict[int, str]:
    mapping: Dict[int, str] = {}
    if not path.exists():
        return mapping
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or "='" not in line:
            continue
        try:
            code_str, name_part = line.split("=", 1)
            code = int(code_str)
            name = name_part.strip().strip("'").strip()
            mapping[code] = name
        except Exception:
            continue
    return mapping


def _build_municipality_translation() -> tuple[
    Dict[int, int], Dict[int, str], Dict[int, str]
]:
    global _MUN_TRANSLATION_CACHE, _MUN2007_TO_LAN, _MUN2007_TO_REG
    if (
        _MUN_TRANSLATION_CACHE is not None
        and _MUN2007_TO_LAN is not None
        and _MUN2007_TO_REG is not None
    ):
        return _MUN_TRANSLATION_CACHE, _MUN2007_TO_LAN, _MUN2007_TO_REG

    # Use embedded merge map to derive legacy -> 2007 code mapping
    name_to_code_2007: Dict[str, int] = {}
    for code, name in KOM_MERGE_TO_2007_NAME.items():
        if 100 <= code <= 999:
            name_to_code_2007.setdefault(name, code)

    translation: Dict[int, int] = {}
    for code, name in KOM_MERGE_TO_2007_NAME.items():
        target_code = name_to_code_2007.get(name)
        if target_code is not None:
            translation[code] = target_code
    # Fallback: if a 2007 code isn’t in the merge map, map to itself
    for code, name in KOM_MERGE_TO_2007_NAME.items():
        if 100 <= code <= 999 and code not in translation and name in name_to_code_2007:
            translation[code] = name_to_code_2007[name]

    # LAN/REG maps embedded
    _MUN_TRANSLATION_CACHE = translation
    _MUN2007_TO_LAN = KOM2LAN_2007
    _MUN2007_TO_REG = KOM2REG_2007
    return translation, _MUN2007_TO_LAN, _MUN2007_TO_REG


def normalise_municipality_codes(series: pd.Series) -> pd.DataFrame:
    translation, lan_map, reg_map = _build_municipality_translation()
    codes = pd.to_numeric(series, errors="coerce").astype("Int64")
    normalized = codes.map(translation).astype("Int64")
    lan = normalized.map(lan_map).astype("string")
    reg = normalized.map(reg_map).astype("string")
    return pd.DataFrame(
        {
            "MUN_CODE_2007": normalized,
            "LAN_2007": lan,
            "REGION_2007": reg,
        },
        index=series.index,
    )


def _classify_region(code: Optional[str]) -> Optional[str]:
    if not code:
        return None

    if code in DANISH_COUNTRY_CODES:
        return "danish_origin"
    if code in WESTERN_COUNTRY_CODES:
        return "western"

    if code.isdigit():
        prefix = code[:2]
        if prefix in REGION_PREFIX_MAP:
            return REGION_PREFIX_MAP[prefix]

    return "non_western"


def _split_parent_codes(value: object) -> List[str]:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return []
    text = str(value).strip()
    if not text:
        return []
    separators = [";", ",", "|"]
    for sep in separators:
        if sep in text:
            parts = [part for part in text.split(sep) if part]
            normalized = [_normalise_country_code(part) for part in parts]
            return [code for code in normalized if code]
    parts = text.split()
    if len(parts) > 1:
        normalized = [_normalise_country_code(part) for part in parts]
        return [code for code in normalized if code]
    code = _normalise_country_code(text)
    return [code] if code else []


def categorize_ethnicity(
    child_country: pd.Series,
    parent_country: pd.Series,
    child_ie_type: pd.Series,
) -> pd.Series:
    child_codes = child_country.map(_normalise_country_code)
    parent_codes = parent_country.map(_split_parent_codes)
    ie_types = pd.to_numeric(child_ie_type, errors="coerce")

    categories: List[str] = []
    for idx in child_country.index:
        child_code = child_codes.at[idx]
        parents = [code for code in parent_codes.at[idx] if code]
        ie_type = ie_types.at[idx]

        child_danish = child_code in DANISH_COUNTRY_CODES
        child_western = child_code in WESTERN_COUNTRY_CODES
        child_non_western = (
            child_code not in DANISH_COUNTRY_CODES
            and child_code not in WESTERN_COUNTRY_CODES
            and child_code is not None
        )

        parents_danish = parents and all(
            code in DANISH_COUNTRY_CODES for code in parents
        )
        parents_western = parents and any(
            code in WESTERN_COUNTRY_CODES for code in parents
        )
        parents_non_western = parents and any(
            (code not in DANISH_COUNTRY_CODES) and (code not in WESTERN_COUNTRY_CODES)
            for code in parents
        )

        if ie_type == 1:
            categories.append("Danish Origin")
            continue

        if child_danish and (not parents or parents_danish):
            categories.append("Danish Origin")
            continue

        if child_western:
            categories.append("Western")
            continue

        if child_non_western:
            categories.append("Non-Western")
            continue

        if child_danish and parents_western and not parents_non_western:
            categories.append("Western")
            continue

        if child_danish and parents_non_western:
            categories.append("Non-Western")
            continue

        if parents_western and not parents_non_western:
            categories.append("Western")
            continue

        if parents_non_western:
            categories.append("Non-Western")
            continue

        if ie_type in {2, 3}:
            categories.append("Non-Western")
            continue

        categories.append("Unknown")

    return pd.Series(categories, index=child_country.index, dtype="string")


def categorize_cohabitation(
    familie_type: pd.Series,
    civst: pd.Series,
    civ_vfra: pd.Series,
) -> pd.Series:
    familie_codes = pd.to_numeric(familie_type, errors="coerce")
    civst_codes = civst.astype("string").str.upper().str.strip()

    cohab_status = pd.Series("Missing", index=familie_type.index, dtype="string")
    cohab_status[familie_codes.isin(list(FAMILIE_TYPE_COHABITING))] = "Cohabiting"
    cohab_status[familie_codes.isin(list(FAMILIE_TYPE_ALONE))] = "Living alone"

    marital_status = pd.Series("Missing", index=civst.index, dtype="string")
    marital_status[civst_codes.isin(list(CIVST_MARRIED))] = "Married"
    marital_status[civst_codes.isin(list(CIVST_NOT_MARRIED))] = "Not married"

    labels: List[str] = []
    for idx in familie_type.index:
        cohab = cohab_status.at[idx]
        marital = marital_status.at[idx]

        if cohab == "Cohabiting" or marital == "Married":
            labels.append("Cohabiting/Married")
        elif cohab == "Living alone" or marital == "Not married":
            labels.append("LivingAlone/NotMarried")
        else:
            labels.append("LivingAlone/NotMarried")

    return pd.Series(labels, index=familie_type.index, dtype="string")


def winsorise(series: pd.Series, lower: float, upper: float) -> pd.Series:
    if series.dropna().empty:
        return series
    quantiles = series.quantile([lower, upper])
    lower_bound = quantiles.iloc[0]
    upper_bound = quantiles.iloc[1]
    return series.clip(lower=lower_bound, upper=upper_bound)


def winsorise_by_group(
    df: pd.DataFrame,
    column: str,
    group_column: str,
    lower: float,
    upper: float,
) -> pd.Series:
    if group_column not in df.columns:
        raise KeyError(f"Grouping column '{group_column}' not found in dataframe.")

    numeric = pd.to_numeric(df[column], errors="coerce")
    grouped = numeric.groupby(df[group_column], observed=True)
    lower_bounds = grouped.quantile(lower)
    upper_bounds = grouped.quantile(upper)

    lower_map = lower_bounds.reindex(df[group_column]).to_numpy()
    upper_map = upper_bounds.reindex(df[group_column]).to_numpy()

    global_quantiles = numeric.quantile([lower, upper])
    global_lower = global_quantiles.iloc[0]
    global_upper = global_quantiles.iloc[1]

    lower_map = np.where(np.isnan(lower_map), global_lower, lower_map)
    upper_map = np.where(np.isnan(upper_map), global_upper, upper_map)

    clipped = np.clip(numeric.to_numpy(dtype=float), lower_map, upper_map)
    return pd.Series(clipped, index=df.index)


def deflate_outcomes(
    df: pd.DataFrame,
    base_year: Optional[int],
    outcomes: Sequence[str] = ("PERINDKIALT_13", "LOENMV_13"),
) -> pd.DataFrame:
    if "YEAR" not in df.columns:
        LOGGER.warning("Column 'YEAR' missing; skipping CPI deflation.")
        return df

    cpi_df = pd.DataFrame(
        {
            "YEAR": list(ANNUAL_CPI_INDEX.keys()),
            "CPI_VALUE": list(ANNUAL_CPI_INDEX.values()),
        }
    )
    df = df.copy()
    max_year = int(df["YEAR"].max())
    last_cpi_year = int(cpi_df["YEAR"].max())
    if max_year > last_cpi_year:
        last_value = float(
            cpi_df.loc[cpi_df["YEAR"] == last_cpi_year, "CPI_VALUE"].iloc[0]
        )
        extra_years = pd.DataFrame(
            {"YEAR": range(last_cpi_year + 1, max_year + 1), "CPI_VALUE": last_value}
        )
        cpi_df = pd.concat([cpi_df, extra_years], ignore_index=True)

    reference_year = base_year if base_year is not None else DEFAULT_CPI_BASE_YEAR
    if reference_year not in set(cpi_df["YEAR"]):
        raise ValueError(f"Reference year {reference_year} not available in CPI table.")
    reference_value = float(
        cpi_df.loc[cpi_df["YEAR"] == reference_year, "CPI_VALUE"].iloc[0]
    )
    cpi_df["__deflator"] = reference_value / cpi_df["CPI_VALUE"]

    df = df.merge(cpi_df[["YEAR", "__deflator"]], on="YEAR", how="left")
    if df["__deflator"].isna().any():
        missing = df.loc[df["__deflator"].isna(), "YEAR"].unique()
        LOGGER.warning(
            "Missing CPI values for years: %s. Using reference-year deflator instead.",
            ", ".join(map(str, sorted(missing))),
        )
        df["__deflator"] = df["__deflator"].fillna(1.0)

    LOGGER.info(
        "Deflating monetary outcomes using CPI reference year %s (value %.2f)",
        reference_year,
        reference_value,
    )

    for outcome in outcomes:
        if outcome not in df.columns:
            LOGGER.warning("Outcome column '%s' missing; skipping deflation.", outcome)
            continue
        nominal_series = pd.to_numeric(df[outcome], errors="coerce")
        if nominal_series.isna().all():
            LOGGER.warning(
                "Outcome column '%s' contains no numeric data after coercion; skipping.",
                outcome,
            )
            continue
        nominal_dkk = nominal_series
        df[f"{outcome}_nominal_dkk"] = nominal_dkk
        df[f"{outcome}_nominal_eur"] = nominal_dkk / DKK_PER_EUR
        df[f"{outcome}_deflated_dkk"] = nominal_dkk * df["__deflator"]
        df[f"{outcome}_deflated_eur"] = df[f"{outcome}_deflated_dkk"] / DKK_PER_EUR
        df[f"{outcome}_deflated"] = df[f"{outcome}_deflated_eur"]
        df[outcome] = df[f"{outcome}_deflated_eur"]

    df = df.drop(columns="__deflator")
    return df


def add_categorizations(
    df: pd.DataFrame,
    winsor_lower: float,
    winsor_upper: float,
) -> pd.DataFrame:
    enriched = df.copy()

    if "SOCIO13" in enriched.columns:
        LOGGER.info("Creating employment_category from SOCIO13")
        enriched["employment_category"] = categorize_employment(enriched["SOCIO13"])
    else:
        LOGGER.warning(
            "Column 'SOCIO13' not found; skipping employment categorization."
        )

    if "ISCED" in enriched.columns:
        LOGGER.info("Creating education_category from ISCED")
        enriched["education_category"] = categorize_education(enriched["ISCED"])
    else:
        LOGGER.warning("Column 'ISCED' not found; skipping education categorization.")

    if "MUN_CODE" in enriched.columns:
        LOGGER.info(
            "Standardizing municipality codes to 2007 version and mapping to LAN/REGION"
        )
        geo_df = normalise_municipality_codes(enriched["MUN_CODE"])
        for col in geo_df.columns:
            enriched[col] = geo_df[col]
    else:
        LOGGER.warning(
            "Column 'MUN_CODE' not found; skipping municipality/region mapping."
        )

    required_ethnicity_cols = {"PARENT_OPR_LAND", "CHILD_OPR_LAND", "CHILD_IE_TYPE"}
    if required_ethnicity_cols.issubset(enriched.columns):
        LOGGER.info("Creating ethnicity_category from origin columns")
        enriched["ethnicity_category"] = categorize_ethnicity(
            enriched["CHILD_OPR_LAND"],
            enriched["PARENT_OPR_LAND"],
            enriched["CHILD_IE_TYPE"],
        )
    else:
        missing = required_ethnicity_cols - set(enriched.columns)
        LOGGER.warning(
            "Skipping ethnicity categorization; missing columns: %s",
            ", ".join(sorted(missing)),
        )

    required_cohab_cols = {"FAMILIE_TYPE", "CIVST", "CIV_VFRA"}
    if required_cohab_cols.issubset(enriched.columns):
        LOGGER.info(
            "Creating cohabitation_category from family and civil status columns"
        )
        enriched["cohabitation_category"] = categorize_cohabitation(
            enriched["FAMILIE_TYPE"],
            enriched["CIVST"],
            enriched["CIV_VFRA"],
        )
    else:
        missing = required_cohab_cols - set(enriched.columns)
        LOGGER.warning(
            "Skipping cohabitation categorization; missing columns: %s",
            ", ".join(sorted(missing)),
        )

    group_column = "YEAR"
    for outcome in ("PERINDKIALT_13", "LOENMV_13"):
        if outcome in enriched.columns:
            if group_column in enriched.columns:
                LOGGER.info(
                    "Winsorising %s by %s (%.2f, %.2f)",
                    outcome,
                    group_column,
                    winsor_lower,
                    winsor_upper,
                )
                enriched[f"{outcome}_winsorized"] = winsorise_by_group(
                    enriched,
                    outcome,
                    group_column,
                    winsor_lower,
                    winsor_upper,
                )
            else:
                LOGGER.warning(
                    "Grouping column '%s' missing; applying global winsorisation to %s.",
                    group_column,
                    outcome,
                )
                enriched[f"{outcome}_winsorized"] = winsorise(
                    pd.to_numeric(enriched[outcome], errors="coerce"),
                    winsor_lower,
                    winsor_upper,
                )
        else:
            LOGGER.warning(
                "Outcome column '%s' not found; skipping winsorisation.", outcome
            )

    return enriched


def main(argv: Optional[Sequence[str]] = None) -> None:
    args = parse_args(argv)
    configure_logging(args.log_level)

    input_path = Path(args.input)
    output_path = Path(args.output)

    LOGGER.info("Reading parquet data from %s", input_path)
    df = pd.read_parquet(input_path)

    df = deflate_outcomes(df, args.cpi_base_year)

    enriched = add_categorizations(df, args.winsor_lower, args.winsor_upper)

    LOGGER.info("Writing enriched data to %s", output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    enriched.to_parquet(output_path, index=False)
    LOGGER.info("Preprocessing completed successfully.")


if __name__ == "__main__":
    main()
