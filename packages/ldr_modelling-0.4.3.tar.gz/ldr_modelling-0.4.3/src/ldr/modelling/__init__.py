# Copyright 2025 Louder Digital Pty Ltd.
# All Rights Reserved.
"""Pydantic helpers to inherit from when modelling data."""
