{{ objname }}
{{ underline }}==============

.. currentmodule:: {{ module }}

.. autofunction:: {{ objname }}

.. example_links:: {{ objname }}