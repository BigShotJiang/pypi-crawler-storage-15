class Problem:
    def __init__(self, leader, follower):
        self.leader = leader
        self.follower = follower
