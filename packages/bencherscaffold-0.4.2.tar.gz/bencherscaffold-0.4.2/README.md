# BencherScaffold

This repository contains the scaffold for the [Bencher](https://github.com/LeoIV/Bencher) project.
It contains the protobuf files and the generated python code to communicate with the Bencher server.

Please refer to the [Bencher](https://github.com/LeoIV/Bencher) repository for more information.

## Installation

```shell
pip install git+https://github.com/LeoIV/BencherScaffold.git
```

## Usage

See the [Bencher](https://github.com/LeoIV/Bencher) repository for usage examples.