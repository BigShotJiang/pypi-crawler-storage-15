Server Startup
==============

To start the server::

    $ python bin/iceprod_server.py start

Other useful commands:

* restart
* stop
* kill
