.. index:: plugins_condor
.. _plugins_condor:

Condor Plugin
=============

.. automodule:: iceprod.server.plugins.condor
   