# Changelog

## v0.1.1 - 2025-12-05

- Improve desired state stability:
  - Sort slices by name during unrolling
  - Preserve embedded entities order from slice source
- Fix deletion of embedded entities

## v0.1.0 - 2025-12-03

- Initial functional release

## v0.0.1 - 2025-10-04

- First empty release
