from .captcha_solver import oca_solve_captcha
from .captcha_solver import oca_solve_captcha_async

__all__ = ['oca_solve_captcha']

__all__ = ['oca_solve_captcha_async']
