---
parent: Installation
nav_order: 900
---

### Replit

{% include replit-pipx.md %}
