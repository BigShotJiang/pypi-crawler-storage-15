from .prox_l_bfgs_score import ProxLQNSCORE
from .prox_n_score import ProxNSCORE
from .prox_ggn_score import ProxGGNSCORE