"""Version information for Mirmer AI SDK."""

__version__ = "0.1.0"
