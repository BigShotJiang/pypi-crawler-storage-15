# src/utils_devops/extras/ssh_ops.py
"""
SSH Operations Module for utils_devops

Provides clean, pragmatic SSH/SCP operations integrated with utils_devops core.
Zero bloat, maximum utility.

Dependencies: paramiko, scp (optional: sshtunnel for port forwarding)
"""

import os
import sys
from contextlib import contextmanager
from pathlib import Path
import time
from typing import Callable, Optional, Tuple, Union, List, Dict, Generator, Any
import concurrent.futures
import threading

from core import datetimes

# Core imports
from ..core.logs import task, get_logger, debug, info, warning, error
from ..core import systems
from ..core import files

try:
    import paramiko
    from scp import SCPClient
except ImportError:
    raise ImportError(
        "ssh_ops requires paramiko and scp. Install with: "
        "pip install paramiko scp"
    )

try:
    from sshtunnel import SSHTunnelForwarder
except ImportError:
    SSHTunnelForwarder = None

__all__ = [
    "ssh_connect",
    "ssh_run_command", 
    "ssh_run_live",
    "scp_put",
    "scp_get",
    "ssh_register_key",
    "ssh_test_connection",
    "ssh_parallel_commands",
    "ssh_tunnel",
    "sshfs_mount",
    "sshfs_umount",
    "sshfs_add_permanent",
    "sshfs_remove_permanent", 
    "sshfs_list_permanent",
]

# Module logger
_logger = get_logger()

class SSHOpsError(Exception):
    """Custom exception for SSH operations failures."""
    pass

def help() -> None:
    """Print help index for SSH operations."""
    help_text = """
SSH Operations Module - Usage Reference
=======================================

Core Connection & Commands:
---------------------------
ssh_connect(host, username="root", password=None, key_file=None, port=22, timeout=20, compress=True, auto_add_host=True)
    Context manager for SSH connections. Auto-closes connection.

ssh_run_command(host, command, username="root", password=None, key_file=None, port=22, sudo=False, hide_on_success=True, check=False)
    Run command remotely, returns subprocess.CompletedProcess. Integrated with task() and logging.

ssh_run_live(host, command, username="root", **kwargs)
    Run command with live streaming output (no buffering).

File Transfer:
--------------
scp_put(local_path, remote_path, host, username="root", recursive=True, preserve_times=True, **kwargs)
    Upload file/directory via SCP.

scp_get(remote_path, local_path, host, username="root", recursive=True, **kwargs)
    Download file/directory via SCP.

Key Management:
---------------
ssh_register_key(host, username="root", public_key=None, key_file=None, password=None, port=22)
    Setup passwordless login by adding public key to remote authorized_keys.

Utility Functions:
------------------
ssh_test_connection(host, username="root", port=22, timeout=10, **kwargs)
    Quick connectivity test.

ssh_parallel_commands(hosts, command, max_workers=15, **common_kwargs)
    Run command on multiple hosts in parallel.

Advanced (Optional):
--------------------
ssh_tunnel(host, local_port, remote_host="127.0.0.1", remote_port=80, username="root", **kwargs)
    SSH port forwarding context manager.

sshfs_mount(host, remote_path="/", local_mountpoint=None, username="root", port=22, key_file=None, options="-o reconnect,follow_symlinks", **kwargs)
    Mount remote filesystem via SSHFS.

sshfs_umount(mountpoint, lazy=True)
    Unmount SSHFS directory.
"""
    print(help_text)

@contextmanager
def ssh_connect(
    host: str,
    username: str = "root",
    password: Optional[str] = None,
    key_file: Optional[Union[str, Path]] = None,
    port: int = 22,
    timeout: int = 20,
    compress: bool = True,
    auto_add_host: bool = True,
    **kwargs: Any,
) -> Generator[paramiko.SSHClient, None, None]:
    """
    Context manager for SSH connections.
    
    Args:
        host: Remote hostname or IP
        username: SSH username (default: root)
        password: SSH password (optional if using key auth)
        key_file: Path to private key file
        port: SSH port (default: 22)
        timeout: Connection timeout in seconds
        compress: Enable compression
        auto_add_host: Automatically add host to known_hosts
    
    Yields:
        paramiko.SSHClient: Connected SSH client
        
    Raises:
        SSHOpsError: On connection failure
    """
    client = None
    try:
        debug(f"Connecting to {username}@{host}:{port}")
        client = paramiko.SSHClient()
        
        if auto_add_host:
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        else:
            client.load_system_host_keys()
        
        connect_kwargs = {
            'hostname': host,
            'username': username,
            'port': port,
            'timeout': timeout,
            'compress': compress,
        }
        
        if key_file:
            key_path = Path(key_file).expanduser()
            if key_path.exists():
                connect_kwargs['key_filename'] = str(key_path)
            else:
                warning(f"SSH key file not found: {key_file}")
        
        if password:
            connect_kwargs['password'] = password
        
        # Merge any additional kwargs
        connect_kwargs.update(kwargs)
        
        client.connect(**connect_kwargs)
        info(f"Connected to {username}@{host}:{port}")
        
        yield client
        
    except Exception as e:
        error(f"SSH connection failed to {host}: {e}")
        raise SSHOpsError(f"SSH connection failed: {e}") from e
    finally:
        if client:
            client.close()
            debug(f"Disconnected from {host}")

def ssh_run_command(
    host: str,
    command: Union[str, List[str]],
    username: str = "root",
    password: Optional[str] = None,
    key_file: Optional[Union[str, Path]] = None,
    port: int = 22,
    sudo: bool = False,
    hide_on_success: bool = True,
    check: bool = False,
    **kwargs: Any,
) -> systems.subprocess.CompletedProcess:
    """
    Run command on remote host via SSH.
    
    Args:
        host: Remote hostname or IP
        command: Command to execute (string or list)
        username: SSH username
        password: SSH password
        key_file: Path to private key file
        port: SSH port
        sudo: Run command with sudo
        hide_on_success: Hide output on success (integrated with task())
        check: Raise exception on non-zero exit code
    
    Returns:
        systems.subprocess.CompletedProcess: Result with stdout, stderr, returncode
    """
    if isinstance(command, list):
        command_str = " ".join(command)
    else:
        command_str = command
        
    if sudo:
        command_str = f"sudo {command_str}"
    
    task_name = f"SSH {username}@{host}: {command_str}"
    
    with task(task_name, hide_on_success=hide_on_success):
        try:
            with ssh_connect(host, username, password, key_file, port, **kwargs) as client:
                debug(f"Executing: {command_str}")
                
                stdin, stdout, stderr = client.exec_command(command_str)
                exit_code = stdout.channel.recv_exit_status()
                
                stdout_text = stdout.read().decode('utf-8').strip()
                stderr_text = stderr.read().decode('utf-8').strip()
                
                if stdout_text:
                    debug(f"STDOUT: {stdout_text}")
                if stderr_text:
                    debug(f"STDERR: {stderr_text}")
                
                result = systems.subprocess.CompletedProcess(
                    args=command_str,
                    returncode=exit_code,
                    stdout=stdout_text,
                    stderr=stderr_text
                )
                
                if check and exit_code != 0:
                    raise SSHOpsError(f"Command failed with exit code {exit_code}: {stderr_text}")
                
                return result
                
        except Exception as e:
            error(f"SSH command failed: {e}")
            if check:
                raise
            return systems.subprocess.CompletedProcess(
                args=command_str,
                returncode=1,
                stdout="",
                stderr=str(e)
            )

def ssh_run_live(
    host: str,
    command: Union[str, List[str]],
    username: str = "root",
    **kwargs: Any,
) -> systems.subprocess.CompletedProcess:
    """
    Run command with live streaming output.
    
    Args:
        host: Remote hostname or IP
        command: Command to execute
        username: SSH username
        **kwargs: Additional arguments for ssh_connect
    
    Returns:
        systems.subprocess.CompletedProcess: Command result
    """
    if isinstance(command, list):
        command_str = " ".join(command)
    else:
        command_str = command
    
    info(f"🚀 SSH {username}@{host}: {command_str}")
    
    try:
        with ssh_connect(host, username, **kwargs) as client:
            stdin, stdout, stderr = client.exec_command(command_str)
            
            # Stream output live
            stdout_lines = []
            stderr_lines = []
            
            for line in iter(stdout.readline, ""):
                if line:
                    print(f"[{host}] {line}", end='')
                    stdout_lines.append(line)
            
            for line in iter(stderr.readline, ""):
                if line:
                    print(f"[{host} ERROR] {line}", end='', file=sys.stderr)
                    stderr_lines.append(line)
            
            exit_code = stdout.channel.recv_exit_status()
            
            result = systems.subprocess.CompletedProcess(
                args=command_str,
                returncode=exit_code,
                stdout="".join(stdout_lines),
                stderr="".join(stderr_lines)
            )
            
            if exit_code != 0:
                warning(f"Command exited with code {exit_code}")
            
            return result
            
    except Exception as e:
        error(f"SSH live command failed: {e}")
        return systems.subprocess.CompletedProcess(
            args=command_str,
            returncode=1,
            stdout="",
            stderr=str(e)
        )

def scp_put(
    local_path: Union[str, Path],
    remote_path: str,
    host: str,
    username: str = "root",
    recursive: bool = True,
    preserve_times: bool = True,
    **kwargs: Any,
) -> None:
    """
    Upload file or directory via SCP.
    
    Args:
        local_path: Local file/directory path
        remote_path: Remote destination path
        host: Remote hostname or IP
        username: SSH username
        recursive: Recursive copy for directories
        preserve_times: Preserve file timestamps
        **kwargs: Additional arguments for ssh_connect
    """
    local_path = Path(local_path).expanduser().resolve()
    
    if not local_path.exists():
        raise SSHOpsError(f"Local path does not exist: {local_path}")
    
    task_name = f"SCP PUT {local_path} → {username}@{host}:{remote_path}"
    
    with task(task_name):
        try:
            with ssh_connect(host, username, **kwargs) as client:
                with SCPClient(client.get_transport()) as scp:
                    if local_path.is_dir() and recursive:
                        scp.put(str(local_path), remote_path, recursive=True, preserve_times=preserve_times)
                        info(f"Uploaded directory: {local_path} → {remote_path}")
                    else:
                        scp.put(str(local_path), remote_path, preserve_times=preserve_times)
                        info(f"Uploaded file: {local_path} → {remote_path}")
                        
        except Exception as e:
            error(f"SCP upload failed: {e}")
            raise SSHOpsError(f"SCP upload failed: {e}") from e

def scp_get(
    remote_path: str,
    local_path: Union[str, Path],
    host: str,
    username: str = "root",
    recursive: bool = True,
    **kwargs: Any,
) -> None:
    """
    Download file or directory via SCP.
    
    Args:
        remote_path: Remote file/directory path
        local_path: Local destination path
        host: Remote hostname or IP
        username: SSH username
        recursive: Recursive copy for directories
        **kwargs: Additional arguments for ssh_connect
    """
    local_path = Path(local_path).expanduser().resolve()
    
    # Ensure parent directory exists
    files.ensure_dir(local_path.parent)
    
    task_name = f"SCP GET {username}@{host}:{remote_path} → {local_path}"
    
    with task(task_name):
        try:
            with ssh_connect(host, username, **kwargs) as client:
                with SCPClient(client.get_transport()) as scp:
                    scp.get(remote_path, str(local_path), recursive=recursive)
                    info(f"Downloaded: {remote_path} → {local_path}")
                        
        except Exception as e:
            error(f"SCP download failed: {e}")
            raise SSHOpsError(f"SCP download failed: {e}") from e

def ssh_register_key(
    host: str,
    username: str = "root",
    public_key: Optional[Union[str, Path]] = None,
    key_file: Optional[Union[str, Path]] = None,
    password: Optional[str] = None,
    port: int = 22,
) -> None:
    """
    Setup passwordless SSH login by adding public key to remote authorized_keys.
    
    Args:
        host: Remote hostname or IP
        username: SSH username
        public_key: Path to public key file, or public key string
        key_file: Path to private key file (used to derive public key)
        password: SSH password for initial connection
        port: SSH port
    """
    # Determine public key content
    pubkey_content = None
    
    if public_key:
        if isinstance(public_key, str) and public_key.startswith('ssh-'):
            # public_key is the actual key string
            pubkey_content = public_key.strip()
        else:
            # public_key is a file path
            pubkey_path = Path(public_key).expanduser()
            if pubkey_path.exists():
                pubkey_content = pubkey_path.read_text().strip()
    
    if not pubkey_content and key_file:
        # Try to derive public key from private key
        privkey_path = Path(key_file).expanduser()
        pubkey_path = Path(f"{key_file}.pub")
        
        if pubkey_path.exists():
            pubkey_content = pubkey_path.read_text().strip()
        else:
            warning(f"Public key not found: {pubkey_path}")
    
    if not pubkey_content:
        raise SSHOpsError("Could not determine public key content")
    
    task_name = f"Register SSH key for {username}@{host}"
    
    with task(task_name):
        try:
            # Create .ssh directory and authorized_keys file
            commands = [
                "mkdir -p ~/.ssh",
                "chmod 700 ~/.ssh",
                f"echo '{pubkey_content}' >> ~/.ssh/authorized_keys",
                "chmod 600 ~/.ssh/authorized_keys"
            ]
            
            for cmd in commands:
                result = ssh_run_command(
                    host, cmd, username, password=password, port=port,
                    check=True, hide_on_success=False
                )
            
            info(f"SSH key registered for {username}@{host}")
            
        except Exception as e:
            error(f"SSH key registration failed: {e}")
            raise SSHOpsError(f"SSH key registration failed: {e}") from e

def ssh_test_connection(
    host: str,
    username: str = "root",
    port: int = 22,
    timeout: int = 10,
    **kwargs: Any,
) -> bool:
    """
    Quick SSH connectivity test.
    
    Args:
        host: Remote hostname or IP
        username: SSH username
        port: SSH port
        timeout: Connection timeout
        **kwargs: Additional arguments for ssh_connect
    
    Returns:
        bool: True if connection successful
    """
    try:
        with ssh_connect(host, username, port=port, timeout=timeout, **kwargs):
            debug(f"SSH test successful: {username}@{host}:{port}")
            return True
    except Exception as e:
        debug(f"SSH test failed: {username}@{host}:{port} - {e}")
        return False

def ssh_parallel_commands(
    hosts: List[str],
    command: Union[str, List[str]],
    max_workers: int = 15,
    **common_kwargs: Any,
) -> Dict[str, systems.subprocess.CompletedProcess]:
    """
    Run command on multiple hosts in parallel.
    
    Args:
        hosts: List of hostnames or IPs
        command: Command to execute on all hosts
        max_workers: Maximum number of parallel workers
        **common_kwargs: Common arguments for all SSH connections
    
    Returns:
        Dict mapping host -> subprocess.CompletedProcess
    """
    results = {}
    
    def _run_on_host(host):
        try:
            result = ssh_run_command(host, command, **common_kwargs)
            return host, result
        except Exception as e:
            error(f"Parallel command failed on {host}: {e}")
            return host, systems.subprocess.CompletedProcess(
                args=command,
                returncode=1,
                stdout="",
                stderr=str(e)
            )
    
    with task(f"Parallel SSH on {len(hosts)} hosts: {command}"):
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_host = {
                executor.submit(_run_on_host, host): host 
                for host in hosts
            }
            
            for future in concurrent.futures.as_completed(future_to_host):
                host, result = future.result()
                results[host] = result
                
                if result.returncode == 0:
                    debug(f"✅ {host}: Success")
                else:
                    warning(f"❌ {host}: Failed (code {result.returncode})")
    
    return results

# Optional advanced functions

@contextmanager
def ssh_tunnel(
    host: str,
    local_port: int,
    remote_host: str = "127.0.0.1",
    remote_port: int = 80,
    username: str = "root",
    **kwargs: Any,
) -> Generator[int, None, None]:
    """
    SSH port forwarding tunnel.
    
    Requires: pip install sshtunnel
    
    Args:
        host: SSH gateway host
        local_port: Local port to bind (0 for auto)
        remote_host: Remote host to forward to
        remote_port: Remote port to forward
        username: SSH username
        **kwargs: Additional SSH connection parameters
    
    Yields:
        int: Actual local port used
    """
    if SSHTunnelForwarder is None:
        raise SSHOpsError("sshtunnel package required for SSH tunneling")
    
    tunnel = None
    try:
        ssh_kwargs = {k: v for k, v in kwargs.items() if k not in ['password', 'key_file']}
        
        if 'key_file' in kwargs:
            ssh_kwargs['ssh_pkey'] = str(Path(kwargs['key_file']).expanduser())
        if 'password' in kwargs:
            ssh_kwargs['ssh_password'] = kwargs['password']
        
        tunnel = SSHTunnelForwarder(
            (host, kwargs.get('port', 22)),
            ssh_username=username,
            remote_bind_address=(remote_host, remote_port),
            local_bind_address=('127.0.0.1', local_port),
            **ssh_kwargs
        )
        
        tunnel.start()
        actual_port = tunnel.local_bind_port
        info(f"SSH tunnel: localhost:{actual_port} → {host} → {remote_host}:{remote_port}")
        
        yield actual_port
        
    except Exception as e:
        error(f"SSH tunnel failed: {e}")
        raise SSHOpsError(f"SSH tunnel failed: {e}") from e
    finally:
        if tunnel:
            tunnel.stop()

def sshfs_mount(
    host: str,
    remote_path: str = "/",
    local_mountpoint: Optional[Union[str, Path]] = None,
    username: str = "root",
    port: int = 22,
    key_file: Optional[Union[str, Path]] = None,
    options: str = "-o reconnect,follow_symlinks",
    **kwargs: Any,
) -> Path:
    """
    Mount remote filesystem via SSHFS.
    
    Args:
        host: Remote hostname or IP
        remote_path: Remote path to mount
        local_mountpoint: Local mount point (auto-created if None)
        username: SSH username
        port: SSH port
        key_file: SSH private key file
        options: SSHFS options
        **kwargs: Additional arguments
    
    Returns:
        Path: Local mount point path
    """
    if local_mountpoint is None:
        # Auto-generate mount point
        mount_name = f"{host}_{remote_path.replace('/', '_').strip('_')}"
        local_mountpoint = Path(f"/mnt/sshfs/{mount_name}")
    
    local_mountpoint = Path(local_mountpoint)
    files.ensure_dir(local_mountpoint)
    
    # Build SSHFS command
    sshfs_cmd = f"sshfs {username}@{host}:{remote_path} {local_mountpoint}"
    
    if port != 22:
        sshfs_cmd += f" -p {port}"
    
    if key_file:
        key_path = Path(key_file).expanduser()
        if key_path.exists():
            sshfs_cmd += f" -o IdentityFile={key_path}"
    
    if options:
        sshfs_cmd += f" {options}"
    
    task_name = f"SSHFS mount {username}@{host}:{remote_path} → {local_mountpoint}"
    
    with task(task_name):
        result = systems.run(sshfs_cmd, shell=True, check=True)
        info(f"SSHFS mounted: {local_mountpoint}")
        
        return local_mountpoint

def sshfs_umount(mountpoint: Union[str, Path], lazy: bool = True) -> None:
    """
    Unmount SSHFS directory.
    
    Args:
        mountpoint: Local mount point path
        lazy: Lazy unmount (force if busy)
    """
    mountpoint = Path(mountpoint)
    
    if not mountpoint.exists():
        warning(f"Mount point does not exist: {mountpoint}")
        return
    
    cmd = f"umount {'-l' if lazy else ''} {mountpoint}"
    
    with task(f"SSHFS unmount {mountpoint}"):
        try:
            systems.run(cmd, shell=True, check=True)
            info(f"SSHFS unmounted: {mountpoint}")
        except Exception as e:
            error(f"SSHFS unmount failed: {e}")
            # Try force unmount
            if not lazy:
                systems.run(f"umount -f {mountpoint}", shell=True, check=False)
                warning(f"Force unmounted: {mountpoint}")
                

def sshfs_add_permanent(
    host: str,
    remote_path: str,
    local_mountpoint: Union[str, Path],
    username: str = "root",
    key_file: Optional[Union[str, Path]] = None,
    options: Optional[str] = None,
    backup: bool = True,
) -> None:
    """
    Add permanent SSHFS mount to /etc/fstab with auto-mounting.
    
    Args:
        host: Remote hostname or IP
        remote_path: Remote path to mount
        local_mountpoint: Local mount point
        username: SSH username
        key_file: SSH private key file (required)
        options: Additional SSHFS options (comma-separated)
        backup: Backup /etc/fstab before modification
    """
    if not key_file:
        raise SSHOpsError("key_file is required for permanent SSHFS mounts")
    
    key_file = Path(key_file).expanduser().resolve()
    if not key_file.exists():
        raise SSHOpsError(f"SSH key file not found: {key_file}")
    
    local_mountpoint = Path(local_mountpoint).resolve()
    
    # Ensure local mount directory exists
    files.ensure_dir(local_mountpoint)
    
    # Build options string
    base_options = [
        "fuse.sshfs",
        "allow_other",
        "default_permissions",
        f"IdentityFile={key_file}",
        "reconnect",
        "ServerAliveInterval=15",
        "ServerAliveCountMax=3",
        "_netdev",
        "x-systemd.automount",
        "x-systemd.requires=network-online.target"
    ]
    
    if options:
        base_options.extend([opt.strip() for opt in options.split(',')])
    
    options_str = ",".join(base_options)
    
    # Build fstab entry
    fstab_entry = f"{username}@{host}:{remote_path} {local_mountpoint} {options_str} 0 0"
    
    task_name = f"Add permanent SSHFS mount: {local_mountpoint}"
    
    with task(task_name):
        try:
            # Define markers for our block
            start_marker = "# BEGIN utils_devops SSHFS mounts"
            end_marker = "# END utils_devops SSHFS mounts"
            
            # Read current fstab
            fstab_path = Path("/etc/fstab")
            if not fstab_path.exists():
                raise SSHOpsError("/etc/fstab does not exist")
            
            current_content = files.read_file(fstab_path)
            
            # Check if entry already exists for this mountpoint
            if str(local_mountpoint) in current_content:
                # Find and remove existing entry for this mountpoint
                lines = current_content.splitlines()
                new_lines = []
                for line in lines:
                    if line.strip() and not line.strip().startswith('#') and str(local_mountpoint) in line:
                        debug(f"Removing existing mount entry: {line.strip()}")
                        continue
                    new_lines.append(line)
                current_content = "\n".join(new_lines)
            
            # Check if our block exists
            if start_marker in current_content and end_marker in current_content:
                # Extract existing block and append new entry
                start_idx = current_content.find(start_marker)
                end_idx = current_content.find(end_marker) + len(end_marker)
                
                before_block = current_content[:start_idx].strip()
                after_block = current_content[end_idx:].strip()
                
                block_content = current_content[start_idx:end_idx]
                
                # Add new entry to block
                if block_content.strip().endswith(end_marker):
                    # Insert before end marker
                    new_block = block_content.replace(
                        end_marker, 
                        f"    {fstab_entry}\n{end_marker}"
                    )
                else:
                    # Append to block
                    new_block = block_content.replace(
                        end_marker,
                        f"    {fstab_entry}\n{end_marker}"
                    )
                
                new_content = f"{before_block}\n{new_block}\n{after_block}"
                
            else:
                # Create new block
                block_content = f"""{start_marker}
# Auto-generated by utils_devops. Do not edit manually.
{fstab_entry}
{end_marker}"""
                
                new_content = f"{current_content.rstrip()}\n\n{block_content}\n"
            
            # Write updated fstab
            files.write_file(fstab_path, new_content, backup=backup)
            info(f"Added permanent SSHFS mount to fstab: {local_mountpoint}")
            
            # Test the mount configuration
            debug("Testing fstab entry with 'mount -a'")
            result = systems.run("mount -a", check=False)
            if result.returncode == 0:
                info("Fstab test successful - all mounts loaded correctly")
            else:
                warning("Fstab test had issues - please check mount configuration")
                
        except Exception as e:
            error(f"Failed to add permanent SSHFS mount: {e}")
            raise SSHOpsError(f"Failed to add permanent SSHFS mount: {e}") from e

def sshfs_remove_permanent(
    local_mountpoint: Union[str, Path],
    backup: bool = True,
) -> None:
    """
    Remove permanent SSHFS mount from /etc/fstab.
    
    Args:
        local_mountpoint: Local mount point to remove
        backup: Backup /etc/fstab before modification
    """
    local_mountpoint = Path(local_mountpoint).resolve()
    
    task_name = f"Remove permanent SSHFS mount: {local_mountpoint}"
    
    with task(task_name):
        try:
            # Define markers for our block
            start_marker = "# BEGIN utils_devops SSHFS mounts"
            end_marker = "# END utils_devops SSHFS mounts"
            
            # Read current fstab
            fstab_path = Path("/etc/fstab")
            if not fstab_path.exists():
                raise SSHOpsError("/etc/fstab does not exist")
            
            current_content = files.read_file(fstab_path)
            
            # Check if our block exists
            if start_marker not in current_content or end_marker not in current_content:
                warning(f"No utils_devops SSHFS block found in {fstab_path}")
                return
            
            # Extract block and remove the specific entry
            start_idx = current_content.find(start_marker)
            end_idx = current_content.find(end_marker) + len(end_marker)
            
            before_block = current_content[:start_idx].strip()
            after_block = current_content[end_idx:].strip()
            block_content = current_content[start_idx:end_idx]
            
            # Remove lines containing the mountpoint from the block
            lines = block_content.splitlines()
            new_lines = []
            mountpoint_str = str(local_mountpoint)
            
            for line in lines:
                if mountpoint_str in line and not line.strip().startswith('#'):
                    debug(f"Removing mount entry: {line.strip()}")
                    continue
                new_lines.append(line)
            
            new_block = "\n".join(new_lines)
            
            # Check if block is empty (only markers and comments)
            block_has_mounts = any(
                line.strip() and 
                not line.strip().startswith('#') and 
                not line.strip() in [start_marker, end_marker]
                for line in new_lines
            )
            
            if not block_has_mounts:
                # Remove entire block if no mounts left
                info("No mounts remaining in SSHFS block - removing entire block")
                new_content = f"{before_block}\n{after_block}".strip()
            else:
                # Keep the block with remaining mounts
                new_content = f"{before_block}\n{new_block}\n{after_block}"
            
            # Write updated fstab
            files.write_file(fstab_path, new_content, backup=backup)
            info(f"Removed permanent SSHFS mount from fstab: {local_mountpoint}")
            
            # Unmount if currently mounted
            mount_result = systems.run(f"mountpoint {local_mountpoint}", check=False)
            if mount_result.returncode == 0:
                debug(f"Unmounting {local_mountpoint}")
                systems.run(f"umount {local_mountpoint}", check=False)
                info(f"Unmounted {local_mountpoint}")
                
        except Exception as e:
            error(f"Failed to remove permanent SSHFS mount: {e}")
            raise SSHOpsError(f"Failed to remove permanent SSHFS mount: {e}") from e

def sshfs_list_permanent() -> List[Dict[str, str]]:
    """
    List all permanent SSHFS mounts from /etc/fstab.
    
    Returns:
        List of dictionaries with mount information
    """
    try:
        fstab_path = Path("/etc/fstab")
        if not fstab_path.exists():
            return []
        
        content = files.read_file(fstab_path)
        lines = content.splitlines()
        
        mounts = []
        in_sshfs_block = False
        
        for line in lines:
            line = line.strip()
            
            if line == "# BEGIN utils_devops SSHFS mounts":
                in_sshfs_block = True
                continue
            elif line == "# END utils_devops SSHFS mounts":
                in_sshfs_block = False
                continue
            elif line.startswith('#') or not line:
                continue
            
            if in_sshfs_block and "fuse.sshfs" in line:
                # Parse fstab entry
                parts = line.split()
                if len(parts) >= 4:
                    remote_spec = parts[0]  # user@host:path
                    mountpoint = parts[1]
                    options = parts[2] if len(parts) > 2 else ""
                    
                    # Parse remote specification
                    if '@' in remote_spec and ':' in remote_spec:
                        user_host, remote_path = remote_spec.split(':', 1)
                        username, host = user_host.split('@', 1)
                    else:
                        username, host, remote_path = "unknown", "unknown", remote_spec
                    
                    mounts.append({
                        'host': host,
                        'username': username,
                        'remote_path': remote_path,
                        'local_mountpoint': mountpoint,
                        'options': options,
                        'fstab_entry': line
                    })
        
        return mounts
        
    except Exception as e:
        error(f"Failed to list permanent SSHFS mounts: {e}")
        return []
    

class SSHConnectionPool:
    """Thread-safe SSH connection pool."""
    def __init__(self, max_size: int = 10):
        self._pool: Dict[str, paramiko.SSHClient] = {}
        self._lock = threading.RLock()
        self._max_size = max_size
    
    def get(self, host: str, username: str, **kwargs) -> paramiko.SSHClient:
        """Get or create SSH connection."""
        key = f"{username}@{host}"
        with self._lock:
            if key in self._pool:
                client = self._pool[key]
                if client.get_transport() and client.get_transport().is_active():
                    return client
                else:
                    del self._pool[key]
            
            # Create new connection
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            # ... connection logic
            self._pool[key] = client
            return client
    
    def close_all(self):
        """Close all connections."""
        with self._lock:
            for client in self._pool.values():
                client.close()
            self._pool.clear()

# Global pool instance
_ssh_pool = SSHConnectionPool()

def get_ssh_pool() -> SSHConnectionPool:
    return _ssh_pool

def read_ssh_config(host_alias: str) -> Dict[str, Any]:
    """Read SSH config from ~/.ssh/config."""
    import paramiko
    ssh_config = paramiko.SSHConfig()
    config_file = Path("~/.ssh/config").expanduser()
    
    if config_file.exists():
        with open(config_file) as f:
            ssh_config.parse(f)
        config = ssh_config.lookup(host_alias)
        return {
            'hostname': config.get('hostname'),
            'username': config.get('user'),
            'port': int(config.get('port', 22)),
            'key_file': config.get('identityfile', [None])[0],
            'proxy_command': config.get('proxycommand')
        }
    return {}

def ssh_connect_with_config(
    host_alias: str,
    **kwargs
) -> Generator[paramiko.SSHClient, None, None]:
    """Connect using SSH config file entries."""
    config = read_ssh_config(host_alias)
    config.update(kwargs)
    with ssh_connect(**config) as client:
        yield client
        
def scp_put_with_progress(
    local_path: Union[str, Path],
    remote_path: str,
    host: str,
    username: str = "root",
    chunk_size: int = 8192,
    progress_callback: Optional[Callable[[int, int], None]] = None,
    resume: bool = True,
    **kwargs
) -> None:
    """
    Upload file with progress tracking and resume support.
    
    Args:
        progress_callback: Callback(current_bytes, total_bytes)
        resume: Resume interrupted transfers
    """
    local_path = Path(local_path).expanduser().resolve()
    total_size = local_path.stat().st_size
    
    with ssh_connect(host, username, **kwargs) as client:
        with SCPClient(client.get_transport(), progress=progress_callback) as scp:
            scp.put(str(local_path), remote_path, recursive=False)
            


def remote_file_exists(host: str, remote_path: str, **kwargs) -> bool:
    """Check if file exists on remote host."""
    result = ssh_run_command(host, f"test -e '{remote_path}' && echo exists", **kwargs)
    return "exists" in result.stdout

def remote_file_size(host: str, remote_path: str, **kwargs) -> Optional[int]:
    """Get remote file size."""
    result = ssh_run_command(host, f"stat -c%s '{remote_path}' 2>/dev/null || echo 0", **kwargs)
    try:
        return int(result.stdout.strip())
    except:
        return None

def remote_md5sum(host: str, remote_path: str, **kwargs) -> Optional[str]:
    """Calculate MD5 of remote file."""
    result = ssh_run_command(host, f"md5sum '{remote_path}' 2>/dev/null | cut -d' ' -f1", **kwargs)
    return result.stdout.strip() if result.stdout else None


def sync_directory(
    local_dir: Union[str, Path],
    remote_dir: str,
    host: str,
    username: str = "root",
    exclude: Optional[List[str]] = None,
    delete: bool = False,
    **kwargs
) -> None:
    """
    Sync local directory to remote using rsync if available, fallback to SCP.
    
    Args:
        exclude: List of patterns to exclude
        delete: Delete files on remote that don't exist locally
    """
    local_dir = Path(local_dir).expanduser().resolve()
    
    # Try rsync first (more efficient)
    rsync_cmd = ["rsync", "-avz"]
    if delete:
        rsync_cmd.append("--delete")
    if exclude:
        for pattern in exclude:
            rsync_cmd.extend(["--exclude", pattern])
    rsync_cmd.extend([str(local_dir), f"{username}@{host}:{remote_dir}"])
    
    try:
        systems.run(rsync_cmd, check=True)
    except:
        # Fallback to SCP
        scp_put(local_dir, remote_dir, host, username, recursive=True, **kwargs)
        
def ssh_connect_with_cert(
    host: str,
    username: str,
    ca_cert: Union[str, Path],
    identity_cert: Union[str, Path],
    **kwargs
) -> Generator[paramiko.SSHClient, None, None]:
    """Connect using SSH certificates."""
    ca_cert_path = Path(ca_cert).expanduser()
    identity_cert_path = Path(identity_cert).expanduser()
    
    kwargs.update({
        'cert_file': str(identity_cert_path),
        'ca_certs': str(ca_cert_path)
    })
    
    with ssh_connect(host, username, **kwargs) as client:
        yield client
        
def ssh_connect_with_agent(
    host: str,
    username: str,
    allow_agent: bool = True,
    **kwargs
) -> Generator[paramiko.SSHClient, None, None]:
    """Connect with SSH agent forwarding."""
    with ssh_connect(host, username, **kwargs) as client:
        if allow_agent:
            try:
                agent = paramiko.Agent()
                agent_keys = agent.get_keys()
                if agent_keys:
                    client.get_transport().auth_agent(username)
            except:
                pass
        yield client
        
def ssh_diagnostics(
    host: str,
    username: str = "root",
    port: int = 22,
    **kwargs
) -> Dict[str, Any]:
    """Run comprehensive SSH diagnostics."""
    results = {
        'host': host,
        'username': username,
        'port': port,
        'timestamp': datetimes.current_datetime().isoformat(),
        'tests': {}
    }
    
    # Test 1: Basic connectivity
    start = time.time()
    success, _ = ssh_test_connection(host, username, port, **kwargs)
    results['tests']['basic_connectivity'] = {
        'success': success,
        'duration': time.time() - start
    }
    
    # Test 2: Authentication methods
    auth_methods = []
    # Try various auth methods...
    
    # Test 3: SSH protocol version
    result = ssh_run_command(host, "echo $SSH_CLIENT", username, **kwargs)
    if result.success:
        results['tests']['ssh_version'] = {
            'client_ip': result.stdout.split()[0] if result.stdout else None
        }
    
    return results


@contextmanager
def ssh_session_record(
    host: str,
    username: str,
    output_file: Union[str, Path],
    **kwargs
) -> Generator[paramiko.SSHClient, None, None]:
    """Record SSH session to file."""
    output_file = Path(output_file).expanduser()
    files.ensure_dir(output_file.parent)
    
    class RecordingTransport(paramiko.Transport):
        def __init__(self, sock, *args, **kwargs):
            super().__init__(sock, *args, **kwargs)
            self.recording_file = open(output_file, 'wb')
        
        def close(self):
            if hasattr(self, 'recording_file'):
                self.recording_file.close()
            super().close()
    
    # Monkey-patch transport for recording
    original_transport = paramiko.Transport
    paramiko.Transport = RecordingTransport
    
    try:
        with ssh_connect(host, username, **kwargs) as client:
            yield client
    finally:
        paramiko.Transport = original_transport
        
def scp_parallel_put(
    files: List[Tuple[Union[str, Path], str]],
    host: str,
    username: str = "root",
    max_workers: int = 5,
    **kwargs
) -> Dict[str, bool]:
    """Upload multiple files in parallel."""
    results = {}
    
    def upload_file(args):
        local_path, remote_path = args
        try:
            scp_put(local_path, remote_path, host, username, **kwargs)
            return (local_path, True)
        except Exception as e:
            error(f"Failed to upload {local_path}: {e}")
            return (local_path, False)
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_file = {
            executor.submit(upload_file, (local, remote)): local
            for local, remote in files
        }
        
        for future in concurrent.futures.as_completed(future_to_file):
            local_path, success = future.result()
            results[str(local_path)] = success
    
    return results


class SSHHostGroup:
    """Manage operations on a group of hosts."""
    
    def __init__(self, hosts: List[Dict[str, Any]]):
        self.hosts = hosts
    
    def run_parallel(self, command: str, **kwargs) -> Dict[str, systems.subprocess.CompletedProcess]:
        """Run command on all hosts in parallel."""
        return ssh_parallel_commands(
            [h['host'] for h in self.hosts],
            command,
            **{**kwargs, 'username': self.hosts[0].get('username', 'root')}
        )
    
    def gather_info(self) -> Dict[str, Dict[str, Any]]:
        """Gather system info from all hosts."""
        info_commands = {
            'os': "uname -a",
            'disk': "df -h",
            'memory': "free -h",
            'uptime': "uptime"
        }
        
        results = {}
        for host in self.hosts:
            host_results = {}
            for key, cmd in info_commands.items():
                result = ssh_run_command(host['host'], cmd, **host)
                host_results[key] = result.stdout if result.success else None
            results[host['host']] = host_results
        
        return results