from .client import MagicFeedback

__all__ = ["MagicFeedback"]
