#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 09:12:04 2024

@author: benjaminlear
"""

# Script capital letters
A: str = '\u1d49c'  # 𝒜
B: str = '\u212c'   # ℬ
C: str = '\u1d49e'  # 𝒞
D: str = '\u1d49f'  # 𝒟
E: str = '\u2130'   # ℰ
F: str = '\u2131'   # ℱ
G: str = '\u1d4a2'  # 𝒢
H: str = '\u210b'   # ℋ
I: str = '\u2110'   # ℐ
J: str = '\u1d4a5'  # 𝒥
K: str = '\u1d4a6'  # 𝒦
L: str = '\u2112'   # ℒ
M: str = '\u2133'   # ℳ
N: str = '\u1d4a9'  # 𝒩
O: str = '\u1d4aa'  # 𝒪
P: str = '\u1d4ab'  # 𝒫
Q: str = '\u1d4ac'  # 𝒬
R: str = '\u211b'   # ℛ
S: str = '\u1d4ae'  # 𝒮
T: str = '\u1d4af'  # 𝒯
U: str = '\u1d4b0'  # 𝒰
V: str = '\u1d4b1'  # 𝒱
W: str = '\u1d4b2'  # 𝒲
X: str = '\u1d4b3'  # 𝒳
Y: str = '\u1d4b4'  # 𝒴
Z: str = '\u1d4b5'  # 𝒵

# Script lowercase letters
a: str = '\u1d4b6'  # 𝒶
b: str = '\u1d4b7'  # 𝒷
c: str = '\u1d4b8'  # 𝒸
d: str = '\u1d4b9'  # 𝒹
e: str = '\u212f'   # ℯ
f: str = '\u1d4bb'  # 𝒻
g: str = '\u210a'   # ℊ
h: str = '\u1d4bd'  # 𝒽
i: str = '\u1d4f2'  # 𝒾
j: str = '\u1d4bf'  # 𝒿
k: str = '\u1d4c0'  # 𝓀
l: str = '\u1d4c1'  # 𝓁
m: str = '\u1d4c2'  # 𝓂
n: str = '\u1d4c3'  # 𝓃
o: str = '\u2134'   # ℴ
p: str = '\u1d4c5'  # 𝓅
q: str = '\u1d4c6'  # 𝓆
r: str = '\u1d4c7'  # 𝓇
s: str = '\u1d4c8'  # 𝓈
t: str = '\u1d4c9'  # 𝓉
u: str = '\u1d4ca'  # 𝓊
v: str = '\u1d4cb'  # 𝓋
w: str = '\u1d4cc'  # 𝓌
x: str = '\u1d4cd'  # 𝓍
y: str = '\u1d4ce'  # 𝓎
z: str = '\u1d4cf'  # 𝓏
    
