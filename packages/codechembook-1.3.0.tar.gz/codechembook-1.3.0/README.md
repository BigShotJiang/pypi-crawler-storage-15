# CodeChemBook
Companion library for Coding for Chemists Book
