# Neo4jGraphRAG-LiteLLMInterface
A LiteLLM LLM component for Neo4j graph RAG. 
