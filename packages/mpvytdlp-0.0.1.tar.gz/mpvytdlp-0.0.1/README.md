# mpvytdlp
lib s.t. python-mpv + yt-dlp. PR wellcome

## What dose it do?

it work as `pip install python-mpv yt-dlp`

because it have depenancy of that.

## cannot import this

normal. it have no files. it just package setup file
