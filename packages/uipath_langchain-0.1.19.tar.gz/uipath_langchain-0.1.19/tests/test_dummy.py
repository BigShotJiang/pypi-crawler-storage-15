def test_dummy():
    """A dummy test that always passes."""
    assert True
