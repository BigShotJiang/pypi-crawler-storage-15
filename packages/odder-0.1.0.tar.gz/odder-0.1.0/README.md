# odder

A simple Python library to check if a number is odd or even.

## Usage
```python
from odder import is_even, is_odd

print(is_even(4))  # True
print(is_odd(7))   # True
