from .mailing_lists import (
    EmailContactMailingListEndpointConfig,
    MailingListEntryEndpointConfig,
    MailingListSubscriberRequestEntryEndpointConfig,
    MailingListSubscriberRequestMailingListEndpointConfig,
    MailMailingListChartEndpointConfig,
)
from .mails import MailEventMailEndpointConfig, MailStatusMassMailEndpointConfig, MailEventMassMailEndpointConfig
