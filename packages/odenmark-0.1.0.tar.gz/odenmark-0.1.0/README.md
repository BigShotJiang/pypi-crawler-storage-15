## odenmark

'''A simple Python library to check whether a number is odd or even.
'''
## Usage

'''python
from odenmark import is_even, is_odd

print(is_even(10))  # True
print(is_odd(7))    # True
'''

'''

# 📌 Build & Upload

### Install tools:

'''