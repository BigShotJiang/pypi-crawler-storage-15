0.2 Series
!!!!!!!!!!

.. toctree::
   :maxdepth: 1

   0.2.4
   0.2.3
   0.2.2
   0.2.1
   0.2.0
