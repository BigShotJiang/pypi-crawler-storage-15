from ..utils import xml_get_text_or_none
from .base import Base
from .medlinecitation import MedlineCitation


class PubmedArticle(Base):
    _root_tag = "PubmedArticle"

    def __str__(self):
        return f"{self.__class__.__name__}({self.pmid}; {self.jrnl}; {self.title}; {self.authors})"

    @property
    def abstract(self):
        return self._medline_citation.abstract

    @property
    def authors(self):
        return self._medline_citation.authors

    @property
    def chemicals(self):
        return self._medline_citation.chemicals

    @property
    def issue(self):
        return self._medline_citation.issue

    @property
    def jrnl(self):
        return self._medline_citation.jrnl

    @property
    def mesh_headings(self):
        return self._medline_citation.mesh_headings

    @property
    def mesh_qualifiers(self):
        return self._medline_citation.mesh_qualifiers

    @property
    def pages(self):
        return self._medline_citation.pages

    @property
    def pmid(self):
        return self._medline_citation.pmid

    @property
    def pub_types(self):
        return self._medline_citation.pub_types

    @property
    def title(self):
        return self._medline_citation.title

    @property
    def volume(self):
        return self._medline_citation.volume

    @property
    def year(self):
        return self._medline_citation.year

    @property
    def doi(self):
        return xml_get_text_or_none(
            self._xml_root, 'PubmedData/ArticleIdList/ArticleId[@IdType="doi"]'
        )

    @property
    def pii(self):
        return xml_get_text_or_none(
            self._xml_root, 'PubmedData/ArticleIdList/ArticleId[@IdType="pii"]'
        )

    @property
    def pmc(self):
        pmc = xml_get_text_or_none(
            self._xml_root, 'PubmedData/ArticleIdList/ArticleId[@IdType="pmc"]'
        )
        return None if pmc is None else pmc[3:]

    @property
    def _medline_citation(self):
        return MedlineCitation(self._xml_root.find("MedlineCitation"))


# if __name__ == "__main__":
#     from pathlib import Path

#     import lxml.etree as le

#     from .pubmedarticleset import PubmedArticleSet

#     data_dir = Path(__file__).parent.parent.parent / "tests" / "data"
#     relpaths = [
#         "efetch.fcgi?db=pubmed&id=20412080&rettype=xml.xml",
#         "efetch.fcgi?db=pubmed&id=22351513&retmode=xml.xml",
#         "efetch.fcgi?db=pubmed&id=23121403&retmode=xml.xml",
#     ]
#     path = data_dir / relpaths[0]
#     pas = PubmedArticleSet(le.parse(path).getroot())
#     pa = next(iter(pas))

# <LICENSE>
# Copyright 2015 eutils Committers
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
# or implied. See the License for the specific language governing
# permissions and limitations under the License.
# </LICENSE>
