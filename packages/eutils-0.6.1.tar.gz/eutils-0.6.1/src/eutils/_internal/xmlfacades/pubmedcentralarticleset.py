from .base import Base
from .pubmedcentralarticle import PubmedCentralArticle


class PubmedCentralArticleSet(Base):
    _root_tag = "pmc-articleset"

    def __iter__(self):
        return (PubmedCentralArticle(pmca_n) for pmca_n in self._xml_root.iterfind("article"))


# if __name__ == "__main__":
#     from pathlib import Path

#     import lxml.etree as le

#     data_dir = Path(__file__).parent.parent.parent / "tests" / "data"
#     relpaths = [
#         "efetch.fcgi?db=pmc&id=3299399&rettype=xml.xml",
#         "efetch.fcgi?db=pmc&id=3299399&retmode=xml.xml",
#         "efetch.fcgi?db=pmc&id=3299399&retmode=xml.xml",
#     ]

#     pmcasets = [
#         PubmedCentralArticleSet(le.parse(data_dir / relpath).getroot())
#         for relpath in relpaths
#     ]

# <LICENSE>
# Copyright 2015 eutils Committers
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
# or implied. See the License for the specific language governing
# permissions and limitations under the License.
# </LICENSE>
