import { JupyterFrontEndPlugin } from '@jupyterlab/application';
import { ToolbarButton } from '@jupyterlab/apputils';
import { DocumentRegistry } from '@jupyterlab/docregistry';
import { INotebookModel, NotebookPanel } from '@jupyterlab/notebook';
import { IDisposable } from '@lumino/disposable';
/** Wait until the kernel has loaded, then check if it is a MATLAB kernel. */
export declare const insertButton: (panel: NotebookPanel, matlabToolbarButton: ToolbarButton) => Promise<void>;
export declare class MatlabToolbarButtonExtension implements DocumentRegistry.IWidgetExtension<NotebookPanel, INotebookModel> {
    createNew(panel: NotebookPanel, context: DocumentRegistry.IContext<INotebookModel>): IDisposable;
}
export declare const matlabToolbarButtonPlugin: JupyterFrontEndPlugin<void>;
