DOCUMENTATION_EVIDENCE_TYPE = "documentation_evidence"
CODE_EVIDENCE_TYPE = "code_evidence"
