# pymlga

Version: 0.2.1

Python machine learning by genetic algorithm

