def main():
    print("Hello from xeto!")


if __name__ == "__main__":
    main()
