"""Version information for putplace-server."""

__version__ = "0.8.2"
