# -*- coding: utf-8 -*-

# Copyright 2025 (c) Vladislav Punko <iam.vlad.punko@gmail.com>

__description__ = "Asynchronous library for FTP-based file system operations."
