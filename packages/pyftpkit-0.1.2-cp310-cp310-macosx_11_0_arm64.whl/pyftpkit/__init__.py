# -*- coding: utf-8 -*-

# Copyright 2025 (c) Vladislav Punko <iam.vlad.punko@gmail.com>

from pyftpkit import logger_wrapper

__version__ = "0.1.2"

logger_wrapper.setup()
