# __init__.py

# source: https://www.python-engineer.com/posts/init-py-file/
# "Generally, this file is kept empty but it can be used to achieve
# the following things:
#    Import submodules
#    Initialize top-level objects/variables
#    (logger, database connections, configurations)
