from time import sleep

def wait(time:float):
    return sleep(time)
