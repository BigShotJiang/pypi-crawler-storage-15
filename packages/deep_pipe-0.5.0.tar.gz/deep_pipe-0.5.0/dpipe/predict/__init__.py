"""
Various functions for prediction with neural networks.
See the :doc:`tutorials/predict` tutorial for more details.
"""
from .functional import *
from .shape import *
