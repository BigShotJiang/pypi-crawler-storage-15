"""
Datasets are used for data and metadata loading.
"""
from .base import Dataset
from .csv import CSV
