Overview
========

A PAS plugin which can manage local roles via an adapter lookup on the current
context.

Source Code
===========

Contributors please read the document `Process for Plone core's development <https://docs.plone.org/develop/coredev/docs/index.html>`_

Sources are at the `Plone code repository hosted at Github <https://github.com/plone/borg.localrole>`_.
