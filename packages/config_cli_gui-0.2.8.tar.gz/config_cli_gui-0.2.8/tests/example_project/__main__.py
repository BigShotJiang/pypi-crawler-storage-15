"""Entry point for config_cli_gui."""

import sys  # pragma: no cover

from .cli.cli_example import main  # pragma: no cover

if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
