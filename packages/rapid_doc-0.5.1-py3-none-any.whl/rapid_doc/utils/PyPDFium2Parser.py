import threading

lock = threading.Lock()