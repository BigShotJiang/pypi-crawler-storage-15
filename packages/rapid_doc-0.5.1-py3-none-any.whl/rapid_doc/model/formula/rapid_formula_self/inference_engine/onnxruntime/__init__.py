from .main import OrtInferSession
