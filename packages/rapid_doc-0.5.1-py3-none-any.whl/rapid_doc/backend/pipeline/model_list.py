class AtomicModel:
    Layout = "layout"
    FORMULA = "formula"
    OCR = "ocr"
    Table = "table"
