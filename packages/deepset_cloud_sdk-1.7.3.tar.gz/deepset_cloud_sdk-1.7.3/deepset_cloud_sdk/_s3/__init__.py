"""Module that handles s3 interactions."""
