"""Sync implementation of workflows client."""
