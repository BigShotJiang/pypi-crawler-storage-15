def prepare(data: dict):
    pass
