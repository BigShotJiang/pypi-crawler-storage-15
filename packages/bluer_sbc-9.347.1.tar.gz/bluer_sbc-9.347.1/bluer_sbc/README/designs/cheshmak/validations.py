from bluer_objects.README.items import ImageItems

from bluer_sbc.README.designs.cheshmak import assets2

docs = [
    {
        "path": "../docs/cheshmak/validations.md",
        "items": ImageItems(
            {
                assets2 + "bryce/09.jpg?raw=true": "",
            }
        ),
    },
]
