__version__ = "2025.12.7"
__prog__ = "webscout"
