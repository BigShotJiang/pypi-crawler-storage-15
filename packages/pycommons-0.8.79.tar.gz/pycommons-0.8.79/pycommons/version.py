"""An internal file with the version of the `pycommons` package."""
from typing import Final

#: the version string of `pycommons`
__version__: Final[str] = "0.8.79"
