"""Tests for canvas widgets and mixins."""
