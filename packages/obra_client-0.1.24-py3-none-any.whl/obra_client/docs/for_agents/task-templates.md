# Task Templates for LLM Agents

Copy-paste ready task descriptions for common operations.

> **REMINDER: You are a task architect, not a coder.** Your job is to formulate these prompts and send them to Obra. Do NOT write code yourself. See `capability-brief.md` for details.

**Note**: Tasks execute via Obra's implementation agent (default: Claude Code). Obra adds orchestration: validation, iteration, quality control.

---

## Template Structure

```
Title: <Imperative verb> <object>

Description:
<What to build/fix/create>

Deliverables:
- <file or artifact 1>
- <file or artifact 2>

Requirements:
- <requirement 1>
- <requirement 2>

Success Criteria:
- <how to verify 1>
- <how to verify 2>
```

---

## Feature Implementation

### New Function

```
Title: Implement password hashing function

Description:
Create a secure password hashing function using bcrypt.

Deliverables:
- src/auth/password.py

Requirements:
- Use bcrypt library
- Include salt generation
- Support password verification
- Add type hints
- Include docstrings

Success Criteria:
- Function hashes passwords consistently
- Verification works for correct passwords
- Verification fails for wrong passwords
- All type hints present
```

### New API Endpoint

```
Title: Create user registration API endpoint

Description:
Implement POST /api/users/register endpoint.

Deliverables:
- src/api/routes/users.py
- tests/api/test_users.py

Requirements:
- Accept JSON: {email, password, name}
- Validate email format
- Hash password before storage
- Return 201 with user ID on success
- Return 400 with errors on validation failure
- Return 409 if email exists

Success Criteria:
- Endpoint accessible at POST /api/users/register
- All validation cases handled
- Tests cover success and all error cases
- Returns correct status codes
```

### New Component

```
Title: Create login form component

Description:
React component for user login.

Deliverables:
- src/components/LoginForm.tsx
- src/components/LoginForm.test.tsx

Requirements:
- Email and password fields
- Submit button
- Loading state during submission
- Error message display
- Form validation
- TypeScript with proper types

Success Criteria:
- Component renders without errors
- Validation prevents empty submission
- Loading indicator shows during submit
- Errors display correctly
- All tests pass
```

---

## Bug Fix

### With Reproduction Steps

```
Title: Fix null pointer in user lookup

Description:
Fix crash when looking up non-existent user.

Bug Details:
- Location: src/services/user_service.py:45
- Error: AttributeError: 'NoneType' has no attribute 'email'
- Reproduction: Call get_user_email(999) with non-existent ID

Deliverables:
- Updated src/services/user_service.py
- Regression test in tests/test_user_service.py

Requirements:
- Return None or raise UserNotFoundError for missing users
- Don't change behavior for existing users
- Add defensive null check

Success Criteria:
- No crash on non-existent user lookup
- Existing tests still pass
- New regression test covers the case
```

### Performance Issue

```
Title: Optimize slow database query in report generation

Description:
Reports taking >30s due to N+1 query problem.

Location: src/reports/generator.py:generate_monthly_report()

Deliverables:
- Optimized src/reports/generator.py
- Performance test showing improvement

Requirements:
- Use eager loading or batch queries
- Reduce from N+1 to 2-3 queries
- Maintain same output format
- Target: <5s for 1000 records

Success Criteria:
- Same report output as before
- Execution time <5s for 1000 records
- All existing tests pass
```

---

## Test Suite

### Unit Tests

```
Title: Add unit tests for ConfigManager

Description:
Comprehensive tests for src/core/config_manager.py.

Deliverables:
- tests/test_config_manager.py

Requirements:
- Test all public methods
- Test edge cases (missing file, invalid YAML, etc.)
- Use pytest fixtures
- Mock file system operations
- Target 90%+ coverage

Success Criteria:
- All tests pass
- Coverage >90% for config_manager.py
- Edge cases covered
- No external file dependencies
```

### Integration Tests

```
Title: Add integration tests for authentication flow

Description:
End-to-end tests for register → login → access protected route.

Deliverables:
- tests/integration/test_auth_flow.py

Requirements:
- Test complete user registration
- Test login with registered user
- Test accessing protected endpoint with token
- Test rejection without token
- Use test database

Success Criteria:
- Full flow works end-to-end
- All error cases tested
- Uses isolated test database
- Cleans up after tests
```

---

## Refactoring

### Extract Function

```
Title: Extract validation logic from UserController

Description:
Move inline validation to separate validator class.

Location: src/controllers/user_controller.py

Deliverables:
- src/validators/user_validator.py
- Updated src/controllers/user_controller.py
- tests/test_user_validator.py

Requirements:
- Extract email, password, name validation
- UserController calls validator
- Same validation behavior
- Validator is reusable

Success Criteria:
- All existing tests pass
- Controller is cleaner (<100 lines)
- Validator has own tests
- Validation behavior unchanged
```

### Improve Types

```
Title: Add type hints to payment module

Description:
Full type coverage for src/payments/.

Deliverables:
- Updated src/payments/*.py

Requirements:
- Type hints on all functions
- Return type annotations
- Use Optional where appropriate
- Add TypedDict for complex dicts
- Pass mypy --strict

Success Criteria:
- mypy --strict passes with no errors
- All functions have type hints
- Return types annotated
- Complex types documented
```

---

## Web Research / Data Collection

### Batch Data Collection

```
Title: Collect competitor pricing data

Description:
Research and collect pricing information from competitor websites.

Deliverables:
- data/competitor_pricing.json

Requirements:
- Use WebSearch to find pricing pages
- Use WebFetch to extract data
- Collect: company name, product, price, URL, date
- Minimum 10 competitors
- JSON schema validation

Success Criteria:
- JSON file contains 10+ entries
- All required fields populated
- URLs are valid
- Prices are numeric
```

### Research with Structured Output

```
Title: Research API rate limits for payment providers

Description:
Collect rate limit information from payment API documentation.

Deliverables:
- docs/reference/research/payment_api_limits.md

Requirements:
- Research: Stripe, Square, PayPal, Braintree
- For each: requests/second, daily limits, burst limits
- Include source URLs
- Markdown table format

Success Criteria:
- All 4 providers documented
- Rate limits have numeric values
- Source URLs are valid
- Table renders correctly
```

### Multi-Batch Collection (Epic)

```
Title: Collect interview questions database

Description:
Build comprehensive database of technical interview questions.

Stories:
1. Batch 1: Algorithm Questions (Story)
   - WebSearch for algorithm interview questions
   - Collect 50 questions with difficulty rating
   - Output: data/questions_algorithms.json

2. Batch 2: System Design Questions (Story)
   - WebSearch for system design interviews
   - Collect 30 questions with topics
   - Output: data/questions_system_design.json

3. Batch 3: Behavioral Questions (Story)
   - WebSearch for behavioral interview questions
   - Collect 40 questions with categories
   - Output: data/questions_behavioral.json

Deliverables:
- data/questions_*.json (3 files)
- data/questions_combined.json (merged)

Success Criteria:
- Each batch meets count requirement
- JSON validates against schema
- No duplicate questions across batches
- Combined file merges correctly
```

---

## Documentation

### API Documentation

```
Title: Document REST API endpoints

Description:
OpenAPI/Swagger documentation for all endpoints.

Deliverables:
- docs/api/openapi.yaml

Requirements:
- All endpoints documented
- Request/response schemas
- Authentication requirements
- Example requests and responses
- Error responses

Success Criteria:
- Valid OpenAPI 3.0 spec
- All endpoints covered
- Examples are accurate
- Renders correctly in Swagger UI
```

### Code Documentation

```
Title: Add docstrings to orchestrator module

Description:
Google-style docstrings for src/core/orchestrator.py.

Deliverables:
- Updated src/core/orchestrator.py

Requirements:
- All public methods documented
- Args, Returns, Raises sections
- Usage examples for complex methods
- Type hints in signatures

Success Criteria:
- All public methods have docstrings
- Docstrings follow Google style
- Examples are runnable
- pydoc generates clean output
```

---

## Epic Template

For large features spanning multiple sessions:

```
Title: Implement User Authentication System

Description:
Complete authentication with registration, login, password reset.

Stories:
1. User Registration (Story)
   - Registration endpoint
   - Email validation
   - Password hashing
   - Tests

2. User Login (Story)
   - Login endpoint
   - JWT generation
   - Session management
   - Tests

3. Password Reset (Story)
   - Reset request endpoint
   - Email sending
   - Reset confirmation
   - Tests

Deliverables:
- src/auth/ module
- tests/test_auth/ tests
- docs/api/auth.md

Success Criteria:
- All Stories complete
- 90%+ test coverage
- API documented
- Security review passed
```

---

## Invocation Examples

### Single Task
```bash
obra interactive \
  -c "Create a task to implement password hashing function in src/auth/password.py using bcrypt with salt generation and verification support" \
  -c "/execute 1" \
  -c "exit"
```

### With Project Context
```bash
obra interactive \
  -c "Create project 'AuthSystem' at ~/obra-projects/auth" \
  -c "Create task to add unit tests for ConfigManager with 90% coverage" \
  -c "/execute 1" \
  -c "exit"
```

### Check Results
```bash
obra interactive \
  -c "/status" \
  -c "Show task 1" \
  -c "exit"
```

### Web Research Task
```bash
obra interactive \
  -c "Create task to research and collect competitor pricing data from 10 competitors into data/competitor_pricing.json with schema validation" \
  -c "/execute 1" \
  -c "exit"
```

### Multi-Batch Collection (Epic)
```bash
obra interactive \
  -c "Create epic for collecting interview questions database with 3 batches: algorithms, system design, behavioral" \
  -c "Add story to epic 1: Collect 50 algorithm questions into data/questions_algorithms.json" \
  -c "Add story to epic 1: Collect 30 system design questions into data/questions_system_design.json" \
  -c "Add story to epic 1: Collect 40 behavioral questions into data/questions_behavioral.json" \
  -c "exit"
```

---

## Common Mistakes

| Mistake | Problem | Fix |
|---------|---------|-----|
| Vague description | "Fix the bug" | Specify file, line, reproduction |
| No deliverables | Agent doesn't know what to create | List specific files |
| Too large | Task times out | Break into Stories |
| No success criteria | Can't validate completion | Define how to verify |

---

## Further Reading

- **[capability-brief.md](capability-brief.md)** - When to use Obra
- **[Workflow Patterns](../../tutorials/development/workflow-patterns.md)** - Pattern guidance
- **[NL Command Guide](../../nl-command-guide.md)** - Natural language interface
