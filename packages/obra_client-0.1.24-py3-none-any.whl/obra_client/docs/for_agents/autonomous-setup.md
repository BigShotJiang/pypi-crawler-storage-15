---
title: Obra SaaS Autonomous Setup - For LLM Agents
type: guide
audience: [agent]
customer_journey: [onboarding]
last_validated: 2025-12-02
related:
  - docs/guides/quick-start-beta.md
  - docs/deployment/beta-onboarding.md
  - client/pyproject.toml
---

# Obra SaaS Setup - For LLM Agents

**Mission**: You are helping a user install Obra SaaS client. Use your knowledge of their OS, Python environment, and shell to adapt these steps autonomously.

## Context (Dense)

- **What**: Obra = AI orchestration platform, SaaS client connects to Firebase backend
- **Why**: Setup achieves local client install + remote orchestration capability
- **Prerequisites**: Python 3.12+, Claude Code CLI (for implementation agent)
- **Outcome**: User can run `obra-client orchestrate "<task>"` successfully
- **Architecture**: Two-Tier Prompting - server generates base prompts, client enriches with local context (code never uploaded)

## Your Role After Setup

> **IMPORTANT**: Once Obra is set up, your role changes.

**During setup** (this guide): You run commands directly to install and configure.

**After setup**: You become a **task architect**:
- ❌ Do NOT write code yourself
- ❌ Do NOT create files directly
- ✅ Formulate detailed prompts with clear intentions, requirements, and success criteria
- ✅ Send prompts to Obra via `obra-client interactive -c "..."`
- ✅ Review and report results

See `capability-brief.md` for detailed guidance on delegating work to Obra.

## Prerequisites Detection Protocol

Detect environment autonomously before installation:

### OS Detection
```bash
uname -s
# Linux → Use apt/yum package managers
# Darwin → Use brew package manager
# MINGW*/MSYS* → Windows, recommend WSL2 or native Python
```

### Python Version Check
```bash
python3 --version
# If < 3.12 → Guide user to upgrade OR install Python 3.12
# If >= 3.12 → Proceed
```

Expected output formats:
- Linux: `Python 3.12.0` or higher
- Mac: `Python 3.12.x` or higher
- Windows: `Python 3.12.x` or higher

### Package Manager Verification
```bash
which pip || which pip3
# If missing → Install via: python3 -m ensurepip
```

### Claude Code CLI Check
```bash
claude-code --version
# If missing → Provide install link: https://docs.anthropic.com/claude-code
```

---

## Installation Protocol

### Step 1: Create Virtual Environment (Recommended)

**OS: All**
```bash
python3.12 -m venv ~/.obra-venv
```

**Activation**:
```bash
# Linux/Mac
source ~/.obra-venv/bin/activate

# Windows (CMD)
~/.obra-venv/Scripts/activate.bat

# Windows (PowerShell)
~/.obra-venv/Scripts/Activate.ps1
```

**Validation**:
```bash
which python  # Should show venv path
python --version  # Should show 3.12.x
```

---

### Step 2: Install from PyPI

**Context**: Package is available on PyPI - no file download needed

**Command**:
```bash
pip install obra-client
```

**Expected Output**:
```
Collecting obra-client
  Downloading obra_client-0.1.0-py3-none-any.whl (15 kB)
Collecting typer>=0.9.0 (from obra-client==0.1.0)
  Using cached typer-0.20.0-py3-none-any.whl (47 kB)
Collecting requests>=2.31.0 (from obra-client==0.1.0)
  Using cached requests-2.32.5-py3-none-any.whl (64 kB)
...
Successfully installed obra-client-0.1.0 typer-0.20.0 requests-2.32.5 ...
```

**Success Criteria**: Line contains `Successfully installed obra-client`

---

### Step 3: Verify Installation

**Command**:
```bash
obra-client --help
```

**Expected Output**:
```
Usage: obra-client [OPTIONS] COMMAND [ARGS]...

Obra SaaS Client - LLM Proxy with prompt enrichment

Commands:
  setup        Run first-time setup and configuration
  orchestrate  Start orchestration session with Cloud Functions
  status       Query orchestration session status
  resume       Resume interrupted orchestration session
  version      Display Obra Client version and check server compatibility
```

**Success Criteria**: Output shows 5 commands (setup, orchestrate, status, resume, version)

---

### Step 4: Run Setup

**Command**:
```bash
obra-client setup
```

**Interactive Prompts & Responses**:

**Prompt 1**: API Base URL
```
Enter API Base URL [https://us-central1-obra-205b0.cloudfunctions.net]:
```
**Action**: Press Enter (use default)

**Prompt 2**: License Key
```
Enter license key:
```
**Action**: Paste user's license key (format: `OBRA-xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx`)

**Prompt 3**: User ID
```
Enter user ID:
```
**Action**: Use email from beta invite OR ask user for email

**Prompt 4**: Project ID
```
Enter project ID [default-project]:
```
**Action**: Suggest GitHub username OR project name OR accept default

**Expected Success Output**:
```
🔧 Obra SaaS Client Setup
═════════════════════════════════════════════════

Checking API connectivity...
✓ Connected to Obra Cloud Functions (v0.1.0)

Enter license key: ************************************
✓ License key validated

Enter user ID: beta-user@example.com
Enter project ID: my-startup

Verifying authentication...
✓ Custom token obtained
✓ Configuration saved to ~/.obra/client-config.yaml

═════════════════════════════════════════════════
🎉 Setup complete! You're ready to orchestrate.
```

**Success Criteria**: Line contains "Setup complete!" and config saved

---

### Step 5: Verify Setup (Health Check)

**Command**:
```bash
obra-client version
```

**Expected Output**:
```
Obra Client: 0.1.0
Server: v0.1.0 (https://us-central1-obra-205b0.cloudfunctions.net)
Status: ✓ Connected
```

**Success Criteria**: Shows client version and server connectivity

---

## Validation Protocol

### Success Checklist

After installation, verify:

1. ✓ `obra-client --help` shows commands
2. ✓ `obra-client version` returns version and server status
3. ✓ Config file exists at `~/.obra/client-config.yaml`
4. ✓ Test orchestration (optional): `obra-client orchestrate "print hello world in Python"`

### Expected Orchestration Output

```
🚀 Starting Obra orchestration session...
📊 Objective: print hello world in Python
🔍 Collecting local context...
   - X recently modified files
   - Y recent commits

📡 Contacting Obra Cloud Functions...
✓ Session created: session-abc123
✓ Base prompt received

🔧 Enriching prompt with local context...
   + Enriched prompt: Z KB

🤖 Executing Claude Code...
[Claude Code output appears here]

✓ Iteration 1 complete

════════════════════════════════════════════════════
🎉 Orchestration complete!
✅ [Task result]
📊 Final status: SUCCESS
════════════════════════════════════════════════════
```

---

## Error Recovery

### Error 1: Module Not Found

**Pattern**: `ModuleNotFoundError: No module named 'obra_client'`

**Diagnosis**: Python can't find installed package

**Autonomous Fix**:
```bash
# Verify installation
pip list | grep obra-client

# If not listed, reinstall
pip install --force-reinstall obra-client
```

**Report to User**: "Reinstalled obra-client package. Please verify with `obra-client --help`"

---

### Error 2: Command Not Found

**Pattern**: `command not found: obra-client` OR `'obra-client' is not recognized`

**Diagnosis**: Entry point not in PATH

**Autonomous Fix (Linux/Mac)**:
```bash
# Add to PATH
export PATH="$HOME/.local/bin:$PATH"

# Make permanent
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc
```

**Autonomous Fix (Windows)**:
```powershell
# Query current PATH
$env:Path

# Report to user
"Please add %APPDATA%\Python\Python312\Scripts to system PATH"
```

**Alternative (All OS)**:
```bash
# Use module directly
python -m obra_client.cli --help
```

**Report to User**: "Added Python scripts to PATH. Alternatively, use `python -m obra_client.cli` instead of `obra-client`"

---

### Error 3: Invalid License Key

**Pattern**: `Error: Invalid license key format`

**Diagnosis**: Key doesn't match expected format

**Validation**:
```python
import re
key_pattern = r'^OBRA-[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
if not re.match(key_pattern, user_key, re.IGNORECASE):
    # Invalid format
```

**Autonomous Fix**:
1. Check for typos (extra spaces, line breaks)
2. Verify format matches pattern
3. If still failing after 3 attempts → HALT, ask user to contact support

**Report to User**: "License key format is incorrect. Expected format: OBRA-xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx. Please verify key from beta invite email."

---

### Error 4: API Connection Failed

**Pattern**: `ConnectionError: Failed to connect to API endpoint`

**Diagnosis**: Network issue or firewall blocking

**Autonomous Fix**:
```bash
# Test connectivity
curl https://us-central1-obra-205b0.cloudfunctions.net/health

# Expected response:
# {"status": "healthy", "version": "0.1.0"}
```

**If curl succeeds**:
- Issue likely in obra-client connection logic
- Report to user with curl success evidence

**If curl fails**:
- Check firewall settings
- Check VPN/proxy
- Report network issue to user

**Report to User**: "Cannot reach Obra Cloud Functions. Please check: 1) Internet connection, 2) Firewall allows cloudfunctions.net, 3) VPN/proxy settings"

---

### Error 5: Claude Code Not Found

**Pattern**: `Error: Claude Code CLI not found in PATH`

**Diagnosis**: Implementation agent not installed

**Autonomous Fix**:
```bash
# Check installation
which claude-code

# If not found, provide install guidance
```

**Report to User**: "Claude Code CLI is required for Obra orchestration. Install from: https://docs.anthropic.com/claude-code"

**HALT**: This is blocking - cannot proceed without Claude Code

---

## Decision Trees

### Setup Flow
```yaml
detect_os:
  - if: uname == "Linux" → use_apt_or_yum
  - if: uname == "Darwin" → use_brew
  - if: uname == "MINGW*" → recommend_wsl2_or_native_python

check_python:
  - if: version >= 3.12 → proceed_to_install
  - if: version < 3.12 → guide_upgrade_python

install_method:
  - if: venv_recommended → create_venv_then_install
  - if: global_install → install_directly

validation:
  - if: all_checks_pass → report_success
  - if: any_check_fails → diagnose_and_fix
```

### Error Handling Flow
```yaml
encounter_error:
  - if: error_pattern_matched → apply_autonomous_fix
  - if: fix_successful → report_fix_to_user
  - if: fix_failed_after_3_attempts → halt_and_escalate
  - if: unknown_error → log_error_and_halt
```

---

## Post-Installation

### First Orchestration Test

Guide user through test orchestration:

```bash
# Navigate to project
cd /path/to/user/project

# Run simple test
obra-client orchestrate "Create a Python function to add two numbers"
```

**Expected Flow**:
1. Client collects context (files, git history)
2. Client sends objective to Firebase
3. Server generates base prompt
4. Client enriches with local context
5. Claude Code executes on user's machine
6. Task completes, returns result

**Success Indicator**: User sees "Orchestration complete!" with SUCCESS status

---

## Troubleshooting Reference

| Symptom | Likely Cause | Quick Fix |
|---------|--------------|-----------|
| `obra-client` not found | PATH issue | Add to PATH or use `python -m obra_client.cli` |
| License key rejected | Format error | Verify OBRA-xxxx... format, check for typos |
| Network timeout | Firewall/connectivity | Test with curl, check firewall |
| Health check fails | Missing Claude Code | Install Claude Code CLI |
| Python version error | Old Python | Upgrade to 3.12+ |
| Module import error | Installation failed | Reinstall with --force-reinstall |

---

## Communication Pattern for LLM Agents

### Reporting Progress
- **Starting**: "Installing Obra SaaS client..."
- **Detecting**: "Detected [OS/Python version]"
- **Installing**: "Installing obra-client from PyPI..."
- **Configuring**: "Running setup with your license key..."
- **Verifying**: "Verifying installation..."
- **Success**: "Installation complete. Running health check..."

### Handling Errors
- **Show Expected vs Actual**: "Expected: X, Got: Y"
- **Explain Recovery**: "Detected PATH issue, adding to shell profile..."
- **Report Fix**: "Fixed by [action]. Please verify with [command]"

### When to HALT (Escalate to Human)

1. **Python 3.12 not available** AND user cannot upgrade (requires system admin)
2. **License key invalid** after 3 attempts
3. **Network completely unreachable** (not just timeout)
4. **Claude Code missing** AND no auto-install method available
5. **Unknown error** that doesn't match any pattern

**HALT Format**:
```
❌ Installation blocked: [reason]
🔧 Required action: [what user must do]
📧 Need help? Contact: omar@unpossible.com
```

---

## OS-Specific Adaptations

### Linux
- Package manager: `apt` (Debian/Ubuntu) or `yum` (RedHat/CentOS)
- Shell: Bash (default)
- Python location: `/usr/bin/python3`
- Scripts path: `~/.local/bin`

### macOS
- Package manager: `brew`
- Shell: Zsh (default on macOS 10.15+)
- Python location: `/usr/local/bin/python3` or `/opt/homebrew/bin/python3`
- Scripts path: `~/Library/Python/3.12/bin`

### Windows
- Package manager: None (use Python installer or WSL2)
- Shell: CMD or PowerShell
- Python location: `%APPDATA%\Local\Programs\Python\Python312`
- Scripts path: `%APPDATA%\Python\Python312\Scripts`
- **Recommendation**: Use WSL2 for best experience

---

## Notes for Autonomous Execution

### Adaptation Strategy
- Use knowledge of user's OS to skip irrelevant steps
- Don't ask permission for standard operations (creating venv, installing packages)
- **DO ask for**: license key, API endpoint (if custom), project directory
- Validate each step before proceeding
- If error occurs, attempt automated recovery before asking user

### Safety Guardrails
- Never execute destructive commands (rm, del, format)
- Never modify system Python installation
- Always use virtual environments when possible
- Never store license key in code/logs (only in config file)

### Efficiency
- Run detection commands in parallel where possible
- Cache detection results (don't re-detect OS multiple times)
- Skip validation steps that already passed
- Report progress concisely (avoid verbose output)

---

## Related Documentation

**For Humans**:
- Quick Start: `docs/guides/quick-start-beta.md`
- Full Onboarding: `docs/deployment/beta-onboarding.md`

**For Developers**:
- Build Process: `docs/deployment/client-wheel-build.md` (for maintainers only - users install from PyPI)
- Architecture: `docs/architecture/firebase-saas-two-tier-prompting.md`

---

**Last Updated**: 2025-12-02 (PyPI distribution now available)
**Target Audience**: LLM agents (Claude Code, GPT-4, etc.)
**Purpose**: Enable autonomous installation of Obra SaaS on behalf of users
