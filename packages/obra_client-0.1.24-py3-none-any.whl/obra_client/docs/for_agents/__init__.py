"""Agent onboarding documentation for LLM-driven Obra operation.

These documents are designed to be read by LLM agents (Claude, GPT, etc.)
to enable autonomous operation of Obra on behalf of users.

Files:
    autonomous-setup.md: Complete setup guide for agent-driven installation
    capability-brief.md: What Obra can do and how agents should use it
    task-templates.md: Pre-built task patterns for common development workflows
"""

import importlib.resources
from pathlib import Path
from typing import Optional


def get_docs_path() -> Path:
    """Get the path to the for-agents documentation directory.

    Returns:
        Path to the directory containing agent onboarding docs
    """
    return Path(__file__).parent


def read_doc(name: str) -> Optional[str]:
    """Read a documentation file by name.

    Args:
        name: Document name (e.g., 'capability-brief', 'autonomous-setup', 'task-templates')
              The .md extension is optional.

    Returns:
        Document contents as string, or None if not found
    """
    if not name.endswith('.md'):
        name = f"{name}.md"

    doc_path = get_docs_path() / name
    if doc_path.exists():
        return doc_path.read_text(encoding='utf-8')
    return None


def list_docs() -> list[str]:
    """List available documentation files.

    Returns:
        List of document names (without .md extension)
    """
    docs_path = get_docs_path()
    return [f.stem for f in docs_path.glob("*.md")]
