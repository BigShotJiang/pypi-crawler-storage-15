# Obra Capability Brief for LLM Agents

Dense reference to decide **when to route work through Obra**, and **how to call it from another LLM agent**.

---

## CRITICAL: Your Role as the Calling Agent

> **YOU DO NOT WRITE CODE. YOU DELEGATE TO OBRA.**

When a user asks you to use Obra, your job is to be a **task architect**, not a coder:

| Your Role (Calling Agent) | Obra's Role (Execution) |
|---------------------------|-------------------------|
| Formulate clear objectives | Plan the implementation |
| Define requirements & constraints | Decompose into subtasks |
| Specify success criteria | Execute code changes |
| Describe target outputs | Validate quality |
| Review results | Iterate until threshold met |

### What You SHOULD Do

1. **Analyze the user's request** - Understand what they want built
2. **Formulate a detailed prompt** with:
   - Clear intention (what outcome)
   - Specific requirements (features, constraints)
   - Target outputs (files, deliverables)
   - Success criteria (how to verify)
3. **Send the prompt to Obra** via `obra interactive -c "..."`
4. **Review the results** and report back to the user

### What You SHOULD NOT Do

- ❌ Write code yourself
- ❌ Create files directly
- ❌ Make git commits
- ❌ Run tests yourself
- ❌ Do the implementation work

**Why?** Obra has its own implementation agent (Claude Code) that will do all of this with quality validation, iteration, and pattern guidance. If you write code yourself, you bypass all of Obra's value.

### Example: User Says "Use Obra to add authentication"

**WRONG** (doing the work yourself):
```
Let me create an auth module...
[writes code]
[creates files]
```

**RIGHT** (delegating to Obra):
```bash
obra interactive -c "Create a task to implement user authentication:

**Objective**: Add JWT-based authentication to the REST API

**Requirements**:
- Login endpoint at POST /api/auth/login
- JWT tokens with 24h expiry
- Password hashing with bcrypt
- Protected route middleware

**Deliverables**:
- src/auth/jwt.py - Token generation/validation
- src/auth/middleware.py - Route protection
- src/routes/auth.py - Login endpoint
- tests/test_auth.py - Authentication tests

**Success Criteria**:
- All tests pass
- Login returns valid JWT
- Protected routes reject invalid tokens
" -c "/execute 1" -c "exit"
```

Then report the results to the user.

---

**Mini index (for agents)**:
- Patterns & triggers → **Workflow Patterns (9‑Pattern Library)**
- Task JSON schema → NL rendering → **Recommended Internal Schema (for LLM Callers)**
- Constraint defaults (YAML) → **Machine‑Readable Constraint Snapshot (Illustrative)**
- Result normalization JSON → **Output Expectations**
- Handoff algorithm (YAML) → **Handoff Protocol**

---

## Identity

**Obra** = Orchestration layer that wraps configurable LLM agents with validation, iteration, quality control, and work decomposition.

**Default implementation agent**: Claude Code CLI  
**Also supported**: OpenAI Codex CLI, others via plugin system

**Two‑LLM architecture (common deployment)**:
- **Orchestrator LLM** (local/remote, configurable) → reasoning, validation, quality scoring, decision making
- **Implementation Agent** (Claude Code / Codex CLI) → code generation and tool use in a workspace

**Critical understanding**: Obra orchestrates your agent, it doesn't replace or restrict it. Tasks run through Obra have ALL capabilities of the configured implementation agent.

**Mental model**:
- Without Obra: You → Agent → Result
- With Obra: You → Obra (orchestrator LLM) → Agent → Validation → Iteration → Quality‑controlled Result

**What Obra adds**:
- Automatic iteration until quality threshold met
- Work decomposition (Epic → Story → Task)
- Pattern‑guided execution (10 workflow patterns)
- Stall detection and recovery
- Session continuity across context limits
- Documentation governance (doc-code coupling)
- Structured logging and monitoring

**What Obra does NOT do**:
- Replace your agent (it orchestrates it)
- Restrict agent capabilities (agent retains all tools)
- Add new execution capabilities (orchestration only)

---

## Core Capabilities

| Capability | Description |
|------------|-------------|
| **Autonomous execution** | Execute code tasks without human intervention |
| **Quality validation** | Validate output, retry until threshold met |
| **Work decomposition** | Break Epic → Story → Task automatically |
| **Pattern guidance** | Apply 10 workflow patterns (docs, tests, commits, planning) |
| **Session continuity** | Checkpoint, handoff, resume across sessions |
| **Doc governance** | Update coupled docs when code changes (`obra docs status`) |
| **Natural language** | Accept tasks in plain English, no DSL |
| **Hybrid prompts** | Structured JSON+NL prompts for validation and control |

### Execution Model (Orchestration Pipeline)

When you ask Obra to execute a task, the high‑level pipeline is:

1. **Task intake**  
   Natural language command (e.g., `Create a task to …`) is parsed into an internal task with scope (Epic/Story/Task) and metadata.
2. **Pattern selection** (workflow mode, default)  
   Obra selects one or more workflow patterns (see below) based on task type and context.
3. **Agent execution**  
   Implementation agent (e.g., Claude Code) runs in a fresh workspace session per iteration.
4. **Validation**  
   - Format/completeness check (ResponseValidator)  
   - Quality check vs requirements (QualityController)  
   - Confidence scoring (ConfidenceScorer)
5. **Decision**  
   DecisionEngine chooses to **proceed**, **retry**, **clarify**, or trigger a **breakpoint**.
6. **Iteration / completion**  
   Iterates until quality threshold or iteration/timeout limits, then returns structured status + metrics.

Legacy non‑pattern “validation pipeline” exists but is disabled by default (see `orchestration.workflow` vs `orchestration.validation` in config).

---

## Workflow Patterns (9‑Pattern Library)

Obra’s workflow mode uses a pattern library defined in `config/patterns.yaml`. Patterns are selected automatically; you normally don’t need to name them, but **phrasing tasks to match their intent improves behavior**.

| Pattern key | Purpose | Typical trigger phrases |
|------------|---------|-------------------------|
| `architecture_docs` | Design & architecture docs | “new subsystem”, “major refactor”, “ADR”, “design” |
| `implementation_planning` | Dual‑format human + machine implementation plans | “plan implementation”, “break down feature” |
| `test_suite` | Comprehensive tests & coverage | “add tests”, “regression test”, “ensure coverage” |
| `git_commit` | Commit discipline & clean git state | “ready to commit”, “finalize work” |
| `continue_coding` | Maintain momentum and avoid stalls | “continue implementation”, “keep coding” |
| `best_practices` | Enforce code quality & style | “apply best practices”, “clean up code” |
| `continuation_prompt` | Session handoff & context management | “handoff”, “pause work”, long‑running sessions |
| `changelog_update` | Keep CHANGELOG updated | “update changelog”, “document release” |
| `agile_breakdown` | Epic → Story → Task breakdown | “large feature”, “epic”, “break down work” |

**LLM tip**: When formulating tasks, include cues that map to the desired pattern(s). Obra will handle the mechanics; you just describe the outcome.

---

## Decision Tree: Should You Use Obra?

```
Does task benefit from iteration/quality control?
├─ NO → Use Claude Code directly (faster, less overhead)
└─ YES → Continue
    │
    Is task well-defined with clear deliverables?
    ├─ NO → Define better, then use Obra
    └─ YES → Continue
        │
        Does task need decomposition or multi-step orchestration?
        ├─ NO → Consider direct Claude Code (simpler)
        └─ YES → Use Obra
            │
            Estimated effort?
            ├─ <1 hour → Create Task
            ├─ 1-4 hours → Create Story
            └─ >4 hours → Create Epic with Stories
```

**Key insight**: Obra adds value when you need quality guarantees, automatic retry, or work decomposition. For simple one‑shot tasks, direct Claude Code is faster.

---

## Use Obra For

Tasks that benefit from orchestration overhead:

- **Multi-step implementations** needing decomposition (Epic/Story)
- **Quality-critical work** requiring validation and iteration
- **Complex features** with multiple deliverables
- **Autonomous execution** without human babysitting
- **Pattern-guided work** (auto-apply best practices)
- **Long-running tasks** needing stall detection
- **Web research + processing** that needs quality validation
- **Data collection pipelines** with defined success criteria

---

## Don't Use Obra For

Tasks where orchestration adds overhead without benefit:

- **Simple one-shot tasks** (<15 min, no iteration needed)
- **Exploratory research** with undefined deliverables
- **Quick queries** ("what does X mean?")
- **Real-time interactive work** requiring human-in-loop
- **Tasks without clear success criteria** (can't validate)

**Note**: "Can't do web research" is FALSE. Default agent (Claude Code) has WebSearch/WebFetch. The question is whether orchestration adds value to your web research task.

---

## Common Misconceptions

| Misconception | Reality |
|---------------|---------|
| "Obra can't access the internet" | Depends on agent. Default (Claude Code) has WebSearch/WebFetch |
| "Obra is a different/limited agent" | FALSE - Obra orchestrates your agent, doesn't replace it |
| "Use Claude Code instead of Obra" | Obra USES Claude Code (or other agents); they're not alternatives |
| "Obra is only for coding tasks" | FALSE - Any task your agent can do, Obra can orchestrate |

### Example: Web Research Task (with default Claude Code agent)

**Without Obra**:
```
You → Claude Code → WebSearch → Results
(Single pass, no validation)
```

**With Obra**:
```
You → Obra → Claude Code → WebSearch → Results → Validation → Iterate if needed
(Quality-controlled, retries on failure, logs results)
```

**When to use Obra for web research**:
- Need to collect data with specific schema
- Need validation that results meet criteria
- Need automatic retry on incomplete results
- Need to decompose into batches (Epic/Story)
- Need logging/monitoring of collection progress

**When to use direct Claude Code**:
- Quick one-off search
- Exploratory research with undefined goals
- Simple queries not needing validation

---

## Invocation

### Prerequisites
- Obra installed (`obra --help` works)
- Orchestrator LLM configured (Codex or Ollama; see `config/default_config.yaml` / user config)
- At least one **project** created and linked to a filesystem path

### Health Check (Run First)

```bash
# 1. Verify LLM connection (most common failure point)
obra llm status
# Expected: "LLM Status: Connected" or similar
# If disconnected: Start LLM service (Codex: `codex --login`, Ollama: `ollama serve`)

# 2. List projects (need at least one)
obra project list
# If empty: Create project first (see Project Management below)

# 3. Quick functional test
obra interactive -c "/status" -c "exit"
# Should show orchestrator state without errors
```

**Startup failures**:
| Symptom | Cause | Fix |
|---------|-------|-----|
| "LLM not available" | LLM service not running | Start Codex/Ollama, then `obra llm status` |
| "No active project" | No project selected | `obra project create "Name" /path` or select existing |
| Connection timeout | LLM overloaded/unreachable | Check service logs, retry |

### Project Management (for calling agents)

Projects map Obra to a workspace on disk. Tasks execute in the **active project's directory**.

```bash
# List projects (shows IDs and which is active)
obra project list

# Create project (becomes active automatically)
obra project create "My App" ~/obra-projects/my-app

# Switch active project
obra interactive -c "/project select 2" -c "exit"
```

**Project selection behavior**:
- New projects auto-activate on creation
- Tasks always run in active project's workspace
- If no project active: task creation fails
- Check active project: `obra project list` (look for `[active]` marker)

### Basic Pattern
```bash
# Start interactive mode
obra interactive

# Inside interactive mode:
obra> Create a project called "MyProject" at ~/obra-projects/myproject
obra> Create a task to <description>
obra> /execute <task_id>
obra> exit
```

### Scripted Pattern (No Human Input)
```bash
obra interactive \
  -c "Create a task to implement user authentication" \
  -c "/execute 1" \
  -c "exit"
```

**LLM tip**: When automating from another agent, prefer `obra interactive -c "<NL command>" ...` to keep everything in one subprocess and avoid interactive prompts.

---

## Task Description Quality

**Effective descriptions include**:
- Clear deliverable (file, function, test)
- Specific location (file path)
- Success criteria
- Constraints

**Good**:
```
Create pytest tests for src/auth/login.py:
- Test successful login with valid credentials
- Test failed login with wrong password
- Test account lockout after 5 failures
Location: tests/test_login.py
```

**Bad**:
```
Write some tests for the login system
```

### Recommended Internal Schema (for LLM Callers)

Obra accepts **natural language**, not JSON. However, as a calling agent you may find it useful to maintain an internal task object and then render it to NL.

```json
{
  "obra_level": "task",           // "task" | "story" | "epic"
  "title": "Add unit tests for login",
  "description": "Create pytest tests for src/auth/login.py",
  "deliverables": ["tests/test_login.py"],
  "requirements": [
    "Test successful login with valid credentials",
    "Test failed login with wrong password",
    "Test account lockout after 5 failures"
  ],
  "success_criteria": [
    "All tests pass",
    "Coverage for login logic ≥ 90%"
  ],
  "estimated_effort_hours": 2,
  "pattern_hints": ["test_suite"]
}
```

Then render into something like:

> “Create a **task** titled ‘Add unit tests for login’. Description: … Deliverables: … Requirements: … Success criteria: … Estimated effort: ~2 hours. This should use the test suite best‑practice pattern.”

---

## Constraints

**High‑level defaults** (see `config/default_config.yaml` and user `config.yaml` for exact values):

| Constraint | Default | Notes |
|------------|---------|-------|
| Token budget (agent) | 150K | Per task, configurable |
| Token budget (local LLM) | 75K | Per task |
| Max iterations | 50 | Per task (`orchestration.max_iterations`) |
| Iteration timeout | 300s | Per iteration (`orchestration.iteration_timeout`) |
| Task timeout | 3600s | Overall (`orchestration.task_timeout`) |
| Quality threshold | 70% | For validation (`validation.quality.threshold`) |
| Confidence threshold | 50% | For decisions (`confidence.threshold`) |
| Concurrent tasks | 1 | Single task at a time per orchestrator |

### Machine‑Readable Constraint Snapshot (Illustrative)

```yaml
orchestration:
  max_iterations: 50
  iteration_timeout_s: 300
  task_timeout_s: 3600
  concurrent_tasks: 1
validation:
  quality_threshold: 0.70
  run_tests: true
confidence:
  threshold: 0.50
workflow:
  enabled: true        # Pattern-guided execution
  patterns_path: config/patterns.yaml
```

---

## Output Expectations

After task execution (via CLI/interactive), you receive human‑readable output including:
- **Status**: completed, failed, stalled
- **Quality score**: 0‑100
- **Confidence score**: 0‑100
- **Iterations used**: count
- **Files modified**: list
- **Git commit**: if git integration enabled (`git.enabled: true`)

The CLI output is not strictly JSON. When automating, normalize it into an internal structure like:

```json
{
  "status": "completed",
  "quality": 82,
  "confidence": 76,
  "iterations_used": 3,
  "files_modified": [
    "src/auth/login.py",
    "tests/test_login.py"
  ],
  "git_commit": "abc1234",
  "notes": "Tests added and all checks passed."
}
```

---

## Handoff Protocol

To delegate work to Obra from another agent:

### 1. Assess Fit
Use decision tree above. If task fits, continue.

### 2. Formulate Task
```
Title: <imperative verb> <object>
Description:
- Deliverable: <what to create>
- Location: <file path>
- Requirements: <list>
- Success criteria: <how to verify>
```

### 3. Invoke
```bash
obra interactive \
  -c "Create a task to <title>: <description>" \
  -c "/execute 1" \
  -c "exit"
```

### 4. Receive Results
- Check exit code (0 = success)
- Parse output for status, quality, files
- Verify deliverables exist

### 5. Handle Failures

| Status | Indicators | Root Cause | Recovery |
|--------|------------|------------|----------|
| **stalled** | Repeated errors, no progress, quality stuck | Task too vague or impossible | Reformulate with specific deliverables, success criteria |
| **failed** (quality) | Quality score <70%, iterations exhausted | Requirements unclear or contradictory | Add detail, clarify constraints, provide examples |
| **failed** (timeout) | Task timeout hit (3600s default) | Task too large | Decompose into Stories (<4h each) |
| **failed** (iteration) | Max iterations (50) hit | Agent loops without converging | Simplify requirements, add intermediate checkpoints |

**Diagnostic commands**:
```bash
# Check what happened
obra interactive -c "/task list" -c "Show task <id>" -c "exit"

# View detailed logs
cat ~/obra-runtime/logs/production.jsonl | grep "task_id.*<id>"
```

**Retry strategy**:
1. Check logs for specific error patterns
2. If vague requirements → add deliverables list, success criteria
3. If too large → break into Epic with Stories
4. If stalled on same error → different approach needed (constraints may be impossible)

### Handoff Algorithm (LLM‑Friendly Pseudocode)

```yaml
handoff_to_obra(task):
  if not should_use_obra(task):
    return run_direct(task)

  description_nl = render_task_to_natural_language(task)

  run_shell([
    "obra", "interactive",
    "-c", f"Create a task to {task.title}: {description_nl}",
    "-c", "/execute 1",
    "-c", "exit"
  ])

  result = parse_obra_output(stdout, stderr)

  if result.status == "stalled":
    task = refine_task_description(task, result)
    return handoff_to_obra(task)
  if result.status == "failed" and result.reason == "timeout":
    smaller_tasks = decompose_into_stories_and_tasks(task)
    return [handoff_to_obra(t) for t in smaller_tasks]

  return result
```

---

## Work Hierarchy

| Level | Scope | When to Use |
|-------|-------|-------------|
| **Epic** | 3‑15 sessions | Large feature (auth system) |
| **Story** | 1 session (4‑16h) | User deliverable (login page) |
| **Task** | 1‑4 hours | Technical work (hash passwords) |

**Decomposition rule**: If >4 hours, break down.

---

## Integration Points

| System | Integration |
|--------|-------------|
| **Git** | Optional auto‑commit per task/milestone (`git.enabled: true`) |
| **GitHub** | Optional PR creation via `gh` CLI |
| **CI/CD** | Scripted mode for automation (`obra interactive -c ...`) |
| **Monitoring** | JSON Lines logs at `~/obra-runtime/logs/` |

### Git Integration Defaults (from `config/default_config.yaml`)

```yaml
git:
  enabled: false          # Auto-integration is opt-in
  auto_commit: true       # Commit after task completion when enabled
  commit_strategy: per_task
  create_branch: true
  branch_prefix: "obra/task-"
  auto_pr: false
```

**LLM tip**: Assume git integration may be enabled. Avoid performing your own git operations on the same workspace while Obra is running unless explicitly asked.

---

## Limitations

Orchestration-level constraints (agent capabilities preserved):

- **Single workspace**: One working directory per task
- **Session isolation**: Each iteration = fresh agent session
- **No GUI**: CLI only
- **LLM required**: Needs configured orchestrator LLM (Codex or Ollama)
- **Validation overhead**: Each iteration has validation cost

**NOT limitations** (capabilities depend on configured agent):

Default agent (Claude Code) includes:
- ~~No internet access~~ → WebSearch/WebFetch available
- ~~No file operations~~ → Full file access
- ~~No shell access~~ → Bash tool available

Your configured agent retains ALL its native capabilities.

---

## Quick Reference

### CLI Commands
```bash
# Health check
obra llm status              # Verify LLM connected
obra project list            # List projects

# Create and execute task
obra interactive -c "Create task to <desc>" -c "/execute 1" -c "exit"

# Check status
obra interactive -c "/status" -c "exit"

# View logs
ls ~/obra-runtime/logs/
```

### Interactive Mode Commands

| Command | Purpose |
|---------|---------|
| `/help` | List all commands |
| `/status` | Orchestrator state, active task, LLM status |
| `/llm status` | LLM connection details |
| `/task list` | All tasks with status |
| `/project list` | All projects |
| `/project select <id>` | Switch active project |
| `execute <id>` | Run task by ID |
| `exit` | Exit interactive mode |

**Note**: Natural text (no `/`) routes to orchestrator as NL command. System commands require `/` prefix.

---

## Further Reading

- **[task-templates.md](task-templates.md)** - Copy-paste task examples
- **[CLAUDE.md](../../../../CLAUDE.md)** - Full development context
- **[System Overview](../../../architecture/obra-system-overview.md)** - Architecture details
