"""DumpConfluence - CLI tool to backup Confluence pages"""

__version__ = "1.0.1"
__author__ = "Dani Lipari"
