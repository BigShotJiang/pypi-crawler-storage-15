"""qen - A tiny, extensible tool for organizing multi-repository development work."""

__version__ = "0.1.1"
