from meridian import __version__


def test_version() -> None:
    assert __version__ == "1.1.1"
