Installation
============

Invenio-curations is on PyPI so all you need is:

.. code-block:: console

   $ pip install invenio-curations
