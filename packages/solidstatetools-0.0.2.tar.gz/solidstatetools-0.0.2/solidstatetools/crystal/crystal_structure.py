import pickle

import matplotlib.pyplot as plt
import numpy as np
from matplotlib import colormaps


def F_function(f, plan, maille):
    F = f * np.exp(2 * np.pi * 1j * (plan[0] * maille[0] + plan[1] * maille[1] + plan[2] * maille[2]))
    return F


def changement_de_base(B, C):
    """
    Calcule la matrice de changement de base de la base B à la base C.

    :param B: Liste des vecteurs de la base B (chacun est un numpy array)
    :param C: Liste des vecteurs de la base C (chacun est un numpy array)
    :return: La matrice de changement de base de B à C
    """
    # Construire les matrices de la base B et C
    B_matrix = np.column_stack(B)
    C_matrix = np.column_stack(C)

    # La matrice de changement de base de B à C est donnée par B_matrix^-1 * C_matrix
    P = np.linalg.inv(B_matrix).dot(C_matrix)

    return P


def phi_rho():
    # phi = []
    # rho = []
    # for plan in plans_list:
    #     d = 1
    #wwa
    #     if plan[0] == 0:
    #         phi.append(plan[1] / np.linalg.norm(plan[1]) * np.pi / 2)
    #     else:
    #         phi.append(np.arctan((self.lattice_parameters[0] * plan[1]) / (self.lattice_parameters[1] * plan[0])))
    #
    #     if plan[2] == 0:
    #         rho.append(np.pi / 2)
    #     else:
    #         rho.append(np.arctan(self.lattice_parameters[2] / (l * d)))
    #
    # r = np.tan(np.array(rho)/2)
    pass


def generate_planes(n, m=3):
    if m == 0:
        return []
    if m == 1:
        l = []
        for i in range(-n, n + 1):
            l.append([i])
        return l

    l = []
    for i in range(-n, n + 1):
        for j in generate_planes(n, m - 1):
            l.append([i] + j)
    return l


def default_maille(name, offset=None):
    if offset is None:
        offset = [0, 0, 0]
    if name == 'fcc':
        return np.array([[0, 0, 0], [1 / 2, 1 / 2, 0], [1 / 2, 0, 1 / 2], [0, 1 / 2, 1 / 2]]) + np.array(offset)
    if name == 'bcc':
        return np.array([[0, 0, 0], [1 / 2, 1 / 2, 1 / 2]]) + np.array(offset)
    if name == 'P':
        return np.array([[0, 0, 0]]) + np.array(offset)


class CrystalStructure():

    def __init__(self, at_positions=None, elements=None, lattice_parameters=None, cell_angles=None):

        self.default_element = 'C'
        if cell_angles is None:
            self.cell_angles = [np.pi / 2, np.pi / 2, np.pi / 2]
        else:
            self.cell_angles = cell_angles

        if lattice_parameters is None:
            self.lattice_parameters = [1, 1, 1]
        else:
            self.lattice_parameters = lattice_parameters

        if at_positions is None:
            self.at_positions = [[0, 0, 0]]
        else:
            self.at_positions = at_positions

        if elements is None:
            self.elements = [self.default_element for _ in enumerate(self.at_positions)]
        else:
            self.elements = elements

        self.color = {'Si': 'grey', 'C': 'black', 'Ge': 'thistle', 'Al': 'grey'}
        self.size = {'Si': 0.132, 'C': 0.0914, 'Ge': 0.137, 'Al': 0.143}

    def d(self, plan):
        h,k,l = plan
        a, b, c = self.lattice_parameters
        alpha, beta, gamma = self.cell_angles
        V = a * b * c * np.sqrt(
            1 - np.cos(alpha) ** 2 - np.cos(beta) ** 2 - np.cos(gamma) ** 2 + 2 * np.cos(alpha) * np.cos(beta) * np.cos(
                gamma))
        S11 = b ** 2 * c ** 2 * np.sin(alpha) ** 2
        S22 = c ** 2 * a ** 2 * np.sin(beta) ** 2
        S33 = a ** 2 * b ** 2 * np.sin(gamma) ** 2
        S12 = a * b * c ** 2 * (np.cos(alpha) * np.cos(beta) - np.cos(gamma))
        S23 = a ** 2 * b * c * (np.cos(beta) * np.cos(gamma) - np.cos(alpha))
        S31 = a * b ** 2 * c * (np.cos(gamma) * np.cos(alpha) - np.cos(beta))
        d = V/np.sqrt(S11*h**2+S22*k**2+S33*l**2+2*S12*h*k+2*S23*k*l+2*S31*l*h)
        return d

    @property
    def data(self):
        data = {
            'at_position': self.at_positions,
            'elements': self.elements,
            'lattice_parameters': self.lattice_parameters,
            'cell_angles': self.cell_angles
        }
        return data

    def save_cell(self, filename):
        with open(filename, 'wb') as file:
            pickle.dump(self.data, file)

    def load_cell(self, filename):
        with open(filename, 'rb') as file:
            data = pickle.load(file)
            self.at_positions = data['at_positions']
            self.elements = data['elements']
            self.lattice_parameters = data['lattice_parameters']
            self.cell_angles = data['cell_angles']
        return 'Cell loaded'

    def add_atom(self, at_positions, elements=None):
        self.at_positions += at_positions

        if elements is None:
            self.elements += [None for _ in range(len(at_positions))]
        else:
            self.elements += elements

    def remove_atom(self, position):
        del self.at_positions[position]
        del self.elements[position]

    @property
    def cartesian_vectors(self):
        alpha, beta, gamma = self.cell_angles
        a = np.array([1, 0, 0])
        b = np.array([np.cos(gamma), np.sin(gamma), 0])
        cx = np.cos(beta)
        cy = (np.cos(alpha)-np.cos(gamma)*cx)/np.sin(gamma)
        cz = np.sqrt(1-cx**2-cy**2)
        c = np.array([cx, cy, cz])
        return [a, b, c]


    def plot_cell(self):
        fig = plt.figure()
        ax = fig.add_subplot(projection='3d')
        lines = [[[0, 0], [0, 0], [0, 1]], [[1, 1], [0, 0], [0, 1]], [[0, 0], [1, 1], [0, 1]], [[1, 1], [1, 1], [0, 1]]]
        lines += [[[0, 1], [0, 0], [0, 0]], [[0, 0], [0, 1], [0, 0]], [[1, 1], [0, 1], [0, 0]],
                  [[0, 1], [1, 1], [0, 0]]]
        lines += [[[0, 1], [0, 0], [1, 1]], [[0, 0], [0, 1], [1, 1]], [[1, 1], [0, 1], [1, 1]],
                  [[0, 1], [1, 1], [1, 1]]]
        for line in lines:
            ax.plot(np.array(line[0]), np.array(line[1]), np.array(line[2]), color='grey')

        for k, i in enumerate(self.at_positions):
            cl = self.color[self.elements[k]]
            s = 10000 * self.size[self.elements[k]]
            ax.scatter3D(i[0], i[1], i[2], s=s, color=cl)
            if i[0] == 0:
                ax.scatter3D(i[0] + 1, i[1], i[2], s=s, color=cl)
            if i[1] == 0:
                ax.scatter3D(i[0], i[1] + 1, i[2], s=s, color=cl)
            if i[2] == 0:
                ax.scatter3D(i[0], i[1], i[2] + 1, s=s, color=cl)
            if i[0] == 0 and i[1] == 0:
                ax.scatter3D(i[0] + 1, i[1] + 1, i[2], s=s, color=cl)
            if i[1] == 0 and i[2] == 0:
                ax.scatter3D(i[0], i[1] + 1, i[2] + 1, s=s, color=cl)
            if i[0] == 0 and i[2] == 0:
                ax.scatter3D(i[0] + 1, i[1], i[2] + 1, s=s, color=cl)
            if i[0] == 0 and i[1] == 0 and i[2] == 0:
                ax.scatter3D(i[0] + 1, i[1] + 1, i[2] + 1, s=s, color=cl)
        plt.show()

    def real_vector(self,plan):
        if self.cell_angles[0] == 2*np.pi/3:
            n = np.linalg.norm(plan)
            rot_matrix = np.array([[np.cos(np.pi / 6), 0, 0], [np.cos(-np.pi / 3), 1, 0], [0, 0, 1]])
            new_vector = np.dot(rot_matrix, np.array(plan) / n)
            return new_vector/np.linalg.norm(new_vector)
        else:
            return plan/np.linalg.norm(plan)

    def plan_angle(self,plan1, plan2):
        real_vector1 = self.real_vector(plan1)
        real_vector2 = self.real_vector(plan2)
        angle = np.arccos(np.round(np.dot(real_vector1, real_vector2),decimals=6))
        return angle

    def F_plan(self, plan):
        F = 0 + 0j
        for i in self.at_positions:
            F += F_function(1, plan, i)
        return np.abs(F)

    def all_plans(self, n, distance_min=None):
        plans = generate_planes(n, m=3)
        plans.remove([0, 0, 0])
        F_list = []
        plan_list = []
        for plan in plans:
            F = self.F_plan(plan)
            if F >= 0.1 or F <= -0.1:
                if distance_min is None:
                    F_list.append(np.round(np.abs(F)))
                    plan_list.append(plan)
                else:
                    if self.d(plan) >= distance_min:
                        F_list.append(np.round(np.abs(F)))
                        plan_list.append(plan)
        return plan_list, F_list

    def reduced_plan(self, plans):
        plans = np.array(plans)
        n_max = np.max(plans)
        # print(n_max)
        stop = True
        n = 0
        while stop:
            bool_array = np.array([True for _ in range(plans.shape[0])])
            for i in range(2, n_max + 1):
                bool_array = np.logical_and(bool_array, np.any(plans != plans[n] * i, axis=1))
            index_array = np.array([j for j, x in enumerate(bool_array) if not x])
            count = np.sum(index_array < n)
            n -= count
            plans = plans[bool_array]
            if plans.shape[0] - 1 <= n:
                stop = False
            n += 1
        return plans

    def stereo_proj(self, direction, n):
        plans = self.all_plans(n)
        plans = self.reduced_plan(plans)



    def apt_proj(self, plans, z=None, x=None, angle_max=None, plot=False):
        if x is None:
            x = [0, 1, 0]
        x = self.real_vector(np.array(x))

        if z is None:
            z = [0, 0, 1]
        z = self.real_vector(np.array(z))
        y = np.cross(z, x)
        # print(x, y, z)
        plans = np.array(plans)
        n_max = np.max(plans)
        # print(n_max)
        stop = True
        n = 0
        while stop:
            bool_array = np.array([True for _ in range(plans.shape[0])])
            for i in range(2, n_max + 1):
                bool_array = np.logical_and(bool_array, np.any(plans != plans[n] * i, axis=1))
            index_array = np.array([j for j, x in enumerate(bool_array) if not x])
            count = np.sum(index_array < n)
            n -= count
            plans = plans[bool_array]
            if plans.shape[0] - 1 <= n:
                stop = False
            n += 1

        plans_list = []
        if angle_max is None:
            for i in range(plans.shape[0]):
                if self.plan_angle(plans[i], z) <= np.pi/2:
                    plans_list.append(list(plans[i]))
        else:
            for i in range(plans.shape[0]):
                if self.plan_angle(plans[i], z) <= angle_max:
                    plans_list.append(list(plans[i]))
            # np.arccos(np.dot(plans[i], z)/(np.linalg.norm(plans[i])*np.linalg.norm(z)))

        plotpoints = np.zeros((len(plans_list), 2))
        for i, v in enumerate(plans_list):
            new_vector = self.real_vector(v)
            plotpoints[i] = [np.dot(x, new_vector), np.dot(y, new_vector)]

        if plot==True:
            plt.rcParams['figure.figsize'] = [24, 24]
            cmap1 = colormaps.get_cmap('jet').resampled(len(plans_list))
            fig1, ax1 = plt.subplots()
            for i, p in enumerate(plotpoints):
                ax1.scatter(p[0], p[1], marker='x', color='k', s=200, linewidth=3)
                ax1.text(p[0] + 0.01, p[1] + 0.01,
                         str('(' + repr(plans_list[i][0]) + ', ' + repr(plans_list[i][1]) + ', ' + repr(
                             plans_list[i][2]) + ')'),
                         fontsize=7, color='k')
            plt.xlabel('Dx', fontsize=18)
            plt.ylabel('Dy', fontsize=18)
            plt.xticks(fontsize=18)
            plt.yticks(fontsize=18)
            ax1.axis('equal')
            plt.show()

        return plans_list, plotpoints
