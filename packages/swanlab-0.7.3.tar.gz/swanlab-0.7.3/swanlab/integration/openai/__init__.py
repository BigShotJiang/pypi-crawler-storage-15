#!/usr/bin/env python
# -*- coding: utf-8 -*-
r"""
@DATE: 2024-04-23 11:24:54
@File: swanlab\intergration\openai\__init__.py
@IDE: vscode
@Description:
    OpenAI集成
"""

from .openai import autolog
