"""
@author: cunyue
@file: __main__.py
@time: 2025/6/5 13:41
@description: SwanLab的主入口文件，提供了命令行接口
"""

from swanlab.cli import cli

if __name__ == "__main__":
    cli()
