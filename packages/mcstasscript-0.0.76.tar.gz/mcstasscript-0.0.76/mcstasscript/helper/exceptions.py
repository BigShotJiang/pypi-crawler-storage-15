class McStasError(Exception):
    # Error raised when McStas simulation can't run
    pass