# SPDX-License-Identifier: Apache-2.0

import sys

from osism.main import main


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
