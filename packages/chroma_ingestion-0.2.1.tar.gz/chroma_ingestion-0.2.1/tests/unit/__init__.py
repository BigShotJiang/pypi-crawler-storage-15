"""Unit tests for chroma_ingestion package.

This module contains isolated unit tests for individual components
of the chroma_ingestion package, including configuration, clients,
and utility functions.
"""
