"""Integration tests for chroma_ingestion package.

This module contains integration tests that test multiple components
working together, including ingestion workflows, retrieval operations,
and end-to-end scenarios.
"""
