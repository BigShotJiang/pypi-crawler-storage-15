from .dict import *


__all__ = [
    "useDict"
]