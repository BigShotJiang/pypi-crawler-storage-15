"""TaskCLI - Interactive Task Manager CLI"""
__version__ = "1.0.0"
