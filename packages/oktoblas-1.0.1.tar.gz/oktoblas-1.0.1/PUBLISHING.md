# 📦 OktoBLAS Publishing Guide

Como publicar OktoBLAS para a comunidade Python.

---

## 🏗️ Estrutura do Projeto

```
python/
├── oktoblas/
│   ├── __init__.py      # Python wrapper
│   └── _oktoblas.pyd    # Compiled Rust extension (Windows)
│       _oktoblas.so     # Compiled Rust extension (Linux)
├── src/
│   └── lib.rs           # Rust bindings (PyO3)
├── Cargo.toml           # Rust dependencies
├── pyproject.toml       # Python package config
└── README.md            # Documentation
```

---

## 🔧 Build Local

### Requisitos

- **Rust** 1.70+ (https://rustup.rs)
- **Python** 3.8+ com pip
- **CUDA Toolkit** 11.8+ (para GPU)
- **Maturin** (build tool)

### Comandos

```bash
# Instalar maturin
pip install maturin

# Build em modo desenvolvimento (para teste local)
cd python
maturin develop --release

# Testar
python -c "import oktoblas; print(oktoblas.info())"
```

---

## 📤 Publicar no PyPI

### 1. Criar conta no PyPI

1. Acesse https://pypi.org/account/register/
2. Crie uma conta
3. Gere um token em https://pypi.org/manage/account/token/

### 2. Configurar credenciais

```bash
# Linux/Mac
export MATURIN_PYPI_TOKEN=pypi-xxx...

# Windows PowerShell
$env:MATURIN_PYPI_TOKEN = "pypi-xxx..."
```

### 3. Build para publicação

```bash
# Build wheels para várias versões de Python
maturin build --release

# Os arquivos .whl ficam em target/wheels/
```

### 4. Publicar

```bash
# Publicar no TestPyPI primeiro (recomendado)
maturin publish --repository testpypi

# Publicar no PyPI oficial
maturin publish
```

### 5. Verificar

```bash
# Instalar do PyPI
pip install oktoblas

# Testar
python -c "import oktoblas; oktoblas.info()"
```

---

## 🏷️ GitHub Releases

### 1. Criar Release

```bash
# Tag versão
git tag -a v0.1.0 -m "Release v0.1.0 - OktoBLAS beats PyTorch FP16"
git push origin v0.1.0
```

### 2. Build Binários

```bash
# Windows
maturin build --release
# Arquivos: target/wheels/oktoblas-0.1.0-cp38-cp38-win_amd64.whl
#           target/wheels/oktoblas-0.1.0-cp39-cp39-win_amd64.whl
#           ...

# Linux (em container ou VM)
docker run -v $(pwd):/io ghcr.io/pyo3/maturin build --release
```

### 3. Upload para GitHub

1. Vá em https://github.com/oktocode/oktoblas/releases
2. Clique "Draft a new release"
3. Selecione a tag v0.1.0
4. Adicione release notes
5. Upload dos arquivos .whl
6. Publique

### 4. Release Notes Template

```markdown
# OktoBLAS v0.1.0

🏆 **First Release - OktoBLAS beats PyTorch FP16!**

## Performance (RTX 4070 Laptop)

### FP16 GEMM (Tensor Cores)

| Matrix | OktoBLAS | PyTorch | Status |
|--------|----------|---------|--------|
| 1024×1024 | 29.1 TF | 23.3 TF | 🏆 **125%** |
| 2048×2048 | 35.1 TF | 34.6 TF | 🏆 **101%** |
| 4096×4096 | 36.5 TF | 38.9 TF | ⚡ 94% |

### Fused Attention

| Config | OktoBLAS | PyTorch | Status |
|--------|----------|---------|--------|
| B4 S256 D64 | 0.96 TF | 0.28 TF | 🏆 **346%** |
| B4 S512 D64 | 1.22 TF | 0.93 TF | 🏆 **131%** |

## Installation

```bash
pip install oktoblas
```

## Downloads

- `oktoblas-0.1.0-cp38-cp38-win_amd64.whl` - Windows Python 3.8
- `oktoblas-0.1.0-cp39-cp39-win_amd64.whl` - Windows Python 3.9
- `oktoblas-0.1.0-cp310-cp310-win_amd64.whl` - Windows Python 3.10
- `oktoblas-0.1.0-cp311-cp311-win_amd64.whl` - Windows Python 3.11
- `oktoblas-0.1.0-cp312-cp312-win_amd64.whl` - Windows Python 3.12

## Requirements

- CUDA 11.8+ (for GPU support)
- NVIDIA GPU with Tensor Cores (RTX 20/30/40 series)
```

---

## 📋 Checklist de Publicação

### Antes de publicar

- [ ] Todos os testes passam
- [ ] README.md atualizado com benchmarks
- [ ] VERSION atualizado em pyproject.toml
- [ ] CHANGELOG atualizado
- [ ] Benchmarks validados com CUDA events

### Publicação

- [ ] Build release local funciona
- [ ] TestPyPI publicado e testado
- [ ] PyPI publicado
- [ ] GitHub Release criado
- [ ] Binários anexados ao release

### Pós-publicação

- [ ] `pip install oktoblas` funciona
- [ ] Documentação atualizada
- [ ] Anúncio em redes sociais

---

## 🔐 Licença para Binários

Como você mencionou que OktoBLAS **NÃO será open source** (apenas binários), recomendo:

### Opção 1: Proprietary License (Recomendada)

```
OktoBLAS Binary License Agreement

Copyright (c) 2025 OktoSeek AI. All Rights Reserved.

This software is provided as a pre-compiled binary for use with the
OktoEngine ecosystem. You may:

✅ Use this software for personal and commercial projects
✅ Distribute applications that use this software
✅ Use this software in academic research

You may NOT:

❌ Reverse engineer, decompile, or disassemble this software
❌ Modify or create derivative works of this software
❌ Redistribute this software separately from your applications
❌ Use this software to compete with OktoSeek AI products

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
```

### Opção 2: Dual License

- **Free Tier**: Binário gratuito para uso pessoal/educacional
- **Pro Tier**: Suporte + priority bugs para empresas

### Implementação

1. Remova `src/` do GitHub público
2. Publique apenas os `.whl` nos releases
3. Adicione `LICENSE.txt` com a licença proprietária

---

## 🌐 CI/CD com GitHub Actions

```yaml
# .github/workflows/release.yml
name: Release

on:
  push:
    tags:
      - 'v*'

jobs:
  build-windows:
    runs-on: windows-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v4
        with:
          python-version: '3.11'
      - uses: dtolnay/rust-toolchain@stable
      - name: Build wheels
        run: |
          pip install maturin
          cd python
          maturin build --release
      - uses: actions/upload-artifact@v4
        with:
          name: wheels-windows
          path: python/target/wheels/*.whl

  publish:
    needs: [build-windows]
    runs-on: ubuntu-latest
    steps:
      - uses: actions/download-artifact@v4
      - name: Publish to PyPI
        env:
          MATURIN_PYPI_TOKEN: ${{ secrets.PYPI_TOKEN }}
        run: |
          pip install maturin
          maturin upload wheels-*/*.whl
```

---

## 📊 Monitoramento

Após publicação:

1. **PyPI Stats**: https://pypistats.org/packages/oktoblas
2. **GitHub Stars**: Acompanhar crescimento
3. **Issues**: Responder bugs rapidamente
4. **Benchmarks**: Atualizar com novas GPUs

---

**Última atualização:** Dezembro 2024

