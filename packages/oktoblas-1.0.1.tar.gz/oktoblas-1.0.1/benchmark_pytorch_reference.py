#!/usr/bin/env python3
"""
🏆 PyTorch Reference Benchmark
================================

HONEST benchmark to compare with OktoBLAS:
- TF32 DISABLED for fair FP32 comparison
- Proper warmup and synchronization
- Same matrix sizes as Rust benchmark

Run: python python/benchmark_pytorch_reference.py
"""

import torch
import time
import sys

def main():
    print("╔═══════════════════════════════════════════════════════════════════╗")
    print("║       🏆 PyTorch Reference Benchmark (for OktoBLAS comparison)    ║")
    print("╚═══════════════════════════════════════════════════════════════════╝")
    print()

    if not torch.cuda.is_available():
        print("❌ CUDA not available")
        return

    # Device info
    device = torch.device('cuda')
    gpu_name = torch.cuda.get_device_name(0)
    print(f"🖥️  GPU: {gpu_name}")
    print(f"📦 PyTorch: {torch.__version__}")
    print()

    # =========================================================================
    # CRITICAL: Disable TF32 for fair FP32 comparison
    # =========================================================================
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    print("⚠️  TF32 DISABLED for fair FP32 comparison")
    print()

    # Test sizes (same as Rust benchmark)
    sizes = [256, 512, 768, 1024, 1536, 2048, 3072, 4096]
    warmup = 5
    iterations = 50

    # =========================================================================
    # PART 1: FP32 GEMM Benchmark
    # =========================================================================
    print("╔═══════════════════════════════════════════════════════════════════╗")
    print("║                    FP32 GEMM BENCHMARK                            ║")
    print("╠═══════════════════════════════════════════════════════════════════╣")
    print("║  Size     │ PyTorch Time  │ TFLOPS  │ Notes                       ║")
    print("╠═══════════════════════════════════════════════════════════════════╣")

    fp32_results = []
    for size in sizes:
        m, n, k = size, size, size

        # Create random matrices
        A = torch.randn(m, k, dtype=torch.float32, device=device)
        B = torch.randn(k, n, dtype=torch.float32, device=device)

        # Warmup
        for _ in range(warmup):
            C = torch.matmul(A, B)
        torch.cuda.synchronize()

        # Benchmark
        start = time.perf_counter()
        for _ in range(iterations):
            C = torch.matmul(A, B)
        torch.cuda.synchronize()
        elapsed = time.perf_counter() - start

        time_ms = elapsed * 1000.0 / iterations
        flops = 2.0 * m * n * k
        tflops = flops / (time_ms / 1000.0) / 1e12

        # Peak efficiency (RTX 4070 = 16 TFLOPS FP32)
        peak_pct = tflops / 16.0 * 100.0
        
        print(f"║ {size:4}x{size:4} │  {time_ms:7.3f} ms   │ {tflops:5.2f} TF │ peak {peak_pct:5.1f}%                 ║")
        fp32_results.append((size, time_ms, tflops))

    print("╚═══════════════════════════════════════════════════════════════════╝")
    print()

    # =========================================================================
    # PART 2: FP16 GEMM Benchmark (Tensor Cores)
    # =========================================================================
    print("╔═══════════════════════════════════════════════════════════════════╗")
    print("║                FP16 GEMM BENCHMARK (Tensor Cores)                 ║")
    print("╠═══════════════════════════════════════════════════════════════════╣")
    print("║  Size     │ PyTorch Time  │ TFLOPS  │ Notes                       ║")
    print("╠═══════════════════════════════════════════════════════════════════╣")

    fp16_results = []
    for size in sizes:
        if size % 16 != 0:
            continue
            
        m, n, k = size, size, size

        # Create random matrices in FP16
        A = torch.randn(m, k, dtype=torch.float16, device=device)
        B = torch.randn(k, n, dtype=torch.float16, device=device)

        # Warmup
        for _ in range(warmup):
            C = torch.matmul(A, B)
        torch.cuda.synchronize()

        # Benchmark
        start = time.perf_counter()
        for _ in range(iterations):
            C = torch.matmul(A, B)
        torch.cuda.synchronize()
        elapsed = time.perf_counter() - start

        time_ms = elapsed * 1000.0 / iterations
        flops = 2.0 * m * n * k
        tflops = flops / (time_ms / 1000.0) / 1e12

        # Peak efficiency (RTX 4070 = 47 TFLOPS FP16 Tensor)
        peak_pct = tflops / 47.0 * 100.0
        
        print(f"║ {size:4}x{size:4} │  {time_ms:7.3f} ms   │ {tflops:5.2f} TF │ peak {peak_pct:5.1f}%                 ║")
        fp16_results.append((size, time_ms, tflops))

    print("╚═══════════════════════════════════════════════════════════════════╝")
    print()

    # =========================================================================
    # Summary for OktoBLAS comparison
    # =========================================================================
    print("╔═══════════════════════════════════════════════════════════════════╗")
    print("║                   PYTORCH REFERENCE VALUES                        ║")
    print("╠═══════════════════════════════════════════════════════════════════╣")
    print("║ Use these values to compare with OktoBLAS results:                ║")
    print("║                                                                   ║")
    print("║ FP32 GEMM (TF32 disabled):                                        ║")
    for size, time_ms, tflops in fp32_results:
        print(f"║   {size:4}x{size:4}: {tflops:5.2f} TFLOPS ({time_ms:.3f} ms)                         ║")
    print("║                                                                   ║")
    print("║ FP16 GEMM (Tensor Cores):                                         ║")
    for size, time_ms, tflops in fp16_results:
        print(f"║   {size:4}x{size:4}: {tflops:5.2f} TFLOPS ({time_ms:.3f} ms)                         ║")
    print("╚═══════════════════════════════════════════════════════════════════╝")
    print()
    print("✅ Benchmark complete!")
    print()
    print("📊 To compare with OktoBLAS, run:")
    print("   cargo run --release --features oktensor_cuda --example benchmark_real_vs_pytorch")

if __name__ == "__main__":
    main()

