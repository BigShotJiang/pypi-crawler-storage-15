FLAVOR_NAME = "openai"
