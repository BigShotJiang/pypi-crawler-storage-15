"""
Outlook.

Using Outlook API for sending emails.
"""

from .outlook import Outlook


__all__ = ["Outlook"]
