"""
Slack.

Provider for sending Slack Messages.
"""
from .slack import Slack

__all__ = ("Slack",)
