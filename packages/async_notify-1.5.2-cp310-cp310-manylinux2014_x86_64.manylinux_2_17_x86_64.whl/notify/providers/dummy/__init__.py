"""
dummy.

A dummy class for testing Notify infraestructure
"""
from .dummy import Dummy

__all__ = ("Dummy",)
