"""
Office 365 Email (outlook).

Using O365 library to send Email Messages through outlook.
"""

from .office365 import Office365

__all__ = ("Office365",)
