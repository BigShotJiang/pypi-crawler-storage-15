"""
OneSignal.

Using OneSignal API to sent push notifications
"""

from .onesignal import Onesignal


__all__ = ["Onesignal"]
