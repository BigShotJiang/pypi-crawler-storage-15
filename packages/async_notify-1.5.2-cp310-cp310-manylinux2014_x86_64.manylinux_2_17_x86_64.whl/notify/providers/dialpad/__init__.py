"""
dialpad.

Provider for send sms vía dialpad
"""
from .dialpad import Dialpad

__all__ = ("Dialpad",)
