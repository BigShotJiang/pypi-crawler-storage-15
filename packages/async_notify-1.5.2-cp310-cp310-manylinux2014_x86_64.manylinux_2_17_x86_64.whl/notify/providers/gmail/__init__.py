"""
Google Mail (gmail).

Using gmail library to send Email Messages
"""

from .gmail import Gmail

__all__ = ["Gmail"]
