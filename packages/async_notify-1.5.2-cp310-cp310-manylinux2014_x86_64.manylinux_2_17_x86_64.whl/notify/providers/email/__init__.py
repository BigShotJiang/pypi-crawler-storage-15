"""
email.

Provider for basic email messages
"""
from .email import Email

__all__ = ("Email",)
