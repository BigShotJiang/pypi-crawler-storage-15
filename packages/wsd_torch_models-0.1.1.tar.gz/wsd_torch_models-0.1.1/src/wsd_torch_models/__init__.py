import importlib.metadata


__version__ = importlib.metadata.version("wsd_torch_models")

# def main() -> None:
#    print("Hello from wsd-torch-models!")
