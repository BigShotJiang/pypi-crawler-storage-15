===================
atsphinx-htmx-boost
===================

.. note:: This is experimental extension.

Improvement user experience of your documents using htmx.

Usage
=====

Installation
------------

Install into your environment.

.. code:: console

   pip install atsphinx-htmx-boost

Configuration
-------------

Add it as extension into your ``conf.py``. There are not other settings.

.. code:: python

   extensions = [
       "atsphinx.htmx_boost",
   ]
