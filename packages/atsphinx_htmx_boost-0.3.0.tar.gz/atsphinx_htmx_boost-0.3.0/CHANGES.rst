v0.3.0
======

:Date: 2025-12-05 (Asia/Tokyo)

Features
--------

* Mark for parallel write

Others
------

* Add 3.13 and 3.14 to supported versions
* Drop 3.8 and 3.9 from supported versions
* Add type stub marker
* Update workspace

  - Use aqua instead of mise
  - Use ty instead of mypy
  - Enable Renovate
  - Split structure of deps

v0.2.2
======

:date: 2025-01-14 (JST)

Bug fixes
---------

- Change rule to inject attributes.

Miscellaneous
-------------

- Use latest workspace environment.

  * uv instead of Rye
  * lefthook instead of pre-commit
  * go-task instead of makefiles
