==========
Changelogs
==========

.. include:: ../CHANGES.rst

Old changelogs
==============

.. toctree::
   :maxdepth: 1
   :glob:
   :reversed:

   changelogs/*
