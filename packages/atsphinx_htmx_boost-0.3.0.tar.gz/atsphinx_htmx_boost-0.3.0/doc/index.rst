====
Home
====

.. note:: This is experimental extension.

``atsphinx-htmx-boost`` is Sphinx-extension that will improve user-experience of documents by `HTMX <https://htmx.org>`_.

Contents
========

.. toctree::
   :maxdepth: 2
   :titlesonly:

   usage
   changelogs
