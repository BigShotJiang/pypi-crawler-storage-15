Release atsphinx-htmx-boost v0.3.0

- Changelog is https://github.com/atsphinx/htmx-boost/blob/v0.3.0/CHANGES.rst
- Changes are https://github.com/atsphinx/htmx-boost/compare/v0.2.2...v0.3.0/
