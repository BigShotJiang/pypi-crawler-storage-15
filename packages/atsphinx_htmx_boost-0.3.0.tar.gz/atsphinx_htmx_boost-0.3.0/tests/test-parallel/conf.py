extensions = [
    "atsphinx.htmx_boost",
]
