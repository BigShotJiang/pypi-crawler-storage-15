Test doc for atsphinx-htmx-boost
================================

.. toctree::
   :glob:

   *
