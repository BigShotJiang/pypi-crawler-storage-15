from .suggester import QuerySuggester

__all__ = ["QuerySuggester"]
