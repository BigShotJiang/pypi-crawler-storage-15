def load_logo():
    return open("suggestify/logo.txt").read()
