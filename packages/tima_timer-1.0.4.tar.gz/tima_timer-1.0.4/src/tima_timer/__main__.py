"""Allow running the package with python -m tima_timer"""
from tima_timer.app import main

if __name__ == "__main__":
    main()
