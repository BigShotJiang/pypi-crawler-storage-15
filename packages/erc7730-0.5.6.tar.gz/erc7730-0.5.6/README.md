python-erc7730
==============

**This library provides tooling for the ERC-7730 standard.**

See documentation at <https://ledgerhq.github.io/python-erc7730>.
