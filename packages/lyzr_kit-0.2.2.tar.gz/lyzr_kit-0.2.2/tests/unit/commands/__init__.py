"""CLI command unit tests."""
