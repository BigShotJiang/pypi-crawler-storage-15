"""Tests for lyzr-kit."""
