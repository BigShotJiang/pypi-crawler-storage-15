# OddEven Yahwin

A simple Python library to check if a number is odd or even.

This package contains two functions:

- `is_even(number)` → Returns `True` if the number is even.
- `is_odd(number)` → Returns `True` if the number is odd.

---

## 📦 Installation

Install using pip:

```bash
pip install oddeven-yahwin
