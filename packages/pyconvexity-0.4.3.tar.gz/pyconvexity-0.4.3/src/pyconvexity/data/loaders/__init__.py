"""
Data loaders and caching utilities for PyConvexity.
"""
