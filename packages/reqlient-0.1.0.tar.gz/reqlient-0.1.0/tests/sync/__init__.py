"""Tests for synchronous REST client modules."""
