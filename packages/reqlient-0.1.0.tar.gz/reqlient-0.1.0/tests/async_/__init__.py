"""Tests for asynchronous REST client modules."""
