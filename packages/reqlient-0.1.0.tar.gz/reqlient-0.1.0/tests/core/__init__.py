"""Tests for core shared modules."""
