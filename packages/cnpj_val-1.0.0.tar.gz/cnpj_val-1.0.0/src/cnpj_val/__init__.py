from .cnpj_val import cnpj_val
from .cnpj_validator import CnpjValidator

__all__ = ["CnpjValidator", "cnpj_val"]

__version__ = "1.0.0"
