name = "openemr"
__version__ = "0.4.3"
from openemr.client import Client
from openemr.patient import Patient