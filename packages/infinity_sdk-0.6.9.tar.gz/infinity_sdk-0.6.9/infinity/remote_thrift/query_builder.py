# Copyright(C) 2023 InfiniFlow, Inc. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

from abc import ABC
from typing import List, Optional, Any

import numpy as np
import pandas as pd
import polars as pl
import pyarrow as pa
from pyarrow import Table
from sqlglot import condition, maybe_parse

from infinity.common import VEC, SparseVector, InfinityException, SortType, FDE
from infinity.errors import ErrorCode
from infinity.remote_thrift.infinity_thrift_rpc.ttypes import *
from infinity.remote_thrift.types import (
    logic_type_to_dtype,
    make_match_tensor_expr,
    make_match_sparse_expr,
)
from infinity.remote_thrift.utils import traverse_conditions, parse_expr, get_search_optional_filter_from_opt_params

"""FIXME: How to disable validation of only the search field?"""


class Query(ABC):
    def __init__(
            self,
            columns: Optional[List[ParsedExpr]],
            highlight: Optional[List[ParsedExpr]],
            search: Optional[SearchExpr],
            filter: Optional[ParsedExpr],
            groupby: Optional[List[ParsedExpr]],
            having: Optional[ParsedExpr],
            limit: Optional[ParsedExpr],
            offset: Optional[ParsedExpr],
            sort: Optional[List[OrderByExpr]],
            total_hits_count: Optional[bool]
    ):
        self.columns = columns
        self.highlight = highlight
        self.search = search
        self.filter = filter
        self.groupby = groupby
        self.having = having
        self.limit = limit
        self.offset = offset
        self.sort = sort
        self.total_hits_count = total_hits_count


class ExplainQuery(Query):
    def __init__(
            self,
            columns: Optional[List[ParsedExpr]],
            highlight: Optional[List[ParsedExpr]],
            search: Optional[SearchExpr],
            filter: Optional[ParsedExpr],
            groupby: Optional[List[ParsedExpr]],
            having: Optional[ParsedExpr],
            limit: Optional[ParsedExpr],
            offset: Optional[ParsedExpr],
            sort: Optional[List[OrderByExpr]],
            explain_type: Optional[ExplainType],
    ):
        super().__init__(columns, highlight, search, filter, groupby, having, limit, offset, sort, False)
        self.explain_type = explain_type


class InfinityThriftQueryBuilder(ABC):
    def __init__(self, table):
        self._table = table
        self._columns = None
        self._highlight = None
        self._search = None
        self._filter = None
        self._groupby = None
        self._having = None
        self._limit = None
        self._offset = None
        self._sort = None
        self._total_hits_count = None

    def reset(self):
        self._columns = None
        self._highlight = None
        self._search = None
        self._filter = None
        self._groupby = None
        self._having = None
        self._limit = None
        self._offset = None
        self._sort = None
        self._total_hits_count = None

    def match_dense(
            self,
            vector_column_name: str,
            embedding_data: VEC,
            embedding_data_type: str,
            distance_type: str,
            topn: int,
            knn_params: {} = None,
    ) -> InfinityThriftQueryBuilder:
        if self._search is None:
            self._search = SearchExpr()
            self._search.match_exprs = list()

        column_expr = ColumnExpr(column_name=[vector_column_name], star=False)

        if not isinstance(topn, int):
            raise InfinityException(
                ErrorCode.INVALID_TOPK_TYPE, f"Invalid topn, type should be embedded, but get {type(topn)}"
            )

        # Check if this is an FDE object
        if isinstance(embedding_data, FDE):
            # Handle FDE function call
            return self._handle_fde_match_dense(
                column_expr, embedding_data, embedding_data_type, distance_type, topn, knn_params
            )

        # type casting for regular embedding data
        if isinstance(embedding_data, list):
            embedding_data = embedding_data
        elif isinstance(embedding_data, tuple):
            embedding_data = embedding_data
        elif isinstance(embedding_data, np.ndarray):
            embedding_data = embedding_data.tolist()
        else:
            raise InfinityException(
                ErrorCode.INVALID_DATA_TYPE,
                f"Invalid embedding data, type should be embedded, but get {type(embedding_data)}",
            )

        if embedding_data_type == "bit":
            if len(embedding_data) % 8 != 0:
                raise InfinityException(
                    ErrorCode.INVALID_EMBEDDING_DATA_TYPE,
                    f"Embeddings with data bit must have dimension of times of 8!"
                )
            else:
                new_embedding_data = []
                dimesions = int(len(embedding_data) / 8)
                for i in range(dimesions):
                    bitunit = 0
                    for bit_idx in range(8):
                        if embedding_data[i * 8 + bit_idx] > 0:
                            bitunit |= (1 << bit_idx)
                    new_embedding_data.append(bitunit)
                embedding_data = new_embedding_data

        if embedding_data_type in ["uint8", "int8", "int16", "int32", "int", "int64"]:
            embedding_data = [int(x) for x in embedding_data]

        if embedding_data_type in ["float", "float32", "double", "float64", "float16", "bfloat16"]:
            embedding_data = [float(x) for x in embedding_data]

        data = EmbeddingData()
        elem_type = ElementType.ElementFloat32
        if embedding_data_type == "bit":
            elem_type = ElementType.ElementBit
            data.u8_array_value = embedding_data
        elif embedding_data_type == "uint8":
            elem_type = ElementType.ElementUInt8
            data.u8_array_value = embedding_data
        elif embedding_data_type == "int8":
            elem_type = ElementType.ElementInt8
            data.i8_array_value = embedding_data
        elif embedding_data_type == "int16":
            elem_type = ElementType.ElementInt16
            data.i16_array_value = embedding_data
        elif embedding_data_type in ["int", "int32"]:
            elem_type = ElementType.ElementInt32
            data.i32_array_value = embedding_data
        elif embedding_data_type == "int64":
            elem_type = ElementType.ElementInt64
            data.i64_array_value = embedding_data
        elif embedding_data_type in ["float", "float32"]:
            elem_type = ElementType.ElementFloat32
            data.f32_array_value = embedding_data
        elif embedding_data_type in ["double", "float64"]:
            elem_type = ElementType.ElementFloat64
            data.f64_array_value = embedding_data
        elif embedding_data_type == "float16":
            elem_type = ElementType.ElementFloat16
            data.f16_array_value = embedding_data
        elif embedding_data_type == "bfloat16":
            elem_type = ElementType.ElementBFloat16
            data.bf16_array_value = embedding_data
        else:
            raise InfinityException(ErrorCode.INVALID_EMBEDDING_DATA_TYPE,
                                    f"Invalid embedding {embedding_data[0]} type")

        dist_type = KnnDistanceType.L2
        if distance_type == "l2":
            dist_type = KnnDistanceType.L2
        elif distance_type == "cosine" or distance_type == "cos":
            dist_type = KnnDistanceType.Cosine
        elif distance_type == "ip":
            dist_type = KnnDistanceType.InnerProduct
        elif distance_type == "hamming":
            dist_type = KnnDistanceType.Hamming
        else:
            raise InfinityException(ErrorCode.INVALID_KNN_DISTANCE_TYPE, f"Invalid distance type {distance_type}")

        knn_opt_params = []
        optional_filter = None
        if knn_params is not None:
            optional_filter = get_search_optional_filter_from_opt_params(knn_params)
            for k, v in knn_params.items():
                key = k.lower()
                value = v.lower()
                knn_opt_params.append(InitParameter(key, value))

        knn_expr = KnnExpr(
            column_expr=column_expr,
            embedding_data=data,
            embedding_data_type=elem_type,
            distance_type=dist_type,
            topn=topn,
            opt_params=knn_opt_params,
            filter_expr=optional_filter,
        )
        generic_match_expr = GenericMatchExpr(match_vector_expr=knn_expr)
        self._search.match_exprs.append(generic_match_expr)
        return self

    def match_sparse(
            self,
            vector_column_name: str,
            sparse_data: SparseVector | dict,
            metric_type: str,
            topn: int,
            opt_params: Optional[dict] = None,
    ) -> InfinityThriftQueryBuilder:
        if self._search is None:
            self._search = SearchExpr()
            self._search.match_exprs = list()

        optional_filter = None if opt_params is None else get_search_optional_filter_from_opt_params(opt_params)
        match_sparse_expr = make_match_sparse_expr(
            vector_column_name, sparse_data, metric_type, topn, opt_params, optional_filter
        )
        generic_match_expr = GenericMatchExpr(match_sparse_expr=match_sparse_expr)
        self._search.match_exprs.append(generic_match_expr)
        return self

    def match_text(
            self, fields: str, matching_text: str, topn: int, extra_options: Optional[dict]
    ) -> InfinityThriftQueryBuilder:
        if self._search is None:
            self._search = SearchExpr()
            self._search.match_exprs = list()
        match_expr = MatchExpr()
        match_expr.fields = fields
        match_expr.matching_text = matching_text
        options_text = f"topn={topn}"
        if extra_options is not None:
            match_expr.filter_expr = get_search_optional_filter_from_opt_params(extra_options)
            for k, v in extra_options.items():
                options_text += f";{k}={v}"
        match_expr.options_text = options_text
        generic_match_expr = GenericMatchExpr(match_text_expr=match_expr)
        self._search.match_exprs.append(generic_match_expr)
        return self

    def match_tensor(
            self,
            column_name: str,
            query_data: VEC,
            query_data_type: str,
            topn: int,
            extra_option: Optional[dict] = None,
    ) -> InfinityThriftQueryBuilder:
        if self._search is None:
            self._search = SearchExpr()
            self._search.match_exprs = list()
        option_str = f"topn={topn}"
        optional_filter = None
        if extra_option is not None:
            optional_filter = get_search_optional_filter_from_opt_params(extra_option)
            for k, v in extra_option.items():
                option_str += f";{k}={v}"
        match_tensor_expr = make_match_tensor_expr(
            vector_column_name=column_name,
            embedding_data=query_data,
            embedding_data_type=query_data_type,
            method_type="maxsim",
            extra_option=option_str,
            filter_expr=optional_filter,
        )
        generic_match_expr = GenericMatchExpr(match_tensor_expr=match_tensor_expr)
        self._search.match_exprs.append(generic_match_expr)
        return self

    def fusion(self, method: str, topn: int, fusion_params: Optional[dict]) -> InfinityThriftQueryBuilder:
        if self._search is None:
            self._search = SearchExpr()
        if self._search.fusion_exprs is None:
            self._search.fusion_exprs = list()
        fusion_expr = FusionExpr()
        fusion_expr.method = method
        final_option_text = f"topn={topn}"
        if method in ["rrf", "weighted_sum"]:
            if isinstance(fusion_params, dict):
                for k, v in fusion_params.items():
                    if k == "topn":
                        raise InfinityException(ErrorCode.INVALID_EXPRESSION, "topn is not allowed in fusion params")
                    final_option_text += f";{k}={v}"
        elif method in ["match_tensor"]:
            fusion_expr.optional_match_tensor_expr = make_match_tensor_expr(
                vector_column_name=fusion_params["field"], embedding_data=fusion_params["query_tensor"],
                embedding_data_type=fusion_params["element_type"], method_type="maxsim", extra_option=None)
        else:
            raise InfinityException(ErrorCode.INVALID_EXPRESSION, "Invalid fusion method")
        fusion_expr.options_text = final_option_text
        self._search.fusion_exprs.append(fusion_expr)
        return self

    def filter(self, where: Optional[str]) -> InfinityThriftQueryBuilder:
        where_expr = traverse_conditions(condition(where))
        self._filter = where_expr
        return self

    def limit(self, limit: Optional[int]) -> InfinityThriftQueryBuilder:
        constant_exp = ConstantExpr(literal_type=LiteralType.Int64, i64_value=limit)
        expr_type = ParsedExprType(constant_expr=constant_exp)
        limit_expr = ParsedExpr(type=expr_type)
        self._limit = limit_expr
        return self

    def offset(self, offset: Optional[int]) -> InfinityThriftQueryBuilder:
        constant_exp = ConstantExpr(literal_type=LiteralType.Int64, i64_value=offset)
        expr_type = ParsedExprType(constant_expr=constant_exp)
        offset_expr = ParsedExpr(type=expr_type)
        self._offset = offset_expr
        return self
    
    def group_by(self, columns: List[str] | str) -> InfinityThriftQueryBuilder:
        group_by_list: List[ParsedExpr] = []
        if isinstance(columns, list):
            for column in columns:
                column = column.lower()
                group_by_list.append(parse_expr(maybe_parse(column)))
        else:
            group_by_list.append(parse_expr(maybe_parse(columns)))
        self._groupby = group_by_list
        return self
    
    def having(self, having: Optional[str]) -> InfinityThriftQueryBuilder:
        having_expr = traverse_conditions(condition(having))
        self._having = having_expr
        return self

    def output(self, columns: Optional[list]) -> InfinityThriftQueryBuilder:
        self._columns = columns
        select_list: List[ParsedExpr] = []
        for column in columns:
            if isinstance(column, str):
                column = column.lower()

            match column:
                case "*":
                    column_expr = ColumnExpr(star=True, column_name=[])
                    expr_type = ParsedExprType(column_expr=column_expr)
                    parsed_expr = ParsedExpr(type=expr_type)
                    select_list.append(parsed_expr)
                case "_row_id":
                    func_expr = FunctionExpr(function_name="row_id", arguments=[])
                    expr_type = ParsedExprType(function_expr=func_expr)
                    parsed_expr = ParsedExpr(type=expr_type)
                    select_list.append(parsed_expr)
                case "_create_timestamp":
                    func_expr = FunctionExpr(function_name="create_timestamp", arguments=[])
                    expr_type = ParsedExprType(function_expr=func_expr)
                    parsed_expr = ParsedExpr(type=expr_type)
                    select_list.append(parsed_expr)
                case "_delete_timestamp":
                    func_expr = FunctionExpr(function_name="delete_timestamp", arguments=[])
                    expr_type = ParsedExprType(function_expr=func_expr)
                    parsed_expr = ParsedExpr(type=expr_type)
                    select_list.append(parsed_expr)
                case "_score":
                    func_expr = FunctionExpr(function_name="score", arguments=[])
                    expr_type = ParsedExprType(function_expr=func_expr)
                    parsed_expr = ParsedExpr(type=expr_type)
                    select_list.append(parsed_expr)
                case "_similarity":
                    func_expr = FunctionExpr(function_name="similarity", arguments=[])
                    expr_type = ParsedExprType(function_expr=func_expr)
                    parsed_expr = ParsedExpr(type=expr_type)
                    select_list.append(parsed_expr)
                case "_distance":
                    func_expr = FunctionExpr(function_name="distance", arguments=[])
                    expr_type = ParsedExprType(function_expr=func_expr)
                    parsed_expr = ParsedExpr(type=expr_type)
                    select_list.append(parsed_expr)
                case "_score_factors":
                    func_expr = FunctionExpr(function_name="score_factors", arguments=[])
                    expr_type = ParsedExprType(function_expr=func_expr)
                    parsed_expr = ParsedExpr(type=expr_type)
                    select_list.append(parsed_expr)
                case "_similarity_factors":
                    func_expr = FunctionExpr(function_name="similarity_factors", arguments=[])
                    expr_type = ParsedExprType(function_expr=func_expr)
                    parsed_expr = ParsedExpr(type=expr_type)
                    select_list.append(parsed_expr)
                case "_distance_factors":
                    func_expr = FunctionExpr(function_name="distance_factors", arguments=[])
                    expr_type = ParsedExprType(function_expr=func_expr)
                    parsed_expr = ParsedExpr(type=expr_type)
                    select_list.append(parsed_expr)
                case _:
                    unknown_expr = maybe_parse(column)
                    select_list.append(parse_expr(unknown_expr))

        self._columns = select_list
        return self

    def highlight(self, columns: Optional[list]) -> InfinityThriftQueryBuilder:
        highlight_list: List[ParsedExpr] = []
        for column in columns:
            if isinstance(column, str):
                column = column.lower()
            highlight_list.append(parse_expr(maybe_parse(column)))

        self._highlight = highlight_list
        return self

    def option(self, option_kv: {}):
        if 'total_hits_count' in option_kv:
            if isinstance(option_kv['total_hits_count'], bool):
                self._total_hits_count = option_kv['total_hits_count']
        return self

    def sort(self, order_by_expr_list: Optional[List[list[str, SortType]]]) -> InfinityThriftQueryBuilder:
        sort_list: List[OrderByExpr] = []
        for order_by_expr in order_by_expr_list:
            order_by_expr_str = str

            if isinstance(order_by_expr[0], str):
                order_by_expr_str = order_by_expr[0].lower()

            match order_by_expr_str:
                case "*":
                    column_expr = ColumnExpr(star=True, column_name=[])
                    expr_type = ParsedExprType(column_expr=column_expr)
                    parsed_expr = ParsedExpr(type=expr_type)
                    order_by_flag: bool = order_by_expr[1] == SortType.Asc
                    order_by_expr = OrderByExpr(expr=parsed_expr, asc=order_by_flag)
                    sort_list.append(order_by_expr)
                case "_row_id":
                    func_expr = FunctionExpr(function_name="row_id", arguments=[])
                    expr_type = ParsedExprType(function_expr=func_expr)
                    parsed_expr = ParsedExpr(type=expr_type)
                    order_by_flag: bool = order_by_expr[1] == SortType.Asc
                    order_by_expr = OrderByExpr(expr=parsed_expr, asc=order_by_flag)
                    sort_list.append(order_by_expr)
                case "_create_timestamp":
                    func_expr = FunctionExpr(function_name="create_timestamp", arguments=[])
                    expr_type = ParsedExprType(function_expr=func_expr)
                    parsed_expr = ParsedExpr(type=expr_type)
                    order_by_flag: bool = order_by_expr[1] == SortType.Asc
                    order_by_expr = OrderByExpr(expr=parsed_expr, asc=order_by_flag)
                    sort_list.append(order_by_expr)
                case "_delete_timestamp":
                    func_expr = FunctionExpr(function_name="delete_timestamp", arguments=[])
                    expr_type = ParsedExprType(function_expr=func_expr)
                    parsed_expr = ParsedExpr(type=expr_type)
                    order_by_flag: bool = order_by_expr[1] == SortType.Asc
                    order_by_expr = OrderByExpr(expr=parsed_expr, asc=order_by_flag)
                    sort_list.append(order_by_expr)
                case "_score":
                    func_expr = FunctionExpr(function_name="score", arguments=[])
                    expr_type = ParsedExprType(function_expr=func_expr)
                    parsed_expr = ParsedExpr(type=expr_type)
                    order_by_flag: bool = order_by_expr[1] == SortType.Asc
                    order_by_expr = OrderByExpr(expr=parsed_expr, asc=order_by_flag)
                    sort_list.append(order_by_expr)
                case "_similarity":
                    func_expr = FunctionExpr(function_name="similarity", arguments=[])
                    expr_type = ParsedExprType(function_expr=func_expr)
                    parsed_expr = ParsedExpr(type=expr_type)
                    order_by_flag: bool = order_by_expr[1] == SortType.Asc
                    order_by_expr = OrderByExpr(expr=parsed_expr, asc=order_by_flag)
                    sort_list.append(order_by_expr)
                case "_distance":
                    func_expr = FunctionExpr(function_name="distance", arguments=[])
                    expr_type = ParsedExprType(function_expr=func_expr)
                    parsed_expr = ParsedExpr(type=expr_type)
                    order_by_flag: bool = order_by_expr[1] == SortType.Asc
                    order_by_expr = OrderByExpr(expr=parsed_expr, asc=order_by_flag)
                    sort_list.append(order_by_expr)
                case "_score_factors":
                    func_expr = FunctionExpr(function_name="score_factors", arguments=[])
                    expr_type = ParsedExprType(function_expr=func_expr)
                    parsed_expr = ParsedExpr(type=expr_type)
                    order_by_flag: bool = order_by_expr[1] == SortType.Asc
                    order_by_expr = OrderByExpr(expr=parsed_expr, asc=order_by_flag)
                    sort_list.append(order_by_expr)
                case "_similarity_factors":
                    func_expr = FunctionExpr(function_name="similarity_factors", arguments=[])
                    expr_type = ParsedExprType(function_expr=func_expr)
                    parsed_expr = ParsedExpr(type=expr_type)
                    order_by_flag: bool = order_by_expr[1] == SortType.Asc
                    order_by_expr = OrderByExpr(expr=parsed_expr, asc=order_by_flag)
                    sort_list.append(order_by_expr)
                case "_distance_factors":
                    func_expr = FunctionExpr(function_name="distance_factors", arguments=[])
                    expr_type = ParsedExprType(function_expr=func_expr)
                    parsed_expr = ParsedExpr(type=expr_type)
                    order_by_flag: bool = order_by_expr[1] == SortType.Asc
                    order_by_expr = OrderByExpr(expr=parsed_expr, asc=order_by_flag)
                    sort_list.append(order_by_expr)
                case _:
                    parsed_expr = parse_expr(maybe_parse(order_by_expr_str))
                    order_by_flag: bool = order_by_expr[1] == SortType.Asc
                    sort_list.append(OrderByExpr(expr=parsed_expr, asc=order_by_flag))

        self._sort = sort_list
        return self

    def to_string(self) -> str:
        query = Query(
            columns=self._columns,
            highlight=self._highlight,
            search=self._search,
            filter=self._filter,
            groupby=self._groupby,
            limit=self._limit,
            offset=self._offset,
            sort=self._sort,
            total_hits_count=self._total_hits_count,
        )
        return self._table._to_string(query)

    def to_result(self) -> tuple[dict[str, list[Any]], dict[str, Any], {}]:
        query = Query(
            columns=self._columns,
            highlight=self._highlight,
            search=self._search,
            filter=self._filter,
            groupby=self._groupby,
            having=self._having,
            limit=self._limit,
            offset=self._offset,
            sort=self._sort,
            total_hits_count=self._total_hits_count,
        )
        self.reset()
        return self._table._execute_query(query)

    def to_df(self) -> (pd.DataFrame, {}):
        df_dict = {}
        data_dict, data_type_dict, extra_result = self.to_result()
        for k, v in data_dict.items():
            data_series = pd.Series(v, dtype=logic_type_to_dtype(data_type_dict[k]))
            df_dict[k] = data_series
        return pd.DataFrame(df_dict), extra_result

    def to_pl(self) -> (pl.DataFrame, {}):
        dataframe, extra_result = self.to_df()
        return pl.from_pandas(dataframe), extra_result

    def to_arrow(self) -> (Table, {}):
        dataframe, extra_result = self.to_df()
        return pa.Table.from_pandas(dataframe), extra_result

    def explain(self, explain_type=ExplainType.Physical) -> Any:
        query = ExplainQuery(
            columns=self._columns,
            highlight=self._highlight,
            search=self._search,
            filter=self._filter,
            groupby=self._groupby,
            having=self._having,
            limit=self._limit,
            offset=self._offset,
            sort=self._sort,
            explain_type=explain_type,
        )
        return self._table._explain_query(query)

    def _handle_fde_match_dense(
            self,
            column_expr: ColumnExpr,
            fde_data: FDE,
            embedding_data_type: str,
            distance_type: str,
            topn: int,
            knn_params: {} = None,
    ) -> InfinityThriftQueryBuilder:
        """Handle FDE function call in match_dense"""

        # Create FDE function expression
        fde_function = FunctionExpr()
        fde_function.function_name = "FDE"
        fde_function.arguments = []

        # Create tensor data constant expression
        tensor_constant = ConstantExpr()
        tensor_constant.literal_type = LiteralType.DoubleTensor
        tensor_constant.f64_tensor_value = fde_data.tensor_data

        # Create target dimension constant expression
        target_dim_constant = ConstantExpr()
        target_dim_constant.literal_type = LiteralType.Int64
        target_dim_constant.i64_value = fde_data.target_dimension

        # Add arguments to function
        tensor_parsed_expr = ParsedExpr()
        tensor_parsed_expr.type = ParsedExprType(constant_expr=tensor_constant)
        fde_function.arguments.append(tensor_parsed_expr)

        target_dim_parsed_expr = ParsedExpr()
        target_dim_parsed_expr.type = ParsedExprType(constant_expr=target_dim_constant)
        fde_function.arguments.append(target_dim_parsed_expr)

        # Convert distance type
        dist_type = KnnDistanceType.L2
        if distance_type == "l2":
            dist_type = KnnDistanceType.L2
        elif distance_type == "cosine" or distance_type == "cos":
            dist_type = KnnDistanceType.Cosine
        elif distance_type == "ip":
            dist_type = KnnDistanceType.InnerProduct
        elif distance_type == "hamming":
            dist_type = KnnDistanceType.Hamming
        else:
            raise InfinityException(ErrorCode.INVALID_KNN_DISTANCE_TYPE, f"Invalid distance type {distance_type}")

        # Convert embedding data type
        elem_type = ElementType.ElementFloat32
        if embedding_data_type in ["float", "float32"]:
            elem_type = ElementType.ElementFloat32
        elif embedding_data_type in ["double", "float64"]:
            elem_type = ElementType.ElementFloat64
        elif embedding_data_type == "float16":
            elem_type = ElementType.ElementFloat16
        elif embedding_data_type == "bfloat16":
            elem_type = ElementType.ElementBFloat16
        else:
            raise InfinityException(ErrorCode.INVALID_EMBEDDING_DATA_TYPE,
                                    f"Invalid embedding data type {embedding_data_type}")

        # Handle optional parameters
        knn_opt_params = []
        optional_filter = None
        if knn_params is not None:
            optional_filter = get_search_optional_filter_from_opt_params(knn_params)
            for k, v in knn_params.items():
                key = k.lower()
                value = v.lower()
                knn_opt_params.append(InitParameter(key, value))

        # Create KnnExpr with FDE function as query_embedding_expr
        knn_expr = KnnExpr(
            column_expr=column_expr,
            embedding_data_type=elem_type,
            distance_type=dist_type,
            topn=topn,
            opt_params=knn_opt_params,
            filter_expr=optional_filter,
            query_embedding_expr=fde_function,  # This is the key difference
        )
        # Don't set embedding_data at all for FDE queries

        generic_match_expr = GenericMatchExpr(match_vector_expr=knn_expr)
        self._search.match_exprs.append(generic_match_expr)
        return self
