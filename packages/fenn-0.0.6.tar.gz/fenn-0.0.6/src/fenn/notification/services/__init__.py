from fenn.notification.services.discord import Discord
from fenn.notification.services.telegram import Telegram