# Copyright The OpenTelemetry Authors
# SPDX-License-Identifier: Apache-2.0

__version__ = "0.2.3"
