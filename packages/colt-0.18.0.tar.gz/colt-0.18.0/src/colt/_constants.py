from typing import Final

DEFAULT_TYPEKEY: Final = "@type"
DEFAULT_ARGSKEY: Final = "*"
DEFAULT_SCHEMAKEY: Final = "$schema"
