NON_CONTIGUOUS_STATES = [
    "02",  # Alaska
    "15",  # Hawaii
    "72",  # Puerto Rico
]
