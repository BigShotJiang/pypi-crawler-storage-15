"""Core processing logic"""
