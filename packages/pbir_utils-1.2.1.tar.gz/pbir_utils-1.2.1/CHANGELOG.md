### Changed
- Improved CLI feedback: all commands now display helpful messages when no changes are needed (e.g., "All folders are already using standard naming.").
- Improved dry-run messages: all dry-run messages now use future tense (e.g., "Would rename 7 folders" instead of "Renamed 7 folders") to clearly indicate that no changes were actually made.

