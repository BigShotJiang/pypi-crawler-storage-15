"""Crypto ecosystems taxonomy package."""
