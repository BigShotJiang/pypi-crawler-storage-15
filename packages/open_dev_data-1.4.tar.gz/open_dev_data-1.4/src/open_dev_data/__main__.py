"""Allow running as python -m python."""

from .commands import main

if __name__ == "__main__":
    main()
