"""Crypto Ecosystems Taxonomy - Python Implementation"""

__version__ = "1.0"
