[![Actions Status](https://github.com/qtoggle/qtoggleserver/workflows/Main/badge.svg)](https://github.com/qtoggle/qtoggleserver/actions)
[![Join us on Discord](https://img.shields.io/discord/742719160865521714)](https://discord.gg/wwYn3jJNPM)
[![Join us on Facebook](https://img.shields.io/badge/chat-facebook-blue)](http://facebook.com/qtoggle)

---


**qToggleServer** is a fully fledged [qToggle](https://github.com/qtoggle/docs) implementation written in Python.

Check out the [Getting Started](https://github.com/qtoggle/qtoggleserver/wiki/Getting-Started) wiki page to install and get started with qToggleServer.
