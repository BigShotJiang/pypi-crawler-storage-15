class DiscoverException(Exception):
    pass


class DuplicateDevice(DiscoverException):
    pass
