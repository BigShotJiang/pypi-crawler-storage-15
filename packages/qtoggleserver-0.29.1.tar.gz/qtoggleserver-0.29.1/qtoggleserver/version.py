VERSION = "0.29.1"
VENDOR = "qtoggle/qtoggleserver"
