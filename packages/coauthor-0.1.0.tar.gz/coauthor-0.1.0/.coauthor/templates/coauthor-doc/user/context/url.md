# Context

Content from URL: {{task['frontmatter-item']['url'] }}
Content:

{{task['frontmatter-item']['url'] | get_url }}
