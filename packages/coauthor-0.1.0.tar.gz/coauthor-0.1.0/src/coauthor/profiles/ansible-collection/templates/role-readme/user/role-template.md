<!-- template for Ansible role README.md-->

{{ 'https://gitlab.com/c2platform/c2/ansible-inventory/-/raw/master/doc/role-template.md' | get_url }}
