# Installation and usage

```{include} ../../README.md
:start-after: <!-- start installing -->
:end-before: <!-- end installing -->
```

```{include} ../../README.md
:start-after: <!-- start cli-usage -->
:end-before: <!-- end cli-usage -->
```
