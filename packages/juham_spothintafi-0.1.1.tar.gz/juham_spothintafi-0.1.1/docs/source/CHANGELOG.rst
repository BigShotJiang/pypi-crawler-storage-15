Changelog
=========

[0.1.9] - April 17, 2025
------------------------

* New unit tests written, for better coverage
* Updated pyproject.toml to comply with the new SPDX expression for packaging standards



[0.1.8] - March 08, 2025
------------------------

- Docs refactored


[0.1.7] - February 21, 2025
---------------------------

- **Changelog:**

* Minor bug fixes to plugin class ``spothintafi_plugin.py``.

* ``pyproject.toml`` updated.

* Status updated to Alpha
 

[0.1.6] - February 17, 2024
---------------------------

- **Changelog:**

* Plugin class ``spothintafi_plugin.py`` added, for automated install.

  

[0.1.5] - December 26, 2024
---------------------------

- **Changelog:**

* CHANGELOG.rst and README.rst added

