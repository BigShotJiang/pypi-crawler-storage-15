"""Pytest-pyvista package."""

from __future__ import annotations

__version__ = "0.3.2"

from .pytest_pyvista import VerifyImageCache  # noqa: F401
