"""Package constants for torch-batteries."""

# Package metadata
_PACKAGE_NAME = __name__.split(".")[0]
