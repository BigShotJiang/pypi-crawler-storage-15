"""Command-line interface module for Flask applications."""

from zecmf.cli.commands import register_commands

__all__ = ["register_commands"]
