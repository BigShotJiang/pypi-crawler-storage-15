"""Recipe registry placeholder for Fluxloop MCP."""

__all__ = []

