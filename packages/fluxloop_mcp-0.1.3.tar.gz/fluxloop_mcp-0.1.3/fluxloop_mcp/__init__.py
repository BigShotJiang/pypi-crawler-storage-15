"""
Fluxloop MCP package.

This module exposes package metadata used by setuptools entry points.
"""

__all__ = ["__version__"]

__version__ = "0.1.1"

