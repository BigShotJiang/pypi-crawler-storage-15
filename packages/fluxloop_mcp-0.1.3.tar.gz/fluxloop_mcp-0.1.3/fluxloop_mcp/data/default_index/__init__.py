"""Bundled default index seed for FluxLoop MCP."""


