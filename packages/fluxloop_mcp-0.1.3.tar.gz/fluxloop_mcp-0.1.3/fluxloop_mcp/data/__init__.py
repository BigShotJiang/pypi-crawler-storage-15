"""Package data namespace for FluxLoop MCP."""


