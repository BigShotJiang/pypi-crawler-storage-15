"""MCP server for querying SPARQL endpoints."""

__version__ = "0.1.0"
