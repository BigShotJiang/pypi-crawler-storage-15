Files pulled from https://github.com/moses-smt/mosesdecoder/tree/master/scripts/share on 10th July 2020.
