
FOO = {'bar': ['baz', 1]}
foo = 'bar'