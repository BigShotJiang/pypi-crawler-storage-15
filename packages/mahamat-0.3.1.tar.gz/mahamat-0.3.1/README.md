# mahamat


Un module Python proposant une barre de progression moderne.

## Exemple

```python
from mahamat import mahamat
import time

for x in progress(range(100)):
    time.sleep(0.05)




