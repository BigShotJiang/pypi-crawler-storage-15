"""CLI package for asynctasq."""

from .main import main

__all__ = ["main"]
