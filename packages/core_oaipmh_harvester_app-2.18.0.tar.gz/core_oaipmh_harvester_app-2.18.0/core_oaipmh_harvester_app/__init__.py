""" Run the Init app
"""

default_app_config = "core_oaipmh_harvester_app.apps.HarvesterAppConfig"
