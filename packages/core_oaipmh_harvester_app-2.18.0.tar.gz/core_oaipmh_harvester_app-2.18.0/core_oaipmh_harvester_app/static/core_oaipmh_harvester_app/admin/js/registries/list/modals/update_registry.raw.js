var updateRegistryGetUrl = "{% url 'core-admin:core_oaipmh_harvester_app_update_registry' %}";
var checkUpdateRegistryGetUrl = "{% url 'core-admin:core_oaipmh_harvester_app_check_update_registry' %}";