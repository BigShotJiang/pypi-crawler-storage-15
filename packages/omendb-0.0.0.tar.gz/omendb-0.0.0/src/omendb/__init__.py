"""OmenDB - Fast embedded vector database.

This is a placeholder package. The full release is coming soon.
"""

__version__ = "0.0.0"


def open(*args, **kwargs):
    raise NotImplementedError("OmenDB is not yet released.")
