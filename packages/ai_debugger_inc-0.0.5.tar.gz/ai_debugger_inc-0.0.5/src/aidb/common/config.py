"""Common configuration utilities."""
