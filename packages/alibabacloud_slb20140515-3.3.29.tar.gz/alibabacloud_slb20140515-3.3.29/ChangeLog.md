2025-12-03 Version: 3.3.28
- Update SDK.

2024-12-25 Version: 3.3.27
- Update API CreateLoadBalancer: update param AutoPay.
- Update API CreateLoadBalancer: update param Duration.
- Update API CreateLoadBalancer: update param PayType.
- Update API CreateLoadBalancer: update param PricingCycle.
- Update API CreateLoadBalancerHTTPListener: update param StickySession.
- Update API CreateLoadBalancerHTTPSListener: update param StickySession.


2024-05-30 Version: 3.3.26
- Generated python 2014-05-15 for Slb.

2024-05-28 Version: 3.3.25
- Update API DescribeLoadBalancerHTTPListenerAttribute: update response param.
- Update API DescribeLoadBalancerHTTPSListenerAttribute: update response param.
- Update API DescribeLoadBalancerListeners: update response param.
- Update API DescribeLoadBalancerTCPListenerAttribute: update response param.
- Update API DescribeLoadBalancerUDPListenerAttribute: update response param.


2024-05-24 Version: 3.3.24
- Generated python 2014-05-15 for Slb.

2023-12-14 Version: 3.3.23
- Generated python 2014-05-15 for Slb.

2023-10-25 Version: 3.3.22
- Generated python 2014-05-15 for Slb.

2023-08-23 Version: 3.3.21
- Generated python 2014-05-15 for Slb.

2023-06-28 Version: 3.3.20
- Support Latest APIs.

2023-04-12 Version: 3.3.19
- Support Latest APIs.

2022-11-16 Version: 3.3.18
- Support Latest APIs.

2022-08-03 Version: 3.3.17
- Support Latest APIs.

2022-05-17 Version: 3.3.16
- Support Latest APIs.

2022-05-12 Version: 3.3.15
- Support Latest APIs.

2022-05-06 Version: 3.3.14
- Support Latest APIs.

2022-03-23 Version: 3.3.13
- Support Latest APIs.

2022-02-24 Version: 3.3.12
- Support latest feature.

2022-02-23 Version: 3.3.11
- Support latest apis.

2022-01-26 Version: 3.3.10
- Support Latest APIs.

2021-12-29 Version: 3.3.9
- Support tags.

2021-08-03 Version: 2.0.3
- Support query tags for DescribeLoadBalancers.

2021-05-24 Version: 2.0.2
- Generated python 2014-05-15 for Slb.

2021-03-31 Version: 2.0.1
- Generated python 2014-05-15 for Slb.

2020-12-30 Version: 2.0.0
- AMP Version Change.

2020-12-28 Version: 1.0.0
- AMP Version Change.

