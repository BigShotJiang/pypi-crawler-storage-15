__docformat__ = "google en"
__author__ = "John Westbrook"
__email__ = "john.westbrook@rcsb.org"
__license__ = "Apache 2.0"
__version__ = "1.1.0"

__apiUrl__ = "https://mmcif.wwpdb.org"
