"""
Runtime execution abstraction for multi-language support.

Provides a pluggable runtime system that allows PCards to execute
in different language environments (Python, JavaScript, Rust, C, etc.)
"""

import json
import logging
import subprocess
import importlib
from abc import ABC, abstractmethod
from typing import Any, Callable, Dict, List, Optional, Tuple
from enum import Enum

from mcard import MCard

# ─────────────────────────────────────────────────────────────────────────────
# Configuration
# ─────────────────────────────────────────────────────────────────────────────
#
# PTR runtime configuration is centralized in mcard.config.settings.
# Import from there for the canonical values, or use these local references
# for backward compatibility.
#
# Usage (recommended):
#     from mcard.config import settings
#     timeout = settings.ptr.lean_timeout
#
# ─────────────────────────────────────────────────────────────────────────────

MODULE_URI_PREFIX = 'module://'

# Import centralized settings
try:
    from mcard.config.settings import settings as _settings
    
    # Subprocess execution defaults (from centralized config)
    DEFAULT_TIMEOUT = _settings.ptr.default_timeout
    LEAN_TIMEOUT = _settings.ptr.lean_timeout
    JULIA_TIMEOUT = _settings.ptr.julia_timeout
    R_TIMEOUT = _settings.ptr.r_timeout
    
    # Allowed imports for sandboxed Python execution
    ALLOWED_IMPORTS = _settings.ptr.allowed_imports
    
    # Safe builtins for sandboxed Python execution
    SAFE_BUILTINS = _settings.ptr.safe_builtins
    
    # Runtime command configurations
    RUNTIME_CONFIG = _settings.ptr.runtime_config

except ImportError:
    # Fallback for edge cases where settings can't be imported
    DEFAULT_TIMEOUT = 5
    LEAN_TIMEOUT = 30
    JULIA_TIMEOUT = 15
    R_TIMEOUT = 10
    
    ALLOWED_IMPORTS = {
        'math': 'math', 'json': 'json', 'yaml': 'yaml', 'pathlib': 'pathlib',
        'typing': 'typing', 'hashlib': 'hashlib', 'mcard': 'mcard',
        'os': 'os', 'time': 'time', 'random': 'random', 'logging': 'logging',
    }
    
    SAFE_BUILTINS = {
        'int', 'float', 'str', 'len', 'range', 'list', 'dict', 'tuple', 'set',
        'abs', 'round', 'max', 'min', 'sum', 'sorted', 'enumerate', 'zip',
        'ValueError', 'Exception', '__build_class__', 'super', 'open',
        'all', 'any', 'bool', 'isinstance', 'bytes', 'print', 'globals',
    }
    
    RUNTIME_CONFIG = {
        'python': {'command': 'python3', 'version_flag': '--version'},
        'javascript': {'command': 'node', 'version_flag': '--version', 'eval_flag': '--eval'},
        'lean': {'command': 'lean', 'version_flag': '--version', 'run_flag': '--run'},
        'r': {'command': 'Rscript', 'version_flag': '--version'},
        'julia': {'command': 'julia', 'version_flag': '--version'},
        'wasm': {'command': None},
    }


# ─────────────────────────────────────────────────────────────────────────────
# Runtime Types
# ─────────────────────────────────────────────────────────────────────────────

class RuntimeType(Enum):
    """Supported runtime types."""
    PYTHON = "python"
    JAVASCRIPT = "javascript"
    RUST = "rust"
    C = "c"
    WASM = "wasm"
    LEAN = "lean"
    R = "r"
    JULIA = "julia"
    LLM = "llm"


# ─────────────────────────────────────────────────────────────────────────────
# Base Executor Classes
# ─────────────────────────────────────────────────────────────────────────────

class RuntimeExecutor(ABC):
    """Abstract base class for runtime executors."""
    
    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)
    
    @abstractmethod
    def execute(self, concrete_impl: Dict[str, Any], target: MCard, context: Dict[str, Any]) -> Any:
        """Execute the operation in the runtime environment."""
        pass
    
    @abstractmethod
    def validate_environment(self) -> bool:
        """Check if runtime environment is available."""
        pass
    
    def get_runtime_status(self) -> Dict[str, Any]:
        """Get detailed status information about this runtime."""
        return {
            'available': self.validate_environment(),
            'version': None,
            'command': self.__class__.__name__.replace('Runtime', '').lower(),
            'details': ''
        }


class SubprocessRuntime(RuntimeExecutor):
    """
    Base class for runtimes that execute via subprocess.
    Reduces duplication across Rust/C/Lean/R/Julia.
    """
    
    runtime_name: str = ""
    command: Optional[str] = None
    version_flag: str = "--version"
    timeout: int = DEFAULT_TIMEOUT
    
    def _run_subprocess(
        self,
        cmd: List[str],
        target: MCard,
        context: Dict,
        timeout: Optional[int] = None
    ) -> str:
        """Execute subprocess and return output or error string."""
        try:
            result = subprocess.run(
                cmd,
                input=target.get_content(),
                capture_output=True,
                timeout=timeout or self.timeout
            )
            if result.returncode != 0:
                return f"Error: {self.runtime_name} execution failed: {result.stderr.decode()}"
            return result.stdout.decode('utf-8')
        except subprocess.TimeoutExpired:
            return f"Error: {self.runtime_name} execution timed out"
        except Exception as e:
            return f"Error executing {self.runtime_name}: {e}"
    
    def _check_command(self, cmd: str, flag: str, timeout: int = 2) -> bool:
        """Check if a command is available."""
        try:
            result = subprocess.run([cmd, flag], capture_output=True, timeout=timeout)
            return result.returncode == 0
        except Exception:
            return False
    
    def validate_environment(self) -> bool:
        if not self.command:
            return True  # No command needed (e.g., compiled binaries)
        return self._check_command(self.command, self.version_flag)


# ─────────────────────────────────────────────────────────────────────────────
# Python Runtime
# ─────────────────────────────────────────────────────────────────────────────

class PythonRuntime(RuntimeExecutor):
    """Python runtime executor - executes Python code directly in-process."""
    
    # Operation handlers mapping
    OPERATIONS: Dict[str, Callable] = {}
    
    def __init__(self):
        super().__init__()
        # Register built-in operations
        self.OPERATIONS = {
            'identity': self._op_identity,
            'transform': self._op_transform,
            'arithmetic': self._op_arithmetic,
            'string_op': self._op_string,
            'fetch_url': self._op_fetch_url,
            'custom': self._op_custom,
        }
    
    def execute(self, concrete_impl: Dict[str, Any], target: MCard, context: Dict[str, Any]) -> Any:
        # Check for module:// syntax first
        code_file = concrete_impl.get('code_file', '')
        if code_file.startswith(MODULE_URI_PREFIX):
            return self._execute_module_logic(code_file, concrete_impl, target, context)
        
        # Determine operation
        operation = concrete_impl.get('operation')
        if not operation:
            # Auto-detect custom operation if code is present
            if 'code_file' in concrete_impl or 'code' in concrete_impl:
                operation = 'custom'
            else:
                operation = 'identity'
                
        handler = self.OPERATIONS.get(operation)
        
        if handler:
            return handler(concrete_impl, target, context)
        return f"Executed {operation} on {target.hash}"
    
    # ─── Operations ───────────────────────────────────────────────────────────
    
    def _op_identity(self, impl: Dict, target: MCard, ctx: Dict) -> Any:
        return target.get_content()
    
    def _op_transform(self, impl: Dict, target: MCard, ctx: Dict) -> Any:
        transforms = {
            'upper_case': lambda t: t.get_content().decode('utf-8').upper().encode('utf-8'),
            'count_bytes': lambda t: len(t.get_content()),
        }
        func = impl.get('transform_function')
        return transforms.get(func, lambda t: t.get_content())(target)
    
    def _op_arithmetic(self, impl: Dict, target: MCard, ctx: Dict) -> Any:
        params = {**impl.get('params', {}), **ctx}
        op, operand = params.get('op'), params.get('operand')
        
        try:
            val = float(target.get_content().decode('utf-8'))
        except ValueError:
            return "Error: Target content is not a valid number"
        
        ops = {
            'add': lambda x, y: x + y,
            'sub': lambda x, y: x - y,
            'mul': lambda x, y: x * y,
            'div': lambda x, y: x / y if y != 0 else "Error: Division by zero"
        }
        return ops.get(op, lambda x, y: f"Error: Unknown operation '{op}'")(val, operand)
    
    def _op_string(self, impl: Dict, target: MCard, ctx: Dict) -> Any:
        params = {**impl.get('params', {}), **ctx}
        func = params.get('func')
        s = target.get_content().decode('utf-8')
        
        ops = {
            'reverse': lambda: s[::-1],
            'len': lambda: len(s),
            'split': lambda: s.split(params.get('delimiter', ' '))
        }
        return ops.get(func, lambda: f"Error: Unknown function '{func}'")()
    
    def _op_fetch_url(self, impl: Dict, target: MCard, ctx: Dict) -> Any:
        import urllib.request
        url = target.get_content().decode('utf-8').strip()
        try:
            with urllib.request.urlopen(url, timeout=5) as resp:
                return resp.read().decode('utf-8')[:1000]
        except Exception as e:
            return f"Error fetching URL: {e}"
    
    def _op_custom(self, impl: Dict, target: MCard, ctx: Dict) -> Any:
        code_file = impl.get('code_file', '')
        if code_file.startswith(MODULE_URI_PREFIX):
            return self._execute_module_logic(code_file, impl, target, ctx)
        
        code = impl.get('code', '')
        if not code:
            return "Error: No code provided"
        
        return self._exec_sandboxed(code, impl, target, ctx)
    
    # ─── Sandboxed Execution ──────────────────────────────────────────────────
    
    def _make_safe_import(self) -> Callable:
        """Create a safe import function."""
        import math
        def safe_import(name, globals=None, locals=None, fromlist=(), level=0):
            if name in ALLOWED_IMPORTS:
                return importlib.import_module(name)
            raise ImportError(f"Import of '{name}' is not allowed")
        return safe_import
    
    def _make_namespace(self, target: MCard, context: Dict) -> Dict:
        """Create a sandboxed namespace for code execution."""
        import math
        import builtins as builtins_module
        
        # Build safe builtins dict from the builtins module
        safe_builtins = {}
        for name in SAFE_BUILTINS:
            if hasattr(builtins_module, name):
                safe_builtins[name] = getattr(builtins_module, name)
        
        safe_builtins['__import__'] = self._make_safe_import()
        safe_builtins['__build_class__'] = builtins_module.__build_class__
        
        return {
            '__builtins__': safe_builtins,
            'target': target.get_content(),
            'context': context,
            'result': None,
            'math': math,
            '__name__': '__clm_runtime__'
        }
    
    def _exec_sandboxed(self, code: str, impl: Dict, target: MCard, ctx: Dict) -> Any:
        """Execute code in a sandboxed namespace."""
        namespace = self._make_namespace(target, ctx)
        
        try:
            exec(code, namespace)
            entry_point = impl.get('entry_point')
            if entry_point:
                return self._call_entry_point(namespace, entry_point, impl, target, ctx)
            return namespace.get('result')
        except Exception as e:
            return f"Error executing Python code: {e}"
    
    def _call_entry_point(self, ns: Dict, entry: str, impl: Dict, target: MCard, ctx: Dict) -> Any:
        """Call a function defined in namespace."""
        if entry not in ns or not callable(ns[entry]):
            return f"Error: Entry point '{entry}' not found or not callable. Keys: {list(ns.keys())}"
        
        func = ns[entry]
        arg = self._prepare_argument(impl, target, ctx)
        return func(arg)
    
    def _prepare_argument(self, impl: Dict, target: MCard, ctx: Dict) -> Any:
        """Prepare argument for entry point function."""
        inputs_def = impl.get('implementation', {}).get('inputs', {})
        if not inputs_def:
            return target.get_content()
        
        input_name = list(inputs_def.keys())[0]
        input_type = inputs_def[input_name]
        
        if input_name == 'context':
            return ctx
        
        raw = target.get_content()
        converters = {
            'float': lambda: float(raw.decode('utf-8')),
            'int': lambda: int(raw.decode('utf-8')),
            'str': lambda: raw.decode('utf-8'),
        }
        
        try:
            return converters.get(input_type, lambda: raw)()
        except Exception:
            return raw
    
    # ─── Module Logic ─────────────────────────────────────────────────────────
    
    def _execute_module_logic(self, uri: str, impl: Dict, target: MCard, ctx: Dict) -> Any:
        """Execute logic imported from a Python module."""
        path = uri.replace(MODULE_URI_PREFIX, '')
        module_name, func_name = (path.split(':', 1) if ':' in path 
                                  else (path, impl.get('entry_point', 'logic')))
        
        try:
            module = importlib.import_module(module_name)
            func = getattr(module, func_name)
            if not callable(func):
                return f"Error: {func_name} in {module_name} is not callable"
            
            arg = target.get_content().decode('utf-8') if hasattr(target, 'get_content') else target
            return func(arg)
        except ImportError as e:
            return f"Error importing module {module_name}: {e}"
        except AttributeError:
            return f"Error: Function {func_name} not found in {module_name}"
        except Exception as e:
            return f"Error executing module logic: {e}"
    
    def validate_environment(self) -> bool:
        return True
    
    def get_runtime_status(self) -> Dict[str, Any]:
        import sys
        return {
            'available': True,
            'version': f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
            'command': RUNTIME_CONFIG['python']['command'],
            'details': f'Python {sys.version}'
        }


# ─────────────────────────────────────────────────────────────────────────────
# JavaScript Runtime
# ─────────────────────────────────────────────────────────────────────────────

class JavaScriptRuntime(SubprocessRuntime):
    """JavaScript runtime executor - executes via Node.js or Deno."""
    
    runtime_name = "JavaScript"
    
    def __init__(self, use_deno: bool = False):
        super().__init__()
        config = RUNTIME_CONFIG['deno' if use_deno else 'javascript']
        self.command = config['command']
        self.eval_flag = config.get('eval_flag', '--eval')
        self.use_deno = use_deno
    
    def execute(self, impl: Dict[str, Any], target: MCard, ctx: Dict[str, Any]) -> Any:
        code = impl.get('code', '')
        if not code and not impl.get('entry_point', {}).get('file'):
            return "Error: No JavaScript code or file provided"
        
        input_data = {
            'target': target.get_content().decode('utf-8', errors='ignore'),
            'context': ctx
        }
        
        js_code = f"""
        const input = {json.dumps(input_data)};
        const target = input.target;
        const context = input.context;
        {code}
        console.log(JSON.stringify(result));
        """
        
        try:
            result = subprocess.run(
                [self.command, self.eval_flag, js_code],
                capture_output=True, text=True, timeout=self.timeout
            )
            if result.returncode != 0:
                return f"Error: JavaScript execution failed: {result.stderr}"
            return json.loads(result.stdout.strip())
        except subprocess.TimeoutExpired:
            return "Error: JavaScript execution timed out"
        except Exception as e:
            return f"Error executing JavaScript: {e}"


# ─────────────────────────────────────────────────────────────────────────────
# Binary-based Runtimes (Rust, C)
# ─────────────────────────────────────────────────────────────────────────────

class BinaryRuntime(SubprocessRuntime):
    """Base class for runtimes that execute compiled binaries."""
    
    def execute(self, impl: Dict[str, Any], target: MCard, ctx: Dict[str, Any]) -> Any:
        binary_path = impl.get('binary_path')
        if not binary_path:
            return f"Error: No {self.runtime_name} binary path provided"
        return self._run_subprocess([binary_path, json.dumps(ctx)], target, ctx)


class RustRuntime(BinaryRuntime):
    """Rust runtime executor - executes via compiled binary or WASM."""
    
    runtime_name = "Rust"
    command = RUNTIME_CONFIG['rust']['command']
    
    def execute(self, impl: Dict[str, Any], target: MCard, ctx: Dict[str, Any]) -> Any:
        wasm_module = impl.get('wasm_module')
        if wasm_module:
            return self._execute_wasm(wasm_module, target, ctx)
        return super().execute(impl, target, ctx)
    
    def _execute_wasm(self, wasm_path: str, target: MCard, ctx: Dict) -> Any:
        """Execute WASM module using wasmtime."""
        try:
            from wasmtime import Store, Module, Linker, WasiConfig
            import tempfile, os
            
            store = Store()
            wasi = WasiConfig()
            wasi.inherit_stdout()
            wasi.inherit_stderr()
            wasi.argv = ["program_name", json.dumps(ctx)]
            
            # Create temp files for stdin/stdout
            with tempfile.NamedTemporaryFile(mode='w+', delete=False) as tmp_in:
                tmp_in.write(target.get_content().decode('utf-8'))
                in_path = tmp_in.name
            
            with tempfile.NamedTemporaryFile(mode='w+', delete=False) as tmp_out:
                out_path = tmp_out.name
            
            wasi.stdin_file = in_path
            wasi.stdout_file = out_path
            store.set_wasi(wasi)
            
            linker = Linker(store.engine)
            linker.define_wasi()
            
            module = Module.from_file(store.engine, wasm_path)
            instance = linker.instantiate(store, module)
            instance.exports(store)["_start"](store)
            
            with open(out_path, 'r') as f:
                output = f.read()
            
            os.unlink(in_path)
            os.unlink(out_path)
            return output
            
        except ImportError:
            return "Error: wasmtime python library not installed"
        except Exception as e:
            return f"Error executing WASM: {e}"
    
    def validate_environment(self) -> bool:
        rust_ok = self._check_command('rustc', '--version')
        wasm_ok = False
        try:
            import wasmtime
            wasm_ok = True
        except ImportError:
            pass
        return rust_ok or wasm_ok


class CRuntime(BinaryRuntime):
    """C runtime executor - executes via compiled binary."""
    runtime_name = "C"
    command = None  # No compiler check needed


# ─────────────────────────────────────────────────────────────────────────────
# Script-based Runtimes (Lean, R, Julia)
# ─────────────────────────────────────────────────────────────────────────────

class ScriptRuntime(SubprocessRuntime):
    """Base class for runtimes that execute script files."""
    
    file_key = 'code_file'
    run_args: List[str] = []
    
    def execute(self, impl: Dict[str, Any], target: MCard, ctx: Dict[str, Any]) -> Any:
        code_file = impl.get(self.file_key)
        if not code_file:
            return f"Error: No {self.runtime_name} code file provided"
        
        cmd = [self.command] + self.run_args + [code_file, json.dumps(ctx)]
        return self._run_subprocess(cmd, target, ctx, self.timeout)


class LeanRuntime(ScriptRuntime):
    """Lean 4 runtime executor."""
    runtime_name = "Lean"
    command = RUNTIME_CONFIG['lean']['command']
    run_args = ['--run']
    timeout = LEAN_TIMEOUT
    
    def validate_environment(self) -> bool:
        # Lean 4 takes longer to initialize, use extended timeout
        return self._check_command(self.command, self.version_flag, timeout=10)
    
    def execute(self, impl: Dict[str, Any], target: MCard, ctx: Dict[str, Any]) -> Any:
        """Execute Lean script, passing input as the argument."""
        code_file = impl.get(self.file_key)
        if not code_file:
            return f"Error: No {self.runtime_name} code file provided"
        
        # Determine what to pass as the argument:
        # 1. If context has 'op', 'a', 'b' keys (polyglot mode), use context as JSON
        # 2. Otherwise, use target content (standalone CLM mode)
        if ctx and ('op' in ctx or 'a' in ctx or 'n' in ctx):
            # Polyglot/advanced mode - context contains the actual input data
            input_data = json.dumps(ctx)
        else:
            # Standalone CLM mode - target content is the JSON input
            input_data = target.get_content().decode('utf-8', errors='ignore')
        
        cmd = [self.command] + self.run_args + [code_file, input_data]
        return self._run_subprocess(cmd, target, ctx, self.timeout)


class RRuntime(ScriptRuntime):
    """R runtime executor."""
    runtime_name = "R"
    command = RUNTIME_CONFIG['r']['command']
    timeout = R_TIMEOUT


class JuliaRuntime(ScriptRuntime):
    """Julia runtime executor."""
    runtime_name = "Julia"
    command = RUNTIME_CONFIG['julia']['command']
    timeout = JULIA_TIMEOUT


# ─────────────────────────────────────────────────────────────────────────────
# Runtime Factory
# ─────────────────────────────────────────────────────────────────────────────

class RuntimeFactory:
    """Factory for creating runtime executors based on configuration."""
    
    _executors: Dict[RuntimeType, RuntimeExecutor] = {}
    
    # Mapping from RuntimeType to executor class
    _EXECUTOR_MAP: Dict[RuntimeType, type] = {
        RuntimeType.PYTHON: PythonRuntime,
        RuntimeType.JAVASCRIPT: JavaScriptRuntime,
        RuntimeType.RUST: RustRuntime,
        RuntimeType.C: CRuntime,
        RuntimeType.WASM: RustRuntime,
        RuntimeType.LEAN: LeanRuntime,
        RuntimeType.R: RRuntime,
        RuntimeType.JULIA: JuliaRuntime,
    }
    
    @classmethod
    def get_executor(cls, runtime_type: str) -> Optional[RuntimeExecutor]:
        """Get or create a runtime executor for the specified type."""
        # Handle LLM runtime specially (dynamic import to avoid circular dependency)
        if runtime_type.lower() == 'llm':
            return cls._get_llm_executor()
        
        try:
            rt_type = RuntimeType(runtime_type.lower())
        except ValueError:
            logging.error(f"Unsupported runtime type: {runtime_type}")
            return None
        
        if rt_type not in cls._executors:
            executor = cls._create_executor(rt_type)
            if executor and executor.validate_environment():
                cls._executors[rt_type] = executor
            else:
                logging.warning(f"Runtime {runtime_type} not available or invalid")
                return None
        
        return cls._executors.get(rt_type)
    
    @classmethod
    def _get_llm_executor(cls) -> Optional[RuntimeExecutor]:
        """Get LLM executor with dynamic import."""
        if RuntimeType.LLM in cls._executors:
            return cls._executors[RuntimeType.LLM]
        
        try:
            from .llm import LLMRuntime
            executor = LLMRuntime()
            if executor.validate_environment():
                cls._executors[RuntimeType.LLM] = executor
                return executor
            else:
                logging.warning("LLM runtime not available (Ollama not running?)")
                return None
        except ImportError as e:
            logging.error(f"Failed to import LLM runtime: {e}")
            return None
    
    @classmethod
    def _create_executor(cls, runtime_type: RuntimeType) -> Optional[RuntimeExecutor]:
        """Create a new runtime executor."""
        executor_class = cls._EXECUTOR_MAP.get(runtime_type)
        return executor_class() if executor_class else None
    
    @classmethod
    def list_available_runtimes(cls) -> Dict[str, bool]:
        """List all runtime types and their availability."""
        return {rt.value: (ex := cls._create_executor(rt)) and ex.validate_environment()
                for rt in RuntimeType}
    
    @classmethod
    def get_detailed_status(cls) -> Dict[str, Dict[str, Any]]:
        """Get detailed status information for all runtimes."""
        status = {}
        for rt in RuntimeType:
            executor = cls._create_executor(rt)
            status[rt.value] = (executor.get_runtime_status() if executor else {
                'available': False, 'version': None, 'command': rt.value,
                'details': 'Runtime executor not implemented'
            })
        return status
    
    @classmethod
    def at_least_one_available(cls) -> bool:
        """Check if at least one runtime is available."""
        return any(cls.list_available_runtimes().values())
    
    @classmethod
    def print_status(cls, verbose: bool = False) -> None:
        """Print runtime status to console."""
        print("\n=== Polyglot Runtime Status ===")
        for name, info in cls.get_detailed_status().items():
            if info['available']:
                ver = f" {info['version']}" if info['version'] else ""
                detail = f": {info['details']}" if verbose and info['details'] else ""
                print(f"✓ {name.capitalize()}{ver}{detail}")
            else:
                print(f"✗ {name.capitalize()} not found")
        
        available = sum(1 for i in cls.get_detailed_status().values() if i['available'])
        print(f"{'=' * 31}\nAvailable: {available}/{len(RuntimeType)} runtimes")
