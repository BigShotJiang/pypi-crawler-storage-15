"""
Vector Store Package

SQLite-based vector storage using sqlite-vec extension.
"""

from .store import MCardVectorStore, VectorSearchResult
from .schema import VECTOR_SCHEMAS

__all__ = [
    'MCardVectorStore',
    'VectorSearchResult',
    'VECTOR_SCHEMAS',
]
