"""
Vector Store Database Schema

SQLite schemas for vector storage and metadata.
"""

# ─────────────────────────────────────────────────────────────────────────────
# Vector Metadata Table
# ─────────────────────────────────────────────────────────────────────────────

VECTOR_METADATA_SCHEMA = """
CREATE TABLE IF NOT EXISTS mcard_vector_metadata (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    hash TEXT NOT NULL,
    model_name TEXT NOT NULL,
    dimensions INTEGER NOT NULL,
    chunk_index INTEGER DEFAULT 0,
    chunk_total INTEGER DEFAULT 1,
    chunk_text TEXT,
    created_at TEXT NOT NULL,
    UNIQUE(hash, chunk_index)
)
"""

VECTOR_METADATA_INDEX = """
CREATE INDEX IF NOT EXISTS idx_vector_metadata_hash 
ON mcard_vector_metadata(hash)
"""

# ─────────────────────────────────────────────────────────────────────────────
# Vector Embeddings Table (for fallback without sqlite-vec)
# ─────────────────────────────────────────────────────────────────────────────

VECTOR_EMBEDDINGS_SCHEMA = """
CREATE TABLE IF NOT EXISTS mcard_embeddings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    metadata_id INTEGER NOT NULL REFERENCES mcard_vector_metadata(id),
    embedding BLOB NOT NULL,
    UNIQUE(metadata_id)
)
"""

# ─────────────────────────────────────────────────────────────────────────────
# Full-Text Search for Hybrid Retrieval
# ─────────────────────────────────────────────────────────────────────────────

FTS_SCHEMA = """
CREATE VIRTUAL TABLE IF NOT EXISTS mcard_fts USING fts5(
    hash,
    content,
    tokenize='porter unicode61'
)
"""

# ─────────────────────────────────────────────────────────────────────────────
# Export All Schemas
# ─────────────────────────────────────────────────────────────────────────────

VECTOR_SCHEMAS = {
    'metadata': VECTOR_METADATA_SCHEMA,
    'metadata_index': VECTOR_METADATA_INDEX,
    'embeddings': VECTOR_EMBEDDINGS_SCHEMA,
    'fts': FTS_SCHEMA,
}


def get_vec0_schema(dimensions: int) -> str:
    """
    Generate sqlite-vec virtual table schema.
    
    Args:
        dimensions: Embedding vector dimensions
        
    Returns:
        SQL CREATE VIRTUAL TABLE statement
    """
    return f"""
    CREATE VIRTUAL TABLE IF NOT EXISTS mcard_vec USING vec0(
        metadata_id INTEGER PRIMARY KEY,
        embedding float[{dimensions}]
    )
    """
