"""
Graph Database Schema

SQLite schemas for knowledge graph storage.
"""

# ─────────────────────────────────────────────────────────────────────────────
# Entity Table
# ─────────────────────────────────────────────────────────────────────────────

ENTITY_SCHEMA = """
CREATE TABLE IF NOT EXISTS graph_entities (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    type TEXT NOT NULL,
    description TEXT,
    source_hash TEXT NOT NULL,
    embedding BLOB,
    created_at TEXT NOT NULL,
    UNIQUE(name, type, source_hash)
)
"""

ENTITY_INDEX_NAME = """
CREATE INDEX IF NOT EXISTS idx_entity_name ON graph_entities(name)
"""

ENTITY_INDEX_TYPE = """
CREATE INDEX IF NOT EXISTS idx_entity_type ON graph_entities(type)
"""

ENTITY_INDEX_SOURCE = """
CREATE INDEX IF NOT EXISTS idx_entity_source ON graph_entities(source_hash)
"""

# ─────────────────────────────────────────────────────────────────────────────
# Relationship Table
# ─────────────────────────────────────────────────────────────────────────────

RELATIONSHIP_SCHEMA = """
CREATE TABLE IF NOT EXISTS graph_relationships (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_entity_id INTEGER NOT NULL REFERENCES graph_entities(id),
    target_entity_id INTEGER NOT NULL REFERENCES graph_entities(id),
    relationship TEXT NOT NULL,
    description TEXT,
    weight REAL DEFAULT 1.0,
    source_hash TEXT NOT NULL,
    created_at TEXT NOT NULL,
    UNIQUE(source_entity_id, target_entity_id, relationship, source_hash)
)
"""

RELATIONSHIP_INDEX_SOURCE = """
CREATE INDEX IF NOT EXISTS idx_rel_source ON graph_relationships(source_entity_id)
"""

RELATIONSHIP_INDEX_TARGET = """
CREATE INDEX IF NOT EXISTS idx_rel_target ON graph_relationships(target_entity_id)
"""

# ─────────────────────────────────────────────────────────────────────────────
# Community Table (for hierarchical summaries)
# ─────────────────────────────────────────────────────────────────────────────

COMMUNITY_SCHEMA = """
CREATE TABLE IF NOT EXISTS graph_communities (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    level INTEGER NOT NULL DEFAULT 0,
    title TEXT,
    summary TEXT NOT NULL,
    embedding BLOB,
    member_entity_ids TEXT,
    parent_community_id INTEGER REFERENCES graph_communities(id),
    created_at TEXT NOT NULL
)
"""

COMMUNITY_INDEX_LEVEL = """
CREATE INDEX IF NOT EXISTS idx_community_level ON graph_communities(level)
"""

# ─────────────────────────────────────────────────────────────────────────────
# Extraction Tracking
# ─────────────────────────────────────────────────────────────────────────────

EXTRACTION_TRACKING_SCHEMA = """
CREATE TABLE IF NOT EXISTS graph_extractions (
    hash TEXT PRIMARY KEY,
    entity_count INTEGER DEFAULT 0,
    relationship_count INTEGER DEFAULT 0,
    extracted_at TEXT NOT NULL
)
"""

# ─────────────────────────────────────────────────────────────────────────────
# Export All Schemas
# ─────────────────────────────────────────────────────────────────────────────

GRAPH_SCHEMAS = {
    'entities': ENTITY_SCHEMA,
    'entity_idx_name': ENTITY_INDEX_NAME,
    'entity_idx_type': ENTITY_INDEX_TYPE,
    'entity_idx_source': ENTITY_INDEX_SOURCE,
    'relationships': RELATIONSHIP_SCHEMA,
    'rel_idx_source': RELATIONSHIP_INDEX_SOURCE,
    'rel_idx_target': RELATIONSHIP_INDEX_TARGET,
    'communities': COMMUNITY_SCHEMA,
    'community_idx_level': COMMUNITY_INDEX_LEVEL,
    'extractions': EXTRACTION_TRACKING_SCHEMA,
}
