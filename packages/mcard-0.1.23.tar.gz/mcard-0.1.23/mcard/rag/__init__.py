"""
MCard RAG (Retrieval-Augmented Generation) Package

Provides vector search, semantic retrieval, and knowledge graph capabilities
for MCard content using SQLite with sqlite-vec extension and Ollama embeddings.
"""

from .config import RAGConfig, DEFAULT_RAG_CONFIG
from .engine import MCardRAGEngine, RAGResponse
from .indexer import (
    PersistentIndexer, 
    get_indexer, 
    semantic_search, 
    index_mcard
)
from .graph import (
    GraphRAGEngine,
    GraphRAGResponse,
    GraphExtractor,
    GraphStore,
    Entity,
    Relationship,
)

__all__ = [
    # Config
    'RAGConfig',
    'DEFAULT_RAG_CONFIG',
    # Vector RAG
    'MCardRAGEngine',
    'RAGResponse',
    # Persistent Indexer
    'PersistentIndexer',
    'get_indexer',
    'semantic_search',
    'index_mcard',
    # GraphRAG
    'GraphRAGEngine',
    'GraphRAGResponse',
    'GraphExtractor',
    'GraphStore',
    'Entity',
    'Relationship',
]

