from django.apps import AppConfig


class RegexRedirectsConfig(AppConfig):
    name = "regex_redirects"
    verbose_name = "Regex Redirects"
