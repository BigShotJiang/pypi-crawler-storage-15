"""
nuttx-env
A Python library for creating and managing project environments for RTOS NuttX.
"""

__version__ = "0.1.0"
__app_name__ = "nuttx-env"
