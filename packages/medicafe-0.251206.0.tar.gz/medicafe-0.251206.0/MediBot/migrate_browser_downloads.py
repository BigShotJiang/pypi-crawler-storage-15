#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
MediBot Secondary Pickup Scanner - Browser Downloads Migration

This script processes files downloaded via browser to source_folder (C:\MEDIANSI\MediCare),
ensuring primary route files (from local_storage_path) take precedence and browser-downloaded
files are migrated to appropriate locations.

Deduplication Logic:
- CSV files: Leave in source_folder (process_csvs.bat handles them)
- DOCX files: Move to inputFilePath if no duplicate exists in local_storage_path
- If duplicate exists in local_storage_path: remove browser-downloaded file (primary takes precedence)

Output Format:
Lines in format: ACTION|FILEPATH
Where ACTION is: REMOVE, KEEP, MOVE
And FILEPATH is the full path to the file
"""

import os
import sys
import json
import argparse

# Setup Python path to find MediCafe
current_dir = os.path.dirname(os.path.abspath(__file__))
workspace_root = os.path.dirname(current_dir)
if workspace_root not in sys.path:
    sys.path.insert(0, workspace_root)

from MediCafe.core_utils import extract_medilink_config

def load_config(config_path):
    """Load configuration from JSON file"""
    try:
        # Resolve to absolute path to avoid issues with relative paths and spaces
        if not os.path.isabs(config_path):
            config_path = os.path.abspath(config_path)
        with open(config_path, 'r') as f:
            config = json.load(f)
        return config
    except Exception as e:
        print("ERROR|Failed to load config: {}".format(str(e)))
        sys.exit(1)

def get_medilink_config(config):
    """Extract MediLink_Config section"""
    try:
        medi_config = extract_medilink_config(config)
        return medi_config
    except Exception as e:
        print("ERROR|Failed to extract MediLink config: {}".format(str(e)))
        sys.exit(1)

def scan_files(source_folder):
    """Scan source_folder for .csv and .docx files"""
    files_to_process = []

    if not os.path.exists(source_folder):
        print("ERROR|Source folder does not exist: {}".format(source_folder))
        sys.exit(1)

    try:
        for filename in os.listdir(source_folder):
            if filename.lower().endswith(('.csv', '.docx')):
                filepath = os.path.join(source_folder, filename)
                if os.path.isfile(filepath):
                    files_to_process.append((filename, filepath))
    except Exception as e:
        print("ERROR|Failed to scan source folder: {}".format(str(e)))
        sys.exit(1)

    return files_to_process

def analyze_file_actions(files, local_storage_path, input_file_path):
    """Analyze files and determine actions based on deduplication logic"""
    actions = []

    for filename, filepath in files:
        try:
            # Check if duplicate exists in local_storage_path
            duplicate_path = os.path.join(local_storage_path, filename)
            duplicate_exists = os.path.exists(duplicate_path)

            if duplicate_exists:
                # Primary route file takes precedence - remove browser download
                actions.append(("REMOVE", filepath))
            else:
                # No duplicate - process based on file type
                if filename.lower().endswith('.csv'):
                    # CSV files stay in source_folder for process_csvs.bat
                    actions.append(("KEEP", filepath))
                elif filename.lower().endswith('.docx'):
                    # DOCX files move to inputFilePath
                    if input_file_path:
                        destination = os.path.join(input_file_path, filename)
                        actions.append(("MOVE", filepath, destination))
                    else:
                        # No inputFilePath configured - keep in place
                        actions.append(("KEEP", filepath))

        except Exception as e:
            print("ERROR|Failed to analyze file {}: {}".format(filepath, str(e)))
            # On error, keep file in place
            actions.append(("KEEP", filepath))

    return actions

def output_actions(actions):
    """Output actions in format parseable by batch file"""
    for action in actions:
        if len(action) == 2:
            # REMOVE or KEEP actions
            action_type, filepath = action
            print("{}|{}".format(action_type, filepath))
        elif len(action) == 3:
            # MOVE action with destination
            action_type, source_path, dest_path = action
            print("{}|{}|{}".format(action_type, source_path, dest_path))

def main():
    parser = argparse.ArgumentParser(description='MediBot Browser Downloads Migration')
    parser.add_argument('--config', required=True, help='Path to config.json')
    parser.add_argument('--source-folder', required=True, help='Source folder to scan')

    args = parser.parse_args()

    # Load configuration
    config = load_config(args.config)
    medi_config = get_medilink_config(config)

    # Extract required paths from config (should already be absolute paths)
    # Only normalize to clean up any path separators, don't resolve relative paths
    # as config paths may span multiple drives (C: and F:)
    # Exception: if path is '.' (default), resolve it relative to config file's directory
    local_storage_path = medi_config.get('local_storage_path', '.')
    if local_storage_path:
        if local_storage_path == '.':
            # Default '.' should be resolved relative to config file location
            config_dir = os.path.dirname(os.path.abspath(args.config))
            local_storage_path = os.path.abspath(os.path.join(config_dir, local_storage_path))
        else:
            local_storage_path = os.path.normpath(local_storage_path)
    
    input_file_path = medi_config.get('inputFilePath')
    if input_file_path:
        if input_file_path == '.':
            # Default '.' should be resolved relative to config file location
            config_dir = os.path.dirname(os.path.abspath(args.config))
            input_file_path = os.path.abspath(os.path.join(config_dir, input_file_path))
        else:
            input_file_path = os.path.normpath(input_file_path)

    # Validate paths exist
    if not os.path.exists(local_storage_path):
        print("ERROR|Local storage path does not exist: {}".format(local_storage_path))
        sys.exit(1)

    if input_file_path and not os.path.exists(input_file_path):
        print("WARNING|Input file path does not exist: {}".format(input_file_path))
        # Continue anyway - batch file will handle creation

    # Scan for files
    files = scan_files(args.source_folder)

    if not files:
        # No files to process
        return

    # Analyze and determine actions
    actions = analyze_file_actions(files, local_storage_path, input_file_path)

    # Output results
    output_actions(actions)

if __name__ == '__main__':
    main()