"""Tests for tool utility functions."""
