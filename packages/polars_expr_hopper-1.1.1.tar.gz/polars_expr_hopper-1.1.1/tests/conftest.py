"""Import the plugin so the DataFrames get the `.hopper` namespace."""

import polars_hopper  # noqa: F401
