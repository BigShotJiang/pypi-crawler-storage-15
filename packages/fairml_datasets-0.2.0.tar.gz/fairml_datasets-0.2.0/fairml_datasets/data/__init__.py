from pathlib import Path

DATA_DIR = Path(__file__).parent

RAW = DATA_DIR / "raw"
INTERIM = DATA_DIR / "interim"
FINAL = DATA_DIR / "final"
