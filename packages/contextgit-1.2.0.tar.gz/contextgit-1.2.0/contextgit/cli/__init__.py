"""CLI application for contextgit."""

from contextgit.cli.app import app, console

__all__ = ['app', 'console']
