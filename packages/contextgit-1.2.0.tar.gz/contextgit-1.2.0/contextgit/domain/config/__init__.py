"""Configuration management module."""

from contextgit.domain.config.manager import ConfigManager

__all__ = ['ConfigManager']
