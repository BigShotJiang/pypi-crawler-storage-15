"""
Email Service.

Provides methods for sending transactional emails via SMTP.
Supports passwordless login via email codes.
"""

import uuid
import random
import string
import hashlib
import smtplib
import logging
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime, timedelta, timezone
from typing import Optional, Any

from .templates import EmailTemplate, login_code_template, welcome_template

logger = logging.getLogger(__name__)


class EmailService:
    """Service for sending transactional emails and passwordless login."""

    def __init__(
        self,
        smtp_host: str | None = None,
        smtp_port: int | None = None,
        sender_email: str | None = None,
        sender_name: str | None = None,
        app_password: str | None = None,
        use_tls: bool = True,
        login_code_expiry_minutes: int = 10,
    ):
        """
        Initialize EmailService.

        If no arguments provided, uses settings from rem.settings.
        This allows no-arg construction for simple usage.

        Args:
            smtp_host: SMTP server host
            smtp_port: SMTP server port
            sender_email: Sender email address
            sender_name: Sender display name
            app_password: SMTP app password
            use_tls: Use TLS encryption
            login_code_expiry_minutes: Login code expiry in minutes
        """
        # Import settings lazily to avoid circular imports
        from ...settings import settings

        self._smtp_host = smtp_host or settings.email.smtp_host
        self._smtp_port = smtp_port or settings.email.smtp_port
        self._sender_email = sender_email or settings.email.sender_email
        self._sender_name = sender_name or settings.email.sender_name
        self._app_password = app_password or settings.email.app_password
        self._use_tls = use_tls
        self._login_code_expiry_minutes = (
            login_code_expiry_minutes
            or settings.email.login_code_expiry_minutes
        )

        if not self._app_password:
            logger.warning(
                "Email app password not configured. "
                "Set EMAIL__APP_PASSWORD to enable email sending."
            )

    @property
    def is_configured(self) -> bool:
        """Check if email service is properly configured."""
        return bool(self._sender_email and self._app_password)

    def _create_smtp_connection(self) -> smtplib.SMTP:
        """Create and authenticate SMTP connection."""
        server = smtplib.SMTP(self._smtp_host, self._smtp_port)

        if self._use_tls:
            server.starttls()

        server.login(self._sender_email, self._app_password)
        return server

    def send_email(
        self,
        to_email: str,
        template: EmailTemplate,
        reply_to: Optional[str] = None,
    ) -> bool:
        """
        Send an email using a template.

        Args:
            to_email: Recipient email address
            template: EmailTemplate with subject and HTML body
            reply_to: Optional reply-to address

        Returns:
            True if sent successfully, False otherwise
        """
        if not self.is_configured:
            logger.error("Email service not configured. Cannot send email.")
            return False

        try:
            # Create message
            msg = MIMEMultipart("alternative")
            msg["Subject"] = template.subject
            msg["From"] = f"{self._sender_name} <{self._sender_email}>"
            msg["To"] = to_email

            if reply_to:
                msg["Reply-To"] = reply_to

            # Attach HTML body
            html_part = MIMEText(template.html_body, "html", "utf-8")
            msg.attach(html_part)

            # Send email
            with self._create_smtp_connection() as server:
                server.sendmail(
                    self._sender_email,
                    to_email,
                    msg.as_string(),
                )

            logger.info(f"Email sent successfully to {to_email}: {template.subject}")
            return True

        except smtplib.SMTPAuthenticationError as e:
            logger.error(f"SMTP authentication failed: {e}")
            return False
        except smtplib.SMTPException as e:
            logger.error(f"SMTP error sending email to {to_email}: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error sending email to {to_email}: {e}")
            return False

    @staticmethod
    def generate_login_code() -> str:
        """
        Generate a 6-digit login code.

        Returns:
            6-digit numeric string
        """
        return "".join(random.choices(string.digits, k=6))

    @staticmethod
    def generate_user_id_from_email(email: str) -> str:
        """
        Generate a deterministic UUID from email address.

        Uses UUID v5 with DNS namespace for consistency.
        Same email always produces same UUID.

        Args:
            email: Email address

        Returns:
            UUID string
        """
        return str(uuid.uuid5(uuid.NAMESPACE_DNS, email.lower().strip()))

    async def send_login_code(
        self,
        email: str,
        db_pool: Any = None,
        template_kwargs: dict | None = None,
    ) -> dict:
        """
        Send a login code to an email address.

        This method:
        1. Generates a 6-digit login code
        2. Upserts the user by email (creates if not exists, using hashed email for ID)
        3. Stores the code and expiry in user metadata
        4. Sends the code via email

        Args:
            email: User's email address
            db_pool: Database connection pool (asyncpg)
            template_kwargs: Additional arguments for template customization

        Returns:
            Dict with status and details:
            {
                "success": bool,
                "email": str,
                "user_id": str,
                "code_sent": bool,
                "expires_at": str (ISO format),
                "error": str (if failed)
            }
        """
        email = email.lower().strip()
        code = self.generate_login_code()
        user_id = self.generate_user_id_from_email(email)
        expires_at = datetime.now(timezone.utc) + timedelta(
            minutes=self._login_code_expiry_minutes
        )

        result = {
            "success": False,
            "email": email,
            "user_id": user_id,
            "code_sent": False,
            "expires_at": expires_at.isoformat(),
        }

        # Upsert user and store login code in metadata
        if db_pool:
            try:
                await self._upsert_user_login_code(
                    db_pool=db_pool,
                    email=email,
                    user_id=user_id,
                    code=code,
                    expires_at=expires_at,
                )
            except Exception as e:
                logger.error(f"Failed to upsert user login code: {e}")
                result["error"] = "Failed to store login code"
                return result

        # Send the email
        kwargs = template_kwargs or {}
        template = login_code_template(code=code, email=email, **kwargs)
        sent = self.send_email(to_email=email, template=template)

        if sent:
            result["success"] = True
            result["code_sent"] = True
            logger.info(
                f"Login code sent to {email}, "
                f"user_id={user_id}, expires at {expires_at.isoformat()}"
            )
        else:
            result["error"] = "Failed to send email"

        return result

    async def _upsert_user_login_code(
        self,
        db_pool: Any,
        email: str,
        user_id: str,
        code: str,
        expires_at: datetime,
    ) -> None:
        """
        Upsert user and store login code in metadata.

        Creates user if not exists (using deterministic UUID from email).
        Updates metadata with login challenge.

        Args:
            db_pool: Database connection pool
            email: User's email
            user_id: Deterministic UUID from email
            code: Generated login code
            expires_at: Code expiration datetime
        """
        import json

        now = datetime.now(timezone.utc)
        metadata = {
            "login_code": code,
            "login_code_expires_at": expires_at.isoformat(),
            "login_code_sent_at": now.isoformat(),
        }

        async with db_pool.acquire() as conn:
            # Upsert user by email, update metadata with login code
            # Uses deterministic UUID from email as the ID
            await conn.execute(
                """
                INSERT INTO users (id, email, metadata, created_at, updated_at)
                VALUES ($1, $2, $3, $4, $4)
                ON CONFLICT (email) DO UPDATE SET
                    metadata = COALESCE(users.metadata, '{}'::jsonb) || $3::jsonb,
                    updated_at = $4
                """,
                uuid.UUID(user_id),
                email,
                json.dumps(metadata),
                now,
            )

    async def verify_login_code(
        self,
        email: str,
        code: str,
        db_pool: Any,
    ) -> dict:
        """
        Verify a login code for an email address.

        On success, clears the code from metadata and returns user info.

        Args:
            email: User's email address
            code: The login code to verify
            db_pool: Database connection pool

        Returns:
            Dict with verification result:
            {
                "valid": bool,
                "user_id": str (if valid),
                "email": str,
                "error": str (if invalid)
            }
        """
        email = email.lower().strip()
        result = {
            "valid": False,
            "email": email,
        }

        try:
            async with db_pool.acquire() as conn:
                row = await conn.fetchrow(
                    """
                    SELECT id, metadata
                    FROM users
                    WHERE email = $1
                    """,
                    email,
                )

                if not row:
                    result["error"] = "User not found"
                    return result

                metadata = row["metadata"] or {}
                stored_code = metadata.get("login_code")
                expires_at_str = metadata.get("login_code_expires_at")

                if not stored_code or not expires_at_str:
                    result["error"] = "No login code requested"
                    return result

                # Check expiration
                expires_at = datetime.fromisoformat(expires_at_str)
                if datetime.now(timezone.utc) > expires_at:
                    result["error"] = "Login code expired"
                    return result

                # Check code match
                if stored_code != code:
                    result["error"] = "Invalid login code"
                    return result

                # Code is valid - clear it from metadata
                await conn.execute(
                    """
                    UPDATE users
                    SET metadata = metadata - 'login_code' - 'login_code_expires_at' - 'login_code_sent_at',
                        updated_at = NOW()
                    WHERE email = $1
                    """,
                    email,
                )

                result["valid"] = True
                result["user_id"] = str(row["id"])
                logger.info(f"Login code verified for {email}, user_id={result['user_id']}")

        except Exception as e:
            logger.error(f"Error verifying login code: {e}")
            result["error"] = "Verification failed"

        return result

    async def send_welcome_email(
        self,
        email: str,
        name: Optional[str] = None,
        template_kwargs: dict | None = None,
    ) -> bool:
        """
        Send a welcome email to a new user.

        Args:
            email: User's email address
            name: Optional user's name
            template_kwargs: Additional arguments for template customization

        Returns:
            True if sent successfully
        """
        kwargs = template_kwargs or {}
        template = welcome_template(name=name, **kwargs)
        return self.send_email(to_email=email, template=template)
