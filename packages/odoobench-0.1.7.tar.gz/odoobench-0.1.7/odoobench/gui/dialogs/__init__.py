"""GUI dialogs for OdooBench"""
