if bold == 1:
                print("\033[1m", end="")
            if underline == 1:
                print("\033[4m", end="")