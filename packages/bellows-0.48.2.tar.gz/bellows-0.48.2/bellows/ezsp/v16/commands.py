from ..v14.commands import COMMANDS as COMMANDS_v14

COMMANDS = {
    **COMMANDS_v14,
}
