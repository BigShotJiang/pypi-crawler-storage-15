#!/usr/bin/env python3
"""
解析 H.264 索引文件（temp.vid）
"""
import struct
import sys

def parse_index_file(index_path):
    """
    解析索引文件，返回所有关键帧信息

    Returns:
        list of dict: [{'offset': int, 'length': int}, ...]
    """
    entries = []

    with open(index_path, 'rb') as f:
        while True:
            # 每次读取 8 字节（4 bytes offset + 4 bytes length）
            data = f.read(8)
            if len(data) < 8:
                break

            # 使用小端序解析两个 uint32
            offset, length = struct.unpack('<II', data)
            entries.append({
                'offset': offset,
                'length': length
            })

    return entries

def print_index_info(index_path):
    """打印索引文件的信息"""
    entries = parse_index_file(index_path)

    print(f"索引文件: {index_path}")
    print(f"总关键帧数: {len(entries)}")
    print(f"\n{'序号':<6} {'偏移量 (字节)':<15} {'长度 (字节)':<15} {'结束位置':<15}")
    print("-" * 60)

    for i, entry in enumerate(entries):
        end_pos = entry['offset'] + entry['length']
        print(f"{i+1:<6} {entry['offset']:<15,} {entry['length']:<15,} {end_pos:<15,}")

def extract_keyframe(h264_path, index_path, keyframe_num, output_path):
    """
    提取指定的关键帧片段

    Args:
        h264_path: 原始 H.264 文件路径
        index_path: 索引文件路径
        keyframe_num: 关键帧编号（从1开始）
        output_path: 输出文件路径
    """
    entries = parse_index_file(index_path)

    if keyframe_num < 1 or keyframe_num > len(entries):
        print(f"错误: 关键帧编号必须在 1-{len(entries)} 之间")
        return False

    entry = entries[keyframe_num - 1]

    with open(h264_path, 'rb') as infile:
        infile.seek(entry['offset'])
        data = infile.read(entry['length'])

        with open(output_path, 'wb') as outfile:
            outfile.write(data)

    print(f"成功提取关键帧 #{keyframe_num}")
    print(f"  偏移: {entry['offset']:,} 字节")
    print(f"  长度: {entry['length']:,} 字节")
    print(f"  输出: {output_path}")
    return True

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法:")
        print(f"  查看索引: {sys.argv[0]} <index_file>")
        print(f"  提取关键帧: {sys.argv[0]} <index_file> <h264_file> <keyframe_num> <output_file>")
        sys.exit(1)

    index_file = sys.argv[1]

    if len(sys.argv) == 2:
        # 只查看索引
        print_index_info(index_file)
    elif len(sys.argv) == 5:
        # 提取关键帧
        h264_file = sys.argv[2]
        keyframe_num = int(sys.argv[3])
        output_file = sys.argv[4]
        extract_keyframe(h264_file, index_file, keyframe_num, output_file)
    else:
        print("参数错误")
        sys.exit(1)
