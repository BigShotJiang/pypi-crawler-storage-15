import hashlib
import os
import shutil
import subprocess
from loguru import logger
import h264indexer

# 配置
ANI_MODE_V0 = 0
ANI_MODE_V2 = 1
CURRENT_ANI_MODE = ANI_MODE_V0

def reverse_first_bytes(file_path, bytes_count=4096):
    """
    修复后的反转字节逻辑。
    原代码中 (~b 1 1 1...) 看起来是反编译错误，通常这是简单的按位取反。
    """
    try:
        file_size = os.path.getsize(file_path)
        # 如果文件太小，只处理实际大小
        actual_bytes = min(file_size, bytes_count)

        with open(file_path, 'r+b') as f:
            data = f.read(actual_bytes)
            # 执行按位取反 (~x & 0xFF)
            inverted = bytes((~b & 0xFF) for b in data)
            f.seek(0)
            f.write(inverted)
        return True
    except Exception as e:
        print(f"Error in reverse_first_bytes: {e}")
        return False

def generate_idx_from_filesize(file_size):
    size_bytes = str(file_size).encode('utf-8')
    return hashlib.sha512(size_bytes).digest()

def process_video_conversion(input_path: str, output_path: str, work_dir: str):
    """核心转换函数，适配 Linux 环境"""

    # 1. 路径配置
    ffmpeg_cmd = "ffmpeg" # Linux 下直接使用系统 ffmpeg
    makeidx_cmd = ["wine", "/app/bin/MakeIdx.exe"] # 使用 Wine 运行 exe

    vid_output_path = os.path.join(work_dir, "temp.vid")
    final_ani_path = output_path

    # 2. FFmpeg 转换 (生成裸流 .vid)
    # 参数参考原代码，去掉了 GUI 相关的变量
    cmd = [
        ffmpeg_cmd,
        '-i', input_path,
        '-vf', 'scale=240:240,fps=20',
        '-r', '20',
        '-c:v', 'libx264',
        '-preset', 'fast',
        '-tune', 'fastdecode',
        '-profile:v', 'baseline',
        '-level', '3.0',
        '-crf', '25',
        '-x264-params', 'ref=0:scenecut=40:bframes=0:fps=20',
        '-pix_fmt', 'yuv420p',
        '-f', 'h264',
        '-an',
        '-y',
        vid_output_path
    ]

    print(f"Running FFmpeg: {' '.join(cmd)}")
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode != 0:
        raise Exception(f"FFmpeg conversion failed: {result.stderr.decode()}")

    # 3. 生成 Index (调用 MakeIdx.exe)
    idx_content = None
    if CURRENT_ANI_MODE == ANI_MODE_V0:
        idx_output_path = os.path.join(work_dir, "temp.idx")

        # 调用 Wine 运行 MakeIdx.exe
        # MakeIdx.exe 用法推测: MakeIdx.exe <input_vid> <output_idx>
        idx_cmd = makeidx_cmd + [vid_output_path, idx_output_path]

        print(f"Running MakeIdx: {' '.join(idx_cmd)}")
        idx_res = subprocess.run(idx_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        if idx_res.returncode == 0 and os.path.exists(idx_output_path):
            with open(idx_output_path, 'rb') as f:
                idx_content = f.read()
        else:
            # 如果 Wine 调用失败，尝试回退到文件大小哈希方案（原代码线索）
            print(f"Warning: MakeIdx failed ({idx_res.stderr.decode()}), falling back to hash.")
            idx_content = generate_idx_from_filesize(os.path.getsize(vid_output_path))
    else:
        idx_content = generate_idx_from_filesize(os.path.getsize(vid_output_path))

    # 4. 打包 ANI 文件
    vid_size = os.path.getsize(vid_output_path)
    idx_size = len(idx_content)

    with open(final_ani_path, 'wb') as img_file:
        # Header
        img_file.write(b'ANI0') # Assuming V0
        img_file.write((20).to_bytes(4, byteorder='little')) # FPS
        img_file.write(idx_size.to_bytes(4, byteorder='little'))

        vid_position = 20 + idx_size
        img_file.write(vid_position.to_bytes(4, byteorder='little'))
        img_file.write(vid_size.to_bytes(4, byteorder='little'))
        img_file.write((20).to_bytes(4, byteorder='little')) # vid_fps

        # Content
        img_file.write(idx_content)
        with open(vid_output_path, 'rb') as vid_file:
            shutil.copyfileobj(vid_file, img_file)

    # 5. 后处理 (反转字节混淆)
    total_size = os.path.getsize(final_ani_path)
    reverse_first_bytes(final_ani_path, total_size) # 原代码逻辑似乎传的是 total_size 或固定 4096，这里需注意

    return final_ani_path


def process_conversion_opt(input_path: str, output_path: str, work_dir: str):
    # 1. 路径配置
    ffmpeg_cmd = "ffmpeg"

    vid_output_path = os.path.join(work_dir, "temp.vid")
    final_ani_path = output_path
    # 参数参考原代码，去掉了 GUI 相关的变量
    cmd = [
        ffmpeg_cmd,
        '-i', input_path,
        '-vf', 'scale=240:240,fps=20',
        '-r', '20',
        '-c:v', 'libx264',
        '-preset', 'fast',
        '-tune', 'fastdecode',
        '-profile:v', 'baseline',
        '-level', '3.0',
        '-crf', '25',
        '-x264-params', 'ref=0:scenecut=40:bframes=0:fps=20',
        '-pix_fmt', 'yuv420p',
        '-f', 'h264',
        '-an',
        '-y',
        vid_output_path
    ]

    # print(f"Running FFmpeg: {' '.join(cmd)}")
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode != 0:
        raise Exception(f"FFmpeg conversion failed: {result.stderr.decode()}")
    logger.info(f'after ffmpeg file size:{os.path.getsize(vid_output_path)}')
    idx_content = None
    if CURRENT_ANI_MODE == ANI_MODE_V0:
        idx_output_path = os.path.join(work_dir, "temp.idx")
        flag = h264indexer.make_index(vid_output_path, idx_output_path)
        logger.info(f'idx_output_path={idx_output_path}, flag={flag}')
        if flag and os.path.exists(idx_output_path):
            with open(idx_output_path, 'rb') as f:
                idx_content = f.read()
        else:
            print(f"Warning: MakeIdx failed, falling back to hash.")
            idx_content = generate_idx_from_filesize(os.path.getsize(vid_output_path))
    else:
        idx_content = generate_idx_from_filesize(os.path.getsize(vid_output_path))
    vid_size = os.path.getsize(vid_output_path)
    idx_size = len(idx_content)

    with open(final_ani_path, 'wb') as img_file:
        # Header
        img_file.write(b'ANI0')  # Assuming V0
        img_file.write((20).to_bytes(4, byteorder='little'))  # FPS
        img_file.write(idx_size.to_bytes(4, byteorder='little'))

        vid_position = 20 + idx_size
        img_file.write(vid_position.to_bytes(4, byteorder='little'))
        img_file.write(vid_size.to_bytes(4, byteorder='little'))
        img_file.write((20).to_bytes(4, byteorder='little'))  # vid_fps

        # Content
        img_file.write(idx_content)
        with open(vid_output_path, 'rb') as vid_file:
            shutil.copyfileobj(vid_file, img_file)

    # 5. 后处理 (反转字节混淆)
    total_size = os.path.getsize(final_ani_path)
    logger.info(f'before fixed first_byte size: {total_size}')
    reverse_first_bytes(final_ani_path, total_size)
    logger.success(f'after process filesize:{os.path.getsize(final_ani_path)}')
    return final_ani_path