# H.264 Index Generator (MakeIndex)

这是一个用于生成 H.264 视频文件索引 (.idx) 的工具。它通过扫描视频文件中的关键帧 (IDR Frame)，记录每一帧的偏移量和长度，生成的索引文件可用于视频播放器的快速定位和拖动。

## 🚀 项目背景
本项目是对一个早期 11KB 大小的 MFC 工具 (`MakeIndex.exe`) 的**现代 C++ 重构版本**。
原版工具虽然体积小巧，但存在缓冲区过小 (1KB) 导致的丢帧风险，且无法跨平台运行。重构后的版本不仅修复了潜在 Bug，还支持编译为 **Windows/Linux CLI**、**Python 扩展** 以及 **WebAssembly (WASM)**。

## 📂 项目结构
*   `src/H264Indexer.hpp`: 核心算法实现 (Header-only C++17)。
*   `src/main.cpp`: 命令行工具入口。
*   `src/bindings.cpp`: Python 绑定 (pybind11)。
*   `src/wasm_bindings.cpp`: WebAssembly 绑定 (Emscripten)。
*   `CMakeLists.txt`: 构建脚本，支持多种构建目标。

## 🛠️ 核心逻辑与改进

### 算法逻辑
1.  **遍历文件**: 以流式方式读取 `.h264` 文件。
2.  **查找 Start Code**: 寻找 `00 00 01` 或 `00 00 00 01` 序列。
3.  **识别 NAL Unit**: 解析 Start Code 后的 NAL Header，识别 `Type 5 (IDR Slice)`。
4.  **记录索引**: 当发现 IDR 帧时，计算上一帧的长度，并将当前帧的 **Offset (4字节)** 和 **Length (4字节)** 写入输出文件。

### ⚡ 改进点 (对比原版)
*   **缓冲区优化**: 将缓冲区从原版的 **1KB** 提升至 **1MB**，大幅减少 I/O 调用次数。
*   **边界处理**: 增加了跨缓冲区边界处理逻辑 (Boundary Handling)，解决了原版在 Start Code 跨越缓冲区时可能漏掉关键帧的 Bug。
*   **跨平台**: 移除 MFC 依赖，使用标准 C++17 (`std::filesystem` 等)，支持所有主流操作系统。

## 📦 编译与使用

### A. 编译为命令行工具 (CLI)
适用于 Windows, macOS, Linux。

**前置要求**: CMake 3.10+, C++17 编译器 (GCC/Clang/MSVC)

```bash
mkdir build && cd build
cmake ..
cmake --build .

# 使用
./makeindex input.h264 out.idx
```

### B. 编译为 Python 扩展
让 Python 代码直接调用 C++ 核心逻辑。

**前置要求**: Python 3, `pip install pybind11`

方法 1: 使用 CMake (推荐开发用)
取消 `CMakeLists.txt` 中 Python 部分的注释并编译。

方法 2: 使用 `setup.py` (推荐安装用)
创建一个 `setup.py` 文件（如下），然后运行安装。

```python
from setuptools import setup, Extension
import pybind11

ext_modules = [
    Extension(
        "h264indexer",
        ["src/bindings.cpp"],
        include_dirs=[pybind11.get_include()],
        language='c++'
    ),
]

setup(name="h264indexer", ext_modules=ext_modules)
```

```bash
pip install .
```

### C. 编译为 WebAssembly (JS/Web)
适用于浏览器或 Node.js 环境。

**前置要求**: [Emscripten SDK](https://emscripten.org/docs/getting_started/downloads.html)

```bash
emcmake cmake ..
emmake make
```

这将生成 `makeindex_wasm.js` 和 `makeindex_wasm.wasm`。

**JavaScript 调用示例**:
```javascript
const Module = require('./makeindex_wasm.js');

Module.onRuntimeInitialized = () => {
  const fs = require('fs');
  // 1. 将本地文件写入 WASM 虚拟文件系统
  const data = fs.readFileSync('test.h264');
  Module.FS.writeFile('/input.h264', data);

  // 2. 调用 C++ 函数生成索引
  // int wasm_make_index(const char* in, const char* out)
  const result = Module.ccall(
    'wasm_make_index',     // C++ 函数名
    'number',              // 返回值类型
    ['string', 'string'],  // 参数类型
    ['/input.h264', '/output.idx'] // 参数值
  );

  if (result === 0) {
    // 3. 从虚拟文件系统读取生成的索引
    const idxData = Module.FS.readFile('/output.idx');
    fs.writeFileSync('local_out.idx', idxData);
    console.log('Index generated successfully!');
  }
};
```
