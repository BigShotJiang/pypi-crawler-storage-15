# H264 Indexer - Python Module Release

## Package Information
- **Version**: 1.0.0
- **Python Version**: Python 3.10+ (Windows x64)
- **Package Name**: `h264indexer-1.0.0-cp310-cp310-win_amd64.whl`

## Installation

```bash
pip install dist/h264indexer-1.0.0-cp310-cp310-win_amd64.whl
```

## Usage

```python
import h264indexer

# Generate index for H.264 video file
result = h264indexer.make_index("input.h264", "output.idx")

if result:
    print("Index created successfully!")
else:
    print("Failed to create index")
```

## Function Reference

### `make_index(input_path, output_path)`

Generate an index file for H.264 video stream.

**Parameters:**
- `input_path` (str): Path to input H.264 raw stream file
- `output_path` (str): Path to output index file (.idx)

**Returns:**
- `bool`: `True` if index was created successfully, `False` otherwise

**Index Format:**
- Binary file containing index entries
- Each entry: 8 bytes (4 bytes offset + 4 bytes length)
- Index boundaries: IDR frame to SPS/PPS/SEI parameter sets

## Example

```python
import h264indexer
import os

# Check if input file exists
if not os.path.exists("video.h264"):
    print("Error: Input file not found")
    exit(1)

# Generate index
success = h264indexer.make_index("video.h264", "video.idx")

if success:
    # Check index file size
    idx_size = os.path.getsize("video.idx")
    num_entries = idx_size // 8
    print(f"Index created with {num_entries} entries")
else:
    print("Failed to create index")
```

## Index File Structure

The generated index file contains:
- **Entry format**: `[offset: uint32][length: uint32]`
- **Offset**: Byte position of IDR frame in source file
- **Length**: Bytes from IDR to next parameter set (SPS/PPS/SEI)

## Technical Details

### Indexed NALU Types
- **Type 5 (IDR)**: I-frame (keyframe) - start position recorded
- **Type 6 (SEI)**: Supplemental Enhancement Information
- **Type 7 (SPS)**: Sequence Parameter Set
- **Type 8 (PPS)**: Picture Parameter Set

### Index Boundary Logic
```
File: [IDR] [P-frames] [SPS] [PPS] [IDR] [P-frames] [SPS] [PPS]
Index: ^-----------------^          ^-----------------^
       Entry 1                      Entry 2
```

Each index entry spans from IDR frame to the next parameter set, ensuring each segment contains necessary decoding information.

## Build from Source

If you need to rebuild the module:

```bash
# Install dependencies
pip install pybind11

# Build in-place
python setup.py build_ext --inplace

# Create wheel package
python setup.py bdist_wheel
```

## System Requirements

- Windows x64
- Python 3.10+
- Microsoft Visual C++ Redistributable (usually pre-installed)

## Troubleshooting

### Import Error
```
ImportError: DLL load failed
```
**Solution**: Install Microsoft Visual C++ Redistributable for Visual Studio 2022

### File Not Found
```
Error: Cannot open input file
```
**Solution**: Ensure input file path is correct and file exists. Use absolute paths if needed.

### Invalid Index
If generated index doesn't work properly:
- Verify input is H.264 raw stream (not MP4/MKV container)
- Check file contains IDR frames
- Ensure file is not corrupted

## Version History

### 1.0.0 (2025-12-02)
- Initial release
- Fixed NALU type detection logic
- Index boundaries aligned with parameter sets (Type 6/7/8)
- Improved from original C implementation

## License

See project LICENSE file for details.
