#!/usr/bin/env python3
"""
ANI 文件解析工具
用于解析由 core.py 生成的 .ani 文件，提取视频和索引信息
"""

import os
import struct
import argparse
from pathlib import Path


class ANIParser:
    """ANI 文件解析器"""

    def __init__(self, file_path):
        self.file_path = file_path
        self.magic = None
        self.fps = None
        self.idx_size = None
        self.vid_position = None
        self.vid_size = None
        self.vid_fps = None
        self.idx_content = None
        self.vid_content = None

    def reverse_bytes(self, data):
        """反转字节（按位取反）"""
        return bytes((~b & 0xFF) for b in data)

    def parse(self):
        """解析 ANI 文件"""
        print(f"正在解析文件: {self.file_path}")

        # 读取整个文件
        with open(self.file_path, 'rb') as f:
            encrypted_data = f.read()

        print(f"文件大小: {len(encrypted_data)} 字节")

        # 反转字节（解密）
        print("正在解密数据...")
        decrypted_data = self.reverse_bytes(encrypted_data)

        # 解析头部（20字节）
        if len(decrypted_data) < 20:
            raise ValueError("文件太小，无法解析头部")

        header = decrypted_data[:20]

        # 解析魔术字
        self.magic = header[0:4].decode('ascii', errors='ignore')
        print(f"魔术字: {self.magic}")

        if self.magic != 'ANI0':
            print(f"警告: 魔术字不匹配，期望 'ANI0'，实际 '{self.magic}'")

        # 解析其他头部字段（小端序）
        self.fps = struct.unpack('<I', header[4:8])[0]
        self.idx_size = struct.unpack('<I', header[8:12])[0]
        self.vid_position = struct.unpack('<I', header[12:16])[0]
        self.vid_size = struct.unpack('<I', header[16:20])[0]

        # 注意：原代码在20字节头部后还写入了一个vid_fps，但实际上头部只有20字节
        # 这里我们假设头部就是20字节，vid_fps实际上是第二个FPS字段

        print(f"FPS: {self.fps}")
        print(f"索引大小: {self.idx_size} 字节")
        print(f"视频位置: {self.vid_position}")
        print(f"视频大小: {self.vid_size} 字节")

        # 验证数据完整性
        if self.vid_position != 20 + self.idx_size:
            print(f"警告: 视频位置不匹配，期望 {20 + self.idx_size}，实际 {self.vid_position}")

        if len(decrypted_data) < self.vid_position + self.vid_size:
            raise ValueError(f"文件数据不完整，期望至少 {self.vid_position + self.vid_size} 字节")

        # 提取索引数据
        self.idx_content = decrypted_data[20:20 + self.idx_size]
        print(f"已提取索引数据: {len(self.idx_content)} 字节")

        # 提取视频数据
        self.vid_content = decrypted_data[self.vid_position:self.vid_position + self.vid_size]
        print(f"已提取视频数据: {len(self.vid_content)} 字节")

        return True

    def save_index(self, output_path):
        """保存索引数据"""
        if self.idx_content is None:
            raise ValueError("索引数据未解析，请先调用 parse()")

        with open(output_path, 'wb') as f:
            f.write(self.idx_content)
        print(f"索引数据已保存到: {output_path}")

    def save_video(self, output_path):
        """保存视频数据（H.264裸流）"""
        if self.vid_content is None:
            raise ValueError("视频数据未解析，请先调用 parse()")

        with open(output_path, 'wb') as f:
            f.write(self.vid_content)
        print(f"视频数据已保存到: {output_path}")

    def generate_report(self, output_path):
        """生成文本报告"""
        if self.magic is None:
            raise ValueError("文件未解析，请先调用 parse()")

        report = []
        report.append("=" * 60)
        report.append("ANI 文件解析报告")
        report.append("=" * 60)
        report.append(f"文件路径: {self.file_path}")
        report.append(f"文件大小: {os.path.getsize(self.file_path)} 字节")
        report.append("")
        report.append("--- 头部信息 ---")
        report.append(f"魔术字: {self.magic}")
        report.append(f"FPS: {self.fps}")
        report.append(f"索引大小: {self.idx_size} 字节")
        report.append(f"视频位置: {self.vid_position}")
        report.append(f"视频大小: {self.vid_size} 字节")
        report.append("")
        report.append("--- 数据信息 ---")
        report.append(f"索引数据: {len(self.idx_content)} 字节")
        report.append(f"视频数据: {len(self.vid_content)} 字节")
        report.append("")

        # 显示索引数据的前128字节（十六进制）
        if self.idx_content:
            report.append("--- 索引数据预览（前128字节，十六进制）---")
            preview_size = min(128, len(self.idx_content))
            hex_lines = []
            for i in range(0, preview_size, 16):
                chunk = self.idx_content[i:i+16]
                hex_part = ' '.join(f'{b:02x}' for b in chunk)
                ascii_part = ''.join(chr(b) if 32 <= b < 127 else '.' for b in chunk)
                hex_lines.append(f"{i:08x}  {hex_part:<48}  {ascii_part}")
            report.extend(hex_lines)
            report.append("")

        # 显示视频数据的前128字节（十六进制）
        if self.vid_content:
            report.append("--- 视频数据预览（前128字节，十六进制）---")
            preview_size = min(128, len(self.vid_content))
            hex_lines = []
            for i in range(0, preview_size, 16):
                chunk = self.vid_content[i:i+16]
                hex_part = ' '.join(f'{b:02x}' for b in chunk)
                ascii_part = ''.join(chr(b) if 32 <= b < 127 else '.' for b in chunk)
                hex_lines.append(f"{i:08x}  {hex_part:<48}  {ascii_part}")
            report.extend(hex_lines)
            report.append("")

        report.append("=" * 60)
        report.append("解析完成")
        report.append("=" * 60)

        report_text = '\n'.join(report)

        # 保存到文件
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(report_text)

        print(f"报告已保存到: {output_path}")

        # 同时打印到控制台
        print("\n" + report_text)

        return report_text


def main():
    parser = argparse.ArgumentParser(
        description='ANI 文件解析工具 - 解析由 core.py 生成的 .ani 文件',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例用法:
  # 解析 ANI 文件并生成报告
  python ani_parser.py 1.ani

  # 解析并提取视频和索引
  python ani_parser.py 1.ani --extract-video output.h264 --extract-index output.idx

  # 自定义报告输出路径
  python ani_parser.py 1.ani --report report.txt
        """
    )

    parser.add_argument('input', help='输入的 ANI 文件路径')
    parser.add_argument('--report', '-r',
                        help='报告输出路径（默认：<输入文件名>_report.txt）')
    parser.add_argument('--extract-video', '-v',
                        help='提取视频数据到指定文件（H.264裸流）')
    parser.add_argument('--extract-index', '-i',
                        help='提取索引数据到指定文件')

    args = parser.parse_args()

    # 检查输入文件
    if not os.path.exists(args.input):
        print(f"错误: 文件不存在: {args.input}")
        return 1

    # 设置默认报告路径
    if args.report is None:
        input_path = Path(args.input)
        args.report = input_path.with_suffix('').with_suffix('.txt').name + '_report.txt'

    try:
        # 创建解析器并解析文件
        ani = ANIParser(args.input)
        ani.parse()

        # 生成报告
        ani.generate_report(args.report)

        # 提取视频数据
        if args.extract_video:
            ani.save_video(args.extract_video)

        # 提取索引数据
        if args.extract_index:
            ani.save_index(args.extract_index)

        print("\n✓ 解析成功完成！")
        return 0

    except Exception as e:
        print(f"\n✗ 解析失败: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == '__main__':
    exit(main())
