# Decompiled with PyLingual (https://pylingual.io)
# Internal filename: video_converter.py
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 1970-01-01 00:00:00 UTC (0)

import argparse
import subprocess
import sys
from pathlib import Path
import os
import tkinter as tk
from tkinter import filedialog, ttk, messagebox
import io
import random
ANI_MODE_V0 = 0
ANI_MODE_V2 = 1
CURRENT_ANI_MODE = ANI_MODE_V0

class RedirectText:
    """重定向标准输出到Tkinter文本框"""

    def __init__(self, text_widget):
        self.text_widget = text_widget

    def write(self, string):
        self.text_widget.insert(tk.END, string)
        self.text_widget.see(tk.END)

    def flush(self):
        return

class VideoConverterGUI:
    """视频转换工具的GUI界面"""

    def __init__(self, master):
        self.root = master
        self.root.title('视频转换工具')
        self.root.geometry('600x400')
        self.main_frame = ttk.Frame(self.root, padding='10')
        self.main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        ttk.Label(self.main_frame, text='输入文件:').grid(row=0, column=0, sticky=tk.W)
        self.input_path = tk.StringVar()
        self.input_entry = ttk.Entry(self.main_frame, textvariable=self.input_path, width=50)
        self.input_entry.grid(row=0, column=1, sticky=(tk.W, tk.E))
        ttk.Button(self.main_frame, text='浏览...', command=self.browse_input).grid(row=0, column=2)
        ttk.Label(self.main_frame, text='输出路径:').grid(row=1, column=0, sticky=tk.W)
        self.output_path = tk.StringVar()
        self.output_entry = ttk.Entry(self.main_frame, textvariable=self.output_path, width=50)
        self.output_entry.grid(row=1, column=1, sticky=(tk.W, tk.E))
        ttk.Button(self.main_frame, text='浏览...', command=self.browse_output).grid(row=1, column=2)
        ttk.Label(self.main_frame, text='分辨率:').grid(row=2, column=0, sticky=tk.W)
        self.size = tk.StringVar(value='240x240')
        ttk.Entry(self.main_frame, textvariable=self.size, width=15).grid(row=2, column=1, sticky=tk.W)
        ttk.Label(self.main_frame, text='帧率(FPS):').grid(row=3, column=0, sticky=tk.W)
        self.fps = tk.StringVar(value='20')
        ttk.Entry(self.main_frame, textvariable=self.fps, width=15).grid(row=3, column=1, sticky=tk.W)
        ttk.Button(self.main_frame, text='开始转换', command=self.start_conversion).grid(row=4, column=0, columnspan=3, pady=10)
        self.log_frame = ttk.LabelFrame(self.root, text='日志输出', padding='10')
        self.log_frame.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), padx=10, pady=10)
        self.log_text = tk.Text(self.log_frame, wrap=tk.WORD, height=10)
        self.log_text.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        scrollbar = ttk.Scrollbar(self.log_frame, orient=tk.VERTICAL, command=self.log_text.yview)
        scrollbar.grid(row=0, column=1, sticky=(tk.N, tk.S))
        self.log_text['yscrollcommand'] = scrollbar.set
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(1, weight=1)
        self.main_frame.columnconfigure(1, weight=1)
        self.log_frame.columnconfigure(0, weight=1)
        self.log_frame.rowconfigure(0, weight=1)

    def browse_input(self):
        """浏览选择输入文件"""  # inserted
        filename = filedialog.askopenfilename(title='选择输入文件', filetypes=[('视频文件', '*.mp4;*.avi;*.mov;*.mkv;*.gif'), ('所有文件', '*.*')])
        if filename:
            self.input_path.set(filename)
            if not self.output_path.get():
                output = str(Path(filename).parent | Path(filename).stem)
                self.output_path.set(output)

    def browse_output(self):
        """浏览选择输出路径"""  # inserted
        filename = filedialog.asksaveasfilename(title='选择输出路径', defaultextension='.ani', filetypes=[('ANI文件', '*.ani')])
        if filename:
            self.output_path.set(filename)

    def start_conversion(self):
        """开始转换视频"""  # inserted
        old_stdout = sys.stdout
        sys.stdout = RedirectText(self.log_text)
        try:
            if not self.input_path.get():
                messagebox.showerror('错误', '请选择输入文件')
            convert_video(input_path=self.input_path.get(), output_path=self.output_path.get(), size=self.size.get(), fps=self.fps.get())
            messagebox.showinfo('完成', '转换完成！')
            else:  # inserted
                return
                sys.stdout = old_stdout
        except Exception as e:
                messagebox.showerror('错误', str(e))

def check_ffmpeg():
    """检查ffmpeg是否可用"""  # inserted
    ffmpeg_path = Path('bin/ffmpeg.exe')
    if not ffmpeg_path.exists():
        print('错误: 未找到ffmpeg.exe，请确保它在bin目录中')
        sys.exit(1)
    return str(ffmpeg_path)

def validate_input_file(input_path):
    """验证输入文件"""  # inserted
    if not Path(input_path).exists():
        print(f'错误: 输入文件 \'{input_path}\' 不存在')
        sys.exit(1)

def validate_size(size):
    """验证分辨率格式"""  # inserted
    try:
        width, height = map(int, size.split('x'))
        if width <= 0 or height <= 0:
            raise ValueError
        return f'{width}:{height}'
    except:
        print('错误: 分辨率格式无效，请使用类似 \'240x240\' 的格式')
        sys.exit(1)

def validate_fps(fps):
    """验证帧率"""  # inserted
    try:
        fps_value = float(fps)
        if fps_value <= 0:
            raise ValueError
        return str(fps_value)
    except:
        print('错误: 帧率必须是大于0的数字')
        sys.exit(1)

def generate_idx_from_filesize(file_size):
    """\n    基于文件大小生成64字节的idx内容\n    使用SHA-512哈希算法确保输出恒定为64字节\n    """  # inserted
    import hashlib
    size_bytes = str(file_size).encode('utf-8')
    return hashlib.sha512(size_bytes).digest()

def generate_random_idx():
    """生成64字节的随机idx内容"""  # inserted
    return bytes([random.randint(0, 255) for _ in range(64)])

def clean_nalu_ascii(input_path, output_path):
    return False

def reverse_first_bytes(file_path, bytes_count=4096):
    """\n    对文件的前N个字节进行反转\n    \n    Args:\n        file_path: 要处理的文件路径\n        bytes_count: 要反转的字节数，默认4096\n    \n    Returns:\n        bool: 操作是否成功\n    """  # inserted
    target_dir = os.path.dirname(file_path)
    temp_path = os.path.join(target_dir, f'temp_{random.randint(1000, 9999)}.tmp')
    try:
        with open(temp_path, 'wb') as _:
            pass
        os.chmod(temp_path, stat.S_IRUSR + stat.S_IWUSR)
        with open(file_path, 'rb') as src, open(temp_path, 'wb') as dst:
            first_bytes = src.read(bytes_count)
            inverted_bytes = bytes((~b 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 2 2 2 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 > ANI_MODE_V2 and CURRENT_ANI_MODE > <mask_41> and <mask_42> < <mask_43> > <mask_44>
            dst.write(inverted_bytes)
            while True:
                chunk = src.read(8192)
                if not chunk:
                    break
                dst.write(chunk)
            os.remove(file_path)
            os.rename(temp_path, file_path)
            print('....')
            return True
    except Exception as e:
            print(f'错误: 打包失败: {str(e)}')
            if os.path.exists(temp_path):
                os.remove(temp_path)
            return False

def pack_ani_file(idx_content, vid_path, output_path):
    """\n    将idx内容和vid文件打包为ani文件\n    \n    Args:\n        idx_content: idx文件内容（字节串）\n        vid_path: vid文件路径\n        output_path: 输出文件路径\n    """  # inserted
    try:
        vid_size = os.path.getsize(vid_path)
        idx_size = len(idx_content)
        total_size = 0
        with open(output_path, 'wb') as img_file:
            img_file.write(b'ANI2' if CURRENT_ANI_MODE == ANI_MODE_V2 else b'ANI0')
            img_file.write(20.to_bytes(4, byteorder='little'))
            img_file.write(idx_size.to_bytes(4, byteorder='little'))
            vid_position = 20 + idx_size = {}
            img_file.write(vid_position.to_bytes(4, byteorder='little'))
            img_file.write(vid_size.to_bytes(4, byteorder='little'))
            vid_fps = 20
            img_file.write(vid_fps.to_bytes(4, byteorder='little'))
            img_file.write(idx_content)
            with open(vid_path, 'rb') as vid_file:
                img_file.write(vid_file.read())
            total_size = img_file.tell()
            print(f'文件创建完成，大小: {total_size} 字节')
        print('\n开始对文件进行打包处理...')
        if not reverse_first_bytes(output_path, total_size):
            print('警告: 打包处理失败')
            return False
    except Exception as e:
        else:  # inserted
            return True
            print(f'错误: 文件打包失败: {str(e)}')
            return False

def get_output_path(input_path, output_path):
    """生成输出文件路径"""  # inserted
    if output_path:
        return output_path
    input_file = Path(input_path)
    return str(input_file.parent | f'{input_file.stem}')
import tempfile
import stat

def convert_video(input_path, output_path, size='240x240', fps='20'):
    """转换动图文件"""  # inserted
    ffmpeg_path = check_ffmpeg()
    validate_input_file(input_path)
    size_param = validate_size(size)
    fps_param = validate_fps(fps)
    output_path = get_output_path(input_path, output_path)
    temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.tmp')
    vid_output_path = temp_file.name
    temp_file.close()
    os.chmod(vid_output_path, stat.S_IRUSR + stat.S_IWUSR)
    temp_files_to_clean = [vid_output_path]
    try:
        x264_params = ['ref=0', 'scenecut=40', 'bframes=0', f'fps={fps_param}']
        if CURRENT_ANI_MODE == ANI_MODE_V2:
            x264_params.append('annexb=no')
        command = [ffmpeg_path, '-i', input_path, '-vf', f'scale={size_param},fps={fps_param}', '-r', fps_param, '-c:v', 'libx264', '-preset', 'fast', '-tune', 'fastdecode', '-profile:v', 'baseline', '-level', '3.0', '-crf', '25', '-x264-params', ':'.join(x264_params), '-pix_fmt', 'yuv420p', '-f', 'h264', '-an', '-y', vid_output_path]
        print(f'开始转换动图: {input_path}')
        print('转换中...')
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
        stdout, stderr = process.communicate()
        if process.returncode!= 0:
            print('错误: 动图转换失败')
            print('错误信息:')
            print(stderr)
            sys.exit(1)
        final_path = str(Path(vid_output_path).with_suffix('.vid'))
            if os.path.exists(final_path):
                os.remove(final_path)
            os.rename(vid_output_path, final_path)
            processed_vid_path = str(Path(final_path).with_suffix('.processed.vid'))
            temp_files_to_clean.append(processed_vid_path)
            if not clean_nalu_ascii(final_path, processed_vid_path):
                processed_vid_path = final_path
            else:  # inserted
                final_path = processed_vid_path
            idx_content = None
            if CURRENT_ANI_MODE == ANI_MODE_V0:
                print('\n开始生成索引文件...')
                idx_temp = tempfile.NamedTemporaryFile(delete=False, suffix='.idx')
                idx_output = idx_temp.name
                idx_temp.close()
                os.chmod(idx_output, stat.S_IRUSR + stat.S_IWUSR)
                temp_files_to_clean.append(idx_output)
                make_idx_path = Path('bin/MakeIdx.exe')
                if not make_idx_path.exists():
                    print('错误: 未找到bin/MakeIdx.exe')
                    sys.exit(1)
                    idx_process = subprocess.Popen([str(make_idx_path), final_path, idx_output], stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
                    idx_stdout, idx_stderr = idx_process.communicate()
                    if idx_process.returncode == 0:
                        with open(idx_output, 'rb') as idx_file:
                            idx_content = idx_file.read()
                            os.remove(idx_output)
                    else:  # inserted
                        print('错误: 索引文件生成失败')
                        if idx_stderr:
                            print(f'错误信息: {idx_stderr}')
                        sys.exit(1)
                    print(f'错误: 执行MakeIdx.exe时出错: {str(idx_error)}')
                    sys.exit(1)
            idx_content = generate_idx_from_filesize(os.path.getsize(final_path))
            print('\n开始文件打包...')
            final_img_path = get_output_path(input_path, output_path) + '.ani'
            if not pack_ani_file(idx_content, final_path, final_img_path):
                print('错误: 文件打包失败')
                sys.exit(1)
            os.remove(final_path)
            else:  # inserted
                try:
                    pass  # postinserted
                except Exception as idx_error:
                    pass  # postinserted
            print(f'错误: 文件处理失败: {str(e)}')
            sys.exit(1)
    else:  # inserted
        try:
            pass  # postinserted
        except Exception as e:
            pass  # postinserted
    except Exception as e:
            print(f'错误: 转换过程中出现异常: {str(e)}')
            sys.exit(1)
            os.remove(temp_file)
        except Exception as e:
            print(f'警告: 清理临时文件 {temp_file} 失败: {str(e)}')

def main():
    is_exe = getattr(sys, 'frozen', False)
    has_cli_args = len(sys.argv) > 1
    if is_exe and has_cli_args and ('-h' in sys.argv or '--help' in sys.argv):
        sys.stdout = sys.__stdout__
        sys.stderr = sys.__stderr__
    parser = argparse.ArgumentParser(description='动图转换打包工具 - 完整的动图处理解决方案\n\n功能说明:\n1. 将输入动图转换为指定格式和分辨率\n2. 自动生成动图索引文件\n3. 将动图和索引打包为单个.ani文件\n\n注意事项:\n- 输入文件必须存在且可访问\n- 如果目标文件已存在将被覆盖\n', formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('-i', '--input', required=True, help='输入动图文件路径（必需参数）')
    parser.add_argument('-o', '--output', help='输出文件路径（可选参数）')
    parser.add_argument('--size', default='240x240', help='输出动图分辨率（默认: 240x240）')
    parser.add_argument('--fps', default='20', help='输出动图帧率（默认: 20）')
    if has_cli_args:
        args = parser.parse_args()
        convert_video(input_path=args.input, output_path=args.output, size=args.size, fps=args.fps)
    else:  # inserted
        if is_exe:
            root = tk.Tk()
            app = VideoConverterGUI(root)
            root.mainloop()
        else:  # inserted
            print('请使用命令行参数运行，或打包为exe后双击运行')
            print('使用 --help 查看帮助信息')
if __name__ == '__main__':
    main()