from setuptools import setup, Extension
from pybind11.setup_helpers import Pybind11Extension, build_ext
import sys

__version__ = "1.0.0"

ext_modules = [
    Pybind11Extension(
        "h264indexer",
        ["src/bindings.cpp"],
        include_dirs=["src"],
        cxx_std=17,
        define_macros=[('VERSION_INFO', __version__)],
    ),
]

setup(
    name="h264indexer",
    version=__version__,
    author="MakeIndex Team",
    description="H.264 video indexer for fast seeking",
    long_description="A C++ implementation of H.264 video indexer that generates index files for fast video seeking operations.",
    ext_modules=ext_modules,
    cmdclass={"build_ext": build_ext},
    zip_safe=False,
    python_requires=">=3.7",
)