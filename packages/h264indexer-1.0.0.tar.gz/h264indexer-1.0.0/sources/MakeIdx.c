#include "MakeIdx.h"


uint DAT_00403018;
undefined LAB_00401dcf;
undefined *PTR_wprintf_00402050;
pointer[8] vftable;
void *ExceptionList;
undefined *PTR_GetPosition_004020c0;
int DAT_00403018;
PVOID DAT_004034bc;
PVOID DAT_004034b8;
undefined4 DAT_004024e8;
undefined _type_info_dtor_internal_method;
int DAT_004034b0;
int DAT_004034a8;
undefined4 DAT_004034b4;
undefined4 DAT_00403094;
undefined *PTR___winitenv_00402080;
undefined4 *DAT_00403098;
undefined4 DAT_00403090;
int DAT_004030a8;
int DAT_0040309c;
int DAT_004030ac;
undefined DAT_0040210c;
undefined DAT_00402118;
undefined DAT_0040211c;
undefined DAT_00402128;
undefined DAT_004034ac;
void *StackBase;
undefined DAT_004031b8;
undefined DAT_004031b4;
undefined DAT_004031b0;
undefined DAT_004031ac;
undefined DAT_004031a8;
undefined DAT_004031a4;
undefined DAT_004031d0;
undefined DAT_004031c4;
undefined DAT_004031a0;
undefined DAT_0040319c;
undefined DAT_00403198;
undefined DAT_00403194;
undefined DAT_004031c8;
undefined DAT_004031bc;
undefined4 DAT_004031c0;
undefined DAT_004031cc;
undefined DAT_00403108;
undefined DAT_004030bc;
undefined DAT_004030b0;
undefined DAT_004030b4;
undefined4 DAT_00403018;
undefined4 DAT_0040301c;
int DAT_00403100;
pointer PTR_DAT_00402194;
undefined __security_check_cookie;
IMAGE_DOS_HEADER IMAGE_DOS_HEADER_00400000;
undefined FUN_00401a79;
uint DAT_0040301c;
undefined DAT_004033f0;

uint __fastcall FUN_00401000(int param_1,int param_2)

{
  uint uVar1;
  uint in_EAX;
  undefined1 *unaff_EDI;
  
  uVar1 = param_2 - 4;
  if (in_EAX < uVar1) {
    do {
      if (((*(char *)(in_EAX + param_1) == '\0') && (*(char *)(in_EAX + 1 + param_1) == '\0')) &&
         (*(char *)(in_EAX + 2 + param_1) == '\x01')) {
        *unaff_EDI = *(undefined1 *)(in_EAX + 3 + param_1);
        return in_EAX;
      }
      if (((in_EAX < uVar1) && (*(char *)(in_EAX + param_1) == '\0')) &&
         ((*(char *)(in_EAX + 1 + param_1) == '\0' &&
          ((*(char *)(in_EAX + 2 + param_1) == '\0' && (*(char *)(in_EAX + 3 + param_1) == '\x01')))
          ))) {
        *unaff_EDI = *(undefined1 *)(in_EAX + 4 + param_1);
        return in_EAX;
      }
      in_EAX = in_EAX + 1;
    } while (in_EAX < uVar1);
  }
  return 0xffffffff;
}



void __cdecl FUN_00401060(undefined4 param_1,undefined4 *param_2)

{
  uint uVar1;
  uint uVar2;
  HMODULE pHVar3;
  LPWSTR pWVar4;
  code *pcVar5;
  uint uVar6;
  longlong lVar7;
  int iVar8;
  wchar_t *pwVar9;
  undefined1 auStack_c84 [3];
  byte bStack_c81;
  undefined4 local_c80;
  uint uStack_c7c;
  undefined **appuStack_c78 [2];
  undefined4 uStack_c70;
  undefined4 uStack_c6c;
  CStringT<wchar_t,class_StrTraitMFC_DLL<wchar_t,class_ATL::ChTraitsCRT<wchar_t>_>_> aCStack_c68 [4]
  ;
  uint uStack_c64;
  CFile aCStack_c60 [20];
  uint uStack_c4c;
  int iStack_c48;
  uint uStack_c44;
  int iStack_c40;
  CFile aCStack_c3c [20];
  undefined1 auStack_c28 [1032];
  wchar_t awStack_820 [1026];
  uint local_1c;
  void *local_14;
  undefined1 *puStack_10;
  uint uStack_c;
  
  uStack_c = 0xffffffff;
  puStack_10 = &LAB_00401dcf;
  local_14 = ExceptionList;
  local_1c = DAT_00403018 ^ (uint)auStack_c84;
  uVar2 = DAT_00403018 ^ (uint)&stack0xfffff370;
  ExceptionList = &local_14;
  local_c80 = 0;
  pHVar3 = GetModuleHandleW((LPCWSTR)0x0);
  if (pHVar3 == (HMODULE)0x0) {
    pwVar9 = L"错误: GetModuleHandle 失败\n";
LAB_004010f6:
    pcVar5 = wprintf_exref;
    wprintf(pwVar9);
    local_c80 = 1;
  }
  else {
    iVar8 = 0;
    pWVar4 = GetCommandLineW();
    iVar8 = AfxWinInit(pHVar3,(HINSTANCE__ *)0x0,pWVar4,iVar8);
    pcVar5 = wprintf_exref;
    if (iVar8 == 0) {
      pwVar9 = L"错误: MFC 初始化失败\n";
      goto LAB_004010f6;
    }
    wprintf(L"rundir:%s\n",*param_2,uVar2);
  }
  if ((param_2[1] == 0) || (param_2[2] == 0)) {
    printf("Err:need 2 Params,\nex:makeIdx in.h264 out.idx\n");
  }
  else {
    CFile::CFile(aCStack_c60);
    uStack_c = 0;
    CFile::CFile(aCStack_c3c);
    uStack_c._0_1_ = 1;
    CException::CException((CException *)appuStack_c78);
    appuStack_c78[0] = CFileException::vftable;
    ATL::CStringT<wchar_t,class_StrTraitMFC_DLL<wchar_t,class_ATL::ChTraitsCRT<wchar_t>_>_>::
    CStringT<wchar_t,class_StrTraitMFC_DLL<wchar_t,class_ATL::ChTraitsCRT<wchar_t>_>_>(aCStack_c68);
    uStack_c._0_1_ = 2;
    uStack_c70 = 0;
    uStack_c6c = 0xffffffff;
    ATL::CStringT<wchar_t,class_StrTraitMFC_DLL<wchar_t,class_ATL::ChTraitsCRT<wchar_t>_>_>::
    operator=(aCStack_c68,(wchar_t *)0x0);
    uStack_c = CONCAT31(uStack_c._1_3_,3);
    iVar8 = CFile::Open(aCStack_c60,(wchar_t *)param_2[1],0x8000,(CFileException *)appuStack_c78);
    if (iVar8 == 0) {
      CFileException::GetErrorMessage((CFileException *)appuStack_c78,awStack_820,0x400,(uint *)0x0)
      ;
      pwVar9 = L"Open Src Error:%s\n";
    }
    else {
      iVar8 = CFile::Open(aCStack_c3c,(wchar_t *)param_2[2],0x9001,(CFileException *)appuStack_c78);
      if (iVar8 != 0) {
        uVar2 = 0xffffffff;
        uVar6 = 0xfffffffd;
        uStack_c7c = 0xffffffff;
        pcVar5 = GetPosition_exref;
LAB_00401260:
        uStack_c64 = CFile::Read(aCStack_c60,auStack_c28,0x400);
joined_r0x0040127e:
        do {
          if (0x3fb < (int)uVar6) goto LAB_00401374;
          uVar6 = FUN_00401000((int)auStack_c28,uStack_c64);
          uStack_c4c = uVar6;
          if (uVar6 == 0xffffffff) {
            uVar6 = 0xfffffffd;
            goto LAB_00401374;
          }
          bStack_c81 = bStack_c81 & 0x1f;
          if ((((bStack_c81 != 7) && (bStack_c81 != 8)) && (bStack_c81 != 6)) ||
             (uVar2 == 0xffffffff)) {
            if (bStack_c81 == 5) {
              if (uVar2 == 0xffffffff) goto joined_r0x0040127e;
              lVar7 = (*pcVar5)();
              uVar1 = uStack_c7c;
              iStack_c48 = (int)uVar2 >> 0x1f;
              lVar7 = lVar7 + CONCAT44((((int)uVar6 >> 0x1f) - iStack_c48) - (uint)(uVar6 < uVar2),
                                       uVar6 - uVar2) + -0x400;
              printf("start at %08x,len:%08x\n",uStack_c7c,(int)lVar7,
                     (int)((ulonglong)lVar7 >> 0x20));
              pcVar5 = GetPosition_exref;
              uVar2 = uVar1;
LAB_0040131f:
              uVar6 = uStack_c4c;
              uStack_c44 = uVar2;
              iVar8 = (*pcVar5)();
              iStack_c40 = iVar8 + -0x400 + (uVar6 - uVar2);
              CFile::Write(aCStack_c3c,&uStack_c44,8);
            }
            else if (uVar2 != 0xffffffff) goto LAB_0040131f;
            iVar8 = (*pcVar5)();
            uVar2 = iVar8 + -0x400 + uVar6;
            uStack_c7c = uVar2;
          }
        } while( true );
      }
      CFileException::GetErrorMessage((CFileException *)appuStack_c78,awStack_820,0x400,(uint *)0x0)
      ;
      pwVar9 = L"Create dest Error:%s\n";
    }
    (*pcVar5)(pwVar9,awStack_820);
    appuStack_c78[0] = CFileException::vftable;
    ATL::CStringT<wchar_t,class_StrTraitMFC_DLL<wchar_t,class_ATL::ChTraitsCRT<wchar_t>_>_>::
    ~CStringT<wchar_t,class_StrTraitMFC_DLL<wchar_t,class_ATL::ChTraitsCRT<wchar_t>_>_>(aCStack_c68)
    ;
    uStack_c = uStack_c & 0xffffff00;
    CFile::~CFile(aCStack_c3c);
    uStack_c = 0xffffffff;
    CFile::~CFile(aCStack_c60);
  }
LAB_004013f2:
  ExceptionList = local_14;
  __security_check_cookie(local_1c ^ (uint)auStack_c84);
  return;
LAB_00401374:
  if ((int)uStack_c64 < 0x400) goto code_r0x00401382;
  goto LAB_00401260;
code_r0x00401382:
  CFile::Close(aCStack_c3c);
  CFile::Close(aCStack_c60);
  printf("Convert Idx finished\n;");
  appuStack_c78[0] = CFileException::vftable;
  ATL::CStringT<wchar_t,class_StrTraitMFC_DLL<wchar_t,class_ATL::ChTraitsCRT<wchar_t>_>_>::
  ~CStringT<wchar_t,class_StrTraitMFC_DLL<wchar_t,class_ATL::ChTraitsCRT<wchar_t>_>_>(aCStack_c68);
  uStack_c = uStack_c & 0xffffff00;
  CFile::~CFile(aCStack_c3c);
  uStack_c = 0xffffffff;
  CFile::~CFile(aCStack_c60);
  goto LAB_004013f2;
}



void __fastcall FUN_00401420(undefined4 *param_1)

{
  *param_1 = CFileException::vftable;
                    // WARNING: Could not recover jumptable at 0x00401429. Too many branches
                    // WARNING: Treating indirect jump as call
  ATL::CStringT<wchar_t,class_StrTraitMFC_DLL<wchar_t,class_ATL::ChTraitsCRT<wchar_t>_>_>::
  ~CStringT<wchar_t,class_StrTraitMFC_DLL<wchar_t,class_ATL::ChTraitsCRT<wchar_t>_>_>
            ((CStringT<wchar_t,class_StrTraitMFC_DLL<wchar_t,class_ATL::ChTraitsCRT<wchar_t>_>_> *)
             (param_1 + 4));
  return;
}



undefined4 * __thiscall FUN_00401430(void *this,byte param_1)

{
  *(undefined ***)this = CFileException::vftable;
  ATL::CStringT<wchar_t,class_StrTraitMFC_DLL<wchar_t,class_ATL::ChTraitsCRT<wchar_t>_>_>::
  ~CStringT<wchar_t,class_StrTraitMFC_DLL<wchar_t,class_ATL::ChTraitsCRT<wchar_t>_>_>
            ((CStringT<wchar_t,class_StrTraitMFC_DLL<wchar_t,class_ATL::ChTraitsCRT<wchar_t>_>_> *)
             ((int)this + 0x10));
  if ((param_1 & 1) != 0) {
    operator_delete(this);
  }
  return (undefined4 *)this;
}



void FUN_00401460(void)

{
  return;
}



void FUN_00401470(void)

{
  return;
}



void __cdecl operator_delete(void *param_1)

{
                    // WARNING: Could not recover jumptable at 0x00401472. Too many branches
                    // WARNING: Treating indirect jump as call
  operator_delete(param_1);
  return;
}



int __thiscall CException::ReportError(CException *this,uint param_1,uint param_2)

{
  int iVar1;
  
                    // WARNING: Could not recover jumptable at 0x00401478. Too many branches
                    // WARNING: Treating indirect jump as call
  iVar1 = ReportError(this,param_1,param_2);
  return iVar1;
}



int __thiscall
CFileException::GetErrorMessage(CFileException *this,wchar_t *param_1,uint param_2,uint *param_3)

{
  int iVar1;
  
                    // WARNING: Could not recover jumptable at 0x0040147e. Too many branches
                    // WARNING: Treating indirect jump as call
  iVar1 = GetErrorMessage(this,param_1,param_2,param_3);
  return iVar1;
}



int __thiscall
CException::GetErrorMessage(CException *this,wchar_t *param_1,uint param_2,uint *param_3)

{
  int iVar1;
  
                    // WARNING: Could not recover jumptable at 0x00401484. Too many branches
                    // WARNING: Treating indirect jump as call
  iVar1 = GetErrorMessage(this,param_1,param_2,param_3);
  return iVar1;
}



CRuntimeClass * __thiscall CFileException::GetRuntimeClass(CFileException *this)

{
  CRuntimeClass *pCVar1;
  
                    // WARNING: Could not recover jumptable at 0x0040148a. Too many branches
                    // WARNING: Treating indirect jump as call
  pCVar1 = GetRuntimeClass(this);
  return pCVar1;
}



// Library Function - Single Match
//  @__security_check_cookie@4
// 
// Libraries: Visual Studio 2005 Release, Visual Studio 2008 Release, Visual Studio 2010 Release
// __fastcall __security_check_cookie,4

void __fastcall __security_check_cookie(int param_1)

{
  if (param_1 == DAT_00403018) {
    return;
  }
                    // WARNING: Subroutine does not return
  ___report_gsfailure();
}



// WARNING: Function: __SEH_prolog4 replaced with injection: SEH_prolog4
// WARNING: Function: __SEH_epilog4 replaced with injection: EH_epilog3
// Library Function - Single Match
//  __onexit
// 
// Library: Visual Studio 2010 Release

_onexit_t __cdecl __onexit(_onexit_t param_1)

{
  _onexit_t p_Var1;
  PVOID pvVar2;
  PVOID *ppvVar3;
  PVOID *ppvVar4;
  PVOID local_24;
  PVOID local_20 [5];
  undefined4 uStack_c;
  undefined4 *local_8;
  
  local_8 = &DAT_004024e8;
  uStack_c = 0x4014ab;
  local_20[0] = DecodePointer(DAT_004034bc);
  if (local_20[0] == (PVOID)0xffffffff) {
    p_Var1 = _onexit(param_1);
  }
  else {
    _lock(8);
    local_8 = (undefined4 *)0x0;
    local_20[0] = DecodePointer(DAT_004034bc);
    local_24 = DecodePointer(DAT_004034b8);
    ppvVar4 = &local_24;
    ppvVar3 = local_20;
    pvVar2 = EncodePointer(param_1);
    p_Var1 = (_onexit_t)__dllonexit(pvVar2,ppvVar3,ppvVar4);
    DAT_004034bc = EncodePointer(local_20[0]);
    DAT_004034b8 = EncodePointer(local_24);
    local_8 = (undefined4 *)0xfffffffe;
    FUN_00401537();
  }
  return p_Var1;
}



void FUN_00401537(void)

{
  _unlock(8);
  return;
}



// Library Function - Single Match
//  _atexit
// 
// Library: Visual Studio 2010 Release

int __cdecl _atexit(_func_4879 *param_1)

{
  _onexit_t p_Var1;
  
  p_Var1 = __onexit((_onexit_t)param_1);
  return (p_Var1 != (_onexit_t)0x0) - 1;
}



// Library Function - Multiple Matches With Different Base Names
//  public: virtual void * __thiscall CDaoRelationFieldInfo::`vector deleting destructor'(unsigned
// int)
//  public: virtual void * __thiscall exception::`vector deleting destructor'(unsigned int)
//  public: virtual void * __thiscall std::exception::`vector deleting destructor'(unsigned int)
//  public: virtual void * __thiscall logic_error::`vector deleting destructor'(unsigned int)
//   5 names - too many to list
// 
// Libraries: Visual Studio 2008 Release, Visual Studio 2010 Release

type_info * __thiscall FID_conflict__vector_deleting_destructor_(void *this,byte param_1)

{
  type_info *ptVar1;
  
  if ((param_1 & 2) == 0) {
    type_info::_type_info_dtor_internal_method((type_info *)this);
    ptVar1 = (type_info *)this;
    if ((param_1 & 1) != 0) {
      operator_delete(this);
    }
  }
  else {
    ptVar1 = (type_info *)((int)this + -4);
    _eh_vector_destructor_iterator_
              (this,0xc,*(int *)ptVar1,type_info::_type_info_dtor_internal_method);
    if ((param_1 & 1) != 0) {
      operator_delete(ptVar1);
    }
  }
  return ptVar1;
}



// WARNING: Function: __SEH_prolog4 replaced with injection: SEH_prolog4
// WARNING: Function: __SEH_epilog4 replaced with injection: EH_epilog3
// Library Function - Single Match
//  ___tmainCRTStartup
// 
// Library: Visual Studio 2010 Release

int ___tmainCRTStartup(void)

{
  bool bVar1;
  void *Exchange;
  void *pvVar2;
  int iVar3;
  BOOL BVar4;
  
  if (DAT_004034b0 == 0) {
    HeapSetInformation((HANDLE)0x0,HeapEnableTerminationOnCorruption,(PVOID)0x0,0);
  }
  Exchange = StackBase;
  bVar1 = false;
  do {
    pvVar2 = (void *)InterlockedCompareExchange((LONG *)&DAT_004034ac,(LONG)Exchange,0);
    if (pvVar2 == (void *)0x0) {
LAB_0040164c:
      if (DAT_004034a8 == 1) {
        _amsg_exit(0x1f);
      }
      else if (DAT_004034a8 == 0) {
        DAT_004034a8 = 1;
        iVar3 = initterm_e(&DAT_0040211c,&DAT_00402128);
        if (iVar3 != 0) {
          return 0xff;
        }
      }
      else {
        DAT_004030ac = 1;
      }
      if (DAT_004034a8 == 1) {
        initterm(&DAT_0040210c,&DAT_00402118);
        DAT_004034a8 = 2;
      }
      if (!bVar1) {
        InterlockedExchange((LONG *)&DAT_004034ac,0);
      }
      if ((DAT_004034b4 != (code *)0x0) &&
         (BVar4 = __IsNonwritableInCurrentImage((PBYTE)&DAT_004034b4), BVar4 != 0)) {
        (*DAT_004034b4)(0,2,0);
      }
      *(undefined4 *)__winitenv_exref = DAT_00403094;
      DAT_004030a8 = FUN_00401060(DAT_00403090,DAT_00403098);
      if (DAT_0040309c != 0) {
        if (DAT_004030ac == 0) {
          _cexit();
        }
        return DAT_004030a8;
      }
                    // WARNING: Subroutine does not return
      exit(DAT_004030a8);
    }
    if (pvVar2 == Exchange) {
      bVar1 = true;
      goto LAB_0040164c;
    }
    Sleep(1000);
  } while( true );
}



void entry(void)

{
  ___security_init_cookie();
  ___tmainCRTStartup();
  return;
}



// WARNING: Function: __SEH_prolog4 replaced with injection: SEH_prolog4
// WARNING: Function: __SEH_epilog4 replaced with injection: EH_epilog3
// Library Function - Single Match
//  void __stdcall __ArrayUnwind(void *,unsigned int,int,void (__thiscall*)(void *))
// 
// Libraries: Visual Studio 2005 Release, Visual Studio 2008 Release, Visual Studio 2010 Release

void __ArrayUnwind(void *param_1,uint param_2,int param_3,_func_void_void_ptr *param_4)

{
  void *in_stack_ffffffc8;
  
  while( true ) {
    param_3 = param_3 + -1;
    if (param_3 < 0) break;
    (*param_4)(in_stack_ffffffc8);
  }
  return;
}



// WARNING: Function: __SEH_prolog4 replaced with injection: SEH_prolog4
// WARNING: Function: __SEH_epilog4 replaced with injection: EH_epilog3
// Library Function - Single Match
//  void __stdcall `eh vector destructor iterator'(void *,unsigned int,int,void (__thiscall*)(void
// *))
// 
// Libraries: Visual Studio 2008 Release, Visual Studio 2010 Release

void _eh_vector_destructor_iterator_
               (void *param_1,uint param_2,int param_3,_func_void_void_ptr *param_4)

{
  void *in_stack_ffffffd0;
  
  while( true ) {
    param_3 = param_3 + -1;
    if (param_3 < 0) break;
    (*param_4)(in_stack_ffffffd0);
  }
  FUN_004018e4();
  return;
}



void FUN_004018e4(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + -0x1c) == 0) {
    __ArrayUnwind(*(void **)(unaff_EBP + 8),*(uint *)(unaff_EBP + 0xc),*(int *)(unaff_EBP + 0x10),
                  *(_func_void_void_ptr **)(unaff_EBP + 0x14));
  }
  return;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address
// Library Function - Single Match
//  ___report_gsfailure
// 
// Libraries: Visual Studio 2005 Release, Visual Studio 2008 Release, Visual Studio 2010 Release

void __cdecl ___report_gsfailure(void)

{
  undefined4 in_EAX;
  HANDLE hProcess;
  undefined4 in_ECX;
  undefined4 in_EDX;
  undefined4 unaff_EBX;
  undefined4 unaff_EBP;
  undefined4 unaff_ESI;
  undefined4 unaff_EDI;
  undefined2 in_ES;
  undefined2 in_CS;
  undefined2 in_SS;
  undefined2 in_DS;
  undefined2 in_FS;
  undefined2 in_GS;
  byte in_AF;
  byte in_TF;
  byte in_IF;
  byte in_NT;
  byte in_AC;
  byte in_VIF;
  byte in_VIP;
  byte in_ID;
  undefined4 unaff_retaddr;
  UINT uExitCode;
  undefined4 local_32c;
  undefined4 local_328;
  
  _DAT_004031c8 =
       (uint)(in_NT & 1) * 0x4000 | (uint)SBORROW4((int)&stack0xfffffffc,0x328) * 0x800 |
       (uint)(in_IF & 1) * 0x200 | (uint)(in_TF & 1) * 0x100 | (uint)((int)&local_32c < 0) * 0x80 |
       (uint)(&stack0x00000000 == (undefined1 *)0x32c) * 0x40 | (uint)(in_AF & 1) * 0x10 |
       (uint)((POPCOUNT((uint)&local_32c & 0xff) & 1U) == 0) * 4 |
       (uint)(&stack0xfffffffc < (undefined1 *)0x328) | (uint)(in_ID & 1) * 0x200000 |
       (uint)(in_VIP & 1) * 0x100000 | (uint)(in_VIF & 1) * 0x80000 | (uint)(in_AC & 1) * 0x40000;
  _DAT_004031cc = &stack0x00000004;
  _DAT_00403108 = 0x10001;
  _DAT_004030b0 = 0xc0000409;
  _DAT_004030b4 = 1;
  local_32c = DAT_00403018;
  local_328 = DAT_0040301c;
  _DAT_004030bc = unaff_retaddr;
  _DAT_00403194 = in_GS;
  _DAT_00403198 = in_FS;
  _DAT_0040319c = in_ES;
  _DAT_004031a0 = in_DS;
  _DAT_004031a4 = unaff_EDI;
  _DAT_004031a8 = unaff_ESI;
  _DAT_004031ac = unaff_EBX;
  _DAT_004031b0 = in_EDX;
  _DAT_004031b4 = in_ECX;
  _DAT_004031b8 = in_EAX;
  _DAT_004031bc = unaff_EBP;
  DAT_004031c0 = unaff_retaddr;
  _DAT_004031c4 = in_CS;
  _DAT_004031d0 = in_SS;
  DAT_00403100 = IsDebuggerPresent();
  _crt_debugger_hook(1);
  SetUnhandledExceptionFilter((LPTOP_LEVEL_EXCEPTION_FILTER)0x0);
  UnhandledExceptionFilter((_EXCEPTION_POINTERS *)&PTR_DAT_00402194);
  if (DAT_00403100 == 0) {
    _crt_debugger_hook(1);
  }
  uExitCode = 0xc0000409;
  hProcess = GetCurrentProcess();
  TerminateProcess(hProcess,uExitCode);
  return;
}



void __cdecl _unlock(int _File)

{
                    // WARNING: Could not recover jumptable at 0x00401a02. Too many branches
                    // WARNING: Treating indirect jump as call
  _unlock(_File);
  return;
}



void __dllonexit(void)

{
                    // WARNING: Could not recover jumptable at 0x00401a08. Too many branches
                    // WARNING: Treating indirect jump as call
  __dllonexit();
  return;
}



void __cdecl _lock(int _File)

{
                    // WARNING: Could not recover jumptable at 0x00401a0e. Too many branches
                    // WARNING: Treating indirect jump as call
  _lock(_File);
  return;
}



// WARNING: This is an inlined function
// WARNING: Unable to track spacebase fully for stack
// WARNING: Variable defined which should be unmapped: param_2
// Library Function - Single Match
//  __SEH_prolog4
// 
// Library: Visual Studio

void __cdecl __SEH_prolog4(undefined4 param_1,int param_2)

{
  int iVar1;
  undefined4 unaff_EBX;
  undefined4 unaff_ESI;
  undefined4 unaff_EDI;
  undefined4 unaff_retaddr;
  uint auStack_1c [5];
  undefined1 local_8 [8];
  
  iVar1 = -param_2;
  *(undefined4 *)((int)auStack_1c + iVar1 + 0x10) = unaff_EBX;
  *(undefined4 *)((int)auStack_1c + iVar1 + 0xc) = unaff_ESI;
  *(undefined4 *)((int)auStack_1c + iVar1 + 8) = unaff_EDI;
  *(uint *)((int)auStack_1c + iVar1 + 4) = DAT_00403018 ^ (uint)&param_2;
  *(undefined4 *)((int)auStack_1c + iVar1) = unaff_retaddr;
  ExceptionList = local_8;
  return;
}



// WARNING: This is an inlined function
// Library Function - Single Match
//  __SEH_epilog4
// 
// Library: Visual Studio

void __SEH_epilog4(void)

{
  undefined4 *unaff_EBP;
  undefined4 unaff_retaddr;
  
  ExceptionList = (void *)unaff_EBP[-4];
  *unaff_EBP = unaff_retaddr;
  return;
}



void __cdecl
FUN_00401a79(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  except_handler4_common(&DAT_00403018,__security_check_cookie,param_1,param_2,param_3,param_4);
  return;
}



// Library Function - Single Match
//  long __stdcall __CxxUnhandledExceptionFilter(struct _EXCEPTION_POINTERS *)
// 
// Libraries: Visual Studio 2008 Release, Visual Studio 2010 Release

long __CxxUnhandledExceptionFilter(_EXCEPTION_POINTERS *param_1)

{
  PEXCEPTION_RECORD pEVar1;
  ULONG_PTR UVar2;
  
  pEVar1 = param_1->ExceptionRecord;
  if (((pEVar1->ExceptionCode == 0xe06d7363) && (pEVar1->NumberParameters == 3)) &&
     ((UVar2 = pEVar1->ExceptionInformation[0], UVar2 == 0x19930520 ||
      (((UVar2 == 0x19930521 || (UVar2 == 0x19930522)) || (UVar2 == 0x1994000)))))) {
    terminate();
  }
  return 0;
}



void __cdecl _amsg_exit(int param_1)

{
                    // WARNING: Could not recover jumptable at 0x00401aee. Too many branches
                    // WARNING: Treating indirect jump as call
  _amsg_exit(param_1);
  return;
}



// WARNING: Removing unreachable block (ram,0x00401b08)
// WARNING: Removing unreachable block (ram,0x00401b0e)
// WARNING: Removing unreachable block (ram,0x00401b10)

void FUN_00401af4(void)

{
  return;
}



// WARNING: Removing unreachable block (ram,0x00401b2e)
// WARNING: Removing unreachable block (ram,0x00401b34)
// WARNING: Removing unreachable block (ram,0x00401b36)

void FUN_00401b1a(void)

{
  return;
}



int __cdecl _XcptFilter(ulong _ExceptionNum,_EXCEPTION_POINTERS *_ExceptionPtr)

{
  int iVar1;
  
                    // WARNING: Could not recover jumptable at 0x00401b40. Too many branches
                    // WARNING: Treating indirect jump as call
  iVar1 = _XcptFilter(_ExceptionNum,_ExceptionPtr);
  return iVar1;
}



// Library Function - Single Match
//  __ValidateImageBase
// 
// Libraries: Visual Studio 2008 Release, Visual Studio 2010 Release

BOOL __cdecl __ValidateImageBase(PBYTE pImageBase)

{
  if ((*(short *)pImageBase == 0x5a4d) &&
     (*(int *)(pImageBase + *(int *)(pImageBase + 0x3c)) == 0x4550)) {
    return (uint)((short)*(int *)((int)(pImageBase + *(int *)(pImageBase + 0x3c)) + 0x18) == 0x10b);
  }
  return 0;
}



// Library Function - Single Match
//  __FindPESection
// 
// Library: Visual Studio 2010 Release

PIMAGE_SECTION_HEADER __cdecl __FindPESection(PBYTE pImageBase,DWORD_PTR rva)

{
  int iVar1;
  PIMAGE_SECTION_HEADER p_Var2;
  uint uVar3;
  
  iVar1 = *(int *)(pImageBase + 0x3c);
  uVar3 = 0;
  p_Var2 = (PIMAGE_SECTION_HEADER)
           (pImageBase + *(ushort *)(pImageBase + iVar1 + 0x14) + 0x18 + iVar1);
  if (*(ushort *)(pImageBase + iVar1 + 6) != 0) {
    do {
      if ((p_Var2->VirtualAddress <= rva) &&
         (rva < (p_Var2->Misc).PhysicalAddress + p_Var2->VirtualAddress)) {
        return p_Var2;
      }
      uVar3 = uVar3 + 1;
      p_Var2 = p_Var2 + 1;
    } while (uVar3 < *(ushort *)(pImageBase + iVar1 + 6));
  }
  return (PIMAGE_SECTION_HEADER)0x0;
}



// Library Function - Single Match
//  __IsNonwritableInCurrentImage
// 
// Library: Visual Studio 2010 Release

BOOL __cdecl __IsNonwritableInCurrentImage(PBYTE pTarget)

{
  BOOL BVar1;
  PIMAGE_SECTION_HEADER p_Var2;
  void *local_14;
  code *pcStack_10;
  uint local_c;
  undefined4 local_8;
  
  pcStack_10 = FUN_00401a79;
  local_14 = ExceptionList;
  local_c = DAT_00403018 ^ 0x402568;
  ExceptionList = &local_14;
  local_8 = 0;
  BVar1 = __ValidateImageBase((PBYTE)&IMAGE_DOS_HEADER_00400000);
  if (BVar1 != 0) {
    p_Var2 = __FindPESection((PBYTE)&IMAGE_DOS_HEADER_00400000,(DWORD_PTR)(pTarget + -0x400000));
    if (p_Var2 != (PIMAGE_SECTION_HEADER)0x0) {
      ExceptionList = local_14;
      return ~(p_Var2->Characteristics >> 0x1f) & 1;
    }
  }
  ExceptionList = local_14;
  return 0;
}



void __cdecl initterm(void)

{
                    // WARNING: Could not recover jumptable at 0x00401c9c. Too many branches
                    // WARNING: Treating indirect jump as call
  initterm();
  return;
}



void __cdecl initterm_e(void)

{
                    // WARNING: Could not recover jumptable at 0x00401ca2. Too many branches
                    // WARNING: Treating indirect jump as call
  initterm_e();
  return;
}



void FUN_00401ca8(void)

{
  errno_t eVar1;
  
  eVar1 = _controlfp_s((uint *)0x0,0x10000,0x30000);
  if (eVar1 != 0) {
                    // WARNING: Subroutine does not return
    _invoke_watson((wchar_t *)0x0,(wchar_t *)0x0,(wchar_t *)0x0,0,0);
  }
  return;
}



undefined4 FUN_00401cd0(void)

{
  return 0;
}



// Library Function - Single Match
//  ___security_init_cookie
// 
// Library: Visual Studio 2010 Release

void __cdecl ___security_init_cookie(void)

{
  DWORD DVar1;
  DWORD DVar2;
  DWORD DVar3;
  uint uVar4;
  LARGE_INTEGER local_14;
  _FILETIME local_c;
  
  local_c.dwLowDateTime = 0;
  local_c.dwHighDateTime = 0;
  if ((DAT_00403018 == 0xbb40e64e) || ((DAT_00403018 & 0xffff0000) == 0)) {
    GetSystemTimeAsFileTime(&local_c);
    uVar4 = local_c.dwHighDateTime ^ local_c.dwLowDateTime;
    DVar1 = GetCurrentProcessId();
    DVar2 = GetCurrentThreadId();
    DVar3 = GetTickCount();
    QueryPerformanceCounter(&local_14);
    DAT_00403018 = uVar4 ^ DVar1 ^ DVar2 ^ DVar3 ^ local_14.s.HighPart ^ local_14.s.LowPart;
    if (DAT_00403018 == 0xbb40e64e) {
      DAT_00403018 = 0xbb40e64f;
    }
    else if ((DAT_00403018 & 0xffff0000) == 0) {
      DAT_00403018 = DAT_00403018 | (DAT_00403018 | 0x4711) << 0x10;
    }
    DAT_0040301c = ~DAT_00403018;
  }
  else {
    DAT_0040301c = ~DAT_00403018;
  }
  return;
}



void __cdecl terminate(void)

{
                    // WARNING: Could not recover jumptable at 0x00401d6e. Too many branches
                    // WARNING: Treating indirect jump as call
  terminate();
  return;
}



void __cdecl _crt_debugger_hook(int param_1)

{
                    // WARNING: Could not recover jumptable at 0x00401d74. Too many branches
                    // WARNING: Treating indirect jump as call
  _crt_debugger_hook(param_1);
  return;
}



void __cdecl except_handler4_common(void)

{
                    // WARNING: Could not recover jumptable at 0x00401d7a. Too many branches
                    // WARNING: Treating indirect jump as call
  except_handler4_common();
  return;
}



void __thiscall type_info::_type_info_dtor_internal_method(type_info *this)

{
                    // WARNING: Could not recover jumptable at 0x00401d80. Too many branches
                    // WARNING: Treating indirect jump as call
  _type_info_dtor_internal_method(this);
  return;
}



void __cdecl
_invoke_watson(wchar_t *param_1,wchar_t *param_2,wchar_t *param_3,uint param_4,uintptr_t param_5)

{
                    // WARNING: Could not recover jumptable at 0x00401d86. Too many branches
                    // WARNING: Subroutine does not return
                    // WARNING: Treating indirect jump as call
  _invoke_watson(param_1,param_2,param_3,param_4,param_5);
  return;
}



errno_t __cdecl _controlfp_s(uint *_CurrentState,uint _NewValue,uint _Mask)

{
  errno_t eVar1;
  
                    // WARNING: Could not recover jumptable at 0x00401d8c. Too many branches
                    // WARNING: Treating indirect jump as call
  eVar1 = _controlfp_s(_CurrentState,_NewValue,_Mask);
  return eVar1;
}



void __CxxFrameHandler3(void)

{
                    // WARNING: Could not recover jumptable at 0x00401d92. Too many branches
                    // WARNING: Subroutine does not return
                    // WARNING: Treating indirect jump as call
  __CxxFrameHandler3();
  return;
}



void Unwind_00401da0(void)

{
  int unaff_EBP;
  
                    // WARNING: Could not recover jumptable at 0x00401da6. Too many branches
                    // WARNING: Treating indirect jump as call
  CFile::~CFile((CFile *)(unaff_EBP + -0xc58));
  return;
}



void Unwind_00401dac(void)

{
  int unaff_EBP;
  
                    // WARNING: Could not recover jumptable at 0x00401db2. Too many branches
                    // WARNING: Treating indirect jump as call
  CFile::~CFile((CFile *)(unaff_EBP + -0xc34));
  return;
}



void Unwind_00401db8(void)

{
  int unaff_EBP;
  
                    // WARNING: Could not recover jumptable at 0x00401dbe. Too many branches
                    // WARNING: Treating indirect jump as call
  ATL::CStringT<wchar_t,class_StrTraitMFC_DLL<wchar_t,class_ATL::ChTraitsCRT<wchar_t>_>_>::
  ~CStringT<wchar_t,class_StrTraitMFC_DLL<wchar_t,class_ATL::ChTraitsCRT<wchar_t>_>_>
            ((CStringT<wchar_t,class_StrTraitMFC_DLL<wchar_t,class_ATL::ChTraitsCRT<wchar_t>_>_> *)
             (unaff_EBP + -0xc60));
  return;
}



void Unwind_00401dc4(void)

{
  int unaff_EBP;
  
  FUN_00401420((undefined4 *)(unaff_EBP + -0xc70));
  return;
}



void FUN_00401e20(void)

{
                    // WARNING: Could not recover jumptable at 0x00401e25. Too many branches
                    // WARNING: Treating indirect jump as call
  CWinApp::~CWinApp((CWinApp *)&DAT_004033f0);
  return;
}


