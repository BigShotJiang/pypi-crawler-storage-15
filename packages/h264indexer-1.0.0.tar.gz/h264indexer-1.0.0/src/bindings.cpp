#include <pybind11/pybind11.h>
#include "H264Indexer.hpp"

namespace py = pybind11;

PYBIND11_MODULE(h264indexer, m) {
    m.doc() = "H.264 Indexer implemented in C++";

    m.def("make_index", &H264Indexer::generateIndex,
          "Generate an index file for H.264 video",
          py::arg("input_path"), py::arg("output_path"));
}