#pragma once

#include <iostream>
#include <fstream>
#include <vector>
#include <cstdint>
#include <string>
#include <cstring>

class H264Indexer {
public:
    struct IndexEntry {
        uint32_t offset;
        uint32_t length;
    };

    static bool generateIndex(const std::string& inputPath, const std::string& outputPath) {
        std::ifstream inFile(inputPath, std::ios::binary | std::ios::ate);
        if (!inFile) {
            std::cerr << "Error: Cannot open input file " << inputPath << std::endl;
            return false;
        }

        size_t fileSize = inFile.tellg();
        inFile.seekg(0, std::ios::beg);

        std::ofstream outFile(outputPath, std::ios::binary);
        if (!outFile) {
            std::cerr << "Error: Cannot open output file " << outputPath << std::endl;
            return false;
        }

        // Use 1MB buffer (more efficient than original 1KB)
        const size_t BUFFER_SIZE = 1024 * 1024;
        std::vector<uint8_t> buffer(BUFFER_SIZE);

        int64_t lastIdrOffset = -1;
        int64_t currentFilePos = 0;

        // Handle cross-buffer Start Code (keep last 4 bytes)
        std::vector<uint8_t> boundaryBytes;

        while (currentFilePos < fileSize) {
            // Calculate bytes to read this round
            size_t bytesToRead = std::min(BUFFER_SIZE, (size_t)(fileSize - currentFilePos));

            // Fill boundary bytes if any
            size_t boundarySize = boundaryBytes.size();
            if (boundarySize > 0) {
                std::memcpy(buffer.data(), boundaryBytes.data(), boundarySize);
            }

            inFile.read(reinterpret_cast<char*>(buffer.data() + boundarySize), bytesToRead);
            size_t bytesInWindow = bytesToRead + boundarySize;

            // Scan buffer
            // Calculate scan limit to prevent buffer overflow
            // Need to access buffer[i+3] (NALU header), so ensure i+3 < bytesInWindow
            size_t scanLimit;
            if (currentFilePos + bytesToRead == fileSize) {
                // Last chunk: scan up to position where buffer[i+3] is valid
                scanLimit = (bytesInWindow > 3) ? bytesInWindow - 3 : 0;
            } else {
                // Not last chunk: reserve 4 bytes for boundary handling
                scanLimit = (bytesInWindow > 4) ? bytesInWindow - 4 : 0;
            }

            for (size_t i = 0; i < scanLimit; ) {
                // Look for 00 00 01 (3-byte) or 00 00 00 01 (4-byte)
                // Finding 00 00 01 is sufficient as 00 00 00 01 contains this pattern
                if (buffer[i] == 0x00 && buffer[i+1] == 0x00 && buffer[i+2] == 0x01) {
                    // Found Start Code
                    // NALU Header is the 1st byte after Start Code
                    // Start Code can be 3 bytes (00 00 01) or 4 bytes (00 00 00 01)
                    // Offset calculation:
                    // If there's a 00 before, it's usually a 4-byte Start Code

                    int startCodeLen = 3;
                    if (i > 0 && buffer[i-1] == 0x00) {
                        startCodeLen = 4; // Actually might be 00 00 00 01
                        // Note: For 4-byte pattern, offset should -1
                        // But original logic is simple, we use 00 00 01 as base
                    }

                    uint8_t naluHeader = buffer[i+3];
                    uint8_t naluType = naluHeader & 0x1F;

                    // Calculate absolute offset of current NALU in file
                    // currentFilePos is total offset before this read
                    // boundarySize is offset correction for concatenation
                    // Real position = (currentFilePos - boundarySize) + i
                    int64_t absOffset = (currentFilePos - boundarySize) + i;

                    // If there's a 00 before (i.e., 00 00 00 01), should include that 00
                    if (absOffset > 0) {
                         // Check if previous byte is 00, if so, offset -1
                         // Since we're streaming, backtracking needs caution
                         // For simplicity, use 00 00 01 as position
                         if (i > 0 && buffer[i-1] == 0x00) absOffset--;
                         else if (i == 0 && boundarySize == 0 && currentFilePos > 0) {
                             // Rare case: 00 00 01 right at buffer start, previous buffer ends with 00
                             // Needs complex state machine, ignore for now
                         }
                    }

                    // ⚠️ Key Logic: Skip parameter sets (Type 6/7/8) when IDR is recorded
                    // Original code skips SPS/PPS/SEI to avoid breaking up GOP segments
                    if ((naluType == 6 || naluType == 7 || naluType == 8) && lastIdrOffset != -1) {
                        i += 3;
                        continue;
                    }

                    // NALU Type 5 is IDR (key frame)
                    if (naluType == 5) {
                        // If there's a previous IDR, write its index entry first
                        if (lastIdrOffset != -1) {
                            uint32_t length = (uint32_t)(absOffset - lastIdrOffset);
                            IndexEntry entry;
                            entry.offset = (uint32_t)lastIdrOffset;
                            entry.length = length;

                            outFile.write(reinterpret_cast<char*>(&entry.offset), 4);
                            outFile.write(reinterpret_cast<char*>(&entry.length), 4);
                        }
                    }
                    // For other NALU types (excluding parameter sets already skipped)
                    else if (lastIdrOffset != -1) {
                        // Write index from last recorded position to current NALU
                        uint32_t length = (uint32_t)(absOffset - lastIdrOffset);
                        IndexEntry entry;
                        entry.offset = (uint32_t)lastIdrOffset;
                        entry.length = length;

                        outFile.write(reinterpret_cast<char*>(&entry.offset), 4);
                        outFile.write(reinterpret_cast<char*>(&entry.length), 4);
                    }

                    // Always update position (except for parameter sets which already continued)
                    lastIdrOffset = absOffset;

                    i += 3; // Skip Start Code
                } else {
                    i++;
                }
            }

            // Prepare for next loop
            // Save last 4 bytes of buffer to boundaryBytes to prevent Start Code truncation
            boundaryBytes.clear();
            if (currentFilePos + bytesToRead < fileSize) {
                // Not the last chunk
                for (size_t k = bytesInWindow - 4; k < bytesInWindow; k++) {
                    boundaryBytes.push_back(buffer[k]);
                }
            }

            currentFilePos += bytesToRead;
        }

        // Handle last segment
        if (lastIdrOffset != -1) {
            uint32_t length = (uint32_t)(fileSize - lastIdrOffset);
            IndexEntry entry;
            entry.offset = (uint32_t)lastIdrOffset;
            entry.length = length;
            outFile.write(reinterpret_cast<char*>(&entry.offset), 4);
            outFile.write(reinterpret_cast<char*>(&entry.length), 4);
        }

        outFile.close();
        inFile.close();
        return true;
    }
};