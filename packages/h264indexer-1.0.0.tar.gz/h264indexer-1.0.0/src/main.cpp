#include "H264Indexer.hpp"

int main(int argc, char* argv[]) {
    if (argc < 3) {
        std::cout << "Usage: MakeIndex <input.h264> <output.idx>" << std::endl;
        return 1;
    }

    std::string inputFile = argv[1];
    std::string outputFile = argv[2];

    std::cout << "Processing: " << inputFile << " -> " << outputFile << std::endl;

    if (H264Indexer::generateIndex(inputFile, outputFile)) {
        std::cout << "Success!" << std::endl;
        return 0;
    } else {
        std::cout << "Failed." << std::endl;
        return 1;
    }
}