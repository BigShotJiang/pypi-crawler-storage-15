#include <emscripten/emscripten.h>
#include "H264Indexer.hpp"

extern "C" {
    // 导出函数给 JS 调用
    // 注意：在 WASM 环境中文件系统通常是虚拟的 (MEMFS 或 IDBFS)
    EMSCRIPTEN_KEEPALIVE
    int wasm_make_index(const char* input_path, const char* output_path) {
        bool result = H264Indexer::generateIndex(std::string(input_path), std::string(output_path));
        return result ? 0 : 1;
    }
}