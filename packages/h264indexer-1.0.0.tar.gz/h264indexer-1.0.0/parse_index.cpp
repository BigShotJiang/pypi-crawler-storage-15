#include <iostream>
#include <fstream>
#include <vector>
#include <cstdint>
#include <iomanip>

struct IndexEntry {
    uint32_t offset;
    uint32_t length;
};

// 读取索引文件
std::vector<IndexEntry> parseIndexFile(const std::string& indexPath) {
    std::vector<IndexEntry> entries;
    std::ifstream file(indexPath, std::ios::binary);

    if (!file) {
        std::cerr << "无法打开索引文件: " << indexPath << std::endl;
        return entries;
    }

    IndexEntry entry;
    while (file.read(reinterpret_cast<char*>(&entry.offset), sizeof(uint32_t)) &&
           file.read(reinterpret_cast<char*>(&entry.length), sizeof(uint32_t))) {
        entries.push_back(entry);
    }

    file.close();
    return entries;
}

// 打印索引信息
void printIndexInfo(const std::string& indexPath) {
    auto entries = parseIndexFile(indexPath);

    std::cout << "索引文件: " << indexPath << std::endl;
    std::cout << "总关键帧数: " << entries.size() << std::endl;
    std::cout << std::endl;

    std::cout << std::left << std::setw(8) << "序号"
              << std::setw(18) << "偏移量 (字节)"
              << std::setw(18) << "长度 (字节)"
              << std::setw(18) << "结束位置" << std::endl;
    std::cout << std::string(62, '-') << std::endl;

    for (size_t i = 0; i < entries.size(); i++) {
        uint32_t endPos = entries[i].offset + entries[i].length;
        std::cout << std::left << std::setw(8) << (i + 1)
                  << std::setw(18) << entries[i].offset
                  << std::setw(18) << entries[i].length
                  << std::setw(18) << endPos << std::endl;
    }
}

// 提取指定关键帧
bool extractKeyframe(const std::string& h264Path, const std::string& indexPath,
                     int keyframeNum, const std::string& outputPath) {
    auto entries = parseIndexFile(indexPath);

    if (keyframeNum < 1 || keyframeNum > (int)entries.size()) {
        std::cerr << "错误: 关键帧编号必须在 1-" << entries.size() << " 之间" << std::endl;
        return false;
    }

    IndexEntry entry = entries[keyframeNum - 1];

    std::ifstream inFile(h264Path, std::ios::binary);
    if (!inFile) {
        std::cerr << "无法打开 H264 文件: " << h264Path << std::endl;
        return false;
    }

    std::ofstream outFile(outputPath, std::ios::binary);
    if (!outFile) {
        std::cerr << "无法创建输出文件: " << outputPath << std::endl;
        return false;
    }

    // 定位并读取数据
    inFile.seekg(entry.offset);
    std::vector<char> buffer(entry.length);
    inFile.read(buffer.data(), entry.length);
    outFile.write(buffer.data(), entry.length);

    std::cout << "成功提取关键帧 #" << keyframeNum << std::endl;
    std::cout << "  偏移: " << entry.offset << " 字节" << std::endl;
    std::cout << "  长度: " << entry.length << " 字节" << std::endl;
    std::cout << "  输出: " << outputPath << std::endl;

    inFile.close();
    outFile.close();
    return true;
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        std::cout << "用法:" << std::endl;
        std::cout << "  查看索引: " << argv[0] << " <index_file>" << std::endl;
        std::cout << "  提取关键帧: " << argv[0] << " <index_file> <h264_file> <keyframe_num> <output_file>" << std::endl;
        return 1;
    }

    std::string indexFile = argv[1];

    if (argc == 2) {
        // 只查看索引
        printIndexInfo(indexFile);
    } else if (argc == 5) {
        // 提取关键帧
        std::string h264File = argv[2];
        int keyframeNum = std::stoi(argv[3]);
        std::string outputFile = argv[4];

        if (!extractKeyframe(h264File, indexFile, keyframeNum, outputFile)) {
            return 1;
        }
    } else {
        std::cerr << "参数错误" << std::endl;
        return 1;
    }

    return 0;
}
