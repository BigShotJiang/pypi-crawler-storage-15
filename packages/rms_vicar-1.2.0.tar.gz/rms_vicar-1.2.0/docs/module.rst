``vicar`` Module
================

.. automodule:: vicar
    :member-order: alphabetical
    :members:
    :undoc-members:
    :special-members:
    :show-inheritance:
    :exclude-members: __dict__, __hash__, __module__, __weakref__
