``vicar`` Module
================

.. automodule:: vicar
    :member-order: groupwise
    :members:
    :undoc-members:
    :special-members:
    :private-members:
    :exclude-members: __dict__, __hash__, __module__, __weakref__
    :show-inheritance:

vicar._DEFINITIONS
------------------

.. automodule:: vicar._DEFINITIONS

vicar._LABEL_GRAMMAR
--------------------

.. automodule:: vicar._LABEL_GRAMMAR

