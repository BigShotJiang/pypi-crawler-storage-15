"""Init for mylibrary."""
from .snp_calling import simple_seq