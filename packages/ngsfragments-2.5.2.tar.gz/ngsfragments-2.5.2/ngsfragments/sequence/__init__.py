"""Init for mylibrary."""
from .kmer_query import kmer_query
from .sequence_query import query_locations