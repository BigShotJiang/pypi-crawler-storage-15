"""Init for ReadSam."""
from __future__ import absolute_import
from .merge_regions import merge_adjacent
