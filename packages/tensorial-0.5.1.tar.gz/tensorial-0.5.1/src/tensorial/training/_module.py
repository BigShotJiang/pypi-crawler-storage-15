"""This is kept here for backward compatibility reasons and will be removed in a future version"""

from ..reaxkit import ReaxModule

__all__ = ("ReaxModule",)
