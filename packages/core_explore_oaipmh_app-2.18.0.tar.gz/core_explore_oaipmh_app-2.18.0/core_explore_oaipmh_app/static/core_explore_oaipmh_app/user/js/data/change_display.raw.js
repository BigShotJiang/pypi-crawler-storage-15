var changeDataDisplayUrl = "{% url 'core_explore_oaipmh_app_change_data_display' %}";
var dataId = "{{ data.data.record_id }}";