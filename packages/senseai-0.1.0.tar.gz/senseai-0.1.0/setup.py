"""
Setup script for backward compatibility with older pip versions.
Modern configuration is in pyproject.toml.
"""
from setuptools import setup

setup()
