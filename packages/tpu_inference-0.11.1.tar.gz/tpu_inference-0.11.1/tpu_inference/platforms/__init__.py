# ruff: noqa
from tpu_inference.platforms.tpu_jax import TpuPlatform
