from w.test_utils.mixins.serializer_mixin import SerializerMixin  # noqa
