#  Test Builder

`AbstractTestBuilder` permet de simplifier la construction de jeux de données de tests. Il s'appuie sur la librairie `factory_boy`.

voir [Wedge Wiki](http://wiki.wedge-digital.com/dev/python/test_builder.html)