CREATE TABLE IF NOT EXISTS another_table (id SERIAL PRIMARY KEY, name VARCHAR(50));
INSERT INTO another_table (name) VALUES ('another_name');
