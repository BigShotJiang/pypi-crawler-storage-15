from django.apps import AppConfig


class WConfig(AppConfig):
    name = "w"
