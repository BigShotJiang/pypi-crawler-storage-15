from w.test_utils.testcases.django_testcase import DjangoTestCase  # noqa
