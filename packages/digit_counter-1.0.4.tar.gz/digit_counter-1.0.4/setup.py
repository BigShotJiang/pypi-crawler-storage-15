from setuptools import setup, find_packages
from pathlib import Path

# Read long description from README.md
here = Path(__file__).parent
readme_path = here / "README.md"
long_description = readme_path.read_text(encoding="utf-8") if readme_path.exists() else ""

setup(
    name="digit-counter",
    version="1.0.4",
    author="Kishor Kumar K",
    author_email="",
    description="High-performance digit counting library for integers, floats, and Decimal values with precision control.",
    long_description=long_description,
    long_description_content_type="text/markdown",

    packages=find_packages(exclude=("tests", "examples")),
    python_requires=">=3.7",

    install_requires=[
        # No external dependencies
    ],

    extras_require={
        "dev": [
            "pytest>=6.0",
            "pytest-cov>=2.0",
            "black>=23.0",
            "isort>=5.10",
            "flake8>=6.0",
            "mypy>=1.0",
            "pre-commit>=2.0",
        ],
        "performance": [
            "orjson>=3.8",
        ],
        "all": [
            "orjson>=3.8",
        ],
    },

    entry_points={
        "console_scripts": [
            "digit-counter=digit_counter.cli:main",
        ],
    },

    include_package_data=True,

    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Scientific/Engineering :: Mathematics",
        "License :: OSI Approved :: MIT License",

        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",

        "Operating System :: OS Independent",
    ],

    keywords="digit counter mathematics utility numeric precision",
)
