"""
Custom exceptions for the digit counter package.
"""


class DigitCounterError(Exception):
    """Base exception for digit counter errors."""

    def __init__(self, message: str, value=None, original_exception=None):
        self.message = message
        self.value = value
        self.original_exception = original_exception
        super().__init__(self._format_message())

    def _format_message(self) -> str:
        parts = [f"DigitCounterError: {self.message}"]
        if self.value is not None:
            parts.append(f"Value: {self.value!r}")
        if self.original_exception:
            parts.append(f"Original error: {str(self.original_exception)}")
        return " | ".join(parts)


class InputValidationError(DigitCounterError):
    """Raised when input validation fails."""


class PrecisionError(DigitCounterError):
    """Raised when precision limits are exceeded."""


class CalculationError(DigitCounterError):
    """Raised when digit calculation fails."""


class CacheError(DigitCounterError):
    """Raised when caching operations fail."""


class BatchProcessingError(DigitCounterError):
    """Raised when batch processing fails."""


class ConfigurationError(DigitCounterError):
    """Raised when configuration is invalid."""
