def rich_ass():
    print("(_$_)")