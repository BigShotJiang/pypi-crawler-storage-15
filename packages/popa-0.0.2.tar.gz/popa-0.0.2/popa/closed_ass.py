def closed_ass():
    print("(_x_)")