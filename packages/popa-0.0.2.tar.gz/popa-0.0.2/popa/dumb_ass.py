def dumb_ass():
    print("(_?_)")