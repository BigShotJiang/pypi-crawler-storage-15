def big_ass():    
    print("(__!__)")