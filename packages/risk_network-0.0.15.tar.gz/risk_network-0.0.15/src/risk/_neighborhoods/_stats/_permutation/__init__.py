"""
risk/_neighborhoods/_stats/_permutation
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
"""

from ._permutation import compute_permutation_test
