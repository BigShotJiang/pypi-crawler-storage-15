"""
risk
~~~~

RISK: Regional Inference of Significant Kinships
"""

from ._risk import RISK

__all__ = ["RISK"]
__version__ = "0.0.15"
