"""
risk/_annotation
~~~~~~~~~~~~~~~~
"""

from ._annotation import (
    define_top_annotation,
    get_weighted_description,
)
from ._io import AnnotationHandler
