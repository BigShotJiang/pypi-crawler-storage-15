"""
risk/_network/_plotter/_utils
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
"""

from ._colors import get_annotated_domain_colors, get_domain_colors, to_rgba
from ._layout import calculate_bounding_box, calculate_centroids
