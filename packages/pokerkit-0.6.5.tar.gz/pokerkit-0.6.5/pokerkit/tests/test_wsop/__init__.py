""":mod:`pokerkit.tests.test_wsop` is the package for the unit tests in
the PokerKit library using hands from the World Series of Poker.
"""
