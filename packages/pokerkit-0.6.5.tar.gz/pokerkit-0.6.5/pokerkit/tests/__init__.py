""":mod:`pokerkit.tests` is the package for the unit tests in the
PokerKit library.
"""
