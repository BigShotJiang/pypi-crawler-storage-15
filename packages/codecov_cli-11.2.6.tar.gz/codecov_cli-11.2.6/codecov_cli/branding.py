from enum import Enum


class Branding(Enum):
    CODECOV = "codecov"
    PREVENT = "prevent"
