
abc at line 3
xyz at line 6

// comment at line
	// another comment
{
	asdfadsf?
}
{ // hey

}
func { 

}

func { // fapsodjfpjasdpf jaspdfj 

}

/*

*/
	/*
	*/

