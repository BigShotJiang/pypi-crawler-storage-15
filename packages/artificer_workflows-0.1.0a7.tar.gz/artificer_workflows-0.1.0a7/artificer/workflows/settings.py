import os

APP_NAME = "artificer"

ARTIFICER_STORE_DIR = os.getenv("ARTIFICER_STORE_DIR", ".artificer")
