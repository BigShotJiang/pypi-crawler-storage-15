## Installation

```bash
pip install mrs-inspector