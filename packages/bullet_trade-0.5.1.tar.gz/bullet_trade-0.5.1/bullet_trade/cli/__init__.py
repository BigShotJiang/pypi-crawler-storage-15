"""
BulletTrade 命令行工具

提供便捷的CLI命令来运行回测、优化和实盘交易
"""

