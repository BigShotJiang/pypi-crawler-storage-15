# PRACTICAL 8B
# Identity Operators: is, is not

x = 5
y = 5
z = [5]

print("x is y:", x is y)
print("x is not y:", x is not y)

print("x is z:", x is z)       # False (int vs list)
print("x is not z:", x is not z)
