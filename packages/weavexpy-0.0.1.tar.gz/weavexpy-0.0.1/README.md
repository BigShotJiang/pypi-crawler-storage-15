# WeavexPy - 0.0.1 - beta
sem documentação