# http://127.0.0.1:5000 
import webview
from threading import Thread
import sys

from .server import *
from .ehtml import *
from .css import *
from .script import *
from .obj import *

class Scope:
    def __init__(self, parent):
        '''## Scope

The **Scope** module is responsible for structuring the body of an HTML page. It acts as a layout manager, allowing you to build and organize the page hierarchy prior to rendering.

---
title -> <title>{self.title}</title>
lang -> <html lang="{self.lang}">
charset -> <meta charset="{self.charset}">
---

## Functions

### `add(element)`
Adds a new element to the page body.

- **Purpose:** Insert HTML components sequentially or hierarchically.  
- **Parameter:**  
  - `element`: object, string, or structure representing HTML.  
- **How it works:** Stores the element internally, keeping insertion order.  
- **Common uses:**  
  - Dynamic page construction  
  - Adding divs, text blocks, menus, scripts  
  - Incrementally expanding the layout  

---

### `__str__()`
Defines or replaces the entire page content.

- **Purpose:** Establish the final layout of the page.  
- **How it works:** Clears the existing structure and sets a new body.  
- **Common uses:**  
  - Template configuration  
  - Layout reset  
  - Base page setup'''
        self.scope = ''
        self.title = 'Document'
        self.charset = 'UTF-8'
        self.lang = 'en'
        self.set = self.__str__
        self.parent = parent
        self.style = ''
        
    def add_style(self, css):
      self.style += str(css) + '\n'
    def add(self, element) : 
        '''### `add(element)`
Adds a new element to the page body.

- **Purpose:** Insert HTML components sequentially or hierarchically.  
- **Parameter:**  
  - `element`: object, string, or structure representing HTML.  
- **How it works:** Stores the element internally, keeping insertion order.  
- **Common uses:**  
  - Dynamic page construction  
  - Adding divs, text blocks, menus, scripts  
  - Incrementally expanding the layout  '''
        self.scope += str(element) + '\n'
    def __str__(self) :
        '''### `__str__()`
Defines or replaces the entire page content.

- **Purpose:** Establish the final layout of the page.  
- **How it works:** Clears the existing structure and sets a new body.  
- **Common uses:**  
  - Template configuration  
  - Layout reset  
  - Base page setup'''
        return f'''<!DOCTYPE html>
<html lang="{self.lang}">
<head>
    <meta charset="{self.charset}">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/brython@3.11.0/brython.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/brython@3.11.0/brython_stdlib.js"></script>
    <title>{self.title}</title>
{self.parent.all_style}
<style>
{self.style}
</style>
</head>
<script type="module" src="https://pyscript.net/releases/2025.11.1/core.js"></script>
<body onload="brython()">
{self.scope}
</body>
</html>'''

class ObjectPage:
    def __init__(self, page_base:list) : 
        '''## ObjectPage

The **ObjectPage** module provides a simple and structured way to add elements to a page created with `@Window().add_page()`.  
It uses a base structure defined by **`page_base`**, which serves as the initial template or layout for the page.

This class behaves like a *page builder*: it collects elements and finally produces a consolidated output — typically HTML.

---

## Methods

### `add(element)`
Adds a new element to the page.

- **Purpose:** insert components into the page layout using the `page_base` model.  
- **Parameter:**  
  - `element`: HTML content, structured object, text block, or custom component.  
- **How it works:** the element is appended internally while preserving order and structure.  
- **Common uses:**  
  - Incremental page construction  
  - Adding HTML blocks, widgets, text, or scripts  
  - Modular composition of layouts

---

### `__str__()`
Finalizes and returns the page representation.

- **Purpose:** generate the final page output based on all added elements.  
- **Returns:** usually a string containing the assembled HTML.  
- **How it works:**  
  - Merges `page_base` with the collected elements  
  - Produces the final layout for rendering  
- **Common uses:**  
  - HTML generation in frameworks  
  - Rendering pages in the browser  
  - Exporting the finished layout'''
        self.page_base = page_base
    
    def add(self, element) : 
        '''### `add(element)`
Adds a new element to the page.

- **Purpose:** insert components into the page layout using the `page_base` model.  
- **Parameter:**  
  - `element`: HTML content, structured object, text block, or custom component.  
- **How it works:** the element is appended internally while preserving order and structure.  
- **Common uses:**  
  - Incremental page construction  
  - Adding HTML blocks, widgets, text, or scripts  
  - Modular composition of layouts'''
        self.page_base.append(element)
    def __str__(self):
        '''### `__str__()`
Finalizes and returns the page representation.

- **Purpose:** generate the final page output based on all added elements.  
- **Returns:** usually a string containing the assembled HTML.  
- **How it works:**  
  - Merges `page_base` with the collected elements  
  - Produces the final layout for rendering  
- **Common uses:**  
  - HTML generation in frameworks  
  - Rendering pages in the browser  
  - Exporting the finished layout'''
        html = ''
        for e in self.page_base:
            html += f'{e}\n'
            
        return html

class Window:
    def __init__(self):
        '''
The **Window** class is responsible for creating and managing the main application window using **PyWebView**.  
It centralizes the configuration of visual appearance, layout, window behavior, window state, and backend–frontend integration through JavaScript APIs.

The following attributes define the initial state and capabilities of the window.

---

## Main Attributes

### 🖼️ **Visual Settings**
| Attribute | Description |
|----------|-------------|
| `title` | Window title displayed in the title bar. |
| `background_color` | Background color (hex). |
| `transparent` | Enables window transparency. |
| `vibrancy` | Enables vibrancy effect (macOS). |
| `frameless` | Removes the default window frame. |
| `text_select` | Enables or disables text selection inside the HTML. |

---

### 🧩 **Content & Integration**
| Attribute | Description |
|----------|-------------|
| `html` | Initial HTML content. |
| `js_api` | Object exposed to JavaScript for backend ↔ frontend communication. |

---

### 📏 **Dimensions**
| Attribute | Description |
|----------|-------------|
| `width` | Initial width of the window. |
| `height` | Initial height of the window. |
| `min_size` | Minimum window size (width, height). |
| `resizable` | Allows window resizing. |

---

### 📍 **Position**
| Attribute | Description |
|----------|-------------|
| `x` | Window X position (optional). |
| `y` | Window Y position (optional). |

---

### ⚙️ **Behavior & State**
| Attribute | Description |
|----------|-------------|
| `fullscreen` | Starts in fullscreen mode. |
| `hidden` | Starts with the window hidden. |
| `minimized` | Starts minimized. |
| `on_top` | Keeps the window always on top. |
| `confirm_close` | Prompts confirmation when closing. |

---

### 🖱️ **Drag & Interaction**
| Attribute | Description |
|----------|-------------|
| `easy_drag` | Allows dragging by clicking any part of the window. |
| `draggable` | Enables only specific draggable areas. |
'''
        self.all_style = ''
        self.pages = {'home.page' : ''}
        self.app = Server(__name__, self.pages)
        
        self.title = 'WeavexPy Window'
        self.html = None
        self.js_api = None
        self.width = 800
        self.height = 600
        self.x = None
        self.y = None
        self.resizable = True
        self.fullscreen = False
        self.min_size = (200, 100)
        self.hidden = False
        self.frameless = False
        self.easy_drag = True
        self.minimized = False
        self.on_top = False
        self.confirm_close = False
        self.background_color = '#FFFFFF'
        self.text_select = False
        self.draggable = True
        self.vibrancy = None
        self.transparent = False
        
        


    def img_format(self, src, mimetype='image/png'):
        return self.app.__img__(src, mimetype)
    def add_style(self, css_style) : 
        '''
## add_style(css_style)

The **add_style** method adds a global CSS style to the entire application.  
It injects CSS rules into the PyWebView window, enabling consistent theming, layout standardization, and the ability to override default styles across all rendered pages.

---

## Parameters

### `css_style`
A string containing valid CSS rules.

- **Type:** `str`
- **Example:**
  ```css
  body { background-color: #222; color: white; }
'''
        self.all_style += f'<style>\n{css_style}\n</style>'
    
    def page(self, route):
        '''## page(route)

The **page** method allows the creation of complex pages using internal application functions.  
Unlike `form_page`, which is intended for simple and static layouts, this method is suited for dynamic pages that rely on Python processing or internal logic.

A route is registered and linked to a Python callback function responsible for generating or assembling the page content.

---

## Parameters

### `route`
Name or path of the page route.

- **Type:** `str`
- **Purpose:** identifies the internal page handled by a function.

---

## How it works
- The route is associated with an internal callback function.
- When the page is accessed, the function is executed.
- The callback can:
  - build HTML dynamically  
  - query databases  
  - process application data  
  - generate components programmatically  
- Ideal for non-static, logic-driven pages.

---

## Common uses
- Dynamic pages with frequently updated data.
- Dashboards, admin panels, and logic-heavy screens.
- Programmatically generated HTML or components.
- Interfaces that react to internal application states.'''
        def dec(func):
            nonlocal route
            route = str(route) if not route in ['/', 'home'] else 'pg.bp'
            if route in ['/', 'home'] : print('[ERRO] back page not in "/" or "home"')
            self.pages[str(route)] = func  
            
        return dec
    
    def form_page(self, route):
        '''## form_page

The **form_page** method allows the creation of simple pages within the application.  
It is particularly recommended for forms, static content, or lightweight layouts that do not require complex components.

It registers a new page that can be rendered or navigated to within the main window.

---

## Parameters

### `route`
Identifier for the page.

- **Type:** `str`
- **Purpose:** route the page.

---

## How it works
- The page is stored inside the window instance.
- It can be rendered at any moment.
- Ideal for:
  - small forms
  - registration screens
  - simple static interfaces

---

## Common uses
- Creating lightweight static pages.
- Building login or registration forms.
- Organizing multiple screens inside a single window.'''
        def dec(func):
            nonlocal route
            route = str(route) if route in ['/', 'home'] else 'home'
            html = ''
            page = func(page = ObjectPage([]))
            if isinstance(page, list) :
                for pg in page :
                    html += f'{pg}\n'
            else : html = str(page)
            
            html_format = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/brython@3.11.0/brython.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/brython@3.11.0/brython_stdlib.js"></script>
    <title>Document</title>
{self.all_style}
</head>
<script type="module" src="https://pyscript.net/releases/2025.11.1/core.js"></script>
<body onload="brython()">
{html}
</body>
</html>'''
            
            self.pages[str(route)] = html_format
            
        return dec
            
        
                
    def run(self):
        '''Executa a aplicação, inicializando todas as páginas, estilos e rotas configuradas.'''
        def server():
            self.app.veri().run('0.0.0.0', '5000', debug=False)
            
        Thread(target=server, daemon=True).start()
            
        def qt():
            window = webview.create_window(
                url = 'http://127.0.0.1:5000',
                title=self.title,
                html=self.html,
                js_api=self.js_api,
                width=self.width,
                height=self.height,
                x=self.x,
                y=self.y,
                resizable=self.resizable,
                fullscreen=self.fullscreen,
                min_size=self.min_size,
                hidden=self.hidden,
                frameless=self.frameless,
                easy_drag=self.easy_drag,
                minimized=self.minimized,
                on_top=self.on_top,
                confirm_close=self.confirm_close,
                background_color=self.background_color,
                text_select=self.text_select,
                draggable=self.draggable,
                vibrancy=self.vibrancy,
                transparent=self.transparent
            )

            webview.start(gui="ctk")


        qt()
