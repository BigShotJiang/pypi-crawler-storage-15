from .style import *
class CSS:
    def __init__(self, tag):
        self.s = style('{}')
        self.style = self.s.obj_sty
        self.tag = tag
        
    def set(self) : return f'{self.tag} {self.s.set()}\n'
    
def get_html(html, arq=False):
    html_ = ''
    if arq == False:
        if isinstance(html, list):
            for _ in html:
                html_ += str(_) + '\n'
        else:
            html_ += html
    else:
        with open(f'{html}.html', "r", encoding="utf-8") as f:
            conteudo = f.read() 
                
        html_ += conteudo 
        
    return html_
        
def get_js(js, arq=False):
    js_ = ''
    if arq == False:
        if isinstance(js, list):
            for _ in js:
                js_ += str(_) + '\n'
        else:
            js_ += js
    else:
        with open(f'{js}.js', "r", encoding="utf-8") as f:
            conteudo = f.read() 
                
        js_ += conteudo
        
    return js_

class create_object_style:
    def __init__(self, name):
        self.name = f'.{name}'

    def norm(self):
        return self.name

    def focus(self):
        return self.name + ':focus'
    
    def active(self):
        return self.name + ':active'
    
    def hover(self):
        return self.name + ':hover'

    def ativo(self):
        return self.name + '.ativo'


def scale(s):
    return f'scale({s})'

def rgb(r=255, b=255, g=255):
    return f'rgb({r}, {b}, {g})'
def hex_shadow(hex_color):
    hex_color = hex_color.lstrip('#')

    if len(hex_color) == 6: 
        r = int(hex_color[0:2], 16)
        g = int(hex_color[2:4], 16)
        b = int(hex_color[4:6], 16)
        a = 1  
    elif len(hex_color) == 8:  
        r = int(hex_color[0:2], 16)
        g = int(hex_color[2:4], 16)
        b = int(hex_color[4:6], 16)
        a = int(hex_color[6:8], 16) / 255
    else:
        raise ValueError("Formato inválido. Use RRGGBB ou RRGGBBAA")

    return f"rgba({r},{g},{b},{a})"

def s(var):
    return f'{var}s'

def deg(var):
    return f'{var}deg'
def px(var):
    return f'{var}px'
def cm(var):
    return f'{var}cm'
def mm(var):
    return f'{var}mm'
def pt(var):
    return f'{var}pt'
def pc(var):
    return f'{var}pc'

def rel(var):
    '''var -> %var '''
    return f'{var}%'
def em(var):
    return f'{var}em'
def rem(var):
    return f'{var}rem'
def ex(var):
    return f'{var}ex'
def ch(var):
    return f'{var}ch'
def vh(var):
    return f'{var}vh'
def vw(var):
    return f'{var}vw'
def vmin(var):
    return f'{var}vmin'
def vmax(var):
    return f'{var}vmax'


def hr_shadow(size=px(2), color='#ccc', box_shadow = (0, 'low', px(5)), shadow_color = hex_shadow('#000000')):
    sh = box_shadow[1]
    if sh == 'low': sh = 2
    elif sh == 'top' : sh = -2
    sh = px(sh)
    return f'<hr style="border: none; border-top: {size} solid {color}; box-shadow: {box_shadow[0]} {sh} {box_shadow[2]} {shadow_color};">'
def hr_boder_style(size=px(2), color='#000', boder_top = 'solid'):
    return f'<hr style"border: none; border-top: {size} {boder_top} {color};">'
def br_style(style):
    return f'<br style={style}>'
def hr_style(style):
    return f'<hr style={style}>'

def translate(x, y):
    return f'translate({x}, {y})'
def custom(*values):
    return ' '.join(values)