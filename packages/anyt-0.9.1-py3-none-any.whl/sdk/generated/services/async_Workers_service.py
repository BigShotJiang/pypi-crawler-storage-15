from typing import *
import httpx


from ..models import *
from ..api_config import APIConfig, HTTPException

async def getProjectCloneInfo(api_config_override : Optional[APIConfig] = None, *, project_id : int, X_Worker_Token : str) -> CloneInfo:
    api_config = api_config_override if api_config_override else APIConfig()

    base_path = api_config.base_path
    path = f'/v1/workers/projects/{project_id}/clone-info'
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': f'Bearer { api_config.get_access_token() }',
        'X-Worker-Token' : X_Worker_Token
    }
    headers = {key:value for (key,value) in headers.items() if value is not None and not (key == 'Authorization' and value == 'Bearer None')}
    query_params : Dict[str,Any] = {
        }

    query_params = {key:value for (key,value) in query_params.items() if value is not None}

    async with httpx.AsyncClient(base_url=base_path, verify=api_config.verify) as client:
        response = await client.request(
            'post',
        httpx.URL(path),
        headers=headers,
        params=query_params,
            )

    if response.status_code != 200:
        raise HTTPException(response.status_code, f'getProjectCloneInfo failed with status code: {response.status_code}')
    else:
                body = None if 200 == 204 else response.json()

    return CloneInfo(**body) if body is not None else CloneInfo()
async def listDemoProjects(api_config_override : Optional[APIConfig] = None, *, X_Worker_Token : str, limit : Optional[int] = None, offset : Optional[int] = None) -> List[Project]:
    api_config = api_config_override if api_config_override else APIConfig()

    base_path = api_config.base_path
    path = f'/v1/workers/projects'
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': f'Bearer { api_config.get_access_token() }',
        'X-Worker-Token' : X_Worker_Token
    }
    headers = {key:value for (key,value) in headers.items() if value is not None and not (key == 'Authorization' and value == 'Bearer None')}
    query_params : Dict[str,Any] = {
            'limit' : limit,
'offset' : offset
        }

    query_params = {key:value for (key,value) in query_params.items() if value is not None}

    async with httpx.AsyncClient(base_url=base_path, verify=api_config.verify) as client:
        response = await client.request(
            'get',
        httpx.URL(path),
        headers=headers,
        params=query_params,
            )

    if response.status_code != 200:
        raise HTTPException(response.status_code, f'listDemoProjects failed with status code: {response.status_code}')
    else:
                body = None if 200 == 204 else response.json()

    return [Project(**item) for item in body]
async def listDemoTasks(api_config_override : Optional[APIConfig] = None, *, X_Worker_Token : str, status : Optional[str] = None, limit : Optional[int] = None, offset : Optional[int] = None) -> TaskListResponse:
    api_config = api_config_override if api_config_override else APIConfig()

    base_path = api_config.base_path
    path = f'/v1/workers/demo-tasks'
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': f'Bearer { api_config.get_access_token() }',
        'X-Worker-Token' : X_Worker_Token
    }
    headers = {key:value for (key,value) in headers.items() if value is not None and not (key == 'Authorization' and value == 'Bearer None')}
    query_params : Dict[str,Any] = {
            'status' : status,
'limit' : limit,
'offset' : offset
        }

    query_params = {key:value for (key,value) in query_params.items() if value is not None}

    async with httpx.AsyncClient(base_url=base_path, verify=api_config.verify) as client:
        response = await client.request(
            'get',
        httpx.URL(path),
        headers=headers,
        params=query_params,
            )

    if response.status_code != 200:
        raise HTTPException(response.status_code, f'listDemoTasks failed with status code: {response.status_code}')
    else:
                body = None if 200 == 204 else response.json()

    return TaskListResponse(**body) if body is not None else TaskListResponse()
async def getWorkerTask(api_config_override : Optional[APIConfig] = None, *, identifier : str, X_Worker_Token : str) -> Task:
    api_config = api_config_override if api_config_override else APIConfig()

    base_path = api_config.base_path
    path = f'/v1/workers/tasks/{identifier}'
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': f'Bearer { api_config.get_access_token() }',
        'X-Worker-Token' : X_Worker_Token
    }
    headers = {key:value for (key,value) in headers.items() if value is not None and not (key == 'Authorization' and value == 'Bearer None')}
    query_params : Dict[str,Any] = {
        }

    query_params = {key:value for (key,value) in query_params.items() if value is not None}

    async with httpx.AsyncClient(base_url=base_path, verify=api_config.verify) as client:
        response = await client.request(
            'get',
        httpx.URL(path),
        headers=headers,
        params=query_params,
            )

    if response.status_code != 200:
        raise HTTPException(response.status_code, f'getWorkerTask failed with status code: {response.status_code}')
    else:
                body = None if 200 == 204 else response.json()

    return Task(**body) if body is not None else Task()
async def updateWorkerTask(api_config_override : Optional[APIConfig] = None, *, identifier : str, X_Worker_Token : str, data : TaskUpdate) -> Task:
    api_config = api_config_override if api_config_override else APIConfig()

    base_path = api_config.base_path
    path = f'/v1/workers/tasks/{identifier}'
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': f'Bearer { api_config.get_access_token() }',
        'X-Worker-Token' : X_Worker_Token
    }
    headers = {key:value for (key,value) in headers.items() if value is not None and not (key == 'Authorization' and value == 'Bearer None')}
    query_params : Dict[str,Any] = {
        }

    query_params = {key:value for (key,value) in query_params.items() if value is not None}

    async with httpx.AsyncClient(base_url=base_path, verify=api_config.verify) as client:
        response = await client.request(
            'patch',
        httpx.URL(path),
        headers=headers,
        params=query_params,
                        json = data.model_dump()
                    )

    if response.status_code != 200:
        raise HTTPException(response.status_code, f'updateWorkerTask failed with status code: {response.status_code}')
    else:
                body = None if 200 == 204 else response.json()

    return Task(**body) if body is not None else Task()
async def addWorkerComment(api_config_override : Optional[APIConfig] = None, *, identifier : str, X_Worker_Token : str, data : CreateCommentRequest) -> Comment:
    api_config = api_config_override if api_config_override else APIConfig()

    base_path = api_config.base_path
    path = f'/v1/workers/tasks/{identifier}/comments'
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': f'Bearer { api_config.get_access_token() }',
        'X-Worker-Token' : X_Worker_Token
    }
    headers = {key:value for (key,value) in headers.items() if value is not None and not (key == 'Authorization' and value == 'Bearer None')}
    query_params : Dict[str,Any] = {
        }

    query_params = {key:value for (key,value) in query_params.items() if value is not None}

    async with httpx.AsyncClient(base_url=base_path, verify=api_config.verify) as client:
        response = await client.request(
            'post',
        httpx.URL(path),
        headers=headers,
        params=query_params,
                        json = data.model_dump()
                    )

    if response.status_code != 200:
        raise HTTPException(response.status_code, f'addWorkerComment failed with status code: {response.status_code}')
    else:
                body = None if 200 == 204 else response.json()

    return Comment(**body) if body is not None else Comment()
async def createWorkerPullRequest(api_config_override : Optional[APIConfig] = None, *, identifier : str, X_Worker_Token : str, data : CreateTaskPRRequest) -> PullRequest:
    api_config = api_config_override if api_config_override else APIConfig()

    base_path = api_config.base_path
    path = f'/v1/workers/tasks/{identifier}/pull-requests'
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': f'Bearer { api_config.get_access_token() }',
        'X-Worker-Token' : X_Worker_Token
    }
    headers = {key:value for (key,value) in headers.items() if value is not None and not (key == 'Authorization' and value == 'Bearer None')}
    query_params : Dict[str,Any] = {
        }

    query_params = {key:value for (key,value) in query_params.items() if value is not None}

    async with httpx.AsyncClient(base_url=base_path, verify=api_config.verify) as client:
        response = await client.request(
            'post',
        httpx.URL(path),
        headers=headers,
        params=query_params,
                        json = data.model_dump()
                    )

    if response.status_code != 201:
        raise HTTPException(response.status_code, f'createWorkerPullRequest failed with status code: {response.status_code}')
    else:
                body = None if 201 == 204 else response.json()

    return PullRequest(**body) if body is not None else PullRequest()
async def listPendingPullRequests(api_config_override : Optional[APIConfig] = None, *, X_Worker_Token : str) -> List[PullRequest]:
    api_config = api_config_override if api_config_override else APIConfig()

    base_path = api_config.base_path
    path = f'/v1/workers/pull-requests/pending'
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': f'Bearer { api_config.get_access_token() }',
        'X-Worker-Token' : X_Worker_Token
    }
    headers = {key:value for (key,value) in headers.items() if value is not None and not (key == 'Authorization' and value == 'Bearer None')}
    query_params : Dict[str,Any] = {
        }

    query_params = {key:value for (key,value) in query_params.items() if value is not None}

    async with httpx.AsyncClient(base_url=base_path, verify=api_config.verify) as client:
        response = await client.request(
            'get',
        httpx.URL(path),
        headers=headers,
        params=query_params,
            )

    if response.status_code != 200:
        raise HTTPException(response.status_code, f'listPendingPullRequests failed with status code: {response.status_code}')
    else:
                body = None if 200 == 204 else response.json()

    return [PullRequest(**item) for item in body]
async def updateWorkerPullRequest(api_config_override : Optional[APIConfig] = None, *, pr_id : int, X_Worker_Token : str, data : UpdatePRRequest) -> PullRequest:
    api_config = api_config_override if api_config_override else APIConfig()

    base_path = api_config.base_path
    path = f'/v1/workers/pull-requests/{pr_id}'
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': f'Bearer { api_config.get_access_token() }',
        'X-Worker-Token' : X_Worker_Token
    }
    headers = {key:value for (key,value) in headers.items() if value is not None and not (key == 'Authorization' and value == 'Bearer None')}
    query_params : Dict[str,Any] = {
        }

    query_params = {key:value for (key,value) in query_params.items() if value is not None}

    async with httpx.AsyncClient(base_url=base_path, verify=api_config.verify) as client:
        response = await client.request(
            'patch',
        httpx.URL(path),
        headers=headers,
        params=query_params,
                        json = data.model_dump()
                    )

    if response.status_code != 200:
        raise HTTPException(response.status_code, f'updateWorkerPullRequest failed with status code: {response.status_code}')
    else:
                body = None if 200 == 204 else response.json()

    return PullRequest(**body) if body is not None else PullRequest()