from enum import Enum

class AssigneeType(str, Enum):
    
        HUMAN = 'human'
        
        AGENT = 'agent'
        