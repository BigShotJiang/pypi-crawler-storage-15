from typing import *
from pydantic import BaseModel, Field
from .Project import Project
from .ExternalRepo import ExternalRepo

class DemoProjectResponse(BaseModel):
    """
    DemoProjectResponse model
        Response for demo project creation/retrieval.
            """
    model_config = {
        "populate_by_name": True,
        "validate_assignment": True
    }
    
    project : Project = Field(validation_alias="project" )
    
    external_repo : ExternalRepo = Field(validation_alias="external_repo" )
    
    is_new : bool = Field(validation_alias="is_new" )
    