from enum import Enum

class SummaryPeriod(str, Enum):
    
        DAILY = 'daily'
        
        WEEKLY = 'weekly'
        
        MONTHLY = 'monthly'
        