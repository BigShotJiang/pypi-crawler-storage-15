from typing import *
from pydantic import BaseModel, Field

class ApprovePlanRequest(BaseModel):
    """
    ApprovePlanRequest model
        Request for approving a plan.
            """
    model_config = {
        "populate_by_name": True,
        "validate_assignment": True
    }
    
    feedback : Optional[Union[str,None]] = Field(validation_alias="feedback" , default = None )
    