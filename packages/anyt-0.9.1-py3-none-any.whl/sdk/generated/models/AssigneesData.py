from typing import *
from pydantic import BaseModel, Field
from .AssigneeUser import AssigneeUser
from .AssigneeAgent import AssigneeAgent
from .AssigneeCodingAgent import AssigneeCodingAgent

class AssigneesData(BaseModel):
    """
    AssigneesData model
        Data structure for assignees with separate users, agents, and coding_agents arrays.
            """
    model_config = {
        "populate_by_name": True,
        "validate_assignment": True
    }
    
    users : Optional[List[Optional[AssigneeUser]]] = Field(validation_alias="users" , default = None )
    
    agents : Optional[List[Optional[AssigneeAgent]]] = Field(validation_alias="agents" , default = None )
    
    coding_agents : Optional[List[Optional[AssigneeCodingAgent]]] = Field(validation_alias="coding_agents" , default = None )
    