Run quality checks, commit changes, and create a pull request for the current task.

**Workflow:**

1. **Discover project quality check commands:**
   - Look for quality check commands in the project:
     - `Makefile` (e.g., `make lint`, `make test`, `make typecheck`, `make format`)
     - `package.json` scripts (e.g., `npm run lint`, `npm test`, `npm run build`)
     - `pyproject.toml` or `setup.py` (e.g., `pytest`, `ruff check`, `mypy`)
     - CI config files (`.github/workflows/`, `.gitlab-ci.yml`)
   - Identify commands for: formatting, linting, type checking, testing

2. **Run quality checks:**
   - Execute the discovered quality check commands in order:
     1. Format code (if formatter exists)
     2. Run linting
     3. Run type checking (if applicable)
     4. Run tests
   - If any check fails:
     - Attempt to fix automatically (formatting, simple lint fixes)
     - If unfixable, stop and inform the user of the issue
   - Continue only when all checks pass

3. **Check git status and commit:**
   - Run `git status` to see changes
   - Run `git diff` to review what will be committed
   - If there are uncommitted changes:
     - Stage relevant files with `git add`
     - Create a descriptive commit message based on changes
     - Commit with standard footer

4. **Check for active AnyTask task:**
   - Run `anyt task active --json` to get the currently picked task
   - If a task is active, extract:
     - Task identifier (e.g., "DEV-42")
     - Task title
     - Task description and objectives
   - If no active task, proceed with generic PR creation

5. **Read task context (if active task exists):**
   - Check if `.anyt/tasks/{IDENTIFIER}/` exists locally
   - Read `task.md` for description and acceptance criteria
   - Read `.meta.json` for status and labels

6. **Create pull request:**
   - Push current branch to remote: `git push -u origin HEAD`
   - Use `gh pr create` with appropriate context:

   **With active task:**
   ```bash
   gh pr create --title "[{IDENTIFIER}] {Task Title}" --body "$(cat <<'EOF'
   ## Summary
   Implements [{IDENTIFIER}] {Task Title}

   **Objectives:**
   - [Objective 1 from task]
   - [Objective 2 from task]

   **Changes:**
   - [Bullet points summarizing commits]

   ## Acceptance Criteria
   - [ ] [Criterion 1 from task]
   - [ ] [Criterion 2 from task]

   ## Test Plan
   - [ ] All tests pass
   - [ ] Type checking passes
   - [ ] Linting passes
   - [ ] Manual testing completed

   🤖 Generated with [Claude Code](https://claude.com/claude-code)
   EOF
   )"
   ```

   **Without active task:**
   ```bash
   gh pr create --title "{Descriptive title from commits}" --body "$(cat <<'EOF'
   ## Summary
   - [Main change]
   - [Secondary changes]

   ## Changes
   [Summary from git log main...HEAD]

   ## Test Plan
   - [ ] All tests pass
   - [ ] Linting passes

   🤖 Generated with [Claude Code](https://claude.com/claude-code)
   EOF
   )"
   ```

7. **Register PR with task (if active):**
   - After PR is created successfully, register it with AnyTask:
     ```bash
     # Extract PR info from gh pr create output
     PR_URL=$(gh pr view --json url -q .url)
     PR_NUMBER=$(gh pr view --json number -q .number)
     HEAD_BRANCH=$(git branch --show-current)
     BASE_BRANCH=main  # or the target branch
     HEAD_SHA=$(git rev-parse HEAD)

     # Register the PR
     anyt task pr register {IDENTIFIER} \
       --pr-number $PR_NUMBER \
       --pr-url $PR_URL \
       --head-branch $HEAD_BRANCH \
       --base-branch $BASE_BRANCH \
       --head-sha $HEAD_SHA
     ```
   - Add a comment noting the PR was created:
     ```bash
     anyt comment add {IDENTIFIER} -m "PR created: {PR_URL}"
     ```

8. **Return result:**
   - Show the PR URL to the user
   - Summarize what was done

**Important:**
- Always run quality checks before committing
- Use HEREDOC format for PR body to preserve formatting
- Do NOT push directly to main/master branch
- Include task context in PR when available
- Use descriptive commit messages following conventional commits style
- Return the PR URL when complete

**Example with active task:**
```bash
# 1. Run quality checks
npm run lint && npm run typecheck && npm test

# 2. Commit changes
git add .
git commit -m "feat(comments): add threading support

Implements comment threading with nested replies.

🤖 Generated with [Claude Code](https://claude.com/claude-code)

Co-Authored-By: Claude <noreply@anthropic.com>"

# 3. Check active task
anyt task active --json
# Returns: {"identifier": "DEV-42", "title": "Add comment threading", ...}

# 4. Push and create PR
git push -u origin HEAD
gh pr create --title "[DEV-42] Add comment threading" --body "..."

# 5. Register PR with task
PR_NUMBER=$(gh pr view --json number -q .number)
PR_URL=$(gh pr view --json url -q .url)
anyt task pr register DEV-42 \
  --pr-number $PR_NUMBER \
  --pr-url $PR_URL \
  --head-branch $(git branch --show-current) \
  --base-branch main \
  --head-sha $(git rev-parse HEAD)

# 6. Add comment
anyt comment add DEV-42 -m "PR created: $PR_URL"
```

Create the PR now.
