"""Shared helpers for task update operations."""

from typing import Any, Optional

from cli.commands.formatters import output_json
from cli.models.common import Priority, Status
from cli.models.task import TaskUpdate
from cli.models.wrappers.task import Task
from cli.services.task_service import TaskService

from ..helpers import console


def validate_priority(
    priority: Optional[int],
    json_output: bool = False,
) -> bool:
    """Validate priority value is within range.

    Args:
        priority: Priority value to validate
        json_output: Whether to output JSON format

    Returns:
        True if valid, False otherwise (and outputs error message)
    """
    if priority is not None and (priority < -2 or priority > 2):
        if json_output:
            output_json(
                {
                    "error": "ValidationError",
                    "message": "Invalid priority value",
                    "details": "Priority must be between -2 and 2",
                },
                success=False,
            )
        else:
            console.print("[red]Error:[/red] Invalid priority value")
            console.print("  Priority must be between -2 and 2")
        return False
    return True


def validate_status(
    status: Optional[str],
    json_output: bool = False,
) -> Optional[Status]:
    """Validate and convert status string to enum.

    Args:
        status: Status string to validate
        json_output: Whether to output JSON format

    Returns:
        Status enum if valid, None if not provided, or raises Exit if invalid
    """
    if status is None:
        return None

    try:
        return Status(status)
    except ValueError:
        valid_statuses = ", ".join([s.value for s in Status])
        if json_output:
            output_json(
                {
                    "error": "ValidationError",
                    "message": f"Invalid status '{status}'. Valid statuses: {valid_statuses}",
                },
                success=False,
            )
        else:
            console.print(f"[red]Error:[/red] Invalid status '{status}'")
            console.print(f"Valid statuses: {valid_statuses}")
        return None  # Caller should check and exit


def build_task_update(
    title: Optional[str] = None,
    description: Optional[str] = None,
    status: Optional[str] = None,
    priority: Optional[int] = None,
    owner: Optional[str] = None,
    labels: Optional[str] = None,
    estimate: Optional[int] = None,
) -> TaskUpdate:
    """Build a TaskUpdate model from optional parameters.

    Args:
        title: New task title
        description: New task description
        status: New status string
        priority: New priority value
        owner: New owner ID
        labels: Comma-separated labels string
        estimate: Time estimate in hours

    Returns:
        TaskUpdate model with non-None values
    """
    # Parse labels
    label_list = None
    if labels is not None:
        label_list = [label.strip() for label in labels.split(",")]

    # Convert priority to enum
    priority_enum = None
    if priority is not None:
        priority_enum = Priority(priority)

    # Convert status to enum
    status_enum = None
    if status is not None:
        status_enum = Status(status)

    return TaskUpdate(
        title=title,
        description=description,
        status=status_enum,
        priority=priority_enum,
        owner_id=owner,
        labels=label_list,
        estimate=estimate,
    )


async def resolve_task_identifiers(
    raw_identifiers: list[str],
    service: TaskService,
    workspace_identifier: Optional[str],
    json_output: bool = False,
) -> tuple[list[str], list[dict[str, Any]]]:
    """Resolve raw identifiers to task identifiers.

    Args:
        raw_identifiers: List of raw task identifiers (UIDs or workspace identifiers)
        service: Task service for resolution
        workspace_identifier: Workspace identifier for normalization
        json_output: Whether to output JSON format

    Returns:
        Tuple of (resolved_ids, errors)
    """
    from ..helpers import resolve_task_identifier

    resolved_ids: list[str] = []
    errors: list[dict[str, Any]] = []

    for raw_id in raw_identifiers:
        try:
            resolved = await resolve_task_identifier(
                raw_id, service, workspace_identifier
            )
            resolved_ids.append(resolved)
        except Exception as e:  # noqa: BLE001 - Intentionally broad: gracefully handle resolution failures
            error_msg = str(e)
            error = format_error_result(
                raw_id, "ResolutionError", f"Failed to resolve identifier: {error_msg}"
            )
            errors.append(error)
            if not json_output:
                console.print(
                    f"[red]Error:[/red] Failed to resolve identifier '{raw_id}': {error_msg}"
                )

    return resolved_ids, errors


def format_error_result(
    task_id: str,
    error_type: str,
    message: str,
    **extra: Any,
) -> dict[str, Any]:
    """Format an error result dictionary.

    Args:
        task_id: Task identifier
        error_type: Type of error (e.g., "NotFound", "ValidationError")
        message: Error message
        **extra: Additional fields to include

    Returns:
        Error dictionary
    """
    result: dict[str, Any] = {
        "task_id": task_id,
        "error": error_type,
        "message": message,
    }
    result.update(extra)
    return result


def display_dry_run_preview(
    task_id: str,
    current_task: Task,
    title: Optional[str] = None,
    description: Optional[str] = None,
    status: Optional[str] = None,
    priority: Optional[int] = None,
    labels: Optional[list[str]] = None,
    owner: Optional[str] = None,
    estimate: Optional[int] = None,
) -> None:
    """Display a preview of changes in dry-run mode.

    Args:
        task_id: Task identifier
        current_task: Current task data
        title: New title (if changing)
        description: New description (if changing)
        status: New status (if changing)
        priority: New priority (if changing)
        labels: New labels (if changing)
        owner: New owner (if changing)
        estimate: New estimate (if changing)
    """
    console.print(f"[yellow][Preview][/yellow] Would update {task_id}:")

    if title is not None:
        console.print(f"  title: {current_task.title} -> {title}")

    if description is not None:
        console.print("  description: <updated>")

    if status is not None:
        current_status = (
            current_task.status.value
            if isinstance(current_task.status, Status)
            else current_task.status
        )
        console.print(f"  status: {current_status} -> {status}")

    if priority is not None:
        current_priority = (
            current_task.priority.value
            if isinstance(current_task.priority, Priority)
            else current_task.priority
        )
        console.print(f"  priority: {current_priority} -> {priority}")

    if labels is not None:
        console.print(f"  labels: {current_task.labels} -> {labels}")

    if owner is not None:
        console.print(f"  owner: {current_task.owner_id} -> {owner}")

    if estimate is not None:
        console.print(f"  estimate: {current_task.estimate} -> {estimate}")

    console.print(f"  updated_at: {current_task.updated_at} -> <now>")
    console.print()


def display_no_task_error(
    json_output: bool, command_example: str, pick_example: str
) -> None:
    """Display error for missing task identifier.

    Args:
        json_output: Whether to output JSON format
        command_example: Example command with task ID
        pick_example: Example pick command
    """
    if json_output:
        output_json(
            {
                "error": "ValidationError",
                "message": "No task identifier provided and no active task set",
                "suggestions": [
                    f"Specify a task: {command_example}",
                    f"Or pick a task first: {pick_example}",
                ],
            },
            success=False,
        )
    else:
        console.print(
            "[red]Error:[/red] No task identifier provided and no active task set"
        )
        console.print(f"Specify a task: [cyan]{command_example}[/cyan]")
        console.print(f"Or pick a task first: [cyan]{pick_example}[/cyan]")
