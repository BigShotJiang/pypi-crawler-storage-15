"""CLI commands for task implementation plans."""

import json
import sys
from typing import Any, Optional

import typer
from rich.markdown import Markdown
from rich.panel import Panel
from typing_extensions import Annotated

from cli.client.exceptions import APIError, NotFoundError, ValidationError
from cli.commands.console import console
from cli.commands.context import CommandContext
from cli.commands.decorators import async_command
from cli.commands.guards import require_workspace_config
from cli.commands.services import ServiceRegistry as services
from cli.commands.task.helpers import get_active_task_id
from cli.utils.errors import handle_api_error
from cli.utils.typer_utils import HelpOnErrorGroup
from sdk.generated.api_config import APIConfig
from sdk.generated.models.ApprovePlanRequest import ApprovePlanRequest
from sdk.generated.models.RequestPlanChangesRequest import RequestPlanChangesRequest
from sdk.generated.models.SubmitPlanRequest import SubmitPlanRequest
from sdk.generated.services.async_Tasks_service import (
    approveTaskPlan,
    requestTaskPlanChanges,
    submitTaskPlan,
)

app = typer.Typer(help="Manage task implementation plans", cls=HelpOnErrorGroup)


def _get_api_config_and_key(
    ctx: Any,
) -> tuple[APIConfig, str | None]:
    """Get API config and key from context."""
    from cli.config import get_effective_api_config

    api_config_dict = get_effective_api_config()
    base_url = api_config_dict.get("api_url")
    auth_token = api_config_dict.get("auth_token")
    api_key = api_config_dict.get("api_key")

    if not base_url:
        raise ValueError("API base URL not configured")

    return APIConfig(base_path=base_url, access_token=auth_token), api_key


def _format_plan_status(status: str | None) -> str:
    """Format plan review status with colors."""
    if not status:
        return "[dim]none[/dim]"
    status_colors = {
        "pending": "[yellow]pending[/yellow]",
        "approved": "[green]approved[/green]",
        "changes_requested": "[red]changes_requested[/red]",
    }
    return status_colors.get(status, f"[dim]{status}[/dim]")


@app.command("submit")
@async_command()
async def submit_plan(
    identifier: Annotated[
        Optional[str],
        typer.Argument(
            help="Task identifier (e.g., DEV-42). Uses active task if not provided."
        ),
    ] = None,
    plan: Annotated[
        Optional[str],
        typer.Option(
            "--plan",
            "-p",
            help="Implementation plan content. Use '-' to read from stdin.",
        ),
    ] = None,
    plan_file: Annotated[
        Optional[str],
        typer.Option(
            "--file",
            "-f",
            help="Read plan from file.",
        ),
    ] = None,
    auto_approve: Annotated[
        bool,
        typer.Option(
            "--auto-approve",
            help="Auto-approve the plan (skip review).",
        ),
    ] = False,
    json_output: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """Submit an implementation plan for a task.

    The plan can be provided inline, from a file, or from stdin.

    Examples:
        # Submit plan inline
        anyt task plan submit DEV-42 -p "1. Setup project\\n2. Implement feature"

        # Submit plan from file
        anyt task plan submit DEV-42 -f plan.md

        # Submit plan from stdin
        cat plan.md | anyt task plan submit DEV-42 -p -

        # Submit with auto-approve
        anyt task plan submit DEV-42 -f plan.md --auto-approve
    """
    with CommandContext(require_auth=True, require_workspace=True) as ctx:
        workspace_config = require_workspace_config(ctx.workspace_config)

        # Resolve task identifier
        if not identifier:
            identifier = get_active_task_id()
            if not identifier:
                console.print(
                    "[red]Error:[/red] No task identifier provided and no active task set"
                )
                console.print(
                    "Use [cyan]anyt task pick <task-id>[/cyan] to set active task"
                )
                raise typer.Exit(1)

        # Get plan content
        plan_content: str | None = None

        if plan_file:
            # Read from file
            try:
                with open(plan_file) as f:
                    plan_content = f.read()
            except FileNotFoundError:
                console.print(f"[red]Error:[/red] File not found: {plan_file}")
                raise typer.Exit(1)
            except OSError as e:
                console.print(f"[red]Error:[/red] Cannot read file: {e}")
                raise typer.Exit(1)
        elif plan == "-":
            # Read from stdin
            plan_content = sys.stdin.read()
        elif plan:
            # Use inline plan
            plan_content = plan

        if not plan_content:
            console.print(
                "[red]Error:[/red] No plan provided. Use --plan, --file, or pipe to stdin."
            )
            raise typer.Exit(1)

        try:
            api_config, api_key = _get_api_config_and_key(ctx)

            # Submit plan
            request = SubmitPlanRequest(
                implementation_plan=plan_content,
                auto_approve=auto_approve if auto_approve else None,
            )

            task = await submitTaskPlan(
                api_config_override=api_config,
                workspace_id=workspace_config.workspace_id,
                identifier=identifier,
                data=request,
                X_API_Key=api_key,
            )

            if json_output:
                output: dict[str, Any] = {
                    "success": True,
                    "data": {
                        "identifier": task.identifier,
                        "plan_review_status": task.plan_review_status,
                        "auto_approved": auto_approve,
                    },
                }
                print(json.dumps(output, indent=2, default=str))
            else:
                status_str = _format_plan_status(task.plan_review_status)
                console.print(
                    f"[green]✓[/green] Plan submitted for task [cyan]{identifier}[/cyan]"
                )
                console.print(f"  Status: {status_str}")
                if auto_approve:
                    console.print("  [dim]Plan was auto-approved[/dim]")

        except NotFoundError:
            console.print(f"[red]Error:[/red] Task '{identifier}' not found")
            raise typer.Exit(1)
        except ValidationError as e:
            console.print(f"[red]Error:[/red] Invalid plan data: {e}")
            raise typer.Exit(1)
        except APIError as e:
            console.print(f"[red]Error:[/red] {e}")
            raise typer.Exit(1)
        except Exception as e:  # noqa: BLE001
            handle_api_error(e, "submitting plan")


@app.command("show")
@async_command()
async def show_plan(
    identifier: Annotated[
        Optional[str],
        typer.Argument(
            help="Task identifier (e.g., DEV-42). Uses active task if not provided."
        ),
    ] = None,
    json_output: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """Show the implementation plan for a task.

    Examples:
        # Show plan for active task
        anyt task plan show

        # Show plan for specific task
        anyt task plan show DEV-42

        # JSON output
        anyt task plan show DEV-42 --json
    """
    with CommandContext(require_auth=True, require_workspace=True) as ctx:
        workspace_config = require_workspace_config(ctx.workspace_config)

        # Resolve task identifier
        if not identifier:
            identifier = get_active_task_id()
            if not identifier:
                console.print(
                    "[red]Error:[/red] No task identifier provided and no active task set"
                )
                console.print(
                    "Use [cyan]anyt task pick <task-id>[/cyan] to set active task"
                )
                raise typer.Exit(1)

        try:
            tasks_client = services.get_tasks_client()
            task = await tasks_client.get_task_by_workspace(
                workspace_config.workspace_id, identifier
            )

            if json_output:
                output: dict[str, Any] = {
                    "success": True,
                    "data": {
                        "identifier": task.identifier,
                        "implementation_plan": task.implementation_plan,
                        "plan_review_status": task.plan_review_status,
                        "plan_reviewed_at": task.plan_reviewed_at,
                        "plan_reviewed_by": task.plan_reviewed_by,
                    },
                }
                print(json.dumps(output, indent=2, default=str))
            else:
                console.print()
                console.print(f"[cyan bold]{task.identifier}:[/cyan bold] {task.title}")
                console.print("━" * 60)

                # Plan status
                status_str = _format_plan_status(task.plan_review_status)
                console.print(f"Plan Status: {status_str}")

                if task.plan_reviewed_at:
                    console.print(f"Reviewed At: {task.plan_reviewed_at}")
                if task.plan_reviewed_by:
                    console.print(f"Reviewed By: {task.plan_reviewed_by}")

                console.print()

                # Plan content
                if task.implementation_plan:
                    console.print(
                        Panel(
                            Markdown(task.implementation_plan),
                            title="Implementation Plan",
                            border_style="blue",
                        )
                    )
                else:
                    console.print("[dim]No implementation plan submitted yet.[/dim]")

                console.print()

        except NotFoundError:
            console.print(f"[red]Error:[/red] Task '{identifier}' not found")
            raise typer.Exit(1)
        except APIError as e:
            console.print(f"[red]Error:[/red] {e}")
            raise typer.Exit(1)
        except Exception as e:  # noqa: BLE001
            handle_api_error(e, "fetching plan")


@app.command("approve")
@async_command()
async def approve_plan(
    identifier: Annotated[
        Optional[str],
        typer.Argument(
            help="Task identifier (e.g., DEV-42). Uses active task if not provided."
        ),
    ] = None,
    feedback: Annotated[
        Optional[str],
        typer.Option(
            "--feedback",
            "-f",
            help="Optional feedback for the plan author.",
        ),
    ] = None,
    json_output: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """Approve the implementation plan for a task.

    Examples:
        # Approve plan for active task
        anyt task plan approve

        # Approve plan with feedback
        anyt task plan approve DEV-42 -f "Looks good, proceed with implementation"
    """
    with CommandContext(require_auth=True, require_workspace=True) as ctx:
        workspace_config = require_workspace_config(ctx.workspace_config)

        # Resolve task identifier
        if not identifier:
            identifier = get_active_task_id()
            if not identifier:
                console.print(
                    "[red]Error:[/red] No task identifier provided and no active task set"
                )
                console.print(
                    "Use [cyan]anyt task pick <task-id>[/cyan] to set active task"
                )
                raise typer.Exit(1)

        try:
            api_config, api_key = _get_api_config_and_key(ctx)

            # Approve plan
            request = ApprovePlanRequest(feedback=feedback)

            task = await approveTaskPlan(
                api_config_override=api_config,
                workspace_id=workspace_config.workspace_id,
                identifier=identifier,
                data=request,
                X_API_Key=api_key,
            )

            if json_output:
                output: dict[str, Any] = {
                    "success": True,
                    "data": {
                        "identifier": task.identifier,
                        "plan_review_status": task.plan_review_status,
                        "feedback": feedback,
                    },
                }
                print(json.dumps(output, indent=2, default=str))
            else:
                console.print(
                    f"[green]✓[/green] Plan approved for task [cyan]{identifier}[/cyan]"
                )
                if feedback:
                    console.print(f"  Feedback: {feedback}")

        except NotFoundError:
            console.print(f"[red]Error:[/red] Task '{identifier}' not found")
            raise typer.Exit(1)
        except ValidationError as e:
            console.print(f"[red]Error:[/red] Invalid request: {e}")
            raise typer.Exit(1)
        except APIError as e:
            console.print(f"[red]Error:[/red] {e}")
            raise typer.Exit(1)
        except Exception as e:  # noqa: BLE001
            handle_api_error(e, "approving plan")


@app.command("request-changes")
@async_command()
async def request_plan_changes(
    feedback: Annotated[
        str,
        typer.Option(
            "--feedback",
            "-f",
            help="Required feedback explaining what changes are needed.",
        ),
    ],
    identifier: Annotated[
        Optional[str],
        typer.Argument(
            help="Task identifier (e.g., DEV-42). Uses active task if not provided."
        ),
    ] = None,
    json_output: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """Request changes to the implementation plan for a task.

    Feedback is required to explain what changes are needed.

    Examples:
        # Request changes with feedback
        anyt task plan request-changes DEV-42 -f "Please add error handling details"

        # Request changes for active task
        anyt task plan request-changes -f "Need more detail on API design"
    """
    with CommandContext(require_auth=True, require_workspace=True) as ctx:
        workspace_config = require_workspace_config(ctx.workspace_config)

        # Resolve task identifier
        if not identifier:
            identifier = get_active_task_id()
            if not identifier:
                console.print(
                    "[red]Error:[/red] No task identifier provided and no active task set"
                )
                console.print(
                    "Use [cyan]anyt task pick <task-id>[/cyan] to set active task"
                )
                raise typer.Exit(1)

        try:
            api_config, api_key = _get_api_config_and_key(ctx)

            # Request changes
            request = RequestPlanChangesRequest(feedback=feedback)

            task = await requestTaskPlanChanges(
                api_config_override=api_config,
                workspace_id=workspace_config.workspace_id,
                identifier=identifier,
                data=request,
                X_API_Key=api_key,
            )

            if json_output:
                output: dict[str, Any] = {
                    "success": True,
                    "data": {
                        "identifier": task.identifier,
                        "plan_review_status": task.plan_review_status,
                        "feedback": feedback,
                    },
                }
                print(json.dumps(output, indent=2, default=str))
            else:
                console.print(
                    f"[yellow]⚠[/yellow] Changes requested for task [cyan]{identifier}[/cyan]"
                )
                console.print(f"  Feedback: {feedback}")

        except NotFoundError:
            console.print(f"[red]Error:[/red] Task '{identifier}' not found")
            raise typer.Exit(1)
        except ValidationError as e:
            console.print(f"[red]Error:[/red] Invalid request: {e}")
            raise typer.Exit(1)
        except APIError as e:
            console.print(f"[red]Error:[/red] {e}")
            raise typer.Exit(1)
        except Exception as e:  # noqa: BLE001
            handle_api_error(e, "requesting plan changes")
