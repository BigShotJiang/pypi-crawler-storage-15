"""errors rules."""
