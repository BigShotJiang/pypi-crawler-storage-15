"""
Tests for shell_commands module.

This package contains comprehensive tests for the shell command execution
module with timeout support and process cleanup capabilities.
""" 