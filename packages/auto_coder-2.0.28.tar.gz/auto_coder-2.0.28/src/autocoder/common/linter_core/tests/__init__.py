"""
Tests for the linter core module.
""" 