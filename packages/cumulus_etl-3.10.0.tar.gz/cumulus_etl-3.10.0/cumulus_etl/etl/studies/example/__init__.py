"""The example study"""

from .example_tasks import ExampleGpt4oTask as ExampleGpt4oTask
from .example_tasks import ExampleGpt4Task as ExampleGpt4Task
from .example_tasks import ExampleGpt5Task as ExampleGpt5Task
from .example_tasks import ExampleGptOss120bTask as ExampleGptOss120bTask
from .example_tasks import ExampleLlama4ScoutTask as ExampleLlama4ScoutTask
