Simple test case, with only a few rows each for all supported resources.

Usually these can just be pulled from the FHIR spec's examples.