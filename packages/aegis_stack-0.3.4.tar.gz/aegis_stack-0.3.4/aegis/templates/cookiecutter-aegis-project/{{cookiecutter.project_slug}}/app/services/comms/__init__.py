"""
Communications service package.

Provides email (Resend), SMS (Twilio), and voice call (Twilio) functionality.
"""
