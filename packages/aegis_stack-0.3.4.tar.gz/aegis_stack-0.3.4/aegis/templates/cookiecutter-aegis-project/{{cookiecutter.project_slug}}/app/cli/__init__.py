"""
CLI management commands for {{cookiecutter.project_name}}.

This module provides command-line utilities for managing and monitoring
the application outside of the main runtime components.
"""
