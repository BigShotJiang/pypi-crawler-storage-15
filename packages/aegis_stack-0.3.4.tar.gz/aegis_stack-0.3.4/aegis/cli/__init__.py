"""
CLI helper utilities for Aegis Stack.

This module contains validation functions, callbacks, and interactive
components used by CLI commands.
"""
