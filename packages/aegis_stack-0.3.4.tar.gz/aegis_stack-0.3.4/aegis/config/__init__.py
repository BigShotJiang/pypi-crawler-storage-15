"""Configuration module for Aegis Stack."""
