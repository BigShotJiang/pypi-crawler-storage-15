"""Animations and utility mobjects related to update functions.

Modules
=======

.. autosummary::
    :toctree: ../reference

    ~mobject_update_utils
    ~update
"""
