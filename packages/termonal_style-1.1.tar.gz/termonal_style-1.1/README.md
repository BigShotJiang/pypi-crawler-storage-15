# Termonal Style

A simple Python library for adding ANSI escape codes to terminal text for styling and colors.

## Installation

```bash
pip install termonal-style