from .styles import BOLD, END, RED, GREEN, YELLOW, BLUE

# (این کار باعث می‌شود که کاربر بتواند به جای "import term_styles.styles"
# از "from term_styles import RED" استفاده کند)