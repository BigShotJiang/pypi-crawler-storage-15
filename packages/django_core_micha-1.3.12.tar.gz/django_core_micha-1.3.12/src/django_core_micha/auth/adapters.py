from allauth.socialaccount.adapter import DefaultSocialAccountAdapter
from django.contrib.auth import get_user_model

class InvitationOnlySocialAdapter(DefaultSocialAccountAdapter):
    def is_open_for_signup(self, request, sociallogin):
        User = get_user_model()
        email = sociallogin.user.email
        # Erlaubt Login nur, wenn User schon existiert
        return User.objects.filter(email__iexact=email).exists()