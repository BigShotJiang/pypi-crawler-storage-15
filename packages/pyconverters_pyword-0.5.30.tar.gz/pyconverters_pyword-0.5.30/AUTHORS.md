# Authors

Contributors to pyconverters_pyword include:

+ [Olivier Terrier](mailto:olivier.terrier@kairntech.com)
