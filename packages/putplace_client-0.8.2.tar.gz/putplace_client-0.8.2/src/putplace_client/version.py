"""Version information for putplace-client."""

__version__ = "0.8.2"
