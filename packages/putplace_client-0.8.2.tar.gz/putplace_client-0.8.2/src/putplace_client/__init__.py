"""PutPlace Client - CLI tool for scanning directories and uploading file metadata."""

from .version import __version__

__all__ = ["__version__"]
