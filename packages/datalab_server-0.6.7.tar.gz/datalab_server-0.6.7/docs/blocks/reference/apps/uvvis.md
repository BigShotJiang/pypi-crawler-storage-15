title: UV-Vis
::: pydatalab.apps.uvvis
