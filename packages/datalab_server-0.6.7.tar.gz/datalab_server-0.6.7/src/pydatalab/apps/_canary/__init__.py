from pydatalab.blocks.base import DataBlock

raise ImportError("This canary block is only used for internal testing of dynamic block loading.")


class CanaryBlock(DataBlock): ...
