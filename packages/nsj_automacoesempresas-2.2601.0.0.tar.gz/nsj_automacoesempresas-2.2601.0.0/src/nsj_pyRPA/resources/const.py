VERSAO_MINIMA_POSTGRES = 90525
"""Versão mínima do PostgreSQL é a 9.5.25, pois nela contém o recurso 'ON CONFLICT' 
usado na função UpInsert"""

ent_data_base = "database"      #-d
ent_user = "user"               #-u
ent_password = "password"       #-p
ent_host = "host"               #-h
ent_port = "port"               #-o

ent_rotina = "rotina"           #-r
ent_competencia = "competencia" #-c
ent_ano = "ano"                 #-a
ent_semana = "semana"           #-s
ent_semana_desc = "semanadesconto" #-sd
ent_escopo = "escopo"           #-e
ent_faixa = "faixa"             #-f
automacaotipo = "automacaotipo" #-automacaotipo
automacaoempresaparametro = "automacaoempresaparametro" #-automacaoempresaparametro
 
UTILITARIO_PERSONACLI = "personacli.exe"
UTILITARIO_PERSONACLI_DEB = r"C:\Nasajon Sistemas\Versao2502\Integratto2\personacli.exe"