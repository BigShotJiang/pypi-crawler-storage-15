from __future__ import annotations

from pathlib import Path

APP_PATH_README: Path = Path("README.md")
APP_PATH_TEST: Path = Path("tests")
APP_PATH_EXAMPLES: Path = Path("examples")
