from __future__ import annotations

from typing import Any, TypedDict

from httpx import Response


class ApiResponse(TypedDict):
    status_code: int
    data: dict[str, Any] | list[Any] | str | None
    text: str


def from_httpx(response: Response) -> ApiResponse:
    """
    Конвертирует httpx.Response → ApiResponse
    """
    try:
        data = response.json()
    except Exception:
        data = None

    return {
        "status_code": response.status_code,
        "data": data,
        "text": response.text,
        "success": response.is_success,
    }
