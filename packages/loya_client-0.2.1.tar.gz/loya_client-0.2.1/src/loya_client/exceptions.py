from __future__ import annotations


class LoyaError(Exception):
    """Базовое исключение для Loya API"""

    pass


class LoyaAuthError(LoyaError):
    """Ошибка авторизации"""

    pass


class LoyaSessionExpiredError(LoyaError):
    """Сессия истекла (для внутреннего использования)"""

    pass
