from .client import LoyaClient, LoyaClientConfig
from .exceptions import LoyaAuthError, LoyaError
from .types import ApiResponse

try:
    from importlib.metadata import version
    __version__ = version(__name__)  # __name__ == "loya_client"
except Exception:  # PackageNotFoundError или ImportError
    __version__ = "0.0.0+dev"

__all__ = [
    "ApiResponse",
    "LoyaAuthError",
    "LoyaClient",
    "LoyaClientConfig",
    "LoyaError",
]
