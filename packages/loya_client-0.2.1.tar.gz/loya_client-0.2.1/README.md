# loya-client

Асинхронный Python-клиент для Loya Loyalty API с автоматической авторизацией через PLAY2AUTH_SESS_ID.

## Установка

```bash
pip install loya-client
```

## Быстрый старт

```python
from functools import lru_cache
from loya_client import LoyaClient, LoyaClientConfig
import os


@lru_cache()
def get_loya_client() -> LoyaClient:
    config = LoyaClientConfig(
            base_url=os.getenv("LOYA_BASE_URL", "http://loya-backend:9000"),
            email=os.getenv("LOYA_EMAIL", "apiuser@example.com"),
            password_hash=os.getenv(
                "LOYA_PASSWORD_HASH", "hash"
            ),
            apikey=os.getenv("LOYA_APIKEY", "apikey"),
            timeout=float(os.getenv("LOYA_TIMEOUT", "20.0")),
        )

    return LoyaClient(config)

client = get_loya_client()
card = await client.get_card_by_number("7770000002302")
print(card)
```

## Особенности

- Автоматический логин и релогин
- Поддержка сессий через куки
- Чистый, модульный код
- Полная поддержка async/await
- Готов к использованию в FastAPI
