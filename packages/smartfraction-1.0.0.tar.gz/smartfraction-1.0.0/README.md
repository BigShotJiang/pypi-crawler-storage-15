# SmartFraction

Exact rational arithmetic with automatic reduction. No more floating-point errors!

## Installation

```bash
pip install smartfraction