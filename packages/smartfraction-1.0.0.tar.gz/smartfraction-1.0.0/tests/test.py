from smartfraction import SmartFraction

# Create fractions
a = SmartFraction(1, 3)  # 1/3
b = SmartFraction(1, 6)  # 1/6

# Exact arithmetic
print(a + b)  # 1/2 (not 0.333... + 0.166... = 0.499999...)
print(a * b)  # 1/18
print(a / b)  # 2/1 (which prints as 2)

# Auto-reduction
c = SmartFraction(6, 8)
print(c)  # 3/4 (automatically reduced!)

# Mixed numbers
d = SmartFraction(7, 2)
print(d.as_mixed_number())  # "3 1/2"

# Decimal conversion
print(d.to_decimal(10))  # "3.5"