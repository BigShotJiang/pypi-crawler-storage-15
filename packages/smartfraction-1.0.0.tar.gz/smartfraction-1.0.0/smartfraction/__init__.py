"""
SmartFraction - Exact rational arithmetic with automatic reduction

A Python library for exact fraction arithmetic with automatic simplification.
Perfect for financial calculations, measurements, and anywhere precision matters.
"""

from .core import SmartFraction, from_decimal, from_float

__version__ = "1.0.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

__all__ = [
    "SmartFraction",
    "from_decimal", 
    "from_float",
]