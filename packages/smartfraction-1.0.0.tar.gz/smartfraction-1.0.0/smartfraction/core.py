"""
SmartFraction - Exact rational arithmetic with automatic reduction
"""

class SmartFraction:
    """
    A fraction class that automatically reduces fractions and supports
    exact arithmetic operations.
    
    Examples:
    >>> a = SmartFraction(1, 2)
    >>> b = SmartFraction(1, 3)
    >>> print(a + b)
    5/6
    >>> print(a * b)
    1/6
    """
    
    def __init__(self, numerator, denominator=1):
        """
        Initialize a fraction with automatic reduction.
        
        Args:
            numerator: The numerator (integer or another SmartFraction)
            denominator: The denominator (integer, default=1)
        
        Raises:
            ZeroDivisionError: If denominator is zero
        """
        # Handle initialization with another SmartFraction
        if isinstance(numerator, SmartFraction):
            self.n = numerator.n
            self.d = numerator.d
            return
        
        if denominator == 0:
            raise ZeroDivisionError("Denominator cannot be zero")
        
        self.n = int(numerator)
        self.d = int(denominator)
        self._auto_reduce()
    
    @staticmethod
    def _gcd(a, b):
        """Euclidean algorithm for GCD"""
        while b:
            a, b = b, a % b
        return abs(a)
    
    def _auto_reduce(self):
        """Reduce fraction to lowest terms"""
        gcd_val = self._gcd(self.n, self.d)
        
        if gcd_val > 1:
            self.n //= gcd_val
            self.d //= gcd_val
        
        # Ensure denominator positive
        if self.d < 0:
            self.n = -self.n
            self.d = -self.d
    
    # ---------- Arithmetic Operations ----------
    
    def __add__(self, other):
        other = self._ensure_fraction(other)
        gcd_val = self._gcd(self.d, other.d)
        lcm = self.d * other.d // gcd_val
        new_num = self.n * (lcm // self.d) + other.n * (lcm // other.d)
        return SmartFraction(new_num, lcm)
    
    def __sub__(self, other):
        other = self._ensure_fraction(other)
        return self + SmartFraction(-other.n, other.d)
    
    def __mul__(self, other):
        other = self._ensure_fraction(other)
        # Cross-cancellation before multiplication
        gcd1 = self._gcd(abs(self.n), abs(other.d))
        gcd2 = self._gcd(abs(other.n), abs(self.d))
        
        n1 = self.n // gcd1
        d2 = other.d // gcd1
        n2 = other.n // gcd2
        d1 = self.d // gcd2
        
        return SmartFraction(n1 * n2, d1 * d2)
    
    def __truediv__(self, other):
        other = self._ensure_fraction(other)
        if other.n == 0:
            raise ZeroDivisionError("Cannot divide by zero")
        return self * SmartFraction(other.d, other.n)
    
    # ---------- Reverse Operations (e.g., 2 + SmartFraction) ----------
    
    def __radd__(self, other):
        return self.__add__(other)
    
    def __rsub__(self, other):
        return SmartFraction(other) - self
    
    def __rmul__(self, other):
        return self.__mul__(other)
    
    def __rtruediv__(self, other):
        return SmartFraction(other) / self
    
    # ---------- Comparison Operations ----------
    
    def __eq__(self, other):
        other = self._ensure_fraction(other)
        return self.n * other.d == other.n * self.d
    
    def __lt__(self, other):
        other = self._ensure_fraction(other)
        return self.n * other.d < other.n * self.d
    
    def __le__(self, other):
        other = self._ensure_fraction(other)
        return self.n * other.d <= other.n * self.d
    
    def __gt__(self, other):
        return not self.__le__(other)
    
    def __ge__(self, other):
        return not self.__lt__(other)
    
    def __ne__(self, other):
        return not self.__eq__(other)
    
    # ---------- Type Conversion ----------
    
    def __int__(self):
        return self.n // self.d
    
    def __float__(self):
        return self.n / self.d
    
    def __round__(self, ndigits=None):
        return round(float(self), ndigits)
    
    def to_decimal(self, precision=20):
        """Convert to decimal string with specified precision"""
        from decimal import Decimal, getcontext
        getcontext().prec = precision
        return Decimal(self.n) / Decimal(self.d)
    
    # ---------- Utility Methods ----------
    
    def _ensure_fraction(self, value):
        """Convert value to SmartFraction if it isn't already"""
        if isinstance(value, SmartFraction):
            return value
        return SmartFraction(value)
    
    def reciprocal(self):
        """Return the reciprocal of the fraction"""
        return SmartFraction(self.d, self.n)
    
    def is_integer(self):
        """Check if the fraction represents an integer"""
        return self.d == 1
    
    # ---------- String Representation ----------
    
    def __str__(self):
        if self.d == 1:
            return str(self.n)
        return f"{self.n}/{self.d}"
    
    def __repr__(self):
        return f"SmartFraction({self.n}, {self.d})"
    
    def as_mixed_number(self):
        """Return as mixed number string (e.g., "1 1/2")"""
        if abs(self.n) < self.d:
            return str(self)
        whole = self.n // self.d
        remainder = abs(self.n) % self.d
        if remainder == 0:
            return str(whole)
        return f"{whole} {remainder}/{self.d}"
    
    # ---------- Special Methods ----------
    
    def __abs__(self):
        return SmartFraction(abs(self.n), self.d)
    
    def __neg__(self):
        return SmartFraction(-self.n, self.d)
    
    def __pos__(self):
        return self
    
    def __hash__(self):
        return hash((self.n, self.d))

# Convenience functions
def from_decimal(decimal_str):
    """Create SmartFraction from decimal string"""
    from decimal import Decimal
    d = Decimal(decimal_str)
    # Convert to fraction: numerator * 10^-exponent
    sign, digits, exponent = d.as_tuple()
    numerator = int(''.join(map(str, digits)))
    if sign:
        numerator = -numerator
    denominator = 10 ** -exponent if exponent < 0 else 1
    if exponent > 0:
        numerator *= 10 ** exponent
    return SmartFraction(numerator, denominator)

def from_float(f):
    """Create SmartFraction from float (approximate)"""
    # Warning: Floats are imprecise!
    from fractions import Fraction
    frac = Fraction(f).limit_denominator(1000000)
    return SmartFraction(frac.numerator, frac.denominator)