# SPDX-FileCopyrightText: 2024-present Daniel Santillan <daniel.santillan@eox.at>
#
# SPDX-License-Identifier: MIT
__version__ = "0.3.28"
