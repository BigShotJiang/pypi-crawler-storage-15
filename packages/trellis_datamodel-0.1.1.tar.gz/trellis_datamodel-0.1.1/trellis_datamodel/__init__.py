"""Trellis Data - Visual data model editor for dbt projects."""

__version__ = "0.1.0"

