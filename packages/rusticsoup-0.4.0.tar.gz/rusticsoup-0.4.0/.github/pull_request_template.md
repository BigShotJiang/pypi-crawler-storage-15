### Summary

### Type
- [ ] feat
- [ ] fix
- [ ] docs
- [ ] chore
- [ ] test
- [ ] perf
- [ ] refactor

### Checklist
- [ ] Tests added/updated
- [ ] Docs/README updated
- [ ] Lint and format pass (pre-commit)
