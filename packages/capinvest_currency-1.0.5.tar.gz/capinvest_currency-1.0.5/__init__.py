"""The Currency router init."""
