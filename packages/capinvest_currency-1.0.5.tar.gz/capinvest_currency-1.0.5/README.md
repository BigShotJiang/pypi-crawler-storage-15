# CapInvest Currency Extension

This extension provides currency exchange related data for the CapInvest Platform.

 

 
