import numpy as np
from app import app_file
from core import core_file

np.array([1, 2, 3])
app_file()
core_file()
