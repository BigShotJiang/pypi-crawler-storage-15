"""配置管理模块"""
import os


class Config:
    """应用配置"""
    
    # YouTube API
    YOUTUBE_API_KEY: str = os.getenv('YOUTUBE_API_KEY', '')
    
    # API 配额管理
    MAX_SEARCH_RESULTS: int = 50  # 单次搜索最大结果数
    
    @classmethod
    def validate(cls) -> None:
        """验证必需的配置项"""
        if not cls.YOUTUBE_API_KEY:
            raise ValueError(
                "❌ YOUTUBE_API_KEY 未设置!\n\n"
                "请在 MCP 配置文件中设置环境变量:\n\n"
                "{\n"
                '  "mcpServers": {\n'
                '    "youtube-shorts-viral": {\n'
                '      "command": "uvx",\n'
                '      "args": ["youtube-shorts-viral-agent"],\n'
                '      "env": {\n'
                '        "YOUTUBE_API_KEY": "your-api-key-here"\n'
                '      }\n'
                '    }\n'
                '  }\n'
                "}\n\n"
                "获取 API Key: https://console.cloud.google.com/apis/credentials"
            )
    
    @classmethod
    def get_api_key(cls) -> str:
        """获取 YouTube API Key"""
        cls.validate()
        return cls.YOUTUBE_API_KEY


# 全局配置实例
config = Config()
