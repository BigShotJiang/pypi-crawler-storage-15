"""视频热度分析器"""
from datetime import datetime, timezone
from typing import List

from ..models.video import VideoData


class ViralAnalyzer:
    """爆款视频分析器"""
    

    
    @staticmethod
    def calculate_engagement_rate(
        views: int,
        likes: int,
        comments: int
    ) -> float:
        """
        计算互动率 (%)
        
        Args:
            views: 播放量
            likes: 点赞数
            comments: 评论数
        
        Returns:
            互动率百分比
        """
        if views == 0:
            return 0.0
        
        total_engagement = likes + comments
        return (total_engagement / views) * 100
    

    
    @classmethod
    def analyze_video(cls, video: VideoData) -> VideoData:
        """
        分析单个视频并填充指标
        
        Args:
            video: 视频数据
        
        Returns:
            填充了分析指标的视频数据
        """
        # 计算互动率
        video.engagement_rate = cls.calculate_engagement_rate(
            video.views,
            video.likes,
            video.comments
        )
        
        return video
    
    @classmethod
    def analyze_videos(cls, videos: List[VideoData]) -> List[VideoData]:
        """
        批量分析视频
        
        Args:
            videos: 视频列表
        
        Returns:
            分析后的视频列表
        """
        return [cls.analyze_video(video) for video in videos]
    
    @staticmethod
    def rank_videos(videos: List[VideoData]) -> List[VideoData]:
        """
        按播放量排序视频
        
        Args:
            videos: 视频列表
        
        Returns:
            排序后的视频列表(降序)
        """
        return sorted(videos, key=lambda v: v.views, reverse=True)
    
    @staticmethod
    def filter_by_views(
        videos: List[VideoData],
        min_views: int = 0
    ) -> List[VideoData]:
        """
        按播放量阈值筛选视频
        
        Args:
            videos: 视频列表
            min_views: 最低播放量阈值 (默认 0,不筛选)
        
        Returns:
            筛选后的视频列表
        """
        if min_views == 0:
            return videos
        
        return [v for v in videos if v.views >= min_views]
    
    @classmethod
    def generate_analysis_report(cls, video: VideoData) -> str:
        """
        生成单个视频的详细分析报告
        
        Args:
            video: 视频数据
        
        Returns:
            Markdown 格式的分析报告
        """
        report = f"""
## 📊 视频分析报告

**标题**: {video.title}
**链接**: {video.url}

### 基础数据
- **频道**: {video.channel_name}
- **发布时间**: {video.published_at.strftime('%Y-%m-%d %H:%M UTC')}

### 核心指标
- **播放量**: {video.views:,}
- **点赞数**: {video.likes:,}
- **评论数**: {video.comments:,}
- **互动率**: {video.engagement_rate:.2f}%

### 潜力评估
"""
        
        # 播放量评估
        if video.views >= 1000000:
            report += "- ✅ 播放量超过 100万,属于热门视频\n"
        elif video.views >= 500000:
            report += "- ✅ 播放量超过 50万,表现优秀\n"
        elif video.views >= 100000:
            report += "- ⚠️ 播放量超过 10万,值得关注\n"
        else:
            report += "- ℹ️ 播放量较低\n"
        
        # 互动率评估
        if video.engagement_rate >= 10:
            report += "- ✅ 互动率超过 10%,内容质量极高\n"
        elif video.engagement_rate >= 5:
            report += "- ✅ 互动率超过 5%,内容质量优秀\n"
        elif video.engagement_rate >= 2:
            report += "- ⚠️ 互动率一般,有提升空间\n"
        else:
            report += "- ℹ️ 互动率较低\n"
        
        # 频道影响力(如果有数据)
        if video.channel_subscribers:
            subs = video.channel_subscribers
            views_per_sub = video.views / max(subs, 1)
            report += f"\n### 频道影响力\n"
            report += f"- **订阅数**: {subs:,}\n"
            report += f"- **播放/订阅比**: {views_per_sub:.2f}\n"
            
            if views_per_sub >= 0.5:
                report += "- ✅ 播放量远超订阅数,内容传播力强\n"
            elif views_per_sub >= 0.1:
                report += "- ⚠️ 播放量正常,依赖订阅者观看\n"
            else:
                report += "- ℹ️ 播放量低于预期\n"
        
        return report
