"""数据模型模块"""
from .video import VideoData, ChannelData

__all__ = ['VideoData', 'ChannelData']
