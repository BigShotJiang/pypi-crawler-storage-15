"""视频数据模型"""
from datetime import datetime
from typing import Optional
from pydantic import BaseModel, Field


class VideoData(BaseModel):
    """YouTube Shorts 视频数据模型"""
    
    video_id: str = Field(..., description="视频 ID")
    title: str = Field(..., description="视频标题")
    channel_name: str = Field(..., description="频道名称")
    channel_id: str = Field(..., description="频道 ID")
    channel_subscribers: Optional[int] = Field(None, description="频道订阅数")
    
    views: int = Field(..., description="播放量")
    likes: int = Field(default=0, description="点赞数")
    comments: int = Field(default=0, description="评论数")
    
    published_at: datetime = Field(..., description="发布时间")
    duration: str = Field(..., description="视频时长")
    
    url: str = Field(..., description="视频链接")
    thumbnail_url: Optional[str] = Field(None, description="缩略图链接")
    description: Optional[str] = Field(None, description="视频描述")
    
    engagement_rate: float = Field(default=0.0, description="互动率 (%)")
    
    class Config:
        """Pydantic 配置"""
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }
    
    def to_markdown_row(self) -> str:
        """转换为 Markdown 表格行"""
        published_time = self.published_at.strftime('%Y-%m-%d %H:%M')
        return (
            f"| [{self.title[:40]}...]({self.url}) "
            f"| {self.channel_name[:20]} "
            f"| {self.views:,} "
            f"| {self.likes:,} "
            f"| {self.comments:,} "
            f"| {self.engagement_rate:.2f}% "
            f"| {published_time} |"
        )
    
    @staticmethod
    def markdown_header() -> str:
        """Markdown 表格头"""
        return (
            "| 标题 | 频道 | 播放量 | 点赞数 | 评论数 | 互动率 | 发布时间 |\n"
            "|------|------|--------|--------|--------|--------|----------|"
        )


class ChannelData(BaseModel):
    """频道数据模型"""
    
    channel_id: str = Field(..., description="频道 ID")
    channel_name: str = Field(..., description="频道名称")
    subscribers: int = Field(..., description="订阅数")
    total_views: int = Field(..., description="总播放量")
    video_count: int = Field(..., description="视频数量")
