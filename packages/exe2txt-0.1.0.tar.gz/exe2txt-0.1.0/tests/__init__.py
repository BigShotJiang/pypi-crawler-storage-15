"""Tests for exe2txt."""
