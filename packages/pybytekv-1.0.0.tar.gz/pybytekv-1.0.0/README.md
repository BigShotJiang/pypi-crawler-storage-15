# pybytekv

Python client for ByteKV — a Redis-like in-memory key-value server over TCP using the RESP protocol.

Supports commands: `SET`, `GET`, `DEL`, `PING`, `EXPIRE`, `TTL`, and `PUBLISH`.