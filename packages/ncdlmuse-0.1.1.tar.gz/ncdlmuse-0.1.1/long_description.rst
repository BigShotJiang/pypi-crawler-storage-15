BIDS_NiChart_DLMUSE
===================

BIDS_NiChart_DLMUSE is a BIDS-Apps wrapper for NiChart_DLMUSE, a tool for brain segmentation.

[Documentation `<https://cbica.github.io/NiChart_DLMUSE/>`_]
