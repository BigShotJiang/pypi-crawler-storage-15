# Contributing to *NCDLMUSE*

*NCDLMUSE* is a project of the
[*NiPreps* Community, which specifies the contributing guidelines](https://www.nipreps.org/community/).

We ask that you follow the guidelines dictated in the *NiPreps* documentation.
