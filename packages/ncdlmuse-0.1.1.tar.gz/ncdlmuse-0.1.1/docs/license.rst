*******************
License information
*******************

We use the 3-clause BSD license.

All trademarks referenced herein are property of their respective holders.

Copyright (c) 2019-2023, PennLINC Developers
All rights reserved.
