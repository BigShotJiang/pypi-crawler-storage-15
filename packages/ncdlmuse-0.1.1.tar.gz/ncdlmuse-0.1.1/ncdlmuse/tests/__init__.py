"""Tests for NCDLMUSE.

Notes on the creation of the test data:

tar -C test_folder -czf test_name.tar.gz .
"""
