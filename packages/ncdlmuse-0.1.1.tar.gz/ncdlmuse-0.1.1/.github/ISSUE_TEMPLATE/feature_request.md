---
name: Feature request
about: Got an idea for a new feature, or changing an existing one? This is the place.
title: ''
labels: 'enhancement'
assignees: ''

---
## Summary
<!--What would you like changed/added and why?-->

## Additional details
<!--What would be the benefit?-->

## Next steps
<!--Do you have any ideas about the implementation?-->
