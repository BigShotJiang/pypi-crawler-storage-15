#!/usr/bin/env python3
# -*- coding: UTF-8 -*-

"""
=================================================
作者：[郭磊]
手机：[15210720528]
Email：[174000902@qq.com]
Github：https://github.com/guolei19850528/py3_http_utils
=================================================
"""
from py3_http_utils.response.requests import Handler as RequestsResponseHandler
from py3_http_utils.response.httpx import Handler as HttpxResponseHandler
