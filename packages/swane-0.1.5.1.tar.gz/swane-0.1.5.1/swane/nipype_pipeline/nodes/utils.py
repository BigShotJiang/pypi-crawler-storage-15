def getn(result_list, index):
    """
    Extracts an element from a list for a single input of a Node (eg. aparcaseg from reconAll).

    """

    return result_list[index]
