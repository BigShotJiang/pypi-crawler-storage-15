"""Entry point for running list_project as a module.

This allows running: python3 -m list_project
"""

from list_project.list_project import main


if __name__ == "__main__":
    main()
