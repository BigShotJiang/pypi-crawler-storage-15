"""Entry point for running sync_ai_guidance as a module.

This allows running: python3 -m sync_ai_guidance
"""

from sync_ai_guidance.sync_ai_guidance import main


if __name__ == "__main__":
    main()
