"""Sync AI guidance files from .ai/rules and .ai/commands source files."""
