"""Tests for products module."""
