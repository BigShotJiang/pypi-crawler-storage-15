# gmail_html_utils.py
# HTML template functions for MediLink Gmail HTTPS server
# Python 3.4.4 + XP SP3 compatible

def build_cert_info_html(cert_info):
    """Build HTML page showing certificate information for trust instructions.
    
    Args:
        cert_info: Dictionary with certificate details from get_certificate_summary()
    
    Returns:
        str: HTML content for certificate info page
    """
    expires = cert_info.get('notAfter', 'Unknown')
    subject = cert_info.get('subject', [])
    issuer = cert_info.get('issuer', [])
    subject_str = ', '.join(': '.join(x) if isinstance(x, tuple) else str(x) for x in subject) if subject else 'Unknown'
    issuer_str = ', '.join(': '.join(x) if isinstance(x, tuple) else str(x) for x in issuer) if issuer else 'Self-signed'
    warning = cert_info.get('warning')
    error = cert_info.get('error')

    instructions = """
        <ol>
            <li>Click the "Advanced" or "More information" button in your browser's warning page.</li>
            <li>Select "Accept the risk" / "Add exception" to trust https://127.0.0.1:8000.</li>
            <li>Return to the MediLink web app and run the connectivity test again.</li>
        </ol>
    """
    extra = ""
    if warning:
        extra += "<p><strong>Note:</strong> {}</p>".format(warning)
    if error:
        extra += "<p><strong>Error decoding certificate:</strong> {}</p>".format(error)

    html = """<!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <title>MediLink Local Certificate</title>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 20px; color: #2b2b2b; }}
            h1 {{ color: #3B2323; }}
            .card {{ border: 1px solid #d9cbbd; border-radius: 8px; padding: 16px; background: #faf8f5; }}
            ol {{ margin-top: 10px; }}
            .meta {{ margin-top: 12px; font-size: 0.95em; }}
            .meta div {{ margin-bottom: 4px; }}
        </style>
    </head>
    <body>
        <h1>Local HTTPS Certificate</h1>
        <div class="card">
            <div class="meta"><div><strong>Subject:</strong> {subject}</div>
            <div><strong>Issuer:</strong> {issuer}</div>
            <div><strong>Expires:</strong> {expires}</div></div>
            {extra}
            <h3>How to trust this certificate</h3>
            {instructions}
        </div>
    </body>
    </html>""".format(subject=subject_str, issuer=issuer_str, expires=expires, instructions=instructions, extra=extra)
    return html


def build_root_status_html(safe_status, cert_info, recent_requests, server_port):
    """Build a friendly status page for the HTTPS server root.
    
    Args:
        safe_status: Dictionary with server status from get_safe_status()
        cert_info: Dictionary with certificate details from get_certificate_summary()
        recent_requests: List or deque of recent request records
        server_port: Integer port number for the server
    
    Returns:
        str: HTML content for root status page
    """
    # Determine status display
    phase = safe_status.get('phase', 'idle')
    safe_to_close = safe_status.get('safeToClose', False)

    if safe_to_close:
        status_class = 'status-safe'
        status_icon = '[OK]'
        status_text = 'Safe to close'
        status_desc = 'All processing complete. You can close this tab.'
    elif phase in ['processing', 'downloading', 'cleanup_triggered']:
        status_class = 'status-working'
        status_icon = '[...]'
        status_text = 'Working'
        status_desc = 'Processing files in the background.'
    else:
        status_class = 'status-attention'
        status_icon = '[!]'
        status_text = 'Attention needed'
        status_desc = 'Check the main app for next steps.'

    # Certificate info
    cert_present = cert_info.get('present', False)
    cert_expires = cert_info.get('notAfter', 'Unknown') if cert_present else 'Not available'
    cert_status = 'Present' if cert_present else 'Missing'

    # Recent activity
    recent_activity = ""
    try:
        if recent_requests:
            # Convert to list if deque, take last 3
            try:
                requests_list = list(recent_requests)
                if len(requests_list) > 3:
                    requests_list = requests_list[-3:]
            except Exception:
                requests_list = []
            
            if requests_list:
                recent_activity = "<ul style='margin: 8px 0; padding-left: 20px;'>"
                for req in requests_list:
                    time_str = req.get('time', '')[:19]  # YYYY-MM-DDTHH:MM:SS
                    method = req.get('method', 'GET')
                    path = req.get('path', '/')
                    status = req.get('status', 200)
                    recent_activity += "<li>{} {} {} (status {})</li>".format(time_str, method, path, status)
                recent_activity += "</ul>"
            else:
                recent_activity = "<p style='color: #666; font-style: italic; margin: 8px 0;'>No recent activity</p>"
        else:
            recent_activity = "<p style='color: #666; font-style: italic; margin: 8px 0;'>No recent activity</p>"
    except Exception:
        # Fallback if any error occurs processing recent requests
        recent_activity = "<p style='color: #666; font-style: italic; margin: 8px 0;'>No recent activity</p>"

    html = """<!DOCTYPE html>
    <html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <title>MediLink Local Server</title>
        <style type="text/css">
            body {{
                font-family: Arial, Helvetica, sans-serif;
                margin: 0;
                padding: 20px;
                background: #f5f3e8;
                color: #2b2b2b;
                line-height: 1.6;
            }}
            .container {{
                width: 600px;
                margin: 0 auto;
                background: white;
                border: 1px solid #ccc;
                overflow: hidden;
            }}
            .header {{
                background: #3B2323;
                color: white;
                padding: 24px;
                text-align: center;
            }}
            .header h1 {{
                margin: 0;
                font-size: 2em;
                font-weight: normal;
            }}
            .header p {{
                margin: 8px 0 0 0;
                font-size: 1.1em;
            }}
            .status-card {{
                padding: 24px;
                border-bottom: 1px solid #e0e0e0;
            }}
            .status-badge {{
                display: inline-block;
                padding: 8px 16px;
                font-weight: bold;
                font-size: 0.95em;
                text-transform: uppercase;
            }}
            .status-safe {{ background: #e8f7ee; color: #1f5132; border: 1px solid #30a46c; }}
            .status-working {{ background: #fff4e6; color: #8b4513; border: 1px solid #f0ad4e; }}
            .status-attention {{ background: #fdecea; color: #dc2626; border: 1px solid #dc2626; }}
            .actions {{
                margin-top: 20px;
                overflow: hidden;
            }}
            .action-btn {{
                display: block;
                float: left;
                width: 48%;
                margin-right: 2%;
                padding: 12px 20px;
                background: #3B2323;
                color: white;
                text-decoration: none;
                text-align: center;
                font-weight: bold;
            }}
            .action-btn:hover {{ background: #4E3B3B; }}
            .action-btn.secondary {{ background: #6b5b5b; }}
            .action-btn.secondary:hover {{ background: #7a6a6a; }}
            .info-section {{
                padding: 20px 24px;
                background: #f8f7f5;
                border-bottom: 1px solid #e0e0e0;
            }}
            .info-section h3 {{
                margin: 0 0 12px 0;
                color: #3B2323;
                font-size: 1.1em;
            }}
            .meta-table {{
                width: 100%;
                font-size: 0.9em;
                border-collapse: collapse;
            }}
            .meta-table td {{
                padding: 4px 8px;
            }}
            .meta-label {{
                font-weight: bold;
                color: #666;
                width: 40%;
            }}
            .footer {{
                padding: 16px 24px;
                background: #faf9f7;
                text-align: center;
                font-size: 0.85em;
                color: #666;
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>MediLink Local Server</h1>
                <p>Secure file processing service</p>
            </div>

            <div class="status-card">
                <h2 style="margin: 0 0 16px 0; color: #3B2323;">Server Status</h2>
                <div class="status-badge {status_class}">
                    <span>{status_icon}</span> <span>{status_text}</span>
                </div>
                <p style="margin: 12px 0; color: #666;">{status_desc}</p>

                <div class="actions">
                    <a href="/_diag" class="action-btn">Run diagnostics</a>
                    <a href="/_cert" class="action-btn secondary">View certificate</a>
                </div>
            </div>

            <div class="info-section">
                <h3>System Information</h3>
                <table class="meta-table">
                    <tr>
                        <td class="meta-label">Certificate:</td>
                        <td>{cert_status}</td>
                    </tr>
                    <tr>
                        <td class="meta-label">Expires:</td>
                        <td>{cert_expires}</td>
                    </tr>
                    <tr>
                        <td class="meta-label">Phase:</td>
                        <td>{phase}</td>
                    </tr>
                    <tr>
                        <td class="meta-label">Port:</td>
                        <td>{server_port}</td>
                    </tr>
                </table>
            </div>

            <div class="info-section">
                <h3>Recent Activity</h3>
                {recent_activity}
            </div>

            <div class="footer">
                <p>This local server handles secure file processing for MediLink. Keep this page open during active processing.</p>
            </div>
        </div>
    </body>
    </html>""".format(
        status_class=status_class,
        status_icon=status_icon,
        status_text=status_text,
        status_desc=status_desc,
        cert_status=cert_status,
        cert_expires=cert_expires,
        phase=phase,
        server_port=server_port,
        recent_activity=recent_activity
    )
    return html

