# MediLink_Gmail.py
import sys, os, subprocess, time, webbrowser, requests, json, ssl, signal
from collections import deque
from datetime import datetime

# Set up Python path to find MediCafe when running directly
def setup_python_path():
    """Set up Python path to find MediCafe package"""
    current_dir = os.path.dirname(os.path.abspath(__file__))
    workspace_root = os.path.dirname(current_dir)
    
    # Add workspace root to Python path if not already present
    if workspace_root not in sys.path:
        sys.path.insert(0, workspace_root)

# Set up paths before importing MediCafe
setup_python_path()

from MediCafe.core_utils import get_shared_config_loader, extract_medilink_config

# New helpers
from MediLink.gmail_oauth_utils import (
    get_authorization_url as oauth_get_authorization_url,
    exchange_code_for_token as oauth_exchange_code_for_token,
    refresh_access_token as oauth_refresh_access_token,
    is_valid_authorization_code as oauth_is_valid_authorization_code,
)
from MediLink.gmail_http_utils import (
    generate_self_signed_cert as http_generate_self_signed_cert,
    start_https_server as http_start_https_server,
    inspect_token as http_inspect_token,
    SSLRequestHandler,
)
from MediLink.gmail_html_utils import (
    build_cert_info_html as html_build_cert_info_html,
    build_root_status_html as html_build_root_status_html,
)
from MediCafe.gmail_token_service import (
    get_gmail_access_token as shared_get_gmail_access_token,
    resolve_credentials_path as shared_resolve_credentials_path,
    resolve_token_path as shared_resolve_token_path,
    clear_gmail_token_cache as shared_clear_token_cache,
    save_gmail_token as shared_save_gmail_token,
)

# Get shared config loader
MediLink_ConfigLoader = get_shared_config_loader()
if MediLink_ConfigLoader:
    load_configuration = MediLink_ConfigLoader.load_configuration
    log = MediLink_ConfigLoader.log
else:
    # Fallback functions if config loader is not available
    def load_configuration():
        return {}, {}
    def log(message, level="INFO"):
        print("[{}] {}".format(level, message))

try:
    from MediCafe.error_reporter import capture_unhandled_traceback as _capture_unhandled_traceback
    sys.excepthook = _capture_unhandled_traceback  # Ensure unhandled exceptions hit MediCafe reporter
    log("MediCafe error reporter registered for Gmail flow exceptions.", level="DEBUG")
except Exception as error_reporter_exc:
    # Keep server running even if error reporter is unavailable
    try:
        log("Unable to register MediCafe error reporter: {}".format(error_reporter_exc), level="DEBUG")
    except Exception:
        pass
from http.server import BaseHTTPRequestHandler, HTTPServer
from threading import Thread, Event
import platform
import ctypes

# Default configuration values
DEFAULT_SERVER_PORT = 8000
DEFAULT_CERT_DAYS = 365

def resolve_openssl_cnf(base_dir):
    """Find openssl.cnf file, searching local dir then fallback path. Returns best-effort path."""
    # Try relative path first
    openssl_cnf = 'openssl.cnf'
    if os.path.exists(openssl_cnf):
        log("Found openssl.cnf at: {}".format(os.path.abspath(openssl_cnf)))
        return openssl_cnf

    # Try base directory
    medilink_openssl = os.path.join(base_dir, 'openssl.cnf')
    log("Trying MediLink directory: {}".format(medilink_openssl))
    if os.path.exists(medilink_openssl):
        log("Found openssl.cnf at: {}".format(medilink_openssl))
        return medilink_openssl

    # Try fallback path (one directory up)
    parent_dir = os.path.dirname(base_dir)
    alternative_path = os.path.join(parent_dir, 'MediBot', 'openssl.cnf')
    log("Trying alternative path: {}".format(alternative_path))
    if os.path.exists(alternative_path):
        log("Found openssl.cnf at: {}".format(alternative_path))
        return alternative_path

    # Return relative path as fallback (may not exist)
    log("Could not find openssl.cnf at alternative path either")
    return openssl_cnf


config, _ = load_configuration()
medi = extract_medilink_config(config)
TOKEN_PATH = shared_resolve_token_path(medi)
local_storage_path = medi.get('local_storage_path', '.')
downloaded_emails_file = os.path.join(local_storage_path, 'downloaded_emails.txt')

server_port = medi.get('gmail_server_port', DEFAULT_SERVER_PORT)
LOCAL_SERVER_BASE_URL = 'https://127.0.0.1:{}'.format(server_port)
cert_file = 'server.cert'
key_file = 'server.key'
# Find openssl.cnf file
medilink_dir = os.path.dirname(os.path.abspath(__file__))
openssl_cnf = resolve_openssl_cnf(medilink_dir)

httpd = None  # Global variable for the HTTP server
shutdown_event = Event()  # Event to signal shutdown
server_crashed = False  # Flag to track if server thread crashed
LAST_SECURE_ACTIVITY_TS = time.time()
CERT_WARNING_EMITTED = False
SECURE_ACTIVITY_PATHS = {'/_diag', '/download', '/delete-files', '/_cert'}

# Safe-to-close flag and lightweight server status tracking
SAFE_TO_CLOSE = False
SERVER_STATUS = {
    'phase': 'idle',  # idle|processing|downloading|cleanup_triggered|cleanup_confirmed|done|error
    'linksReceived': 0,
    'filesDownloaded': 0,
    'filesToDelete': 0,
    'filesDeleted': 0,
    'lastError': None,
}
RECENT_REQUESTS = deque(maxlen=25)

def set_safe_to_close(value):
    global SAFE_TO_CLOSE
    SAFE_TO_CLOSE = bool(value)

def set_phase(phase):
    try:
        SERVER_STATUS['phase'] = str(phase or '')
    except Exception:
        SERVER_STATUS['phase'] = 'error'

def set_counts(links_received=None, files_downloaded=None, files_to_delete=None, files_deleted=None):
    try:
        if links_received is not None:
            SERVER_STATUS['linksReceived'] = int(links_received)
        if files_downloaded is not None:
            SERVER_STATUS['filesDownloaded'] = int(files_downloaded)
        if files_to_delete is not None:
            SERVER_STATUS['filesToDelete'] = int(files_to_delete)
        if files_deleted is not None:
            SERVER_STATUS['filesDeleted'] = int(files_deleted)
    except Exception:
        pass

def set_error(msg):
    try:
        SERVER_STATUS['lastError'] = str(msg or '')
    except Exception:
        SERVER_STATUS['lastError'] = 'Unknown error'

def get_safe_status():
    try:
        elapsed = max(0, int(time.time() - LAST_SECURE_ACTIVITY_TS))
        return {
            'safeToClose': bool(SAFE_TO_CLOSE),
            'phase': SERVER_STATUS.get('phase', 'idle'),
            'counts': {
                'linksReceived': SERVER_STATUS.get('linksReceived', 0),
                'filesDownloaded': SERVER_STATUS.get('filesDownloaded', 0),
                'filesToDelete': SERVER_STATUS.get('filesToDelete', 0),
                'filesDeleted': SERVER_STATUS.get('filesDeleted', 0),
            },
            'lastError': SERVER_STATUS.get('lastError'),
            'connectivity': {
                'secondsSinceSecureActivity': elapsed,
                'certificateWarningActive': bool(CERT_WARNING_EMITTED)
            }
        }
    except Exception:
        return {'safeToClose': False, 'phase': 'error'}


def record_request_event(method, path, status, note=None, client=None):
    try:
        RECENT_REQUESTS.appendleft({
            'time': datetime.utcnow().isoformat() + 'Z',
            'method': method,
            'path': path,
            'status': status,
            'note': note,
            'client': client
        })
        if path in SECURE_ACTIVITY_PATHS:
            mark_secure_activity()
    except Exception:
        pass


def _get_client_ip(handler):
    try:
        return handler.client_address[0]
    except Exception:
        return None


def mark_secure_activity():
    global LAST_SECURE_ACTIVITY_TS, CERT_WARNING_EMITTED
    LAST_SECURE_ACTIVITY_TS = time.time()
    CERT_WARNING_EMITTED = False


def maybe_warn_secure_idle():
    global CERT_WARNING_EMITTED
    elapsed = time.time() - LAST_SECURE_ACTIVITY_TS
    if elapsed > 120 and not CERT_WARNING_EMITTED:
        log("No secure local HTTPS activity detected for {:.0f} seconds. Browser may still need to trust https://127.0.0.1:8000.".format(elapsed), level="WARNING")
        CERT_WARNING_EMITTED = True
    return elapsed


def get_certificate_summary(cert_path):
    summary = {
        'present': False
    }
    try:
        if os.path.exists(cert_path):
            summary['present'] = True
            ssl_impl = getattr(ssl, '_ssl', None)
            can_decode = ssl_impl is not None and hasattr(ssl_impl, '_test_decode_cert')
            if can_decode:
                cert_dict = ssl._ssl._test_decode_cert(cert_path)
                not_before = cert_dict.get('notBefore')
                not_after = cert_dict.get('notAfter')
                summary.update({
                    'subject': cert_dict.get('subject'),
                    'issuer': cert_dict.get('issuer'),
                    'notBefore': not_before,
                    'notAfter': not_after,
                    'serialNumber': cert_dict.get('serialNumber')
                })
            else:
                summary['warning'] = 'Certificate decoding not supported on this Python build.'
    except Exception as cert_err:
        summary['error'] = str(cert_err)
    return summary


def build_diagnostics_payload():
    try:
        recent = list(RECENT_REQUESTS)
    except Exception:
        recent = []
    return {
        'status': 'ok',
        'time': datetime.utcnow().isoformat() + 'Z',
        'serverPort': server_port,
        'safeStatus': get_safe_status(),
        'certificate': get_certificate_summary(cert_file),
        'recentRequests': recent,
        'connectivity': {
            'secondsSinceSecureActivity': max(0, int(time.time() - LAST_SECURE_ACTIVITY_TS)),
            'certificateWarningActive': bool(CERT_WARNING_EMITTED)
        },
        'headers': {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Private-Network': 'true'
        },
        'platform': {
            'os': os_name,
            'version': os_version
        }
    }


# Define the scopes for the Gmail API and other required APIs
SCOPES = ' '.join([
    "https://www.googleapis.com/auth/gmail.modify",
    "https://www.googleapis.com/auth/gmail.compose",
    "https://www.googleapis.com/auth/gmail.readonly",
    "https://www.googleapis.com/auth/gmail.send",
    "https://www.googleapis.com/auth/script.external_request",
    "https://www.googleapis.com/auth/userinfo.email",
    "https://www.googleapis.com/auth/script.scriptapp",
    "https://www.googleapis.com/auth/drive",
    "https://www.googleapis.com/auth/userinfo.email"
])

# Determine the operating system and version
os_name = platform.system()
os_version = platform.release()

# Set the credentials path based on the OS and version
CREDENTIALS_PATH = shared_resolve_credentials_path(medi, os_name=os_name, os_version=os_version)

# Log the selected path for verification
log("Using CREDENTIALS_PATH: {}".format(CREDENTIALS_PATH), level="DEBUG")

REDIRECT_URI = 'https://127.0.0.1:8000'

def get_authorization_url():
    return oauth_get_authorization_url(CREDENTIALS_PATH, REDIRECT_URI, SCOPES, log)

def exchange_code_for_token(auth_code, retries=3):
    return oauth_exchange_code_for_token(auth_code, CREDENTIALS_PATH, REDIRECT_URI, log, retries=retries)

def _mask_token_value(value):
    """Mask a token value for safe logging. Returns first 4 and last 4 chars, or '***' if too short."""
    try:
        s = str(value or '')
        if len(s) <= 8:
            return '***'
        return s[:4] + '...' + s[-4:]
    except Exception:
        return '***'


def _mask_sensitive_dict(data):
    """Create a copy of a dict with sensitive fields masked for logging."""
    if not isinstance(data, dict):
        return data
    try:
        masked = data.copy()
        # Mask token fields
        for key in ['access_token', 'refresh_token', 'id_token']:
            if key in masked and masked[key]:
                masked[key] = _mask_token_value(masked[key])
        # Mask Authorization header if present
        if 'Authorization' in masked:
            auth_val = str(masked['Authorization'])
            if 'Bearer ' in auth_val:
                # Extract token from "Bearer <token>"
                parts = auth_val.split('Bearer ', 1)
                if len(parts) > 1:
                    token = parts[1].strip()
                    masked['Authorization'] = 'Bearer ' + _mask_token_value(token)
        return masked
    except Exception:
        return data


def get_access_token():
    return shared_get_gmail_access_token(log=log, medi_config=medi, os_name=os_name, os_version=os_version)

def refresh_access_token(refresh_token):
    return oauth_refresh_access_token(refresh_token, CREDENTIALS_PATH, log)

def bring_window_to_foreground():
    """Brings the current window to the foreground on Windows."""
    try:
        if platform.system() == 'Windows':
            pid = os.getpid()
            hwnd = ctypes.windll.user32.GetForegroundWindow()
            current_pid = ctypes.c_ulong()
            ctypes.windll.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(current_pid))
            if current_pid.value != pid:
                ctypes.windll.user32.SetForegroundWindow(hwnd)
                if ctypes.windll.user32.GetForegroundWindow() != hwnd:
                    ctypes.windll.user32.ShowWindow(hwnd, 9)
                    ctypes.windll.user32.SetForegroundWindow(hwnd)
    except Exception as e:
        log("Error bringing window to foreground: {}".format(e))

class RequestHandler(SSLRequestHandler):
    def _set_headers(self):
        from MediLink.gmail_http_utils import set_standard_headers
        set_standard_headers(self)

    def do_OPTIONS(self):
        self.send_response(200)
        self._set_headers()
        self.end_headers()
        record_request_event('OPTIONS', self.path, 200, note='preflight', client=_get_client_ip(self))
        try:
            origin = self.headers.get('Origin')
        except Exception:
            origin = None
        try:
            print("[CORS] Preflight {0} from {1}".format(self.path, origin))
        except Exception:
            pass

    def do_POST(self):
        """Handle POST requests with comprehensive exception handling to prevent server crashes."""
        from MediLink.gmail_http_utils import (
            parse_content_length, read_post_data, parse_json_data,
            send_error_response, safe_write_response, log_request_error
        )
        try:
            if self.path == '/download':
                set_phase('processing')
                try:
                    content_length = parse_content_length(self.headers, log_fn=log)
                except (KeyError, ValueError) as e:
                    send_error_response(self, 400, "Missing or invalid Content-Length header", log_fn=log, error_details=str(e))
                    return
                post_data = read_post_data(self, content_length, log_fn=log)
                if post_data is None:
                    return  # Client disconnected
                try:
                    data = parse_json_data(post_data, log_fn=log)
                except (ValueError, UnicodeDecodeError) as e:
                    send_error_response(self, 400, "Invalid request format", log_fn=log, error_details=str(e))
                    return
                links = data.get('links', [])
                log("Received links: {}".format(links), level="DEBUG")
                try:
                    print("[Handshake] Received {0} link(s) from webapp".format(len(links)))
                except Exception:
                    pass
                try:
                    set_counts(links_received=len(links))
                except Exception:
                    pass
                file_ids = [link.get('fileId', None) for link in links if link.get('fileId')]
                log("File IDs received from client: {}".format(file_ids), level="DEBUG")
                set_phase('downloading')
                try:
                    download_docx_files(links)
                except Exception as e:
                    set_phase('error')
                    set_error(e)
                # Only delete files that actually downloaded successfully
                downloaded_names = load_downloaded_emails()
                successful_ids = []
                try:
                    name_to_id = { (link.get('filename') or ''): link.get('fileId') for link in links if link.get('fileId') }
                    for name in downloaded_names:
                        fid = name_to_id.get(name)
                        if fid:
                            successful_ids.append(fid)
                except Exception as e:
                    log("Error computing successful file IDs for cleanup: {}".format(e))
                    successful_ids = file_ids  # Fallback: attempt all provided IDs
                try:
                    set_counts(files_to_delete=len(successful_ids))
                except Exception:
                    pass
                # Trigger cleanup in Apps Script with auth
                try:
                    cleanup_ok = False
                    if successful_ids:
                        ok = send_delete_request_to_gas(successful_ids)
                        if ok:
                            set_phase('cleanup_confirmed')
                            try:
                                set_counts(files_deleted=len(successful_ids))
                            except Exception:
                                pass
                            cleanup_ok = True
                        else:
                            set_phase('cleanup_triggered')
                            set_error('Cleanup request not confirmed')
                    else:
                        log("No successful file IDs to delete after download.")
                        set_phase('done')
                        cleanup_ok = True  # nothing to delete -> safe
                except Exception as e:
                    log("Cleanup trigger failed: {}".format(e))
                    set_phase('error')
                    set_error(e)
                    cleanup_ok = False
                self.send_response(200)
                self._set_headers()
                self.end_headers()
                try:
                    set_safe_to_close(bool(cleanup_ok))
                except Exception:
                    pass
                response = json.dumps({"status": "success", "message": "All files downloaded", "fileIds": successful_ids, "safeToClose": bool(cleanup_ok)})
                safe_write_response(self, response)
                try:
                    print("[Handshake] Completed. Returning success for {0} fileId(s)".format(len(successful_ids)))
                except Exception:
                    pass
                shutdown_event.set()
                bring_window_to_foreground()
                record_request_event('POST', '/download', 200, note='download', client=_get_client_ip(self))
                return
            elif self.path == '/shutdown':
                log("Shutdown request received.")
                self.send_response(200)
                self._set_headers()
                self.end_headers()
                response = json.dumps({"status": "success", "message": "Server is shutting down."})
                safe_write_response(self, response)
                shutdown_event.set()
                record_request_event('POST', '/shutdown', 200, note='shutdown', client=_get_client_ip(self))
                return
            elif self.path == '/delete-files':
                try:
                    content_length = parse_content_length(self.headers, log_fn=log)
                except (KeyError, ValueError) as e:
                    send_error_response(self, 400, "Missing or invalid Content-Length header", log_fn=log, error_details=str(e))
                    return
                post_data = read_post_data(self, content_length, log_fn=log)
                if post_data is None:
                    return  # Client disconnected
                try:
                    data = parse_json_data(post_data, log_fn=log)
                except (ValueError, UnicodeDecodeError) as e:
                    send_error_response(self, 400, "Invalid request format", log_fn=log, error_details=str(e))
                    return
                file_ids = data.get('fileIds', [])
                log("File IDs to delete received from client: {}".format(file_ids))
                if not isinstance(file_ids, list):
                    send_error_response(self, 400, "Invalid fileIds parameter.", log_fn=log)
                    return
                self.send_response(200)
                self._set_headers()
                self.end_headers()
                response = json.dumps({"status": "success", "message": "Files deleted successfully."})
                safe_write_response(self, response)
                record_request_event('POST', '/delete-files', 200, note='cleanup', client=_get_client_ip(self))
                return
            else:
                self.send_response(404)
                self.end_headers()
        except KeyError as e:
            send_error_response(self, 400, "Missing required header: {}".format(str(e)), log_fn=log, error_details=str(e))
        except (ValueError, TypeError) as e:
            # Note: json.JSONDecodeError doesn't exist in Python 3.4.4; json.loads raises ValueError
            send_error_response(self, 400, "Invalid request format: {}".format(str(e)), log_fn=log, error_details=str(e))
        except OSError as e:
            from MediLink.gmail_http_utils import _is_expected_disconnect
            if _is_expected_disconnect(e):
                log("Client disconnected during POST request handling: {}".format(e), level="DEBUG")
                self.close_connection = True
            else:
                log("Connection error in POST request: {} - This usually indicates a network error, client disconnect, or socket issue on Windows XP".format(e), level="ERROR")
                send_error_response(self, 500, "Connection error", log_fn=log, error_details=str(e))
        except Exception as e:
            log_request_error(e, self.path, "POST", log, headers=self.headers)
            send_error_response(self, 500, "Internal server error", log_fn=log, error_details=str(e))

    def do_GET(self):
        """Handle GET requests with comprehensive exception handling to prevent server crashes."""
        from MediLink.gmail_http_utils import (
            _is_expected_disconnect, safe_write_response,
            send_error_response, log_request_error
        )
        try:
            log("Full request path: {}".format(self.path), level="DEBUG")
            if self.path == '/_health':
                try:
                    print("[Health] Probe OK")
                except Exception:
                    pass
                self.send_response(200)
                self._set_headers()
                self.end_headers()
                try:
                    self.wfile.write(json.dumps({"status": "ok"}).encode('ascii'))
                except Exception:
                    try:
                        self.wfile.write(b'{"status":"ok"}')
                    except OSError as e:
                        if _is_expected_disconnect(e):
                            self.close_connection = True
                        else:
                            raise
                return
            elif self.path == '/status':
                maybe_warn_secure_idle()
                self.send_response(200)
                self._set_headers()
                self.end_headers()
                try:
                    payload = json.dumps(get_safe_status())
                except Exception:
                    payload = '{}'
                try:
                    self.wfile.write(payload.encode('ascii'))
                except Exception:
                    try:
                        self.wfile.write(payload.encode('utf-8'))
                    except Exception:
                        try:
                            self.wfile.write(b'{}')
                        except OSError as e:
                            if _is_expected_disconnect(e):
                                self.close_connection = True
                            else:
                                raise
                record_request_event('GET', '/status', 200, note='status', client=_get_client_ip(self))
                return
            elif self.path.startswith('/_diag'):
                diag_payload = build_diagnostics_payload()
                self.send_response(200)
                self._set_headers()
                self.end_headers()
                try:
                    self.wfile.write(json.dumps(diag_payload).encode('utf-8'))
                except Exception as write_err:
                    log("Failed to write diagnostics payload: {}".format(write_err))
                record_request_event('GET', '/_diag', 200, note='diagnostics', client=_get_client_ip(self))
                return
            elif self.path.startswith('/_cert'):
                cert_info = get_certificate_summary(cert_file)
                cert_html = html_build_cert_info_html(cert_info)
                self.send_response(200)
                self.send_header('Content-type', 'text/html; charset=utf-8')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                try:
                    self.wfile.write(cert_html.encode('utf-8'))
                except Exception as write_err:
                    log("Failed to write cert info payload: {}".format(write_err))
                record_request_event('GET', '/_cert', 200, note='cert-info', client=_get_client_ip(self))
                return
            if self.path.startswith("/?code="):
                try:
                    auth_code = self.path.split('=')[1].split('&')[0]
                except IndexError as e:
                    log("Invalid authorization code path format: {}".format(self.path), level="ERROR")
                    self.send_response(400)
                    self.send_header('Content-type', 'text/html')
                    self.end_headers()
                    try:
                        self.wfile.write("Invalid authorization code format. Please try again.".encode())
                    except Exception:
                        pass
                    return
                try:
                    auth_code = requests.utils.unquote(auth_code)
                except Exception as e:
                    log("Error unquoting authorization code: {}".format(e), level="ERROR")
                    self.send_response(400)
                    self.send_header('Content-type', 'text/html')
                    self.end_headers()
                    try:
                        self.wfile.write("Invalid authorization code format. Please try again.".encode())
                    except Exception:
                        pass
                    return
                log("Received authorization code: {}".format(_mask_token_value(auth_code)), level="DEBUG")
                if oauth_is_valid_authorization_code(auth_code, log):
                    try:
                        token_response = exchange_code_for_token(auth_code)
                        if 'access_token' not in token_response:
                            if token_response.get("status") == "error":
                                self.send_response(400)
                                self.send_header('Content-type', 'text/html')
                                self.end_headers()
                                self.wfile.write(token_response["message"].encode())
                                return
                            raise ValueError("Access token not found in response.")
                    except Exception as e:
                        log("Error during token exchange: {}".format(e))
                        self.send_response(500)
                        self.send_header('Content-type', 'text/html')
                        self.end_headers()
                        self.wfile.write("An error occurred during authentication. Please try again.".encode())
                    else:
                        log("Token response: {}".format(_mask_sensitive_dict(token_response)), level="DEBUG")
                    if 'access_token' in token_response:
                        if shared_save_gmail_token(token_response, log=log, medi_config=medi):
                            # Success - continue with response
                            self.send_response(200)
                            self.send_header('Content-type', 'text/html')
                            self.end_headers()
                            self.wfile.write("Authentication successful. You can close this window now.".encode())

                        # Only launch webapp if not in Gmail send-only mode
                        global httpd
                        if httpd is not None and not getattr(httpd, 'gmail_send_only_mode', False):
                            initiate_link_retrieval(config)
                        else:
                            # For Gmail send-only: just signal completion
                            log("Gmail send-only authentication complete. Server will shutdown after token poll.")
                            shutdown_event.set()
                    else:
                        log("Authentication failed with response: {}".format(_mask_sensitive_dict(token_response)))
                        if 'error' in token_response:
                            error_description = token_response.get('error_description', 'No description provided.')
                            log("Error details: {}".format(error_description))
                        if token_response.get('error') == 'invalid_grant':
                            log("Invalid grant error encountered. Authorization code: {}, Response: {}".format(_mask_token_value(auth_code), _mask_sensitive_dict(token_response)), level="DEBUG")
                            check_invalid_grant_causes(auth_code)
                            shared_clear_token_cache(log=log, medi_config=medi)
                            user_message = "Authentication failed: Invalid or expired authorization code. Please try again."
                        else:
                            user_message = "Authentication failed. Please check the logs for more details."
                        self.send_response(400)
                        self.send_header('Content-type', 'text/html')
                        self.end_headers()
                        self.wfile.write(user_message.encode())
                        shutdown_event.set()
                else:
                    log("Invalid authorization code format: {}".format(_mask_token_value(auth_code)), level="DEBUG")
                    self.send_response(400)
                    self.send_header('Content-type', 'text/html')
                    self.end_headers()
                    try:
                        self.wfile.write("Invalid authorization code format. Please try again.".encode())
                    except Exception:
                        pass
                    shutdown_event.set()
            elif self.path == '/downloaded-emails':
                self.send_response(200)
                self._set_headers()
                self.end_headers()
                downloaded_emails = load_downloaded_emails()
                response = json.dumps({"downloadedEmails": list(downloaded_emails)})
                try:
                    self.wfile.write(response.encode('utf-8'))
                except OSError as e:
                    if _is_expected_disconnect(e):
                        self.close_connection = True
                    else:
                        raise
            elif self.path == '/':
                # Serve friendly root status page
                try:
                    safe_status = get_safe_status()
                    cert_info = get_certificate_summary(cert_file)
                    root_html = html_build_root_status_html(safe_status, cert_info, RECENT_REQUESTS, server_port)
                except Exception as e:
                    log("Error building root status HTML: {}".format(e))
                    root_html = """<!DOCTYPE html>
    <html>
    <head><title>MediLink Local Server</title></head>
    <body style="font-family: Arial, sans-serif; padding: 20px;">
        <h1>MediLink Local Server</h1>
        <p>HTTPS server is running on port {}</p>
        <p><a href="/_diag">Run diagnostics</a> | <a href="/_cert">View certificate</a></p>
    </body>
    </html>""".format(server_port)
                self.send_response(200)
                self.send_header('Content-type', 'text/html; charset=utf-8')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                try:
                    self.wfile.write(root_html.encode('utf-8'))
                except OSError as e:
                    if _is_expected_disconnect(e):
                        self.close_connection = True
                    else:
                        raise
                record_request_event('GET', '/', 200, note='root-page', client=_get_client_ip(self))
                return
            else:
                self.send_response(200)
                self.send_header('Access-Control-Allow-Origin', '*')
                self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
                self.send_header('Access-Control-Allow-Headers', 'Content-Type')
                self.send_header('Content-type', 'text/html')
                self.end_headers()
                try:
                    self.wfile.write(b'HTTPS server is running.')
                except OSError as e:
                    if _is_expected_disconnect(e):
                        self.close_connection = True
                    else:
                        raise
        except IndexError as e:
            log("IndexError in do_GET for path {}: {}".format(self.path, e), level="ERROR")
            try:
                self.send_response(400)
                self._set_headers()
                self.end_headers()
                error_response = json.dumps({"status": "error", "message": "Invalid request path format"})
                self.wfile.write(error_response.encode('utf-8'))
            except Exception:
                pass
        except OSError as e:
            from MediLink.gmail_http_utils import _is_expected_disconnect
            if _is_expected_disconnect(e):
                log("Client disconnected during GET request: {}".format(e), level="DEBUG")
                self.close_connection = True
            else:
                log("Connection error in GET request: {} - This usually indicates a network error, client disconnect, or socket issue on Windows XP".format(e), level="ERROR")
                send_error_response(self, 500, "Connection error", log_fn=log, error_details=str(e))
        except Exception as e:
            log_request_error(e, self.path, "GET", log, headers=self.headers)
            send_error_response(self, 500, "Internal server error", log_fn=log, error_details=str(e))

def generate_self_signed_cert(cert_file, key_file):
    cert_days = medi.get('gmail_cert_days', DEFAULT_CERT_DAYS)
    http_generate_self_signed_cert(openssl_cnf, cert_file, key_file, log, subprocess, cert_days)

def run_server():
    global httpd
    try:
        log("Attempting to start server on port " + str(server_port))
        if not os.path.exists(cert_file):
            log("Error: Certificate file not found: " + cert_file)
        if not os.path.exists(key_file):
            log("Error: Key file not found: " + key_file)
        httpd = HTTPServer(('0.0.0.0', server_port), RequestHandler)
        httpd.gmail_send_only_mode = False  # Default: allow full webapp flow
        httpd.timeout = 30  # Request timeout to prevent hanging on malformed or slow requests
        httpd.socket = ssl.wrap_socket(httpd.socket, certfile=cert_file, keyfile=key_file, server_side=True)
        log("Starting HTTPS server on port {}".format(server_port))
        try:
            print("[Server] HTTPS server ready at https://127.0.0.1:{0}".format(server_port))
        except Exception:
            pass
        httpd.serve_forever()
    except Exception as e:
        global server_crashed
        server_crashed = True  # Mark that server has crashed
        import traceback
        error_type = type(e).__name__
        error_msg = str(e)
        error_msg_full = "HTTPS server thread crashed: {}: {}".format(error_type, error_msg)
        log(error_msg_full, level="ERROR")
        
        # Collect comprehensive diagnostic information
        diagnostic_info = {
            'error_type': error_type,
            'error_message': error_msg,
            'server_port': server_port,
            'cert_file_exists': os.path.exists(cert_file),
            'key_file_exists': os.path.exists(key_file),
            'server_thread_alive': False,
        }
        
        # Capture traceback once for logging and file writing
        tb_str = None
        try:
            tb_str = traceback.format_exc()
            log("Server thread crash traceback: {}".format(tb_str), level="ERROR")
            diagnostic_info['traceback'] = tb_str
        except Exception:
            pass
        
        # Log server state at time of crash
        try:
            status = get_safe_status()
            log("Server status at crash time: {}".format(status), level="ERROR")
            diagnostic_info['server_status'] = status
        except Exception:
            pass
        
        # Write traceback to file so error_reporter can include it in bundle
        if tb_str:
            try:
                trace_path = os.path.join(local_storage_path, 'traceback.txt')
                with open(trace_path, 'w') as f:
                    f.write(tb_str)
                log("Traceback saved to {}".format(trace_path), level="INFO")
            except Exception as trace_err:
                log("Failed to save traceback to file: {}".format(trace_err), level="WARNING")
        else:
            log("No traceback available to save", level="WARNING")
        
        # Automatically submit error report - error_reporter handles collection and submission
        report_submitted = False
        try:
            from MediCafe.error_reporter import submit_support_bundle_email
            log("Submitting error report for server crash...", level="INFO")
            # Write diagnostic info to a temporary file for inclusion in bundle
            try:
                diagnostic_file = os.path.join(local_storage_path, 'server_crash_diagnostics.json')
                import json as json_module
                with open(diagnostic_file, 'w') as df:
                    json_module.dump(diagnostic_info, df, indent=2)
                log("Server crash diagnostic information saved to: {}".format(diagnostic_file), level="INFO")
            except Exception as diag_file_err:
                log("Failed to save diagnostic file: {}".format(diag_file_err), level="WARNING")
            # submit_support_bundle_email() automatically collects bundle if zip_path is None
            # and handles online/offline submission, bundle size limits, etc.
            success = submit_support_bundle_email(zip_path=None, include_traceback=True)
            report_submitted = success
            if success:
                log("Error report submitted successfully for server crash", level="INFO")
            else:
                log("Error report submission failed or queued for later submission", level="WARNING")
        except Exception as report_exc:
            log("Error report submission failed for server crash: {}".format(report_exc), level="WARNING")
        
        # Display concise console message to user AFTER submission attempt
        try:
            print("\n" + "=" * 60)
            print("SERVER ERROR - HTTPS Server Thread Crashed")
            print("=" * 60)
            print("Error Type: {}".format(error_type))
            print("Error Message: {}".format(error_msg))
            if report_submitted:
                print("\nError report has been automatically submitted.")
            else:
                print("\nError report is being collected and will be submitted when possible.")
            print("Returning to main menu...")
            print("=" * 60 + "\n")
        except Exception:
            pass
        stop_server()

def stop_server():
    global httpd
    if httpd:
        log("Stopping HTTPS server.")
        httpd.shutdown()
        httpd.server_close()
        log("HTTPS server stopped.")
    shutdown_event.set()
    bring_window_to_foreground()

def load_downloaded_emails():
    downloaded_emails = set()
    if os.path.exists(downloaded_emails_file):
        with open(downloaded_emails_file, 'r') as file:
            downloaded_emails = set(line.strip() for line in file)
    log("Loaded downloaded emails: {}".format(downloaded_emails), level="DEBUG")
    return downloaded_emails

def download_docx_files(links):
    downloaded_emails = load_downloaded_emails()
    downloads_count = 0
    for link in links:
        try:
            url = link.get('url', '')
            filename = link.get('filename', '')
            log("Processing link: url='{}', filename='{}'".format(url, filename), level="DEBUG")
            lower_name = (filename or '').lower()
            looks_like_csv = any(lower_name.endswith(ext) for ext in ['.csv', '.tsv', '.txt', '.dat'])
            if looks_like_csv:
                log("[CSV Routing Preview] Detected CSV-like filename: {}. Would route to CSV processing directory.".format(filename))
            if filename in downloaded_emails:
                log("Skipping already downloaded email: {}".format(filename))
                continue
            log("Downloading .docx file from URL: {}".format(url), level="DEBUG")
            response = requests.get(url, verify=False)
            if response.status_code == 200:
                file_path = os.path.join(local_storage_path, filename)
                with open(file_path, 'wb') as file:
                    file.write(response.content)
                log("Downloaded .docx file: {}".format(filename))
                downloaded_emails.add(filename)
                with open(downloaded_emails_file, 'a') as file:
                    file.write(filename + '\n')
                downloads_count += 1
                try:
                    set_counts(files_downloaded=downloads_count)
                except Exception:
                    pass
            else:
                log("Failed to download .docx file from URL: {}. Status code: {}".format(url, response.status_code))
        except Exception as e:
            log("Error downloading .docx file from URL: {}. Error: {}".format(url, e))

def open_browser_with_executable(url, browser_path=None):
    try:
        if browser_path:
            log("Attempting to open URL with provided executable: {} {}".format(browser_path, url), level="DEBUG")
            process = subprocess.Popen([browser_path, url], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            stdout, stderr = process.communicate()
            if process.returncode == 0:
                log("Browser opened with provided executable path using subprocess.Popen.")
            else:
                log("Browser failed to open using subprocess.Popen. Return code: {}. Stderr: {}".format(process.returncode, stderr))
        else:
            log("No browser path provided. Attempting to open URL with default browser: {}".format(url), level="DEBUG")
            webbrowser.open(url)
            log("Default browser opened.", level="DEBUG")
    except Exception as e:
        log("Failed to open browser: {}".format(e))

def initiate_link_retrieval(config):
    log("Initiating two-tab launch: local status page first, then GAS webapp.")
    medi = extract_medilink_config(config)
    dep_id = (medi.get('webapp_deployment_id', '') or '').strip()
    if not dep_id:
        log("webapp_deployment_id is empty. Please set it in config before continuing.")
        shutdown_event.set()
        return

    # First tab: Open local status page to verify connectivity and trust
    local_status_url = LOCAL_SERVER_BASE_URL + '/'
    log("Opening local status page: {}".format(local_status_url))
    try:
        print("[Launch] Opening local server status page...")
        open_browser_with_executable(local_status_url)
        # Brief pause to let the first tab load and surface any certificate prompts
        time.sleep(1.5)
    except Exception as e:
        log("Warning: Failed to open local status page: {}".format(e))

    # Second tab: Open GAS webapp for the main workflow
    url_get = "https://script.google.com/macros/s/{}/exec?action=get_link".format(dep_id)
    try:
        log("Opening GAS web app: {}".format(url_get), level="DEBUG")
    except Exception:
        pass
    # Preflight probe to surface HTTP status/redirects before opening the browser
    try:
        probe_url = "https://script.google.com/macros/s/{}/exec".format(dep_id)
        try:
            resp = requests.get(probe_url, allow_redirects=False, timeout=8)
            loc = resp.headers.get('Location')
            log("Preflight probe: status={} location={}".format(resp.status_code, loc), level="DEBUG")
        except Exception as probe_err:
            log("Preflight probe failed: {}".format(probe_err))
    except Exception:
        pass
    try:
        print("[Launch] Opening MediLink web application...")
        open_browser_with_executable(url_get)
    except Exception as e:
        log("Warning: Failed to open GAS webapp: {}".format(e))
    log("Preparing POST call.", level="DEBUG")
    url = "https://script.google.com/macros/s/{}/exec".format(dep_id)
    downloaded_emails = list(load_downloaded_emails())
    payload = {"downloadedEmails": downloaded_emails}
    access_token = get_access_token()
    if not access_token:
        log("Access token not found. Please authenticate first.")
        shutdown_event.set()
        return
    token_info = http_inspect_token(access_token, log, delete_token_file_fn=delete_token_file, stop_server_fn=stop_server)
    if token_info is None:
        log("Access token is invalid. Please re-authenticate.")
        shutdown_event.set()
        return
    headers = {'Authorization': 'Bearer {}'.format(access_token), 'Content-Type': 'application/json'}
    log("Request headers: {}".format(_mask_sensitive_dict(headers)), level="DEBUG")
    log("Request payload: {}".format(payload), level="DEBUG")
    handle_post_response(url, payload, headers)

def handle_post_response(url, payload, headers):
    try:
        response = requests.post(url, json=payload, headers=headers)
        log("Response status code: {}".format(response.status_code), level="DEBUG")
        log("Response body: {}".format(response.text), level="DEBUG")
        if response.status_code == 200:
            response_data = response.json()
            log("Parsed response data: {}".format(response_data), level="DEBUG")
            if response_data.get("status") == "error":
                log("Error message from server: {}".format(response_data.get("message")))
                print("Error: {}".format(response_data.get("message")))
                shutdown_event.set()
            else:
                log("Link retrieval initiated successfully.")
        elif response.status_code == 401:
            # Automatic re-auth: clear token and prompt user to re-consent, keep server up
            log("Unauthorized (401). Clearing cached token and initiating re-authentication flow. Response body: {}".format(response.text))
            delete_token_file()
            auth_url = get_authorization_url()
            print("Your Google session needs to be refreshed to regain permissions. A browser window will open to re-authorize the app with the required scopes.")
            open_browser_with_executable(auth_url)
            # Wait for the OAuth redirect/flow to complete; the server remains running
            shutdown_event.wait()
        elif response.status_code == 403:
            # Treat 403 similarly; scopes may be missing/changed. Force a fresh consent.
            log("Forbidden (403). Clearing cached token and prompting for fresh consent. Response body: {}".format(response.text))
            delete_token_file()
            auth_url = get_authorization_url()
            print("Permissions appear insufficient (403). Opening browser to request the correct Google permissions.")
            open_browser_with_executable(auth_url)
            shutdown_event.wait()
        elif response.status_code == 404:
            log("Not Found. Verify the URL and ensure the Apps Script is deployed correctly. Response body: {}".format(response.text))
            shutdown_event.set()
        else:
            log("Failed to initiate link retrieval. Unexpected status code: {}. Response body: {}".format(response.status_code, response.text))
            shutdown_event.set()
    except requests.exceptions.RequestException as e:
        log("RequestException during link retrieval initiation: {}".format(e))
        shutdown_event.set()
    except Exception as e:
        log("Unexpected error during link retrieval initiation: {}".format(e))
        shutdown_event.set()

def send_delete_request_to_gas(file_ids):
    """Send a delete_files action to the Apps Script web app for the provided Drive file IDs.
    Relies on OAuth token previously obtained. Sends user notifications via GAS.
    """
    try:
        medi = extract_medilink_config(config)
        url = "https://script.google.com/macros/s/{}/exec".format(medi.get('webapp_deployment_id', ''))
        access_token = get_access_token()
        if not access_token:
            log("Access token not found. Skipping cleanup request to GAS.")
            return False
        headers = {'Authorization': 'Bearer {}'.format(access_token), 'Content-Type': 'application/json'}
        payload = {"action": "delete_files", "fileIds": list(file_ids)}
        log("Initiating cleanup request to GAS. Payload size: {} id(s)".format(len(file_ids)))
        resp = requests.post(url, json=payload, headers=headers)
        log("Cleanup response status: {}".format(resp.status_code))
        # Print a concise console message
        if resp.ok:
            try:
                body = resp.json()
                msg = body.get('message', 'Files deleted successfully') if isinstance(body, dict) else 'Files deleted successfully'
            except Exception:
                msg = 'Files deleted successfully'
            print("Cleanup complete: {} ({} file(s))".format(msg, len(file_ids)))
            return True
        else:
            print("Cleanup failed with status {}: {}".format(resp.status_code, resp.text))
            return False
    except Exception as e:
        log("Error sending delete request to GAS: {}".format(e))
        print("Cleanup request error: {}".format(e))
        return False

def inspect_token(access_token):
    return http_inspect_token(access_token, log, delete_token_file_fn=delete_token_file, stop_server_fn=stop_server)

def delete_token_file():
    try:
        if os.path.exists(TOKEN_PATH):
            shared_clear_token_cache(log=log, medi_config=medi)
            if os.path.exists(TOKEN_PATH):
                log("Failed to remove token cache at {}. Check file locks/permissions.".format(TOKEN_PATH), level="WARNING")
            else:
                log("Deleted token cache at {}".format(TOKEN_PATH))
        else:
            log("Token cache already cleared (no file at {}).".format(TOKEN_PATH), level="DEBUG")
    except Exception as e:
        log("Error deleting token cache at {}: {}".format(TOKEN_PATH, e), level="ERROR")

def signal_handler(sig, frame):
    log("Signal received: {}. Initiating shutdown.".format(sig))
    stop_server()
    sys.exit(0)

def auth_and_retrieval():
    access_token = get_access_token()
    if not access_token:
        log("Access token not found or expired. Please authenticate first.")
        auth_url = get_authorization_url()
        open_browser_with_executable(auth_url)
        shutdown_event.wait()
    else:
        log("Access token found. Proceeding.")
        initiate_link_retrieval(config)
        shutdown_event.wait()

def is_valid_authorization_code(auth_code):
    return oauth_is_valid_authorization_code(auth_code, log)

def clear_token_cache():
    shared_clear_token_cache(log=log, medi_config=medi)

def check_invalid_grant_causes(auth_code):
    log("FUTURE IMPLEMENTATION: Checking common causes for invalid_grant error with auth code: {}".format(_mask_token_value(auth_code)))


def ensure_authenticated_for_gmail_send(max_wait_seconds=120):
    """Ensure a valid Gmail access token is available for sending.

    - Reuses existing OAuth helpers in this module.
    - Starts the local HTTPS server if needed, opens the browser for consent,
      and polls for a token for up to max_wait_seconds.
    - Returns True if a usable access token is available after the flow; otherwise False.
    """
    try:
        token = get_access_token()
    except Exception:
        token = None
    if token:
        return True

    # Prepare server and certificates
    try:
        generate_self_signed_cert(cert_file, key_file)
    except Exception as e:
        log("Warning: could not ensure self-signed certs: {}".format(e))

    server_started_here = False
    global httpd
    try:
        if httpd is None:
            log("Starting local HTTPS server for OAuth redirect handling.")
            server_thread = Thread(target=run_server)
            server_thread.daemon = True
            server_thread.start()
            server_started_here = True
            time.sleep(0.5)  # Wait for server to initialize
            # Set flag to prevent webapp launch
            if httpd is not None:
                httpd.gmail_send_only_mode = True
    except Exception as e:
        log("Failed to start OAuth local server: {}".format(e))

    try:
        auth_url = get_authorization_url()
        print("Opening browser to authorize Gmail permission for sending...")
        open_browser_with_executable(auth_url)
    except Exception as e:
        log("Failed to open authorization URL: {}".format(e))

    # Poll for token availability within timeout
    start_ts = time.time()
    token = None
    while time.time() - start_ts < max_wait_seconds:
        try:
            token = get_access_token()
        except Exception:
            token = None
        if token:
            break
        time.sleep(3)

    if server_started_here:
        try:
            # Reset flag before shutdown
            if httpd is not None:
                httpd.gmail_send_only_mode = False
            stop_server()
        except Exception:
            pass

    if not token:
        print("Gmail authorization not completed within timeout. Please finish consent and retry.")

    return bool(token)

if __name__ == "__main__":
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    try:
        generate_self_signed_cert(cert_file, key_file)
        from threading import Thread
        log("Starting server thread.")
        server_thread = Thread(target=run_server)
        server_thread.daemon = True
        server_thread.start()
        auth_and_retrieval()
        log("Stopping HTTPS server.")
        stop_server()
        log("Waiting for server thread to finish.")
        server_thread.join(timeout=5)  # Wait up to 5 seconds for thread to finish
        
        # Check if server crashed - if so, exit with error code so batch file can return to menu
        # Note: Reading global variable doesn't require 'global' declaration
        if server_crashed:
            log("Server thread crashed. Exiting with error code to return to main menu.", level="ERROR")
            sys.exit(1)
    except KeyboardInterrupt:
        log("KeyboardInterrupt received, stopping server.")
        stop_server()
        sys.exit(0)
    except Exception as e:
        log("An error occurred: {}".format(e))
        stop_server()
        sys.exit(1)