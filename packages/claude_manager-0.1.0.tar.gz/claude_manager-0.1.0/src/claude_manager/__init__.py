"""Claude Manager - Gestionnaire de bibliothèque d'agents et serveurs MCP pour Claude Code."""

__version__ = "0.1.0"
__author__ = "Zug"

from claude_manager.core.paths import ClaudePaths

__all__ = ["__version__", "ClaudePaths"]
