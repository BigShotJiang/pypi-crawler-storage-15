"""Library module - manages the embedded library of agents, commands, hooks, and MCP servers."""
