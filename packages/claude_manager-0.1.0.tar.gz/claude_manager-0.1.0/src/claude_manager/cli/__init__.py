"""CLI module for claude-manager."""
