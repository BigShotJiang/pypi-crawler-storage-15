"""Entry point for python -m claude_manager."""

from claude_manager.cli.main import main

if __name__ == "__main__":
    main()
