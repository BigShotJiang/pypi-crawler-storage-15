"""Prompts for the strands-agents analyzer."""
