"""Agent module - strands-agents based project analyzer."""
