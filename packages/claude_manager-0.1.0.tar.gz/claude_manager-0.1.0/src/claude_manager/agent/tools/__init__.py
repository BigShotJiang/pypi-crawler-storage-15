"""Custom tools for the strands-agents analyzer."""
