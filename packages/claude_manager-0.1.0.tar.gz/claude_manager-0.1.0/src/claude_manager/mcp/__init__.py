"""MCP module - manages Model Context Protocol servers."""
