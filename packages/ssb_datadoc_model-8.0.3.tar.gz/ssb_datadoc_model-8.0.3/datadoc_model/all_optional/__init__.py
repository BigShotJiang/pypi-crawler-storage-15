"""Module where all model fields are forced to be optional.

This is useful for persisting and validating data from users as it is entered via an interface.
"""
