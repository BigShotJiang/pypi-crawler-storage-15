#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Project : quant1x
@Package : quant1x.std
@File    : __init__.py
@Author  : wangfeng
@Date    : 2025/9/15 17:06
@Desc    : 标准库
"""
