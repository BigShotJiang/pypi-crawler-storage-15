"""Entry point so ``python -m quarry`` matches the CLI binary."""

from quarry.quarry import main

if __name__ == "__main__":
    main()
