from .assume_role_decorator import assume_role
from .assume_role import OBP_ASSUME_ROLE_ARN_ENV_VAR

__mf_promote_submodules__ = ["plugins.aws"]
