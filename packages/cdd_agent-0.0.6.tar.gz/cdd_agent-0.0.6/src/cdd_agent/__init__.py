"""CDD Agent - AI coding assistant with structured workflows."""

__version__ = "0.0.6"
__author__ = "Guilherme Gouw"
__email__ = "guilherme.gouw@gmail.com"
