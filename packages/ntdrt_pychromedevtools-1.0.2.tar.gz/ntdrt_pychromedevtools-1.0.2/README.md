My own PyChromeDevTools enhancements
