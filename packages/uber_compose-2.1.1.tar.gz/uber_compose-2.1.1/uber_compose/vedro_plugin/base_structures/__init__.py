"""
This module used for the vedro plugin cli command base class
"""
