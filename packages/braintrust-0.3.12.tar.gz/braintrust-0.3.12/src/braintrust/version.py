VERSION = "0.3.12"

# this will be templated during the build
GIT_COMMIT = "8c2b2995c2097f5699c101f4ab5e653ff40014a1"
