# 국내주식 실시간호가 (NXT)

> API 경로: `/tryitout/H0NXASP0`

---

# WEBSOCKET국내주식 실시간호가 (NXT)

**국내주식 실시간호가 (NXT) 정보** **Method, URL, 실전 Domain, 모의 Domain, Format, Content-Type** Method | POST | URL | /tryitout/H0NXASP0  
---|---|---|---  
실전 Domain  | ws://ops.koreainvestment.com:21000 | 모의 Domain | 모의투자 미지원  
실전 TR ID  | H0NXASP0 | 모의 TR ID | 모의투자 미지원  
Format |  | Content-Type |   
  
## 개요

## 요청

### Header

**주식주문(현금[V1_국내주식-001]) 정보** **Element, 한글명, Type, Rquired, Length, Description** Element | 한글명 | Type | Required | Length | Description  
---|---|---|---|---|---  
approval_key | 웹소켓 접속키 | String | N | 286 | 실시간 (웹소켓) 접속키 발급 API(/oauth2/Approval)를 사용하여 발급받은 웹소켓 접속키  
custtype | 고객타입 | String | N | 1 | 'B : 법인  
P : 개인'  
tr_type | 거래타입 | String | N | 1 | '1 : 등록  
2 : 해제'  
content-type | 컨텐츠타입 | String | N | 1 | ' utf-8'  
  
### Body

**주식주문(현금[V1_국내주식-001]) 정보** **Element, 한글명, Type, Rquired, Length, Description** Element | 한글명 | Type | Required | Length | Description  
---|---|---|---|---|---  
tr_id | 거래ID | String | Y | 2 | H0NXASP0 : 실시간 주식 호가 (NXT)  
tr_key | 구분값 | String | Y | 12 | 종목코드 (ex 005930 삼성전자)  
  
## 응답

### Header

### Body

**주식주문(현금[V1_국내주식-001]) 정보** **Element, 한글명, Type, Rquired, Length, Description** Element | 한글명 | Type | Required | Length | Description  
---|---|---|---|---|---  
MKSC_SHRN_ISCD | 유가증권 단축 종목코드 | String | Y | 9 |   
BSOP_HOUR | 영업 시간 | String | Y | 6 |   
HOUR_CLS_CODE | 시간 구분 코드 | String | Y | 1 |   
ASKP1 | 매도호가1 | String | Y | 4 |   
ASKP2 | 매도호가2 | String | Y | 4 |   
ASKP3 | 매도호가3 | String | Y | 4 |   
ASKP4 | 매도호가4 | String | Y | 4 |   
ASKP5 | 매도호가5 | String | Y | 4 |   
ASKP6 | 매도호가6 | String | Y | 4 |   
ASKP7 | 매도호가7 | String | Y | 4 |   
ASKP8 | 매도호가8 | String | Y | 4 |   
ASKP9 | 매도호가9 | String | Y | 4 |   
ASKP10 | 매도호가10 | String | Y | 4 |   
BIDP1 | 매수호가1 | String | Y | 4 |   
BIDP2 | 매수호가2 | String | Y | 4 |   
BIDP3 | 매수호가3 | String | Y | 4 |   
BIDP4 | 매수호가4 | String | Y | 4 |   
BIDP5 | 매수호가5 | String | Y | 4 |   
BIDP6 | 매수호가6 | String | Y | 4 |   
BIDP7 | 매수호가7 | String | Y | 4 |   
BIDP8 | 매수호가8 | String | Y | 4 |   
BIDP9 | 매수호가9 | String | Y | 4 |   
BIDP10 | 매수호가10 | String | Y | 4 |   
ASKP_RSQN1 | 매도호가 잔량1 | String | Y | 8 |   
ASKP_RSQN2 | 매도호가 잔량2 | String | Y | 8 |   
ASKP_RSQN3 | 매도호가 잔량3 | String | Y | 8 |   
ASKP_RSQN4 | 매도호가 잔량4 | String | Y | 8 |   
ASKP_RSQN5 | 매도호가 잔량5 | String | Y | 8 |   
ASKP_RSQN6 | 매도호가 잔량6 | String | Y | 8 |   
ASKP_RSQN7 | 매도호가 잔량7 | String | Y | 8 |   
ASKP_RSQN8 | 매도호가 잔량8 | String | Y | 8 |   
ASKP_RSQN9 | 매도호가 잔량9 | String | Y | 8 |   
ASKP_RSQN10 | 매도호가 잔량10 | String | Y | 8 |   
BIDP_RSQN1 | 매수호가 잔량1 | String | Y | 8 |   
BIDP_RSQN2 | 매수호가 잔량2 | String | Y | 8 |   
BIDP_RSQN3 | 매수호가 잔량3 | String | Y | 8 |   
BIDP_RSQN4 | 매수호가 잔량4 | String | Y | 8 |   
BIDP_RSQN5 | 매수호가 잔량5 | String | Y | 8 |   
BIDP_RSQN6 | 매수호가 잔량6 | String | Y | 8 |   
BIDP_RSQN7 | 매수호가 잔량7 | String | Y | 8 |   
BIDP_RSQN8 | 매수호가 잔량8 | String | Y | 8 |   
BIDP_RSQN9 | 매수호가 잔량9 | String | Y | 8 |   
BIDP_RSQN10 | 매수호가 잔량10 | String | Y | 8 |   
TOTAL_ASKP_RSQN | 총 매도호가 잔량 | String | Y | 8 |   
TOTAL_BIDP_RSQN | 총 매수호가 잔량 | String | Y | 8 |   
OVTM_TOTAL_ASKP_RSQN | 시간외 총 매도호가 잔량 | String | Y | 8 |   
OVTM_TOTAL_BIDP_RSQN | 시간외 총 매수호가 잔량 | String | Y | 8 |   
ANTC_CNPR | 예상 체결가 | String | Y | 4 |   
ANTC_CNQN | 예상 체결량 | String | Y | 8 |   
ANTC_VOL | 예상 거래량 | String | Y | 8 |   
ANTC_CNTG_VRSS | 예상 체결 대비 | String | Y | 4 |   
ANTC_CNTG_VRSS_SIGN | 예상 체결 대비 부호 | String | Y | 1 |   
ANTC_CNTG_PRDY_CTRT | 예상 체결 전일 대비율 | String | Y | 8 |   
ACML_VOL | 누적 거래량 | String | Y | 8 |   
TOTAL_ASKP_RSQN_ICDC | 총 매도호가 잔량 증감 | String | Y | 4 |   
TOTAL_BIDP_RSQN_ICDC | 총 매수호가 잔량 증감 | String | Y | 4 |   
OVTM_TOTAL_ASKP_ICDC | 시간외 총 매도호가 증감 | String | Y | 4 |   
OVTM_TOTAL_BIDP_ICDC | 시간외 총 매수호가 증감 | String | Y | 4 |   
STCK_DEAL_CLS_CODE | 주식 매매 구분 코드 | String | Y | 2 |   
KMID_PRC | KRX 중간가 | String | Y | 4 |   
KMID_TOTAL_RSQN | KRX 중간가잔량합계수량 | String | Y | 8 |   
KMID_CLS_CODE | KRX 중간가 매수매도 구분 | String | Y | 1 |   
NMID_PRC | NXT 중간가 | String | Y | 4 |   
NMID_TOTAL_RSQN | NXT 중간가잔량합계수량 | String | Y | 8 |   
NMID_CLS_CODE | NXT 중간가 매수매도 구분 | String | Y | 1 |   
  
## 예시

### Request

  * Data Class (Python)

### Data Class (Python)
    
    
    from dataclasses import dataclass
    
    @dataclass
    class RequestHeader:
        approval_key: Optional[str] = None    #웹소켓 접속키
        custtype: Optional[str] = None    #고객타입
        tr_type: Optional[str] = None    #거래타입
        content-type: Optional[str] = None    #컨텐츠타입
    
    @dataclass
    class RequestBody:
        tr_id: str    #거래ID
        tr_key: str    #구분값
    
    

복사하기

### Response

  * Data Class (Python)

### Data Class (Python)
    
    
    from dataclasses import dataclass
    from typing import List, Optional
    
    @dataclass
    class ResponseHeader:
    
    @dataclass
    class ResponseBody:
        MKSC_SHRN_ISCD: str    #유가증권 단축 종목코드
        BSOP_HOUR: str    #영업 시간
        HOUR_CLS_CODE: str    #시간 구분 코드
        ASKP1: str    #매도호가1
        ASKP2: str    #매도호가2
        ASKP3: str    #매도호가3
        ASKP4: str    #매도호가4
        ASKP5: str    #매도호가5
        ASKP6: str    #매도호가6
        ASKP7: str    #매도호가7
        ASKP8: str    #매도호가8
        ASKP9: str    #매도호가9
        ASKP10: str    #매도호가10
        BIDP1: str    #매수호가1
        BIDP2: str    #매수호가2
        BIDP3: str    #매수호가3
        BIDP4: str    #매수호가4
        BIDP5: str    #매수호가5
        BIDP6: str    #매수호가6
        BIDP7: str    #매수호가7
        BIDP8: str    #매수호가8
        BIDP9: str    #매수호가9
        BIDP10: str    #매수호가10
        ASKP_RSQN1: str    #매도호가 잔량1
        ASKP_RSQN2: str    #매도호가 잔량2
        ASKP_RSQN3: str    #매도호가 잔량3
        ASKP_RSQN4: str    #매도호가 잔량4
        ASKP_RSQN5: str    #매도호가 잔량5
        ASKP_RSQN6: str    #매도호가 잔량6
        ASKP_RSQN7: str    #매도호가 잔량7
        ASKP_RSQN8: str    #매도호가 잔량8
        ASKP_RSQN9: str    #매도호가 잔량9
        ASKP_RSQN10: str    #매도호가 잔량10
        BIDP_RSQN1: str    #매수호가 잔량1
        BIDP_RSQN2: str    #매수호가 잔량2
        BIDP_RSQN3: str    #매수호가 잔량3
        BIDP_RSQN4: str    #매수호가 잔량4
        BIDP_RSQN5: str    #매수호가 잔량5
        BIDP_RSQN6: str    #매수호가 잔량6
        BIDP_RSQN7: str    #매수호가 잔량7
        BIDP_RSQN8: str    #매수호가 잔량8
        BIDP_RSQN9: str    #매수호가 잔량9
        BIDP_RSQN10: str    #매수호가 잔량10
        TOTAL_ASKP_RSQN: str    #총 매도호가 잔량
        TOTAL_BIDP_RSQN: str    #총 매수호가 잔량
        OVTM_TOTAL_ASKP_RSQN: str    #시간외 총 매도호가 잔량
        OVTM_TOTAL_BIDP_RSQN: str    #시간외 총 매수호가 잔량
        ANTC_CNPR: str    #예상 체결가
        ANTC_CNQN: str    #예상 체결량
        ANTC_VOL: str    #예상 거래량
        ANTC_CNTG_VRSS: str    #예상 체결 대비
        ANTC_CNTG_VRSS_SIGN: str    #예상 체결 대비 부호
        ANTC_CNTG_PRDY_CTRT: str    #예상 체결 전일 대비율
        ACML_VOL: str    #누적 거래량
        TOTAL_ASKP_RSQN_ICDC: str    #총 매도호가 잔량 증감
        TOTAL_BIDP_RSQN_ICDC: str    #총 매수호가 잔량 증감
        OVTM_TOTAL_ASKP_ICDC: str    #시간외 총 매도호가 증감
        OVTM_TOTAL_BIDP_ICDC: str    #시간외 총 매수호가 증감
        STCK_DEAL_CLS_CODE: str    #주식 매매 구분 코드
        KMID_PRC: str    #KRX 중간가
        KMID_TOTAL_RSQN: str    #KRX 중간가잔량합계수량
        KMID_CLS_CODE: str    #KRX 중간가 매수매도 구분
        NMID_PRC: str    #NXT 중간가
        NMID_TOTAL_RSQN: str    #NXT 중간가잔량합계수량
        NMID_CLS_CODE: str    #NXT 중간가 매수매도 구분
    
    

복사하기