#!/usr/bin/env python3
# coding=utf-8

"""
implementations of git commands using subprocess.
"""
