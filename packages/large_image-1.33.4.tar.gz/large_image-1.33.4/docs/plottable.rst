.. include:: ../girder_annotation/docs/plottable.rst
