.. include:: ../sources/dicom/docs/dicomweb_assetstore.rst
