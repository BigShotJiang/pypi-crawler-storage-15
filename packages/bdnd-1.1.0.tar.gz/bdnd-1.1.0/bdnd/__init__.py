"""Baidu Netdisk Client - A Python client for Baidu Netdisk API"""

from .client import BaiduNetdiskClient

__version__ = "1.1.0"
__all__ = ["BaiduNetdiskClient"]

