# Changelog

## [0.1.2](https://github.com/uermel/cryoet-alignment/compare/cryoet-alignment-v0.1.1...cryoet-alignment-v0.1.2) (2025-12-02)


### 🐞 Bug Fixes

* Allow for negative XAXISTILT values in imod .com files ([#10](https://github.com/uermel/cryoet-alignment/issues/10)) ([2e5e6af](https://github.com/uermel/cryoet-alignment/commit/2e5e6afa018d824f3fd960bc0814a8b6249936ea))

## [0.1.1](https://github.com/uermel/cryoet-alignment/compare/cryoet-alignment-v0.1.0...cryoet-alignment-v0.1.1) (2025-11-03)


### 🐞 Bug Fixes

* remove pin to numpy&lt;2 ([#11](https://github.com/uermel/cryoet-alignment/issues/11)) ([1022419](https://github.com/uermel/cryoet-alignment/commit/10224198f81c7826a696c94e4da854e605914fb6))

## [0.1.0](https://github.com/uermel/cryoet-alignment/compare/cryoet-alignment-v0.0.10...cryoet-alignment-v0.1.0) (2025-07-08)


### ✨ Features

* fix ALN file creating from data portal metadata. ([#8](https://github.com/uermel/cryoet-alignment/issues/8)) ([35342cc](https://github.com/uermel/cryoet-alignment/commit/35342cc31d45aa368023fb27f95e2f5c4a2b789e))


### 🧹 Miscellaneous Chores

* add CI ([#6](https://github.com/uermel/cryoet-alignment/issues/6)) ([378d5dc](https://github.com/uermel/cryoet-alignment/commit/378d5dc6c02ea5b9a75fcda0a248a501485a9885))
* update tests to use uv ([#9](https://github.com/uermel/cryoet-alignment/issues/9)) ([2e88508](https://github.com/uermel/cryoet-alignment/commit/2e88508a0a34c654b394ab17c2b671492fd062fc))
