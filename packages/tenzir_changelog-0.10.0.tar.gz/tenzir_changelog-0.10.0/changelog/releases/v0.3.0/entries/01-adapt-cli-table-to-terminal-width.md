---
title: Polish the table view layout
type: change
authors:
- codex
created: 2025-10-22
---

The default `tenzir-changelog show` table now adapts column widths to the active terminal,
right-aligns row numbers, centers the version column, and inserts release separators so
multi-digit identifiers stay readable even when the screen gets narrow.
