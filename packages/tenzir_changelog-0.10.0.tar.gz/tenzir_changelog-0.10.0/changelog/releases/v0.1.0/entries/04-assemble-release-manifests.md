---
title: Assemble release manifests from unreleased entries
type: feature
authors:
- codex
created: 2025-10-21
---

Provide a `release` subcommand that collects unreleased entries, writes versioned manifests with archived entry copies, and generates release notes with an optional introduction template.
