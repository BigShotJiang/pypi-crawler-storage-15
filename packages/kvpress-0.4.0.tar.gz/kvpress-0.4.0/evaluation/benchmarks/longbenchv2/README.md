# LongBench-v2 dataset

[longbench](https://github.com/THUDM/LongBench). 

## Create Hugging Face dataset

The processed Hugging Face dataset for LongBench-v2 can be found [here](https://huggingface.co/datasets/simonjegou/LongBench-v2). To reproduce this dataset, simply run the `create_huggingface_dataset.py` script.