# `HaxallClient`

::: phable.haxall_client.open_haxall_client

::: phable.haxall_client.HaxallClient