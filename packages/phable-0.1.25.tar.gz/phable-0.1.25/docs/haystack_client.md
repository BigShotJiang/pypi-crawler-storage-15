# `HaystackClient`

::: phable.open_haystack_client

::: phable.HaystackClient

::: phable.AuthError

::: phable.CallError

::: phable.UnknownRecError