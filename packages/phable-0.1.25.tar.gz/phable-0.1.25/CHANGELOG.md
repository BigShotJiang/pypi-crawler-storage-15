# Changelog

## 0.1.25 (2025-12-05)

* fix: correct build config
