---
schema_version: "1.0.0"
name: "missing-checksum"
title: "Missing Checksum"
version: "1.0.0"
status: "stable"
objective: "This dossier is missing the required checksum field"
authors:
  - name: "Test Author"
---

# Missing Checksum

This dossier has no checksum.
