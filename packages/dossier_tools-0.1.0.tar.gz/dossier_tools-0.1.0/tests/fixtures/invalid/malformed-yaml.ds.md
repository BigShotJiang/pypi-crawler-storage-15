---
schema_version: "1.0.0"
title: "Malformed
  this is broken yaml
    indentation: wrong
---

# Malformed

Body content.
