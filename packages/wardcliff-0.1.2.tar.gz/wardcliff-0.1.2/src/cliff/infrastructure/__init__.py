"""Infrastructure layer (config, database, logging) for Cliff."""
