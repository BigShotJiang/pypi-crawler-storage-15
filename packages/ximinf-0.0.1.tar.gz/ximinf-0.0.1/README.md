# ximinf
Simulation Based Inference of Cosmological parameters in Jax using type Ia supernovae.
