var username = "{{data.jquery_data_username}}";
var email = "{{data.jquery_data_email}}";