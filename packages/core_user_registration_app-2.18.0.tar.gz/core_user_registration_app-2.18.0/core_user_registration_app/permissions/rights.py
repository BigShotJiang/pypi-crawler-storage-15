""" Rights for core user registration
"""

register_content_type = "core_user_registration"
register_access = "access_register"
register_data_structure_access = "access_user_data_structure"
