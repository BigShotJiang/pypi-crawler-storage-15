from .scraper import AIOScraper

__all__ = ("AIOScraper",)
