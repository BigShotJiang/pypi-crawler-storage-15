import pytest
from aresponses import ResponsesMockServer

from aioscraper import AIOScraper
from aioscraper.exceptions import ClientException, HTTPException
from aioscraper.types import Request, SendRequest


class Scraper:
    def __init__(self) -> None:
        self.status = None
        self.response_data = None

    async def __call__(self, send_request: SendRequest) -> None:
        await send_request(Request(url="https://api.test.com/v1", errback=self.errback))

    async def errback(self, exc: ClientException) -> None:
        if isinstance(exc, HTTPException):
            self.status = exc.status_code
            self.response_data = exc.message


@pytest.mark.asyncio
async def test_error(aresponses: ResponsesMockServer):
    response_data = "Internal Server Error"

    def handle_request(request):
        return aresponses.Response(status=500, text=response_data)

    aresponses.add("api.test.com", "/v1", "GET", response=handle_request)  # pyright: ignore

    scraper = Scraper()
    async with AIOScraper(scraper) as s:
        await s.start()

    assert scraper.status == 500
    assert scraper.response_data == response_data
    aresponses.assert_plan_strictly_followed()
