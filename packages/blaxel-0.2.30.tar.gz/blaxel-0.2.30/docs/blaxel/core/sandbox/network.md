Module blaxel.core.sandbox.network
==================================

Classes
-------

`SandboxNetwork(sandbox_config: blaxel.core.sandbox.types.SandboxConfiguration)`
:   

    ### Ancestors (in MRO)

    * blaxel.core.sandbox.action.SandboxAction