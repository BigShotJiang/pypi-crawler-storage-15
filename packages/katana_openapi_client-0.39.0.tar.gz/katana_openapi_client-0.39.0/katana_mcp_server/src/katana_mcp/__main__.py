"""Entry point for running Katana MCP Server as a module.

Usage:
    python -m katana_mcp
"""

from katana_mcp.server import main

if __name__ == "__main__":
    main()
