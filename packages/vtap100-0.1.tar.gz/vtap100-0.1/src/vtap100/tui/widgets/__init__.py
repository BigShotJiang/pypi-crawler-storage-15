"""TUI Widgets for VTAP100 Editor."""
