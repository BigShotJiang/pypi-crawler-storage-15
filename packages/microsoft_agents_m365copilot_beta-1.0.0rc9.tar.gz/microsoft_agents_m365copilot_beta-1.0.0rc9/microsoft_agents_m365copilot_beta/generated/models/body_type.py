from enum import Enum

class BodyType(str, Enum):
    Text = "text",
    Html = "html",

