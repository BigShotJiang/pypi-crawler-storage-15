PyDDA Example Gallery
====================

In this section, we show different examples on:
   * How to use HRRR to initalize your wind retrieval
   * How to adjust the variational retrieval parameters
