Getting started with PyDDA
==========================

This is a template to help you get started adding content for the user guide!

You will start with a title (above), and some text (here).

Code blocks are formatted as follows:

.. code-block:: python

    import pyart
    import pydda

You can add subsections like this:

-------------
Section 1
-------------

Or like this

++++++++++++
Subsection 1
++++++++++++

To add your content, you should copy this file, edit it,
and add it to the index.rst file under user_guide.
