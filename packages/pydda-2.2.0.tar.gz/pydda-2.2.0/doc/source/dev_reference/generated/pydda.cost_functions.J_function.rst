﻿pydda.cost\_functions.J\_function
=================================

.. currentmodule:: pydda.cost_functions

.. autofunction:: J_function
