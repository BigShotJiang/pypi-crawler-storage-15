﻿pydda.cost\_functions.calculate\_background\_gradient
=====================================================

.. currentmodule:: pydda.cost_functions

.. autofunction:: calculate_background_gradient
