﻿pydda.retrieval.get\_bca
========================

.. currentmodule:: pydda.retrieval

.. autofunction:: get_bca
