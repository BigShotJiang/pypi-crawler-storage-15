﻿pydda.cost\_functions.calculate\_smoothness\_gradient
=====================================================

.. currentmodule:: pydda.cost_functions

.. autofunction:: calculate_smoothness_gradient
