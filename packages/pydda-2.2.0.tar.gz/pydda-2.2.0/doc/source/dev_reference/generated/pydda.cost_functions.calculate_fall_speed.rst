﻿pydda.cost\_functions.calculate\_fall\_speed
============================================

.. currentmodule:: pydda.cost_functions

.. autofunction:: calculate_fall_speed
