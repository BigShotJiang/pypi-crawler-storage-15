﻿pydda.cost\_functions.calculate\_vertical\_vorticity\_cost
==========================================================

.. currentmodule:: pydda.cost_functions

.. autofunction:: calculate_vertical_vorticity_cost
