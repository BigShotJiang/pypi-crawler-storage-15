﻿pydda.vis.plot\_xz\_xsection\_barbs
===================================

.. currentmodule:: pydda.vis

.. autofunction:: plot_xz_xsection_barbs
