﻿pydda.cost\_functions.grad\_J
=============================

.. currentmodule:: pydda.cost_functions

.. autofunction:: grad_J
