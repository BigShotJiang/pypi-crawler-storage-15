﻿pydda.cost\_functions.calculate\_grad\_radial\_vel
==================================================

.. currentmodule:: pydda.cost_functions

.. autofunction:: calculate_grad_radial_vel
