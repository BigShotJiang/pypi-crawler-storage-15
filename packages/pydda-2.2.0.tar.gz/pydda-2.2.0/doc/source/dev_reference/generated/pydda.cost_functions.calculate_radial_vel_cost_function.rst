﻿pydda.cost\_functions.calculate\_radial\_vel\_cost\_function
============================================================

.. currentmodule:: pydda.cost_functions

.. autofunction:: calculate_radial_vel_cost_function
