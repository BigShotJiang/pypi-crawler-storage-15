﻿pydda.vis.plot\_yz\_xsection\_barbs
===================================

.. currentmodule:: pydda.vis

.. autofunction:: plot_yz_xsection_barbs
