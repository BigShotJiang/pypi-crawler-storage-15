﻿pydda.retrieval.get\_dd\_wind\_field
====================================

.. currentmodule:: pydda.retrieval

.. autofunction:: get_dd_wind_field
