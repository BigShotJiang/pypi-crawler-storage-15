﻿pydda.vis.plot\_horiz\_xsection\_barbs
======================================

.. currentmodule:: pydda.vis

.. autofunction:: plot_horiz_xsection_barbs
