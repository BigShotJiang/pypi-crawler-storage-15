﻿pydda.cost\_functions.calculate\_background\_cost
=================================================

.. currentmodule:: pydda.cost_functions

.. autofunction:: calculate_background_cost
