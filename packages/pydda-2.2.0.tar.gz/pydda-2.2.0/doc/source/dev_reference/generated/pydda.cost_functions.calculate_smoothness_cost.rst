﻿pydda.cost\_functions.calculate\_smoothness\_cost
=================================================

.. currentmodule:: pydda.cost_functions

.. autofunction:: calculate_smoothness_cost
