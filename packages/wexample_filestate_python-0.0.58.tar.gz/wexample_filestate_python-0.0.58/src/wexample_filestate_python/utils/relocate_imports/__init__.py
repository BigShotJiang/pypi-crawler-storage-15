from __future__ import annotations

from .python_parser_import_index import PythonParserImportIndex

__all__ = [
    "PythonParserImportIndex",
]
