
from setuptools import setup

if __name__ == "__main__":
    # Minimal shim: metadata declared in pyproject.toml (PEP 621)
    setup()
