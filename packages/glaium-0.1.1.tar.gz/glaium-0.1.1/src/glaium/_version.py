"""Version information for Glaium SDK."""

__version__ = "0.1.1"
