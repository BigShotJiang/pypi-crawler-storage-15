__version__ = "1.2.22"  # pragma: no cover
