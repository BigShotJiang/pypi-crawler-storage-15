"""
Blessed Github connector for Airbyte SDK.

Auto-generated from OpenAPI specification.
"""

from .connector import GithubConnector

__all__ = ["GithubConnector"]
