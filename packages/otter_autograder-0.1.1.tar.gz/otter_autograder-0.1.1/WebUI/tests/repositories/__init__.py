"""
Tests for repository layer.
"""
