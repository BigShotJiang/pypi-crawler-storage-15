"""Tests for keycardai.mcp package."""
