"""Tests for the keycardai.mcp.server.middleware module."""
