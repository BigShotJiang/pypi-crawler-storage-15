"""OAuth service tests."""

