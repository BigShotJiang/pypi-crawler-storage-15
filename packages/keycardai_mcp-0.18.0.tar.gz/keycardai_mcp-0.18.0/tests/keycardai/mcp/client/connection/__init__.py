"""Tests for connection module."""

