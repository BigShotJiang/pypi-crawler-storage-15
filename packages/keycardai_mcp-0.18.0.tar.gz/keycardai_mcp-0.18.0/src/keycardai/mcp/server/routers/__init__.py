from .metadata import auth_metadata_mount, protected_mcp_router

__all__ = [
    "auth_metadata_mount",
    "protected_mcp_router",
]
