This module collects modules migration data from Odoo repositories.
