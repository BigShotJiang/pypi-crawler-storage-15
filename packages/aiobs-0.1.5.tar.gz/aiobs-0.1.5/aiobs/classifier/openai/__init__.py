"""OpenAI-based classifier for aiobs."""

from .classifier import OpenAIClassifier

__all__ = ["OpenAIClassifier"]

