# Change Log

## Version 0.12.x

- Implements periodic boundary confitions

## Version 0.11.x

- More comfortable API. (Old API still available)

## Version 0.10.x

- Create symbolic representations of finite difference schemes

## Version 0.9.x

- Generate differential operators for generic stencils

## Version 0.8.x

- Formulate and solve partial differential equations

## Version 0.7.*

- Generation of stencils for given FinDiff object
- Generation of matrix representation for arbitrary linear differential operator
