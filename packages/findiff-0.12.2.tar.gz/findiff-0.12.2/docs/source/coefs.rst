==============
Finite Difference Coefficients
==============

.. automodule:: findiff.coefs
    :members:



