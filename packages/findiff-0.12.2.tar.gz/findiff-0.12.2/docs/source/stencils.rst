==================
Module *stencils*
==================

.. automodule:: findiff.stencils
    :members:

