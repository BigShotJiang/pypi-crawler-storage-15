#!/usr/bin/python3
"""
TonieToolbox - Convert audio files to Tonie box compatible format
"""

__version__ = '0.6.5'