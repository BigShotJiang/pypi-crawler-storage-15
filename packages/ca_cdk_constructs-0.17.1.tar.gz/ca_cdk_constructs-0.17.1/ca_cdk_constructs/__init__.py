# ruff: noqa: F401
from ca_cdk_constructs.cross_account_domain_delegation import (
    CrossAccountDomainDelegation,
    R53ParentZoneConfig,
)
