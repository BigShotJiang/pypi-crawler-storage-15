"""Integration tests for LazyClaude."""
