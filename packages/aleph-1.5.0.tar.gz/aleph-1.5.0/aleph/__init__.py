import sys
import os

here = os.path.abspath(os.path.dirname(__file__))

sys.path.append(os.path.join(here,"core"))
sys.path.append(os.path.join(here,"gui"))

