memtab.vizhookspecs module
==========================

.. automodule:: memtab.vizhookspecs
   :members:
   :undoc-members:
   :show-inheritance:
