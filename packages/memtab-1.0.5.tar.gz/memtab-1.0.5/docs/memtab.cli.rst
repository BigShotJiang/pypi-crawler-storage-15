memtab.cli module
=================

.. automodule:: memtab.cli
   :members:
   :undoc-members:
   :show-inheritance:
