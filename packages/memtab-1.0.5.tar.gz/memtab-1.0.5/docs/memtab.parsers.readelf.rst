memtab.parsers.readelf module
=============================

.. automodule:: memtab.parsers.readelf
   :members:
   :undoc-members:
   :show-inheritance:
