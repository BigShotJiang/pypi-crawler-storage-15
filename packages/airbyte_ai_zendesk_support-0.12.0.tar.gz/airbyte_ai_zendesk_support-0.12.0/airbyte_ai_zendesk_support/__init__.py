"""
Blessed Zendesk-Support connector for Airbyte SDK.

Auto-generated from OpenAPI specification.
"""

from .connector import ZendeskSupportConnector

__all__ = ["ZendeskSupportConnector"]
