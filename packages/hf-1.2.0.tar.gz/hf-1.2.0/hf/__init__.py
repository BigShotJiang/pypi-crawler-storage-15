raise ImportError(
    "The 'hf' package only provides a CLI entry point. It cannot be imported. Please import 'huggingface_hub' instead."
)
