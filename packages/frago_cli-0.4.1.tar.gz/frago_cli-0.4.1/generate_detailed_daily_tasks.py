#!/usr/bin/env python3
"""
生成Frago项目11月25日-12月1日的每日ONES任务
要求：每天最少1个最多3个任务，每天总工时≥8小时
"""

import subprocess
import json
from pathlib import Path
from datetime import datetime, timedelta
from collections import defaultdict
import re

def parse_conventional_commit(subject: str):
    """解析 Conventional Commits 格式"""
    pattern = r'^(\w+)(?:\(([^)]+)\))?: (.+)$'
    match = re.match(pattern, subject)

    if match:
        return {
            'type': match.group(1),
            'scope': match.group(2) or "",
            'description': match.group(3)
        }
    return {
        'type': 'unknown',
        'scope': '',
        'description': subject
    }

def get_commit_details(commit_hash: str):
    """获取单个commit的详细信息"""
    # 获取完整提交消息
    msg_result = subprocess.run(
        ['git', 'show', '--format=%B', '--no-patch', commit_hash],
        capture_output=True, text=True, check=True
    )
    full_message = msg_result.stdout.strip()

    # 获取统计信息
    stat_result = subprocess.run(
        ['git', 'show', '--stat', '--format=', commit_hash],
        capture_output=True, text=True, check=True
    )

    # 获取作者和日期
    info_result = subprocess.run(
        ['git', 'show', '--format=%an|%ae|%ad', '--date=iso', '--no-patch', commit_hash],
        capture_output=True, text=True, check=True
    )
    author_info = info_result.stdout.strip().split('|')

    files_changed = []
    lines_added = 0
    lines_deleted = 0

    for line in stat_result.stdout.strip().split('\n'):
        file_match = re.match(r'^\s+(\S+)\s+\|\s+(\d+)\s+([+-]+)?', line)
        if file_match:
            filename = file_match.group(1)
            files_changed.append(filename)

    # 从汇总行提取准确数字
    summary_match = re.search(r'(\d+) files? changed(?:, (\d+) insertions?\(\+\))?(?:, (\d+) deletions?\(-\))?', stat_result.stdout)
    if summary_match:
        if summary_match.group(2):
            lines_added = int(summary_match.group(2))
        if summary_match.group(3):
            lines_deleted = int(summary_match.group(3))

    return {
        'full_message': full_message,
        'files_changed': files_changed,
        'files_count': len(files_changed),
        'lines_added': lines_added,
        'lines_deleted': lines_deleted,
        'author_name': author_info[0] if len(author_info) > 0 else '',
        'author_email': author_info[1] if len(author_info) > 1 else '',
        'date': author_info[2] if len(author_info) > 2 else ''
    }

def estimate_hours_from_stats(lines_added: int, lines_deleted: int) -> float:
    """根据代码行数估算工时"""
    total_lines = lines_added + lines_deleted

    if total_lines < 30:
        return 1.5
    elif total_lines < 100:
        return 2.5
    elif total_lines < 300:
        return 3.5
    elif total_lines < 500:
        return 4.5
    else:
        return 6.0

def get_commits_by_date(start_date: str, end_date: str):
    """获取指定日期范围的提交，按日期分组"""
    cmd = [
        'git', 'log',
        '--pretty=format:%H|%ad|%s',
        '--date=short',
        '--no-merges',
        f'--since={start_date}',
        f'--until={end_date}'
    ]

    result = subprocess.run(cmd, capture_output=True, text=True, check=True)

    commits_by_date = defaultdict(list)

    for line in result.stdout.strip().split('\n'):
        if not line:
            continue

        parts = line.split('|')
        if len(parts) < 3:
            continue

        commit_hash = parts[0]
        commit_date = parts[1]
        subject = parts[2]

        parsed = parse_conventional_commit(subject)
        details = get_commit_details(commit_hash)

        commits_by_date[commit_date].append({
            'hash': commit_hash,
            'hash_short': commit_hash[:7],
            'date': commit_date,
            'subject': subject,
            **parsed,
            **details
        })

    return commits_by_date

def map_commit_type_to_category(commit_type: str) -> str:
    """将 commit type 映射到任务类型"""
    mapping = {
        'feat': '新功能开发',
        'fix': '问题修复',
        'refactor': '代码重构',
        'docs': '文档更新',
        'test': '测试',
        'chore': '杂务',
        'style': '代码格式',
        'perf': '性能优化',
        'ci': 'CI/CD',
        'build': '构建'
    }
    return mapping.get(commit_type.lower(), '其他')

def select_tasks_for_day(commits, target_hours=8):
    """选择任务，确保总工时≥8小时"""
    if not commits:
        return [], 0.0

    for commit in commits:
        commit['estimated_hours'] = estimate_hours_from_stats(
            commit['lines_added'],
            commit['lines_deleted']
        )

    sorted_commits = sorted(commits, key=lambda x: x['estimated_hours'], reverse=True)

    selected = []
    total_hours = 0.0

    for commit in sorted_commits[:3]:
        selected.append(commit)
        total_hours += commit['estimated_hours']

        if total_hours >= target_hours and len(selected) >= 1:
            break

    if selected and total_hours < target_hours:
        shortfall = target_hours - total_hours
        selected[-1]['estimated_hours'] += shortfall
        total_hours = target_hours

    return selected, total_hours

def generate_daily_tasks(commits_by_date, output_dir):
    """生成详细的每日任务文档"""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    start = datetime(2025, 11, 25)
    end = datetime(2025, 12, 1)

    all_dates = []
    current = start
    while current <= end:
        all_dates.append(current.strftime('%Y-%m-%d'))
        current += timedelta(days=1)

    for date_str in all_dates:
        commits = commits_by_date.get(date_str, [])

        if not commits:
            print(f"⚠️  {date_str}: 无提交记录，跳过")
            continue

        selected_commits, total_hours = select_tasks_for_day(commits, target_hours=8)

        filename = f"{date_str.replace('-', '')}_total.md"
        filepath = output_dir / filename

        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(f"# {date_str} 工作日报\n\n")
            f.write(f"> Date: {date_str}\n")
            f.write(f"> Author: Jamey Tsai <yammi@yammi.cafe>\n\n")
            f.write("---\n\n")

            f.write("## 基本信息\n\n")
            f.write(f"- **Title**: {date_str} 工作日报\n")
            f.write("- **Project**: [Scrum] Frago\n")
            f.write("- **Issue type**: Task\n")
            f.write("- **任务类型**: 开发/重构/文档\n")
            f.write("- **负责人**: Jamey Tsai\n")
            f.write("- **所属模块**: Frago\n")
            f.write(f"- **预估工时**: {total_hours:.1f} 小时\n")
            f.write("- **当前步骤**: 已完成\n")
            f.write("- **验收标准**: \n")
            f.write("  1. 代码通过自动化测试\n")
            f.write("  2. 功能符合需求描述\n")
            f.write("  3. 文档已更新并准确反映变更\n\n")

            f.write("## 描述\n\n")
            f.write("今日主要完成了以下工作：\n\n")

            for idx, commit in enumerate(selected_commits, 1):
                f.write(f"### 任务 {idx}: {commit['description']}\n")

                message_lines = commit['full_message'].split('\n')
                body_lines = message_lines[1:] if len(message_lines) > 1 else []
                body = '\n'.join([line for line in body_lines if line.strip()]).strip()

                if body:
                    f.write(f"{body}\n\n")
                else:
                    task_type = map_commit_type_to_category(commit['type'])
                    f.write(f"**类型**: {task_type}\n\n")
                    if commit['scope']:
                        f.write(f"**模块**: {commit['scope']}\n\n")
                    f.write(f"完成了 {commit['description']} 相关功能的开发工作。\n\n")

            f.write("\n## 技术细节\n\n")

            for idx, commit in enumerate(selected_commits, 1):
                f.write(f"### 任务 {idx} 技术细节 ({commit['hash_short']})\n")
                f.write("**修改文件**:\n")
                if commit['files_changed']:
                    for file in commit['files_changed'][:10]:
                        f.write(f"- `{file}`\n")
                    if len(commit['files_changed']) > 10:
                        f.write(f"- ... 及其他 {len(commit['files_changed']) - 10} 个文件\n")
                else:
                    f.write("- (无)\n")
                f.write("\n")

                f.write("**变更统计**:\n")
                f.write(f"- 新增: {commit['lines_added']} 行\n")
                f.write(f"- 删除: {commit['lines_deleted']} 行\n")
                f.write(f"- 修改文件数: {commit['files_count']}\n\n")

                f.write("**Commit 信息**:\n")
                f.write(f"- Hash: `{commit['hash']}`\n")
                f.write(f"- Short Hash: `{commit['hash_short']}`\n")
                f.write(f"- Author: {commit['author_name']} <{commit['author_email']}>\n")
                f.write(f"- Date: {commit['date']}\n\n")

            f.write("---\n\n")
            f.write("🤖 Generated with [Claude Code](https://claude.com/claude-code)\n\n")
            f.write("Co-Authored-By: Claude <noreply@anthropic.com>\n")

        print(f"✅ {date_str}: 生成 {len(selected_commits)} 个任务，总工时 {total_hours:.1f}h → {filename}")

def main():
    """主函数"""
    print("\n🔍 正在提取commit信息...\n")

    commits_by_date = get_commits_by_date('2025-11-25', '2025-12-02')

    print("📊 提交统计：")
    for date in sorted(commits_by_date.keys()):
        print(f"  {date}: {len(commits_by_date[date])} 个提交")

    print(f"\n总计: {sum(len(v) for v in commits_by_date.values())} 个提交\n")
    print("⏳ 正在生成详细的每日任务文档...\n")

    output_dir = Path('frago_daily_tasks_output')
    generate_daily_tasks(commits_by_date, output_dir)

    print(f"\n✅ 完成！任务文件已生成到: {output_dir.absolute()}")
    print(f"📝 每天工时已调整为≥8小时，任务内容包含详细的技术细节\n")

if __name__ == '__main__':
    main()
