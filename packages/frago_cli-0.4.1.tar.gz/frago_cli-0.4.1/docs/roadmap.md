[简体中文](roadmap.zh-CN.md)

# Frago Project Progress

## Project Status

📍 **Current Phase**: Three-system architecture complete (Run + Recipe + CDP), entering ecosystem building phase

**Completed**:
- ✅ Native CDP protocol layer (~3,763 lines of Python)
- ✅ CLI tools and command system
- ✅ Recipe metadata-driven architecture (multi-runtime support)
- ✅ Run command system (topic-based task management)
- ✅ Init command (dependency check, resource installation)
- ✅ Environment variable support (three-level config priority)

**Technical Highlights**:
- 🏆 Native CDP (no Playwright/Selenium dependencies, ~2MB)
- 🏆 AI-First design (Claude AI hosts task execution and workflow orchestration)
- 🏆 Recipe acceleration system (solidify high-frequency operations, avoid repeated AI reasoning)
- 🏆 Run System (AI's working memory with persistent context)
- 🏆 Environment variable system (sensitive info management + Workflow context sharing)

---

## Completed Features ✅

### Feature 001-002: Core CDP Implementation

- [x] **Native CDP Protocol Layer** (~3,763 lines of Python code)
  - WebSocket direct to Chrome (no Node.js relay)
  - Intelligent retry mechanism (proxy environment optimized)
  - Complete command modules (page/screenshot/runtime/input/scroll/wait/zoom/status/visual_effects)
  - Type-safe configuration system

- [x] **CLI Tools** (Click framework)
  - `uv run frago <command>` - Unified interface for all CDP functionality
  - Proxy configuration support (environment variables + CLI parameters)
  - Function mapping validation tool

- [x] **Cross-Platform Chrome Launcher**
  - macOS/Linux support
  - Auto profile initialization
  - Window size control

### Feature 003-004: Recipe System

- [x] **Recipe Metadata-Driven Architecture**
  - Metadata parser (YAML frontmatter)
  - Recipe registry (three-level lookup path: project > user > example)
  - Recipe executor (chrome-js/python/shell runtime)
  - Output handler (stdout/file/clipboard)
  - CLI command group (list/info/run/copy)

- [x] **AI-Understandable Field Design**
  - `description`: Functionality description
  - `use_cases`: Usage scenarios
  - `tags`: Category tags
  - `output_targets`: Output targets

- [x] **Recipe Storage Structure**
  - Code-resource separation
  - Example Recipes in `examples/`
  - Descriptive naming convention
  - Supporting metadata documentation

### Feature 005: Run Command System

- [x] **Topic-Based Task Management**
  - Run instance creation and discovery
  - RapidFuzz fuzzy matching (80% threshold)
  - Context persistence across sessions
  - Lifecycle: init → execute → log → archive

- [x] **Structured JSONL Logs**
  - 100% programmatically parseable
  - Complete operation history tracking
  - Error logging with stack traces
  - Auditable execution history

- [x] **Persistent Context Storage**
  - `projects/<run_id>/` directory structure
  - `logs/execution.jsonl` - Complete operation history
  - `screenshots/` - Timestamped images
  - `scripts/` - Validated working scripts
  - `outputs/` - Result files

- [x] **AI-Driven Task Execution**
  - `/frago.run` slash command integration
  - Automatic Run instance discovery
  - Recipe selection and orchestration

### Feature 006-007: Init Command System

- [x] **Dependency Check and Installation**
  - Parallel detection of Node.js and Claude Code
  - Smart installation of missing components
  - Installation verification

- [x] **Authentication Configuration**
  - Official Claude Code login
  - Custom API endpoints (DeepSeek, Aliyun, Kimi, MiniMax)
  - Mutually exclusive selection design

- [x] **Resource Installation**
  - Slash commands installed to `~/.claude/commands/`
  - User-level Recipe directory creation `~/.frago/recipes/`
  - Example Recipe copying

- [x] **Config Persistence**
  - `~/.frago/config.json` configuration file
  - Config status view `--show-config`
  - Reset functionality `--reset`

### Environment Variable Support (2025-11-26)

- [x] **Three-Level Config Priority**
  - CLI `--env` parameter (highest)
  - Project-level `.frago/.env`
  - User-level `~/.frago/.env`
  - System environment variables
  - Recipe defaults (lowest)

- [x] **Recipe Metadata Extension**
  - `env` field to declare required environment variables
  - `required`/`default`/`description` attributes
  - Validation and default value application at execution time

- [x] **Workflow Context Sharing**
  - `WorkflowContext` class for cross-Recipe sharing
  - Complete system environment inheritance
  - CLI `-e KEY=VALUE` override

---

## Pending Features 📝

### High Priority

- [ ] **Chrome-JS Parameter Injection**
  - Currently chrome-js runtime doesn't support parameter passing
  - Need to inject parameters via global variables or script wrapping
  - Support passing Recipe-declared `inputs` to JS scripts

- [ ] **Workflow Orchestration Enhancement**
  - Combine atomic Recipes into complex workflows
  - Conditional branching and loop support
  - Error handling and rollback mechanisms
  - Parallel execution support

- [ ] **Recipe Ecosystem Building**
  - Common platform Recipe library (YouTube, GitHub, X, Upwork, LinkedIn)
  - Recipe sharing and import mechanism
  - Community Recipe contribution process
  - Recipe performance benchmarking

### Medium Priority

- [ ] **Run System Enhancement**
  - Run templates for common workflows
  - Run metrics and analytics reports
  - Multi-format log export (CSV, Excel)
  - Run comparison and diff tools

- [ ] **Developer Experience**
  - Recipe testing framework
  - Recipe debugging tools
  - Better error messages
  - VS Code extension (syntax highlighting, intellisense)

- [ ] **Documentation and Examples**
  - Video tutorials for key workflows
  - Interactive documentation
  - More real-world Recipe examples
  - Best practices guide

### Low Priority

- [ ] **Advanced Features**
  - Recipe version management system
  - Multi-browser support (Firefox, Safari)
  - Distributed Recipe execution
  - Recipe marketplace
  - AI-powered Recipe optimization suggestions

- [ ] **Enterprise Features**
  - Team Recipe sharing
  - Execution audit logs
  - Access control
  - API call statistics

---

## Iteration Details

### 001: CDP Script Standardization
**Goal**: Unify websocat method, establish basic CDP operation patterns

**Achievements**:
- Standardized CDP script templates
- Unified websocat interface
- Basic operation command set

### 002: CDP Integration Refactor
**Goal**: Replace Shell scripts with native Python implementation, support proxy

**Achievements**:
- ~3,763 lines of Python CDP implementation
- Native WebSocket connection
- Proxy configuration support
- Intelligent retry mechanism
- CLI tools (Click framework)

### 003: Recipe Automation System Design
**Goal**: Design Recipe system, solidify high-frequency operations, accelerate AI reasoning

**Achievements**:
- Recipe system architecture design
- `/frago.recipe` command design
- Recipe creation and update workflow
- Recipe storage and naming conventions

### 004: Recipe Architecture Refactor
**Goal**: Metadata-driven + AI-First design

**Achievements**:
- Metadata parser (YAML frontmatter)
- Recipe registry (three-level lookup path)
- Recipe executor (multi-runtime)
- CLI command group (list/info/run)
- AI-understandable field design

### 005: Run Command System
**Goal**: Provide persistent context management for AI agents

**Achievements**:
- Topic-based Run instance creation and management
- RapidFuzz-based fuzzy matching auto-discovery
- JSONL structured logging (100% parseable)
- Persistent context storage
- `/frago.run` slash command integration
- Complete test coverage

**Key Features**:
- **Knowledge Accumulation**: Validated scripts persist across sessions
- **Auditability**: Complete operation history in JSONL format
- **Resumability**: AI can resume exploration days later
- **Token Efficiency**: 93.5% token savings vs. repeated exploration

### 006: Init Command
**Goal**: One-click environment initialization after user installation

**Achievements**:
- Parallel dependency check (Node.js, Claude Code)
- Smart installation of missing components
- Authentication configuration (official/custom endpoints)
- Config persistence

### 007: Init Resource Installation
**Goal**: Auto-install slash commands and example Recipes

**Achievements**:
- Slash commands installed to `~/.claude/commands/`
- User-level Recipe directory creation
- Example Recipe copying
- Resource status view

---

## Version History

### v0.1.0 (Released - 2025-11-26)

First official release, core infrastructure complete.

**Included Features**:
- Native CDP protocol layer (~3,763 lines Python, direct Chrome connection)
- Recipe metadata-driven architecture (chrome-js/python/shell runtime)
- Run command system (persistent task context, JSONL structured logs)
- Init command (dependency check, resource installation)
- Environment variable support (three-level config priority)
- Claude Code slash commands (/frago.run, /frago.recipe, /frago.exec)

### v0.2.0 (Released - 2025-11-26)

**Milestone**: Architecture Enhancement & Workspace Isolation

**Major Changes**:

1. **Recipe Directory-Based Structure**
   - Recipes changed from file-based to directory-based format
   - Each recipe is now a directory: `recipe_name/recipe.md + recipe.py + examples/`
   - Schemas and example data travel with recipes for shareability
   - Two recipe types clarified: Type A (external structures like DOM) vs Type B (self-defined structures like VideoScript)

2. **Single Run Mutex Mechanism**
   - System only allows one active Run context at a time
   - Added `uv run frago run release` command to release context
   - `set-context` rejects if another run is active (except for same run)
   - Design constraint to ensure focused work

3. **Workspace Isolation Principle**
   - All outputs must be in `projects/<run_id>/` directory
   - Recipes must specify `output_dir` parameter explicitly
   - Documented in `/frago.run` and `/frago.exec` commands

4. **Tool Priority Principle**
   - Priority: Recipe > frago commands > Claude Code tools
   - frago CDP commands are cross-agent compatible
   - Documented guidelines for search/browse operations

5. **Dependency Changes**
   - `pyperclip` moved from optional to base dependencies
   - Clipboard support now included by default

6. **Version Management**
   - `__version__` now reads from `pyproject.toml` via `importlib.metadata`
   - Single source of truth for version number

### v0.3.0 (Planned)

**Milestone**: Recipe System Enhancement

**Core Goals**:
- Chrome-JS parameter injection (solve current JS script parameter passing issue)
- Workflow orchestration enhancement (conditional branching, loops, error handling)
- Common platform Recipe library expansion (YouTube, GitHub, Upwork)

**Secondary Goals**:
- Run system template support
- Log export (CSV/Excel)

### v0.4.0 (Planned)

**Milestone**: Developer Experience

**Core Goals**:
- Recipe testing framework
- Recipe debugging tools
- VS Code extension (syntax highlighting, intellisense)

**Secondary Goals**:
- Performance optimization
- More documentation and examples

### v1.0.0 (Long-term Goal)

**Milestone**: Production Ready

**Core Goals**:
- Stable public API
- Comprehensive documentation and tutorials
- Community Recipe marketplace

**Secondary Goals**:
- Multi-browser support (Firefox, Safari)
- Enterprise features (team sharing, audit logs, access control)
