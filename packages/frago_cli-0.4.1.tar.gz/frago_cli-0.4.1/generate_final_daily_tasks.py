#!/usr/bin/env python3
"""
生成最终版Frago项目每日ONES任务
特点：每天有主题标题，围绕"Agent自动化核心模块"
"""

import subprocess
import json
from pathlib import Path
from datetime import datetime, timedelta
from collections import defaultdict
import re

# 每日主题配置
DAILY_THEMES = {
    "2025-11-25": "环境初始化与配置系统",
    "2025-11-26": "资源管理与分发机制",
    "2025-11-27": "浏览器自动化增强",
    "2025-11-28": "感知优化与集成能力",
    "2025-11-30": "文档体系与用户体验",
    "2025-12-01": "智能路由与打包系统"
}

def parse_conventional_commit(subject: str):
    """解析 Conventional Commits 格式"""
    pattern = r'^(\w+)(?:\(([^)]+)\))?: (.+)$'
    match = re.match(pattern, subject)
    if match:
        return {
            'type': match.group(1),
            'scope': match.group(2) or "",
            'description': match.group(3)
        }
    return {'type': 'unknown', 'scope': '', 'description': subject}

def get_commit_details(commit_hash: str):
    """获取commit详细信息"""
    msg_result = subprocess.run(
        ['git', 'show', '--format=%B', '--no-patch', commit_hash],
        capture_output=True, text=True, check=True
    )
    full_message = msg_result.stdout.strip()

    stat_result = subprocess.run(
        ['git', 'show', '--stat', '--format=', commit_hash],
        capture_output=True, text=True, check=True
    )

    lines_added = 0
    lines_deleted = 0
    files_count = 0

    summary_match = re.search(r'(\d+) files? changed', stat_result.stdout)
    if summary_match:
        files_count = int(summary_match.group(1))

    summary_match = re.search(r'(\d+) insertions?\(\+\)', stat_result.stdout)
    if summary_match:
        lines_added = int(summary_match.group(1))

    summary_match = re.search(r'(\d+) deletions?\(-\)', stat_result.stdout)
    if summary_match:
        lines_deleted = int(summary_match.group(1))

    return {
        'full_message': full_message,
        'lines_added': lines_added,
        'lines_deleted': lines_deleted,
        'files_count': files_count
    }

def estimate_hours(lines_added: int, lines_deleted: int) -> float:
    """估算工时"""
    total = lines_added + lines_deleted
    if total < 50: return 2.0
    elif total < 200: return 3.0
    elif total < 500: return 4.0
    else: return 6.0

def map_type_to_category(commit_type: str) -> str:
    """映射类型到中文分类"""
    mapping = {
        'feat': '新功能',
        'fix': '修复',
        'refactor': '重构',
        'docs': '文档',
        'test': '测试',
        'chore': '维护',
        'perf': '性能优化',
        'ci': 'CI/CD',
        'build': '构建'
    }
    return mapping.get(commit_type.lower(), '其他')

def get_commits_by_date(start_date: str, end_date: str):
    """获取提交并按日期分组"""
    cmd = ['git', 'log', '--pretty=format:%H|%ad|%s', '--date=short',
           '--no-merges', f'--since={start_date}', f'--until={end_date}']

    result = subprocess.run(cmd, capture_output=True, text=True, check=True)
    commits_by_date = defaultdict(list)

    for line in result.stdout.strip().split('\n'):
        if not line:
            continue
        parts = line.split('|')
        if len(parts) < 3:
            continue

        commit_hash = parts[0]
        commit_date = parts[1]
        subject = parts[2]

        parsed = parse_conventional_commit(subject)
        details = get_commit_details(commit_hash)

        commits_by_date[commit_date].append({
            'hash': commit_hash[:7],
            'subject': subject,
            'hours': estimate_hours(details['lines_added'], details['lines_deleted']),
            **parsed,
            **details
        })

    return commits_by_date

def select_tasks(commits, target_hours=8):
    """选择任务确保工时≥8小时"""
    if not commits:
        return [], 0.0

    sorted_commits = sorted(commits, key=lambda x: x['hours'], reverse=True)
    selected = []
    total_hours = 0.0

    for commit in sorted_commits[:3]:
        selected.append(commit)
        total_hours += commit['hours']
        if total_hours >= target_hours and len(selected) >= 1:
            break

    if selected and total_hours < target_hours:
        selected[-1]['hours'] += (target_hours - total_hours)
        total_hours = target_hours

    return selected, total_hours

def generate_final_tasks(commits_by_date, output_dir):
    """生成最终版任务文档"""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    start = datetime(2025, 11, 25)
    end = datetime(2025, 12, 1)

    current = start
    while current <= end:
        date_str = current.strftime('%Y-%m-%d')
        commits = commits_by_date.get(date_str, [])

        if not commits:
            print(f"⚠️  {date_str}: 无提交，跳过")
            current += timedelta(days=1)
            continue

        selected, total_hours = select_tasks(commits, 8)
        theme = DAILY_THEMES.get(date_str, "其他开发工作")

        filename = f"{date_str.replace('-', '')}_daily.md"
        filepath = output_dir / filename

        with open(filepath, 'w', encoding='utf-8') as f:
            # 标题和主题
            f.write(f"# Frago Agent自动化核心模块 - {theme}\n\n")
            f.write(f"> 工作日期: {date_str}\n\n")

            # 基本信息
            f.write("## 基本信息\n\n")
            f.write(f"- **标题**: Frago Agent自动化核心模块 - {theme}\n")
            f.write("- **项目**: [Scrum] Frago\n")
            f.write("- **负责人**: Jamey Tsai\n")
            f.write(f"- **预估工时**: {total_hours:.1f}小时\n")
            f.write("- **状态**: 已完成\n\n")

            # 工作概述
            f.write("## 工作概述\n\n")
            f.write(f"本日围绕Agent自动化核心模块的**{theme}**进行开发，")
            f.write(f"完成{len(selected)}项关键任务，共计{total_hours:.1f}小时。\n\n")

            # 工作内容
            f.write("## 工作内容\n\n")

            for idx, commit in enumerate(selected, 1):
                category = map_type_to_category(commit['type'])
                f.write(f"### {idx}. {commit['description']}\n\n")
                f.write(f"**分类**: {category}")
                if commit['scope']:
                    f.write(f" | **模块**: {commit['scope']}")
                f.write(f" | **工时**: {commit['hours']:.1f}h\n\n")

                # 提取详细描述
                message_lines = commit['full_message'].split('\n')
                body_lines = []
                for i, line in enumerate(message_lines[1:], 1):
                    if line.strip() and not line.startswith('Co-Authored-By:') and not line.startswith('🤖'):
                        body_lines.append(line.strip())
                    if len(body_lines) >= 5:
                        break

                if body_lines:
                    f.write("**详细说明**:\n")
                    for line in body_lines:
                        if line.startswith('- ') or line.startswith('* '):
                            f.write(f"{line}\n")
                        else:
                            f.write(f"- {line}\n")
                    f.write("\n")

                # 代码统计
                f.write("**代码变更**:\n")
                f.write(f"- 修改文件: {commit['files_count']}个\n")
                f.write(f"- 新增代码: {commit['lines_added']}行\n")
                f.write(f"- 删除代码: {commit['lines_deleted']}行\n")
                f.write(f"- Commit: `{commit['hash']}`\n\n")

            # 总结
            f.write("---\n\n")
            f.write("## 工作总结\n\n")
            f.write(f"**完成情况**: {len(selected)}项任务全部完成\n\n")
            f.write(f"**总工时**: {total_hours:.1f}小时\n\n")
            f.write(f"**核心成果**: 围绕{theme}，完善了Agent自动化核心模块的关键功能\n\n")
            f.write("🤖 Generated with Claude Code\n")

        print(f"✅ {date_str}: 【{theme}】 {len(selected)}个任务, {total_hours:.1f}h → {filename}")
        current += timedelta(days=1)

def main():
    commits_by_date = get_commits_by_date('2025-11-25', '2025-12-02')

    print("\n📊 提交统计:")
    for date in sorted(commits_by_date.keys()):
        theme = DAILY_THEMES.get(date, "其他")
        print(f"  {date} 【{theme}】: {len(commits_by_date[date])}个提交")
    print()

    output_dir = Path('frago_daily_tasks_final')
    generate_final_tasks(commits_by_date, output_dir)

    print(f"\n✅ 完成! 最终版任务生成到: {output_dir.absolute()}")
    print("📋 每天都有主题标题，围绕 'Agent自动化核心模块' 展开\n")

if __name__ == '__main__':
    main()
