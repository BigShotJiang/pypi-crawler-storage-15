Metrics = dict[str, float]
