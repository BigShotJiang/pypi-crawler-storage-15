# Contributing

Every contribution is welcome. If you want to contribute, please first discuss
the change you wish to make in an issue before making a change.
