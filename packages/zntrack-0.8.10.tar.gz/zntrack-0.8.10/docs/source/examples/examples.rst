Examples
========

.. toctree::
   :maxdepth: 1

   pack_box
   classifier_comparison
