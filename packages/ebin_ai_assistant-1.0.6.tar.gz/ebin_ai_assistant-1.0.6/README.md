# ebin_ai_assistant

A Python library that provides AI-powered utility functions using Google's Gemini API. This library simplifies common AI tasks such as getting responses, summarizing text, and formatting content.

## Features

-   **Get AI Response**: Send prompts to Google Gemini and get text responses.
-   **Summarize Text**: Automatically summarize long pieces of text.
-   **Format Text**: Intelligently clean and format messy text into professional, structured output.

## Installation

You can install `ebin_ai_assistant` directly from PyPI:

```bash
pip install ebin_ai_assistant
```

## Configuration

Before using the library, you need to configure it with your Google Gemini API key. You can get an API key from [Google AI Studio](https://makersuite.google.com/app/apikey).

```python
from ebin_ai_assistant import configure_api

# Replace with your actual API key
configure_api("YOUR_GOOGLE_GEMINI_API_KEY")
```

## Usage

### 1. Get a Response

Send a prompt to the AI and get a response.

```python
from ebin_ai_assistant import get_response

response = get_response("What is the capital of France?")
print(response)
# Output: The capital of France is Paris.
```

**Custom Model:**
By default, it uses `gemini-2.5-flash`. You can specify a different model if needed:

```python
response = get_response("Explain quantum physics", model_name="gemini-pro")
```

### 2. Summarize Text

Summarize a long block of text.

```python
from ebin_ai_assistant import summarize_text

long_text = """
Python is a high-level, general-purpose programming language. Its design philosophy emphasizes code readability with the use of significant indentation. Python is dynamically typed and garbage-collected. It supports multiple programming paradigms, including structured (particularly procedural), object-oriented and functional programming.
"""

summary = summarize_text(long_text)
print(summary)
# Output: Python is a readable, high-level programming language that supports multiple paradigms like object-oriented and functional programming.
```

### 3. Format Text

Clean up messy text and make it professional.

```python
from ebin_ai_assistant import format_response

messy_text = "  hey there...   i need this   to be fixed!!  "
formatted = format_response(messy_text)
print(formatted)
# Output: Hey there, I need this to be fixed.
```

## Requirements

-   Python 3.9+
-   `google-generativeai`

## License

MIT License
