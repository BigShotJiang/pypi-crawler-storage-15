##########
 humanize
##########

.. automodule:: anemoi.utils.humanize
   :members:
   :no-undoc-members:
   :show-inheritance:
