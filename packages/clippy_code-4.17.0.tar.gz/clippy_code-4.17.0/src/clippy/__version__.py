"""Version information for clippy-code."""

__version__ = "4.17.0"
