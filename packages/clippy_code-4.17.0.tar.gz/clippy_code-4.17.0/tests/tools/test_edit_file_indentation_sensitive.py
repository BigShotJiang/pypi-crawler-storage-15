"""Tests for edit_file tool - indentation and whitespace sensitivity."""
