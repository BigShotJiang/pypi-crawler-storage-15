"""Real-world edit_file tests based on actual LLM usage patterns and failures.

These tests simulate common patterns that LLMs generate when using edit_file,
including common mistakes and edge cases found in production logs.
"""
