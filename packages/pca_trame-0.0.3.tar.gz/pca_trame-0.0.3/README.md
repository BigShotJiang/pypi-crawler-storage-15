# Trame

## Concepts

- A **Trame** is a list of **Pieces**, which are themselves made of **Actors**
- The goal is to display information, *Piece by Piece*




## Dev / Install


### Install locally with dev dependencies

```bash
pip3 install -e ".[dev]"
```

**If you don't need dev dependencies, you can install locally without the `.[dev]` suffix :**

```bash
pip3 install -e .
```


### Try it out !

```bash
python -m tests.sandbox README.md
python -m tests.sandbox README.md --style tests/data/obvious-style.css
```

### Install locally

```bash
pip install -e .
```

### Run unit tests

```bash
python -m tests
```

### Sandbox

```bash
python -m tests.sandbox /path/to/markdown.md
python -m tests.sandbox /path/to/markdown.md --port=8000 --style=/path/to/style.css
```


