from markdown.extensions.tables import TableExtension

# TODO sel: améliorer le pattern sur l'encoding
ENCODING = "utf-8"

MD_EXTENSION = [
    # "toc",
    TableExtension(use_align_attribute=True),
    "fenced_code",
    # "abbr",
    # "attr_list",
]


BS4_HTML_PARSER = "html.parser"
