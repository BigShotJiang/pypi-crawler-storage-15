# Copyright (C) 2025 Embedl AB

"""vLLM integration for FlashHead."""

import importlib
import os
import sys

import torch
from embedl.models.flash_head import FlashHead, get_flash_head_parameters
from safetensors.torch import load_file
from torch import nn
from transformers import AutoConfig

from vllm import LLM as _LLM
from vllm.engine.arg_utils import AsyncEngineArgs
from vllm.v1.engine.async_llm import AsyncLLM as _AsyncLLM


def _patch_vllm_module(target_path, replacement_module):
    spec = importlib.util.find_spec(replacement_module)
    if spec is None:
        raise ImportError(
            f"Could not find replacement module: {replacement_module}"
        )

    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    sys.modules[target_path] = module


_patch_vllm_module(
    "vllm.v1.sample.sampler", "embedl.models.vllm.patching.sampler"
)
_patch_vllm_module(
    "vllm.model_executor.layers.logits_processor",
    "embedl.models.vllm.patching.logits_processor",
)


def _get_flash_head() -> nn.Module:
    path = "/tmp/embedl_flash_head.pt"
    if not os.path.exists(path):
        return None
    flash_head = torch.load(
        "/tmp/embedl_flash_head.pt", map_location="cuda", weights_only=False
    )
    return flash_head


def _set_flash_head(new_flash_head):
    path = "/tmp/embedl_flash_head.pt"
    if new_flash_head:
        torch.save(new_flash_head, path)
    else:
        if os.path.exists(path):
            os.remove(path)


def _load_flash_head_from_checkpoint(
    model_dir, dtype=torch.bfloat16, device="cuda"
):
    config = AutoConfig.from_pretrained(model_dir)

    if not hasattr(config, "flash_head_cache_dir"):
        return None

    cache_dir = config.flash_head_cache_dir
    if not os.path.isabs(cache_dir):
        cache_dir = os.path.join(model_dir, cache_dir)

    vocab_size = getattr(config, "vocab_size")
    hidden_size = getattr(config, "hidden_size")

    dummy_lm_head = torch.nn.Linear(hidden_size, vocab_size, bias=False)

    safetensor_path = os.path.join(model_dir, "model.safetensors")
    bin_path = os.path.join(model_dir, "pytorch_model.bin")

    if os.path.exists(safetensor_path):
        print(f"[Embedl] Loading weights from {safetensor_path}")
        sd = load_file(safetensor_path)
    elif os.path.exists(bin_path):
        print(f"[Embedl] Loading weights from {bin_path}")
        sd = torch.load(bin_path, map_location="cpu")
    else:
        raise FileNotFoundError(f"No model weights found in {model_dir}")

    weight_keys = [
        "lm_head.weight",
        "model.lm_head.weight",
        "transformer.lm_head.weight",
        "model.embed_tokens.weight",  # tied embedding
    ]

    found = None
    for k in weight_keys:
        if k in sd:
            found = k
            break

    if found is None:
        raise KeyError(
            f"Could not find lm_head or embedding weights. "
            f"Available keys include: {list(sd.keys())[:5]}..."
        )

    print(f"[Embedl] Using '{found}' as lm_head weights")

    dummy_lm_head.weight.data.copy_(sd[found])

    flash_head = FlashHead(
        dummy_lm_head,
        **get_flash_head_parameters(dummy_lm_head, cache_dir=cache_dir),
    )
    flash_head = flash_head.to(device=device, dtype=dtype)

    print(f"[Embedl] FlashHead initialized from cache {cache_dir}")
    return flash_head


class LLM(_LLM):
    """
    vLLM LLM with FlashHead preloaded.

    This class wraps vLLM's synchronous LLM and ensures FlashHead is loaded and
    registered before model initialization. It also defaults GPU memory
    utilization to 0.75 so FlashHead fits comfortably.

    :param model: The model id or local path.
    :param args: Positional args forwarded to vLLM LLM.
    :param kwargs: Keyword args forwarded to vLLM LLM (gpu_memory_utilization is
                   set to 0.75 to fit FlashHead unless explicitly provided).
    """

    def __init__(self, model: str, *args, **kwargs):
        flash_head = _load_flash_head_from_checkpoint(model)
        _set_flash_head(flash_head)

        # Default to 0.75 unless caller overrides
        kwargs.setdefault("gpu_memory_utilization", 0.75)

        super().__init__(model=model, *args, **kwargs)


class AsyncLLM(_AsyncLLM):
    """
    vLLM AsyncLLM with FlashHead preloaded.

    This class wraps vLLM's AsyncLLM and ensures FlashHead is loaded and
    registered before engine creation. It also defaults GPU memory utilization
    to 0.75 so FlashHead fits comfortably.

    vLLM async engines are created via `from_engine_args`, so this class
    implements `__new__` and returns an instance produced by vLLM.

    :param model: The model id or local path.
    :param kwargs: Keyword args forwarded into AsyncEngineArgs (gpu_memory_utilization
                   is set to 0.75 to fit FlashHead unless explicitly provided)
    """

    def __new__(cls, model: str, **kwargs):
        flash_head = _load_flash_head_from_checkpoint(model)
        _set_flash_head(flash_head)

        kwargs.setdefault("gpu_memory_utilization", 0.75)

        engine_args = AsyncEngineArgs(model=model, **kwargs)
        engine = _AsyncLLM.from_engine_args(engine_args)
        return engine
