# Copyright (C) 2025 Embedl AB

"""FlashHead - an efficient drop-in replacement for lm heads."""

import json
import os
from typing import Optional, Tuple

import torch
from torch import nn
from transformers import PreTrainedTokenizer


def _get_centroids(
    lm_head: nn.Linear,
    cache_dir: str,
) -> Optional[tuple[torch.Tensor, torch.Tensor]]:
    """Get the centroids from a cache directory."""
    os.makedirs(cache_dir, exist_ok=True)

    cache_file = os.path.join(cache_dir, "clustering_cache.pt")
    metadata_file = os.path.join(cache_dir, "clustering_config.json")

    original_shape = lm_head.weight.shape

    try:
        if os.path.exists(cache_file) and os.path.exists(metadata_file):
            with open(metadata_file) as f:
                metadata = json.load(f)
            if (
                metadata["vocab_size"] == original_shape[0]
                and metadata["hidden_size"] == original_shape[1]
            ):
                print("Loading precomputed FlashHead parameters.")
                cache_data = torch.load(cache_file)
                centroids = cache_data["centroids"].to(lm_head.weight.device)
                cluster_assignments = cache_data["cluster_assignments"].to(
                    lm_head.weight.device
                )
    except Exception as e:
        raise ValueError(f"Error loading cache: {e}") from e
    return centroids, cluster_assignments


def get_flash_head_parameters(
    lm_head: nn.Module,
    cache_dir: str,
    n_clusters: Optional[int] = None,
    verbose: bool = False,
) -> tuple[torch.Tensor]:
    """
    Get parameters for the FlashHead layer.

    :param lm_head:
        The language model head to replace.
    :param cache_dir:
        Directory to flash head artifacts.
    :param n_clusters:
        The number of clusters.
    :param verbose:
        Whether to be verbose with the clusterings.
    :return:
        The centroids and clustering assignments to use.
    """
    if n_clusters is None:
        n_clusters = int(lm_head.weight.shape[0] / 16)

    centroids, cluster_assignments = _get_centroids(
        lm_head=lm_head,
        cache_dir=cache_dir,
    )
    total_clusters = n_clusters
    original_shape = lm_head.weight.shape
    if verbose:
        for cluster_id in range(20):
            indices = torch.where(cluster_assignments == cluster_id)[0]
            print(f"\nCluster {cluster_id}:")
            print(
                f"Size: {len(indices)} tokens ({(len(indices)/original_shape[0])*100:.2f}% of vocab)"
            )
    cluster_to_vocab_maps = [
        torch.where(cluster_assignments == i)[0] for i in range(total_clusters)
    ]

    combined_centroids = torch.zeros(
        (original_shape[1], total_clusters),
        device=lm_head.weight.device,
        dtype=lm_head.weight.dtype,
    )
    centroids_reshaped = centroids.squeeze(0).squeeze(0)
    combined_centroids[:, :n_clusters] = centroids_reshaped
    max_len = max(m.shape[0] for m in cluster_to_vocab_maps)
    vocab_maps_tensor = torch.full(
        (len(cluster_to_vocab_maps), max_len), -1, device=lm_head.weight.device
    )
    for i, m in enumerate(cluster_to_vocab_maps):
        length = m.shape[0]
        vocab_maps_tensor[i, :length] = m
        vocab_maps_tensor[i, length:] = m[0]
    return {
        "centroids": combined_centroids,
        "vocab_maps_tensor": vocab_maps_tensor,
    }


class FlashHead(nn.Module):
    """
    Implementation of FlashHead.

    :param lm_head:
        The original classification head.
    :param centroids:
        The cluster centroids to use.
    :param vocab_maps_tensor:
        A mapping between cluster centroid index and token index.
    :param n_probes:
        Number of probes to use.
    """

    def __init__(
        self,
        lm_head: nn.Linear,
        centroids: torch.Tensor,
        vocab_maps_tensor: torch.Tensor,
        n_probes: Optional[int] = None,
    ):
        super().__init__()

        self.original_lm_head = lm_head
        self.original_shape = lm_head.weight.shape

        self.register_buffer("vocab_maps_tensor", vocab_maps_tensor)
        self.register_buffer("centroids", centroids.contiguous())

        if n_probes is None:
            n_probes = int(centroids.shape[1] / 16)
        self.n_probes = n_probes

        pre_norm = centroids / centroids.norm(dim=0, keepdim=True)
        pre_norm = pre_norm.t().contiguous()
        self.register_buffer("pre_normalized_centroids", pre_norm)

        self.cluster_linear = nn.Linear(
            pre_norm.shape[1],
            pre_norm.shape[0],
            bias=False,
        )
        self.cluster_linear.weight = nn.Parameter(pre_norm)

        self.register_buffer(
            "vocab_maps_lengths", (vocab_maps_tensor != -1).sum(dim=1)
        )
        self.register_buffer(
            "row_indices", torch.arange(vocab_maps_tensor.shape[1])[None, :]
        )
        self.register_buffer(
            "output_buffer", torch.zeros((1, 1), dtype=torch.int64)
        )

    def _get_cluster_probs(self, hidden_states, temperature=1.0):
        hidden_states_norm = hidden_states
        similarities = torch.nn.functional.linear(
            hidden_states_norm, self.centroids.t(), bias=None
        )
        probs = torch.softmax(similarities / temperature, dim=-1)
        return probs

    def _get_top_clusters(
        self,
        hidden_states: torch.Tensor,
        do_sample: bool = False,
        temperature: float = 1.0,
    ) -> torch.Tensor:
        if do_sample:
            probs = self._get_cluster_probs(
                hidden_states=hidden_states, temperature=temperature
            )
            bsz, seq, num_clusters = probs.shape
            probs_flat = probs.view(-1, num_clusters)
            sampled_indices = torch.multinomial(
                probs_flat, self.n_probes, replacement=False
            )
            top_clusters = sampled_indices.view(bsz, seq, self.n_probes)
        else:
            similarities = self.cluster_linear(hidden_states)
            _, top_clusters = torch.topk(similarities, k=self.n_probes, dim=-1)
        return top_clusters

    def _get_cluster_logits(
        self,
        hidden_states: torch.Tensor,
        top_clusters: torch.Tensor,
        use_identical_tiebreak: bool,
    ) -> tuple[torch.Tensor, Optional[torch.Tensor]]:
        if top_clusters.shape[1] > 1 or top_clusters.shape[0] > 1:
            raise NotImplementedError(
                "Use original lm head for seq-len or bs > 1"
            )

        cluster_indices = top_clusters[0, 0]
        maps = self.vocab_maps_tensor.index_select(0, cluster_indices)
        indices = maps.flatten()

        mapping = None
        if use_identical_tiebreak:
            sorted = indices.sort()
            indices = sorted.values
            mapping = sorted.indices
        result = self.original_lm_head.weight.index_select(0, indices)

        final_result = (
            torch.nn.functional.linear(hidden_states, result, bias=None),
            mapping,
        )
        return final_result

    def forward(self, _hidden_states: torch.Tensor) -> torch.Tensor:
        """Forward method that should not be used for FlashHead."""
        raise ValueError(
            """
            FlashHead generates outputs in an efficient way that differs
            from standard generation, please use the custom generation pipeline
            `embedl.models.flash_head.GenerationPipeline` for text generation."
            """
        )

    def get_next_token(
        self,
        hidden_states: torch.Tensor,
        do_sample: bool = False,
        temperature: float = 1.0,
        use_identical_tiebreak: bool = False,
    ) -> torch.Tensor:
        """
        Return the next token, given `hidden_states`.

        :param hidden_states:
            The output of the model body.
        :param do_sample:
            Whether to sample the next token according to probabilities,
            or simply return the most probable.
        :param temperature:
            The temperature to use in the softmax
            (both the softmax in cluster probabilities and for the
            softmax in token probabilities).
            Only relevant when `do_sample` is ``True``.
        :param use_identical_tiebreak:
            Whether to reorder the logits so that when two logits are the same,
            the new head will use the same tiebreak as the original.
        :returns:
            The next predicted token, represented as an index.
        """
        top_clusters = self._get_top_clusters(
            hidden_states,
            do_sample=do_sample,
            temperature=temperature,
        )
        cluster_logits, mapping = self._get_cluster_logits(
            hidden_states, top_clusters, use_identical_tiebreak
        )

        if do_sample:
            probs = (cluster_logits[:, -1, :] / temperature).softmax(dim=-1)
            cluster_token_idx = torch.multinomial(probs, num_samples=1)
        else:
            cluster_token_idx = cluster_logits[:, -1, :].argmax(
                dim=-1, keepdim=True
            )
            if use_identical_tiebreak:
                cluster_token_idx = mapping[cluster_token_idx]

        cap = self.row_indices.shape[1]
        cluster_index = cluster_token_idx // cap
        relative_pos = cluster_token_idx % cap
        vocab_index = self.vocab_maps_tensor[
            top_clusters[0, 0, cluster_index], relative_pos
        ]
        self.output_buffer[0][0] = vocab_index

        return self.output_buffer
