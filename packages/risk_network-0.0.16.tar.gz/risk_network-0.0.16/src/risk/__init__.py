"""
risk
~~~~

RISK: Regional Inference of Significant Kinships
"""

from .risk import RISK

__all__ = ["RISK"]
__version__ = "0.0.16"
