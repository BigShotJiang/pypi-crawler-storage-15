# Foundations of Light Theory

A beginner-friendly overview of the ideas behind **Light Theory Realm** – without requiring a physics background.

---

## 1. What is Light Theory?

Modern AI models and physical systems have something in common:

They don't just *compute* – they **move through a landscape of possibilities**.

- A neural network moves through a loss landscape as it trains.
- A physical system moves through a space of configurations as it evolves.
- A quantum state moves through a space of parameters as you tune a circuit.

**Light Theory** is a way to *measure the shape of that landscape*.

Instead of treating a model as "a function with parameters," Light Theory treats it as an **information surface** and asks:

- How *stretchy* is this surface if I change the parameters a bit?
- How much *twist* or "geometric memory" do I pick up if I move in a loop?
- Are there special regions where the landscape changes character (phases, thresholds, "magic spots")?

Light Theory Realm is the first implementation of this idea as a working, open-source engine.

---

## 2. The core idea: geometry of information

At the heart of Light Theory is a simple but powerful viewpoint:

> Any learning or physical system lives on a **curved information manifold**.  
> If you can measure that curvature, you learn something fundamental about the system.

Concretely, the engine focuses on two geometric quantities:

1. **Stretchiness (Metric / Fisher information)**  
   - "If I nudge the parameters a little, how much does the state change?"  
   - Large stretchiness = the system is very sensitive here.  
   - Small stretchiness = the system is stable / insensitive.

2. **Twist (Berry-like curvature)**  
   - "If I move around in a loop in parameter space and come back, does something remember the path?"  
   - Nonzero twist = the system has hidden structure or "topology."  
   - Zero twist = motion is more "flat" and forgetful.

Light Theory Realm computes both for you – from models, circuits, or toy physics setups – and packages them into one object: the **geometry of information**.

You don't need to know the formal definitions to use the library. What matters is:

- Stretchiness tells you about **sensitivity and stability**.
- Twist tells you about **hidden constraints, phases, and structure**.

---

## 3. How Light Theory represents systems

To make this concrete, the engine needs three ingredients:

### 3.1 A way to describe "directions" and "rotations"

Under the hood, Light Theory uses a mathematical toolbox called **Clifford algebra**. You can think of it as:

> A more powerful vector math that can handle rotations, reflections, and higher-dimensional "planes" in a unified way.

The project wraps this in a class called `CliffordEngine` so that as a user you get:

- A consistent way to represent vectors, planes, and rotations.
- Clean operations for combining and decomposing them.
- A JAX-compatible implementation so everything can be differentiated and accelerated.

You do **not** need to understand the underlying algebra to use it – but it matters that the engine is built on something robust enough to describe spacetime-like geometry.

### 3.2 A way to attach geometry to a model

Given a model or state that depends on parameters (for example, a neural network weight vector or a few angles in a quantum circuit), Light Theory:

1. Samples how the state changes as you nudge each parameter.
2. Uses those changes to build the **local metric** (stretchiness).
3. Extracts the **local twist** (curvature) from how phases change around loops.

All of this is exposed via a `CliffordQGT` object (QGT = "quantum geometric tensor"), but you can mentally file it under:

> The thing that takes my model and gives me a matrix of how it bends and twists.

### 3.3 A way to label structures (prime sequences)

One of the more unusual aspects of Light Theory is how it labels different "modes" of the system.

Instead of arbitrary IDs, it uses short **sequences of prime numbers** (called "prime plaquettes") as **barcodes** for particles or configurations.

You can think of each plaquette as:

- A small ordered list of primes, like `[2, 3, 5, 7]` or `[2, 17, 23, 7]`.
- A compact way to encode which "jumps" or "twists" you allow in a tiny discrete structure.
- A bridge between **number theory** and **geometry** – the same geometric engine can consume these barcodes and turn them into concrete geometric data.

This is where the project crosses into speculative territory – but the important point for a non-physicist reader is:

> Prime sequences become structured, reproducible inputs to the geometry engine – not magic constants.

---

## 4. What the engine can do today

Even without deep physics, the current engine already demonstrates interesting behaviour.

### 4.1 Standard Model toy (Pocket_U Lite)

Light Theory Realm builds a small **toy model** of particle masses:

- It encodes each of the 9 standard charged fermions (electron, muon, tau, and six quarks) with a different prime barcode.
- It runs those barcodes through the geometric engine.
- It produces a **predicted mass** for each particle.

Result:

- The predictions match known experimental values to around **2–3%** on average.
- A famous empirical relation between electron, muon, and tau masses (the **Koide relation**) emerges from the geometry rather than being imposed by hand.

For a non-physicist, you can read this as:

> Given only prime barcodes and geometry, the engine produces mass patterns that are surprisingly close to reality.

Whether that holds up under deeper scrutiny is a research question, but the fact that it happens at all is nontrivial and worth exploring.

### 4.2 Curvature landscapes

The engine can also produce **curvature landscapes**:

- For each prime barcode / configuration, it computes how curved the information manifold is near that point.
- It then compares different barcodes (e.g., ones corresponding to different quark flavours) and sees which ones live in more curved regions.

This gives you a visual and quantitative way to say things like:

- This mode lives in a much more curved part of the landscape than that one.
- Heavier particles tend to sit in more curved regions (a hypothesis you can test).

Again, you don't need field theory to appreciate this:

> It's like comparing how hilly or flat different neighbourhoods are on a map – but the map lives in information space.

---

## 5. A gentle architecture tour

Under the hood, the project is organised into four layers. You can think of them as:

1. **Algebra (CliffordEngine)**  
   - The low-level math engine for vectors, rotations, and multivectors.
   - JAX-based, fully differentiable.

2. **Geometry (CliffordQGT)**  
   - Wraps the algebra to compute stretchiness (metric) and twist (curvature) from a model or state.
   - This is where the "geometry of information" is actually extracted.

3. **Theory**  
   - Uses the geometric quantities to implement specific ideas:
     - Prime plaquette barcodes.
     - Mapping those barcodes to geometric configurations.
     - High-order operators that relate curvature and "mass-like" behaviour.
   - If you are a physicist or mathematically inclined, this is where the deeper structure lives (detailed in the companion paper **Light Mechanics**).

4. **Experiments**  
   - Concrete demos and tools:
     - The Pocket_U Lite mass table.
     - Koide relation analysis.
     - Curvature scanning and plotting.
   - This is what you touch from the CLI and quickstart examples.

This separation makes the project easier to reason about:

- You can treat it as **a library** (engine + geometry) plus **a set of experiments** (models that show what the engine can do).

---

## 6. Who this is for

Even in this early form, Light Theory Realm is designed to be useful for several audiences:

### 6.1 ML engineers and researchers

Use it to:

- Inspect the **geometry** of your model's parameter space.
- Compare how different architectures, optimizers, or regularisers change:
  - Stretchiness (sensitivity).
  - Twist (hidden structure / "topology").
- Experiment with geometry-aware training or diagnostics.

You can ignore the physics interpretation entirely and treat it as:

> A tool to see how my model's learning surface bends and twists.

### 6.2 Physicists and mathematical scientists

Use it to:

- Experiment with prime-labelled toy models of particle spectra.
- Connect information geometry with mass patterns and curvature.
- Test speculative ideas about how "geometry of information" might underpin known physics.

The conceptual and mathematical details for this audience live in **Light Mechanics**, not here.

### 6.3 Curious generalists / hiring managers

Even if you never run the code, this project demonstrates:

- A coherent, end-to-end build of a geometric engine.
- A bridge between theory and practice: from abstract geometry to concrete demos.
- The ability to ship tests, docs, and a CLI around an unusual but carefully argued idea.

---

## 7. How to explore it (without doing physics)

A few entry points that don't require a physics background:

1. **Read the Executive Summary**  
   - 1–2 pages explaining what the engine does in plain language.

2. **Skim the Quickstart**  
   - Run `light-realm sm-table` to see the Standard Model toy.
   - Run `light-realm koide 0.511 105.66 1776.86` to inspect the mass relation demo.

3. **Look at the examples**  
   - Short scripts that:
     - Build a simple state.
     - Feed it into the geometry engine.
     - Print or plot stretchiness and twist.

4. **Only then** – if you're curious –  
   - Dive into **Light Mechanics** for the full physics story.

---

## 8. Why this matters (even if some of it is speculative)

Light Theory is *not* claiming to have "solved physics." What it does claim is:

1. There is a **coherent way** to treat learning systems and physical systems through the same geometric lens.
2. There is **nontrivial evidence** that this lens can reproduce patterns in real data (like particle mass relations) without hand-tuning each case.
3. The approach is **testable**:
   - It makes concrete, falsifiable predictions (mass patterns, curvature–mass correlations, phase transitions in the information geometry).
   - It provides a software engine that others can run, modify, and challenge.

#### A note for physicists

If you know about holography (or AdS/CFT): Light Theory is built on that same assumption. The information manifold we describe is the **boundary**, and there's a higher-dimensional **bulk** (the 5D metric from Light Mechanics) dual to it. The boundary/bulk relationship works the same way it does in string theory – the bulk geometry encodes the dynamics of the boundary, and vice versa. Light Mechanics spells out this dictionary explicitly.

If you know general relativity or geometrodynamics: Light Theory is also a form of *geometrodynamics*, but for information. The metric and curvature are not living on a fixed background – they are themselves the fundamental dynamical objects. What we call "mass", "particles", and "structure" are knots and excitations in this information geometry. Light Mechanics develops this picture systematically.

---

For non-physicists, maybe the most important takeaway is this:

> Light Theory Realm isn't just an idea – it's a working geometric engine, with real code, real tests, and real experiments.  
> This document is your on-ramp into that world, without requiring you to be a physicist.

For the full technical story behind the equations and derivations, see the companion paper:

**→ Light Mechanics**
