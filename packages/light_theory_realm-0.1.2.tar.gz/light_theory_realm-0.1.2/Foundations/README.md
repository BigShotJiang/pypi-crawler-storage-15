# Foundations

A collection of papers exploring Light Theory from different angles and audiences.

## Papers in this collection

### 1. Foundations of Light Theory
**Audience:** ML engineers, curious non-physicists, hiring managers  
**Difficulty:** Beginner-friendly  
**Read time:** 15 minutes

A beginner-friendly overview of Light Theory Realm without physics jargon or equations. Explains the core ideas (information geometry, curvature, prime barcodes) in terms accessible to anyone with a software or math background.

→ [Read Foundations_of_Light_Theory.md](./Foundations_of_Light_Theory.md)

---

### 2. Light Mechanics
**Audience:** Physicists, mathematicians, theorists  
**Difficulty:** Advanced  
**Read time:** 45+ minutes

The full mathematical and theoretical story: Clifford algebra, quantum geometric tensor, Kaluza-Klein uplift, Reeb flow, and the postulates linking curvature to mass and information density.

→ [Read Light_Mechanics.md](./Light_Mechanics.md)

---

## How to use these papers

- **First time here?** Start with **Foundations of Light Theory**.
- **Want the technical details?** Proceed to **Light Mechanics** (when available).
- **Looking for a specific concept?** Each paper has a table of contents and clear section headers.
- **Need a 1-page summary?** See the **Executive Summary** in the root directory.

---

## Quick reference

| Document | For whom | Length | Focus |
|----------|---------|--------|-------|
| Foundations | Engineers, generalists | 10 mins | Ideas without equations |
| Light Mechanics | Physicists, theorists | 45 mins | Full mathematics & theory |
| Executive Summary | Decision makers | 2 pages | Business/impact framing |
| QUICKSTART | Builders | 10 mins | Code & CLI examples |
| API_REFERENCE | Developers | 20 mins | Function signatures & usage |

---

## Contributing

If you're extending Light Theory with new papers (e.g., applications, case studies, derivations), add them to this folder and link them here.

Keep each paper self-contained but link between them when relevant.
