# This file makes the 'geometry' directory a Python package.
