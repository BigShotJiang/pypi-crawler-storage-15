# Copyright (c) Microsoft. All rights reserved.

# This makes agent_framework a namespace package
__path__ = __import__("pkgutil").extend_path(__path__, __name__)
