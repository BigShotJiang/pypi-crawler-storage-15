# fastkafka2/core/partition_processor.py
import asyncio
import logging
from typing import Any, Awaitable, Callable, Optional

logger = logging.getLogger(__name__)


class PartitionProcessor:
    """Processor for a single partition - guarantees ordering"""
    
    def __init__(
        self,
        topic: str,
        partition: int,
    ):
        self.topic = topic
        self.partition = partition
        self._queue: asyncio.Queue = asyncio.Queue()
        self._processing = False
        self._task: Optional[asyncio.Task] = None
        
    async def process_message(
        self,
        msg_data: Any,
        headers: dict[str, str],
        key: Optional[str],
        offset: int,
        handlers: list[Callable],
        commit_callback: Optional[Callable[[], Awaitable[None]]] = None,
    ) -> None:
        """Add message to partition queue"""
        await self._queue.put((msg_data, headers, key, offset, handlers, commit_callback))
        
    async def start(self) -> None:
        """Start partition processing - sequentially"""
        if self._processing:
            logger.warning(
                "Processor for partition %s:%s is already running",
                self.topic, self.partition
            )
            return
        
        # Clean up old task if it exists and is done
        if self._task and self._task.done():
            try:
                self._task.result()  # Check for exceptions
            except Exception:
                pass
            self._task = None
            
        self._processing = True
        self._task = asyncio.create_task(self._process_loop())
        
    async def _process_loop(self) -> None:
        """Main processing loop - sequential"""
        while self._processing:
            try:
                # Use timeout to periodically check if processing should stop
                try:
                    msg_data, headers, key, offset, handlers, commit_callback = await asyncio.wait_for(
                        self._queue.get(), timeout=1.0
                    )
                except asyncio.TimeoutError:
                    # Timeout allows checking self._processing periodically
                    continue
                
                try:
                    for handler in handlers:
                        await handler(msg_data, headers, key, offset)
                    
                    if commit_callback:
                        await commit_callback()
                except Exception as e:
                    logger.exception(
                        "Error processing message in partition %s:%s: %s",
                        self.topic, self.partition, e
                    )
                finally:
                    self._queue.task_done()
            except asyncio.CancelledError:
                logger.debug(
                    "Process loop cancelled for partition %s:%s",
                    self.topic, self.partition
                )
                break
            except Exception as e:
                logger.exception(
                    "Unexpected error in process loop for partition %s:%s: %s",
                    self.topic, self.partition, e
                )
                # Don't call task_done() if we didn't get an item
                if not self._queue.empty():
                    try:
                        self._queue.task_done()
                    except ValueError:
                        pass
                
    async def stop(self) -> None:
        """Stop processing and wait for completion"""
        if not self._processing:
            logger.debug(
                "Processor for partition %s:%s is not running",
                self.topic, self.partition
            )
            return
            
        self._processing = False
        
        if self._task:
            # Wait for queue to be processed with timeout
            try:
                await asyncio.wait_for(self._queue.join(), timeout=30.0)
            except asyncio.TimeoutError:
                logger.warning(
                    "Timeout waiting for queue to empty in partition %s:%s",
                    self.topic, self.partition
                )
            
            # Cancel the task
            if not self._task.done():
                self._task.cancel()
                try:
                    await self._task
                except asyncio.CancelledError:
                    pass
            else:
                # Task already done, check for exceptions
                try:
                    self._task.result()
                except Exception as e:
                    logger.exception(
                        "Task for partition %s:%s completed with error: %s",
                        self.topic, self.partition, e
                    )
            
            self._task = None
                

