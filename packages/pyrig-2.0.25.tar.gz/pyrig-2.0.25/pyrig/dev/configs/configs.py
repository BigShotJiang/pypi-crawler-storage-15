"""Configs for pyrig.

All subclasses of ConfigFile in the configs package are automatically called.
"""
