from .aipy import *

if __name__ == "__main__":
    print("aipy is working")