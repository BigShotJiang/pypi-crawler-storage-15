The Hypothesis python readme has moved to [the main readme](../README.md)!
