"""Combined invocation TypedDicts for direct SDK unpacking.

These TypedDicts combine message payloads with model parameters,
enabling direct unpacking into provider SDK calls:

    response = await anthropic.messages.create(**session.to_anthropic_invocation())
"""

from typing import Sequence, TypedDict

from moxn_types.type_aliases.anthropic import (
    AnthropicContentBlockParam,
    AnthropicSystemContentBlockParam,
)
from moxn_types.type_aliases.google import GoogleContent, GoogleFile
from moxn_types.type_aliases.openai_chat import OpenAIChatContentBlock
from moxn_types.type_aliases.openai_responses import OpenAIResponsesInputItemParam


class AnthropicInvocationParam(TypedDict, total=False):
    """Complete Anthropic payload for `anthropic.messages.create(**payload)`.

    Combines message content with model parameters for direct SDK unpacking.
    """

    # Message fields (from AnthropicMessagesParam)
    system: str | list[AnthropicSystemContentBlockParam]
    messages: list[AnthropicContentBlockParam]

    # Model parameters
    model: str
    max_tokens: int
    temperature: float
    top_p: float


class OpenAIChatInvocationParam(TypedDict, total=False):
    """Complete OpenAI Chat payload for `openai.chat.completions.create(**payload)`.

    Combines message content with model parameters for direct SDK unpacking.
    """

    # Message fields (from OpenAIChatMessagesParam)
    messages: list[OpenAIChatContentBlock]

    # Model parameters
    model: str
    max_tokens: int
    temperature: float
    top_p: float


class OpenAIResponsesInvocationParam(TypedDict, total=False):
    """Complete OpenAI Responses API payload for `openai.responses.create(**payload)`.

    Combines input items with model parameters for direct SDK unpacking.
    """

    # Message fields (from OpenAIResponsesMessagesParam)
    input: list[OpenAIResponsesInputItemParam]
    instructions: str

    # Model parameters
    model: str
    max_tokens: int
    temperature: float
    top_p: float


class GoogleInvocationParam(TypedDict, total=False):
    """Complete Google Gemini/Vertex payload for `generate_content(**payload)`.

    Combines content with model parameters for direct SDK unpacking.
    Note: Google uses `max_output_tokens` instead of `max_tokens`.
    """

    # Message fields (from GoogleMessagesParam)
    system_instruction: str
    content: Sequence[GoogleContent | GoogleFile]

    # Model parameters (note: Google uses max_output_tokens)
    model: str
    max_output_tokens: int
    temperature: float
    top_p: float


# Union type for any provider invocation payload
ProviderInvocationPayload = (
    AnthropicInvocationParam
    | OpenAIChatInvocationParam
    | OpenAIResponsesInvocationParam
    | GoogleInvocationParam
)
