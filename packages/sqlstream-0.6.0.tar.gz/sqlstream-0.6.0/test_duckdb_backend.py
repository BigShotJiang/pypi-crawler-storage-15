"""
Test DuckDB backend with complex SQL
"""

from sqlstream import query

# Create test with DuckDB backend supporting window functions
def test_duckdb_window_function():
    """Test complex SQL with window functions using DuckDB backend"""

    result = query("employees.csv").sql("""
        SELECT
            name,
            department,
            salary,
            ROW_NUMBER() OVER (PARTITION BY department ORDER BY salary DESC) as dept_rank,
            AVG(salary) OVER (PARTITION BY department) as dept_avg_salary
        FROM 'employees.csv'
        WHERE salary > 50000
        ORDER BY department, dept_rank
    """, backend="duckdb")

    results = list(result)
    print(f"Found {len(results)} results")
    for row in results[:5]:
        print(row)


def test_duckdb_cte():
    """Test Common Table Expressions (CTEs) with DuckDB backend"""

    result = query("employees.csv").sql("""
        WITH high_earners AS (
            SELECT * FROM 'employees.csv'
            WHERE salary > 100000
        ),
        dept_stats AS (
            SELECT
                department,
                AVG(salary) as avg_salary,
                COUNT(*) as count
            FROM high_earners
            GROUP BY department
        )
        SELECT * FROM dept_stats
        WHERE count > 5
        ORDER BY avg_salary DESC
    """, backend="duckdb")

    results = list(result)
    print(f"Found {len(results)} departments")
    for row in results:
        print(row)


if __name__ == "__main__":
    print("Testing DuckDB backend...")
    print("\n=== Test 1: Window Functions ===")
    try:
        test_duckdb_window_function()
    except Exception as e:
        print(f"Error: {e}")

    print("\n=== Test 2: CTEs ===")
    try:
        test_duckdb_cte()
    except Exception as e:
        print(f"Error: {e}")
