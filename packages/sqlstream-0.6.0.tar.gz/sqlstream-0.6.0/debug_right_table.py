#!/usr/bin/env python3
"""Test the edge case with 'right' table name"""

import sys
import tempfile
from pathlib import Path

sys.path.insert(0, '/home/fiftyfive/Downloads/SQLstream')

from sqlstream.core.query import QueryResult
from sqlstream.core.duckdb_executor import DuckDBExecutor

tmpdir = Path(tempfile.mkdtemp())
left = tmpdir / "left.csv"
right = tmpdir / "right.csv"

left.write_text("id,name\n1,Alice\n")
right.write_text("user_id,amount\n1,100\n")

sql = f"""
    SELECT *
    FROM {left}
    INNER JOIN {right} ON id = user_id
"""

print("="*80)
print("SQL:")
print(sql)

# Mock setup to test discover_sources
class MockReader:
    pass

qr = QueryResult(
    ast=None,
    reader=MockReader(),
    reader_factory=lambda x: MockReader(),
    source=str(left),
    backend="duckdb",
    raw_sql=sql
)

sources = qr._discover_sources()
print("\n" + "="*80)
print("Discovered sources:")
for table_name, file_path in sources.items():
    print(f"  {table_name:20s} -> {file_path}")

executor = DuckDBExecutor()
transformed = executor._replace_sources_in_sql(sql, sources)

print("\n" + "="*80)
print("Transformed SQL:")
print(transformed)
