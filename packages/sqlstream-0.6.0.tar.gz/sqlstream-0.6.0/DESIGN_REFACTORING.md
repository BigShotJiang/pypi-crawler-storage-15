# SQLStream Design Refactoring Proposal

## Issues Identified

### 1. ✅ FIXED: Source Discovery Not Extracting All Sources
**Problem**: The `_discover_sources()` method wasn't capturing all sources from complex SQL queries with URL fragments.

**Solution**: 
- Updated regex pattern to capture full quoted strings including fragments
- Added proper fragment parsing using `parse_source_fragment()`
- Added logic to generate unique table names based on fragment indices
- Example: `complex.html#html:3` → table name `complex_3`

**Status**: ✅ **FIXED** - All 5 sources now correctly discovered from your complex query

### 2. ✅ FIXED: SQL Not Using Registered Table Names  
**Problem**: DuckDB was receiving SQL with original file paths instead of registered table names.

**Solution**:
- Added `_replace_sources_in_sql()` method in `DuckDBExecutor`
- Replaces file paths with registered table names before execution
- Example: `FROM 'https://.../complex.html#html:3'` → `FROM complex_3`

**Status**: ✅ **FIXED** - SQL transformation working perfectly

### 3. 🔄 TODO: Remove Required Source Parameter from query()
**Current Design**:
```python
query("data.csv").sql("SELECT * FROM data")
```

**Proposed Design**:
```python
# Option A: Pure SQL-based (like DuckDB CLI)
query("SELECT * FROM 'data.csv' WHERE age > 25")

# Option B: Separate inline mode (current QueryInline class)
query_inline().sql("SELECT * FROM 'data.csv'")

# Option C: Make source optional
query().sql("SELECT * FROM 'data.csv'")  # no source
query("data.csv").sql("SELECT *")  # with source (backward compat)
```

**Recommendation**: Option C - Makes source optional while maintaining backward compatibility

### 4. 🔄 TODO: Smart Backend Selection
**Current**: User must choose backend explicitly or it auto-selects

**Proposed**: Automatically determine if custom parser can handle the query:

```python
def _can_use_custom_parser(sql: str) -> bool:
    """
    Determine if SQL can be handled by custom parser
    
    Returns True if:
    - No advanced features (CTEs, window functions, subqueries)
    - Only basic SELECT, WHERE, JOIN, GROUP BY, ORDER BY, LIMIT
    
    Returns False if needs DuckDB:
    - Contains: WITH, OVER, PARTITION BY, HAVING, UNION, etc.
    - Complex expressions or nested queries
    """
    # Check for advanced SQL features
    advanced_keywords = [
        'WITH', 'OVER', 'PARTITION BY', 'WINDOW',
        'HAVING', 'UNION', 'INTERSECT', 'EXCEPT',
        'CASE WHEN', 'CAST', 'EXTRACT'
    ]
    
    sql_upper = sql.upper()
    for keyword in advanced_keywords:
        if keyword in sql_upper:
            return False  # Needs DuckDB
    
    # Check for subqueries
    if '(' in sql and 'SELECT' in sql.split('(', 1)[1].upper():
        return False  # Has subquery
    
    return True  # Can use custom parser
```

**Backend Selection Logic**:
```
if backend == "auto":
    if _can_use_custom_parser(sql):
        if PANDAS_AVAILABLE:
            use PandasExecutor (fastest for simple queries)
        else:
            use Executor (pure Python)
    else:
        if DUCKDB_AVAILABLE:
            use DuckDBExecutor (full SQL support)
        else:
            raise Error("Query requires DuckDB but not installed")
```

## Summary

✅ **Completed**:
1. Fixed source discovery to handle URL fragments properly
2. Fixed SQL transformation to use table names

🔄 **Remaining** (if you want to proceed):
1. Make `query()` function work without source parameter
2. Add smart backend selection based on SQL complexity

Would you like me to proceed with items 3 and 4?
