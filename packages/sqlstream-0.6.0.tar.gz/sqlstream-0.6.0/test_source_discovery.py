#!/usr/bin/env python3
"""
Test script to verify the source discovery and SQL replacement functionality
"""

from sqlstream.core.query import QueryResult
from sqlstream.core.fragment_parser import parse_source_fragment


# Test SQL with multiple JOINs using URL fragments
test_sql = """
SELECT
    o.order_id,
    o.order_date,
    o.status,
    c.first_name || ' ' || c.last_name AS customer_name,
    c.email,
    c.loyalty_tier,
    p.product_name,
    oi.quantity,
    oi.unit_price,
    oi.discount_percent,
    (oi.quantity * oi.unit_price * (1 - oi.discount_percent/100)) AS line_total,
    cat.category_name
FROM 'https://github.com/subhayu99/sqlstream/raw/refs/heads/main/examples/complex.html#html:3' o
JOIN 'https://github.com/subhayu99/sqlstream/raw/refs/heads/main/examples/complex.html#html:0' c ON o.customer_id = c.customer_id
JOIN 'https://github.com/subhayu99/sqlstream/raw/refs/heads/main/examples/complex.html#html:4' oi ON o.order_id = oi.order_id
JOIN 'https://github.com/subhayu99/sqlstream/raw/refs/heads/main/examples/complex.html#html:2' p ON oi.product_id = p.product_id
JOIN 'https://github.com/subhayu99/sqlstream/raw/refs/heads/main/examples/complex.html#html:1' cat ON p.category_id = cat.category_id
ORDER BY o.order_date DESC, o.order_id
"""


def test_discover_sources():
    """Test the _discover_sources method"""
    print("=" * 80)
    print("Testing _discover_sources()")
    print("=" * 80)

    # Create a mock QueryResult to test discover_sources
    # We'll need to set up the necessary attributes
    class MockReader:
        pass

    # Create instance with minimal setup
    qr = QueryResult(
        ast=None,
        reader=MockReader(),
        reader_factory=lambda x: MockReader(),
        source="",
        backend="duckdb",
        raw_sql=test_sql
    )

    # Call _discover_sources
    sources = qr._discover_sources()

    print(f"\nDiscovered {len(sources)} sources:")
    print("-" * 80)
    for table_name, file_path in sources.items():
        print(f"  Table: {table_name:20s} -> {file_path}")

    return sources


def test_sql_replacement():
    """Test SQL replacement with table names"""
    print("\n" + "=" * 80)
    print("Testing SQL Replacement")
    print("=" * 80)

    from sqlstream.core.duckdb_executor import DuckDBExecutor, is_duckdb_available

    if not is_duckdb_available():
        print("\n⚠️  DuckDB not available - install with: pip install duckdb")
        return

    executor = DuckDBExecutor()

    # Get sources from previous test
    class MockReader:
        pass

    qr = QueryResult(
        ast=None,
        reader=MockReader(),
        reader_factory=lambda x: MockReader(),
        source="",
        backend="duckdb",
        raw_sql=test_sql
    )

    sources = qr._discover_sources()

    # Test SQL replacement
    transformed_sql = executor._replace_sources_in_sql(test_sql, sources)

    print("\nOriginal SQL:")
    print("-" * 80)
    print(test_sql)

    print("\nTransformed SQL:")
    print("-" * 80)
    print(transformed_sql)

    print("\nVerification:")
    print("-" * 80)
    for table_name, file_path in sources.items():
        if table_name in transformed_sql:
            print(f"  ✓ Table '{table_name}' is in transformed SQL")
        else:
            print(f"  ✗ Table '{table_name}' is NOT in transformed SQL")

        if file_path in transformed_sql:
            print(f"  ✗ File path '{file_path[:50]}...' still in transformed SQL!")
        else:
            print(f"  ✓ File path replaced successfully")


if __name__ == "__main__":
    sources = test_discover_sources()
    test_sql_replacement()

    print("\n" + "=" * 80)
    print("Test completed!")
    print("=" * 80)
