# Test Coverage Gaps Analysis

**Current Overall Coverage: 32%** (377 tests collected, updated after optimizer work)

## Critical Coverage Issues

### 1. **CSV Reader - 17% Coverage**
Missing tests for:
- ✗ Delimiter auto-detection (tab, pipe, semicolon)
- ✗ Encoding handling (UTF-8, Latin-1, Windows-1252, etc.)
- ✗ Chunked/streaming reading
- ✗ Malformed CSV handling (missing columns, extra columns)
- ✗ Empty files
- ✗ Files with only headers
- ✗ Special characters and quoting
- ✗ Escape sequences
- ✗ Large file handling (memory efficiency)
- ✗ Type inference edge cases (mixed types, nulls)
- ✗ Comment lines (if supported)

**Impact**: CSV is the primary data source - low coverage is risky

---

### 2. **Parquet Reader - 13% Coverage**
Missing tests for:
- ✗ Arrow type to SQLStream type mapping (`_arrow_type_to_dtype`)
- ✗ All Arrow data types (timestamp, date, decimal, list, struct)
- ✗ Schema reading and inference
- ✗ Partitioned parquet files
- ✗ Column selection optimization
- ✗ Row group filtering
- ✗ Compression codecs (snappy, gzip, zstd)
- ✗ Nested data structures
- ✗ Large file handling
- ✗ Error handling (corrupted files, schema mismatches)

**Impact**: Parquet is critical for performance - needs thorough testing

---

### 3. **HTTP Reader - 32% Coverage**
Missing tests for:
- ✗ Caching behavior (disk cache, TTL)
- ✗ Cache hit/miss scenarios
- ✗ SSL/HTTPS handling
- ✗ HTTP redirects (301, 302, 307, 308)
- ✗ Timeouts and retries
- ✗ Custom headers
- ✗ Authentication (Basic, Bearer)
- ✗ Streaming vs full download
- ✗ Error handling (404, 500, timeout)
- ✗ Content-Type detection
- ✗ Encoding detection
- ✗ Large file streaming

**Impact**: HTTP sources are common - needs robust error handling

---

### 4. **SQL Parser - 13% Coverage**
Missing tests for:
- ✗ Complex expressions (arithmetic, logical)
- ✗ Operator precedence
- ✗ String literals (single quotes, escaping)
- ✗ Numeric literals (integers, floats, scientific notation)
- ✗ NULL handling
- ✗ Aliases with AS keyword
- ✗ Table aliases in JOINs
- ✗ Column qualifiers (table.column)
- ✗ Multiple tables in FROM
- ✗ Nested expressions
- ✗ Function calls with multiple arguments
- ✗ CASE expressions (when implemented)
- ✗ Subqueries (when implemented)
- ✗ Error messages for invalid SQL
- ✗ Edge cases (trailing semicolon, extra whitespace, comments)

**Impact**: Parser is foundation - bugs here affect everything

---

### 5. **Join Operator - 14% Coverage**
Missing tests for:
- ✗ LEFT JOIN (mentioned in docs but not tested)
- ✗ RIGHT JOIN (mentioned in docs but not tested)
- ✗ FULL OUTER JOIN
- ✗ CROSS JOIN
- ✗ Semi/Anti joins
- ✗ Multiple join conditions (AND)
- ✗ Join with NULL values (NULL = NULL behavior)
- ✗ Join on different types
- ✗ Large dataset joins (performance)
- ✗ Self-joins
- ✗ Multiple joins in one query
- ✗ Join with WHERE clause
- ✗ Join with GROUP BY

**Impact**: JOINs are documented as supported but minimally tested

---

### 6. **OrderBy Operator - 29% Coverage**
Missing tests for:
- ✗ Multiple columns sorting
- ✗ DESC ordering
- ✗ Mixed ASC/DESC (e.g., `ORDER BY a ASC, b DESC`)
- ✗ NULL handling (NULLS FIRST/LAST if supported)
- ✗ Sorting with different data types
- ✗ Sorting with expressions
- ✗ Sorting large datasets
- ✗ Stability of sort
- ✗ ORDER BY with LIMIT

**Impact**: Basic feature needs comprehensive testing

---

### 7. **Project Operator - 29% Coverage**
Missing tests for:
- ✗ Expression evaluation
- ✗ Column aliasing
- ✗ Computed columns
- ✗ Type conversions in projections
- ✗ Aggregate projections
- ✗ Complex expressions

---

### 8. **Limit Operator - 38% Coverage**
Missing tests for:
- ✗ LIMIT 0
- ✗ LIMIT larger than dataset
- ✗ LIMIT with streaming
- ✗ LIMIT with different backends

---

### 9. **Aggregates - 33% Coverage**
Missing tests for:
- ✗ COUNT(DISTINCT column)
- ✗ Multiple aggregates in one query
- ✗ Aggregates on different types (string, date)
- ✗ NULL handling in aggregates
- ✗ Empty groups
- ✗ Aggregates without GROUP BY
- ✗ GROUP BY with multiple columns
- ✗ GROUP BY with expressions
- ✗ HAVING clause (when implemented)
- ✗ Window functions (when implemented)

**Impact**: Aggregations are complex - needs thorough testing

---

### 10. **Interactive Shell - Minimal Coverage**
The shell tests in test_shell_components.py test basic logic, but missing:

**Auto-completion (SQLSuggester)**:
- ✗ Keyword completion edge cases
- ✗ Table name completion from multiple files
- ✗ Column completion from multiple tables
- ✗ Completion with partial matches
- ✗ Case sensitivity
- ✗ Completion priority (keywords vs tables vs columns)

**Modal Dialogs**:
- ✗ FilterDialog interaction
- ✗ ExplainDialog rendering
- ✗ SaveFileDialog validation
- ✗ OpenFileDialog navigation
- ✗ Dialog cancellation
- ✗ Dialog input validation

**File Operations**:
- ✗ File browser navigation
- ✗ Directory traversal
- ✗ File filtering by extension
- ✗ Permission handling

**Query History**:
- ✗ History persistence
- ✗ Multiline query preservation (delimiter: \n===\n)
- ✗ History navigation edge cases
- ✗ History size limits (100 queries)
- ✗ Corrupted history file handling

**Export Functionality**:
- ✗ CSV export with special characters
- ✗ JSON export formatting
- ✗ Parquet export (with/without pyarrow)
- ✗ Export error handling
- ✗ Custom filename validation

**Display/UI**:
- ✗ Pagination boundary cases (page 1, last page)
- ✗ Sorting stability
- ✗ Filter with no matches
- ✗ Large result sets (1M+ rows)
- ✗ Column width calculation
- ✗ Unicode handling
- ✗ Error message display

**Schema Browser**:
- ✗ Async schema loading
- ✗ Multiple file schemas
- ✗ Schema load errors
- ✗ Schema updates

**Explain Plan**:
- ✗ Plan formatting
- ✗ Optimization display
- ✗ Complex query plans

**Impact**: Shell is user-facing - bugs are immediately visible

---

### 11. **Formatters - Limited Coverage**
Missing tests for:
- ✗ Table formatter with very long text
- ✗ Table formatter with special characters
- ✗ Table formatter with Unicode
- ✗ Table formatter with empty results
- ✗ JSON formatter pretty printing
- ✗ JSON formatter with date/time types
- ✗ CSV formatter with quoting
- ✗ CSV formatter with special characters
- ✗ All formatters with NULL values

**New formatters needing tests:**
- ✗ **Markdown formatter** (new in `sqlstream/cli/formatters/markdown.py`)
  - ✗ GFM table generation
  - ✗ Alignment options (left, center, right)
  - ✗ Pipe character escaping
  - ✗ NULL value handling
  - ✗ Footer with row count
  - ✗ Special characters and Unicode
  - ✗ Empty results
  - ✗ Very wide tables

---

### 11a. **HTML Reader - New Feature**
**Status**: ⚠️ **NEEDS TESTS**

Newly created `HTMLReader` using pandas `read_html()`. Missing tests for:
- ✗ Basic table extraction
- ✗ Multiple tables in HTML (table parameter)
- ✗ Table selection by index (positive/negative)
- ✗ Table selection with `match` parameter
- ✗ Empty HTML (no tables)
- ✗ Malformed HTML
- ✗ Tables with rowspan/colspan
- ✗ Tables with nested elements
- ✗ Unicode in table cells
- ✗ Very large HTML tables
- ✗ Filter pushdown
- ✗ Column selection
- ✗ Schema inference from HTML tables
- ✗ `list_tables()` functionality
- ✗ Error messages for out-of-range table index
- ✗ Integration with query engine
- ✗ URL fragment parsing (`page.html#html:1`)

**Impact**: New user-facing feature - needs comprehensive testing

---

### 11b. **Markdown Reader - New Feature**
**Status**: ⚠️ **NEEDS TESTS**

Newly created `MarkdownReader` with custom GFM parser. Missing tests for:
- ✗ Basic table parsing (pipe tables)
- ✗ Header and separator row parsing
- ✗ Multiple tables in markdown file
- ✗ Table selection by index (positive/negative)
- ✗ Empty markdown (no tables)
- ✗ Malformed tables (missing columns)
- ✗ Alignment indicators (:---,  :---:, ---:)
- ✗ Escaped pipe characters (\|)
- ✗ NULL value recognition (null, NULL, N/A, -)
- ✗ Type inference (int, float, bool, string)
- ✗ Mixed type columns
- ✗ Very long table rows
- ✗ Unicode in cells
- ✗ Filter pushdown
- ✗ Column selection
- ✗ Schema inference accuracy
- ✗ `list_tables()` functionality
- ✗ Error messages for invalid tables
- ✗ Integration with query engine
- ✗ URL fragment parsing (`README.md#markdown:0`)

**Impact**: New parser implementation - needs thorough testing

---

### 11c. **URL Fragment Parser - New Feature**
**Status**: ⚠️ **BASIC TESTS EXIST**

Created `fragment_parser.py` module. Has basic tests in `test_fragment_parser.py` but needs:
- ✅ Basic parsing (format, table, both)
- ✅ Negative table indices
- ✅ Error cases (invalid format, invalid table)
- ✗ Edge cases:
  - ✗ Empty fragments (#)
  - ✗ Multiple # in URL handling
  - ✗ Query strings with fragments
  - ✗ Very long format/table values
  - ✗ Whitespace handling
- ✗ Integration tests:
  - ✗ Fragment in FROM clause
  - ✗ Fragment with JOIN
  - ✗ Fragment with HTTP URLs
  - ✗ Fragment parsing in pandas executor
  - ✗ Fragment parsing in python executor
- ✗ `build_source_fragment()` comprehensive tests

**Impact**: Core new feature - needs robust testing

---

### 11d. **HTTPReader Format Detection - Enhanced**
**Status**: ⚠️ **PARTIALLY TESTED**

Enhanced `HTTPReader` with explicit `format` parameter and better detection. Missing tests for:
- ✗ Explicit format parameter (`format="csv"`)
- ✗ Format parameter with table parameter
- ✗ Content-Type header detection (when implemented)
- ✗ Detection priority: explicit > extension > content-type > magic bytes
- ✗ Format detection for HTML
- ✗ Format detection for Markdown
- ✗ Pastebin-style URLs (no extension) with format parameter
- ✗ Format mismatch (extension says .csv but content is HTML)
- ✗ Unknown format fallback to CSV

**Impact**: Enhancement to existing feature - needs verification

---

### 12. **Type System - Needs Expansion**
Missing tests for:
- ✗ Type coercion rules
- ✗ Type validation
- ✗ DateTime parsing (multiple formats)
- ✗ Date parsing
- ✗ NULL type handling
- ✗ Type inference from mixed data
- ✗ Type errors and recovery
- ✗ Type conversion edge cases

---

### 13. **Pandas Backend - Minimal Tests**
Missing tests for:
- ✗ Large dataset handling
- ✗ Memory efficiency comparison
- ✗ Type mapping correctness
- ✗ Performance benchmarks
- ✗ Error handling
- ✗ Feature parity with Python backend

---

### 14. **S3 Support - Basic Tests Only**
Missing tests for:
- ✗ Authentication methods (env vars, config file, IAM)
- ✗ Bucket access permissions
- ✗ Different regions
- ✗ Partitioned files (Hive-style, custom)
- ✗ Error handling (access denied, not found)
- ✗ Performance with large files
- ✗ Multipart downloads
- ✗ Path resolution (s3://, s3a://)

**Impact**: S3 is a major feature - needs production-ready testing

---

### 15. **Core Executor - Needs Integration Tests**
Missing tests for:
- ✗ Full query execution pipelines
- ✗ Error propagation
- ✗ Operator chaining
- ✗ Memory management
- ✗ Cancellation
- ✗ Progress reporting

---

### 16. **Optimizers Module**
**Status**: ✅ **RESOLVED**

**What was done:**
- ✅ Created modular optimizer architecture with base classes
- ✅ Moved QueryPlanner from `core/planner.py` to `optimizers/planner.py`
- ✅ Created individual optimizer rule classes:
  - `PredicatePushdownOptimizer` (97% coverage)
  - `ColumnPruningOptimizer` (78% coverage)
  - `LimitPushdownOptimizer` (81% coverage)
  - `ProjectionPushdownOptimizer` (80% coverage - placeholder)
- ✅ All 19 optimizer tests passing
- ✅ Overall test coverage increased from 18% to 32%
- ✅ Comprehensive documentation added

**New structure:**
```
sqlstream/optimizers/
├── base.py                    (92% coverage)
├── planner.py                 (90% coverage)
├── predicate_pushdown.py      (97% coverage)
├── column_pruning.py          (78% coverage)
├── limit_pushdown.py          (81% coverage)
└── projection_pushdown.py     (80% coverage)
```

---

## Test Organization Issues

1. **Integration Tests Missing**
   - No end-to-end tests for complex queries
   - No tests for real-world scenarios
   - No performance regression tests
   - No stress tests

2. **Error Path Testing**
   - Most tests only cover happy paths
   - Need systematic error injection tests
   - Need invalid input tests
   - Need edge case tests

3. **Backend Coverage**
   - Most tests use Python backend
   - Pandas backend needs equal coverage
   - Backend switching needs testing

4. **File Format Testing**
   - Need tests with various CSV dialects
   - Need tests with different parquet schemas
   - Need tests with real-world messy data

---

## Recommended Test Priorities

### Priority 1 (Critical - Production Blockers)
1. CSV Reader edge cases (encoding, malformed data)
2. Parquet Reader type mapping
3. HTTP Reader error handling
4. SQL Parser error messages
5. Join operator (LEFT/RIGHT joins documented but not tested)
6. S3 authentication and error handling

### Priority 2 (High - User-Facing Features)
1. Interactive Shell modal dialogs
2. Query history persistence
3. Export functionality
4. Auto-completion
5. Formatters with special characters

### Priority 3 (Medium - Quality & Robustness)
1. OrderBy multiple columns
2. Aggregates NULL handling
3. Type system edge cases
4. Pandas backend parity
5. Integration tests

### Priority 4 (Low - Nice to Have)
1. Performance benchmarks
2. Stress tests
3. ~~Optimizer module implementation~~ ✅ **DONE**
4. Advanced S3 features

---

## Testing Infrastructure Needs

1. **Test Data**
   - Need diverse test datasets
   - Need large test files for performance
   - Need malformed data for error handling
   - Need real-world sample data

2. **Test Fixtures**
   - Reusable CSV/Parquet generators
   - Mock HTTP servers
   - Mock S3 (moto library?)
   - Sample schemas

3. **Test Utilities**
   - Coverage reporting in CI
   - Performance regression detection
   - Test data generators
   - Assertion helpers

4. **CI/CD**
   - Run tests on multiple Python versions
   - Platform-specific tests (Windows, Linux, Mac)
   - Coverage thresholds
   - Performance benchmarks

---

## Coverage Goals

**Target Coverage by Module:**
- Readers: 80%+ (currently 13-32%)
- Operators: 80%+ (currently 14-38%)
- SQL Parser: 90%+ (currently 13%)
- CLI/Shell: 70%+ (currently ~40%)
- Core: 85%+ (currently varies)
- Overall: 75%+ (currently 18%)

**Timeline Estimate:**
- Priority 1: 40-50 new tests (~2-3 weeks)
- Priority 2: 30-40 new tests (~2 weeks)
- Priority 3: 50+ new tests (~3 weeks)
- Priority 4: Ongoing

**Total**: ~120-140 additional tests needed to reach 75% coverage
