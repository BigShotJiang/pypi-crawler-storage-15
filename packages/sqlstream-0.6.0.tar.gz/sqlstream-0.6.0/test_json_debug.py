#!/usr/bin/env python3
import json
import tempfile
from sqlstream import query

# Simple test
data = {'result': {'users': [{'name': 'Alice', 'id': 1}, {'name': 'Bob', 'id': 2}]}}
with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
    json.dump(data, f)
    path = f.name

print(f"File: {path}")
print(f"Data: {data}")

# Test the reader directly
from sqlstream.readers.json_reader import JSONReader
reader = JSONReader(path, records_key='result.users')
rows = list(reader.read_lazy())
print(f"Direct reader rows: {rows}")

# Test via query
result = list(query(f'{path}#json:result.users').sql('SELECT * FROM users'))
print(f"Query result: {result}")
