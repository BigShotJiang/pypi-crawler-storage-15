[](){#CopickTomogramMeta}
::: copick.models.CopickTomogramMeta
    options:
        show_if_no_docstring: true
