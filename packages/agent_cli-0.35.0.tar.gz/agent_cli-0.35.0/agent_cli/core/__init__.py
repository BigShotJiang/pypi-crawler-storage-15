"""Core functionalities for the agent CLI."""
