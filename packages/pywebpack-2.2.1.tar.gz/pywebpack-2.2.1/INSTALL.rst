Installation
============

PyWebpack is on PyPI so all you need is:

.. code-block:: console

   $ pip install pywebpack

Dependencies
------------
PyWebpack is dependent on `NodeJS <https://nodejs.org/en/>`_,
`NPM <https://www.npmjs.com>`_ and `Webpack <https://webpack.js.org>`_.
