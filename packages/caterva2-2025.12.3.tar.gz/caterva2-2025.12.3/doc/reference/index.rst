API Reference
=============
.. toctree::
    :maxdepth: 1

    client_class
    root_class
    file_class
    dataset_class
    utils
