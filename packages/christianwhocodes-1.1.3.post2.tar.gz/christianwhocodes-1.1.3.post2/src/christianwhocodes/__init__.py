from .stdout import print


def main() -> None:
    print(
        "...but the people who know their God shall be strong, and carry out great exploits. [purple]—[/] [bold green]Daniel[/] 11:32"
    )


if __name__ == "__main__":
    main()
