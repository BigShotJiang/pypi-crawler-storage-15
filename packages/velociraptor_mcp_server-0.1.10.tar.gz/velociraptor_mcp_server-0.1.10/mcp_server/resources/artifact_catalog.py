ARTIFACT_CATALOG = [
    {
        "name": "Windows.Sys.Users",
        "description": "Enumerate Windows local users and groups.",
    },
    {
        "name": "Windows.Sys.Autoruns",
        "description": "Startup items and persistence mechanisms.",
    },
    {
        "name": "Linux.Sys.Procs",
        "description": "Process listing on Linux hosts.",
    },
    {
        "name": "Generic.Client.Info",
        "description": "Basic client inventory information.",
    },
]
