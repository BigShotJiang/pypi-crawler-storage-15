from .generator import ulid, ULIDGenerator as generator

__all__ = ["ulid", "generator"]
