"""Kiro Hooks Generator for SpecMem."""

from specmem.hooks.generator import KiroHook, KiroHooksGenerator


__all__ = ["KiroHook", "KiroHooksGenerator"]
