"""CLI module for SpecMem commands."""

from specmem.cli.main import app


__all__ = ["app"]
