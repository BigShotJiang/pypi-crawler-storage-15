"""Output generators for SpecMem (living docs, etc.)."""

from specmem.output.living_docs import LivingDocsGenerator


__all__ = ["LivingDocsGenerator"]
