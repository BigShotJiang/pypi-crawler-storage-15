"""Integration tests for SpecMem."""
