"""Property-based tests for SpecMem."""
