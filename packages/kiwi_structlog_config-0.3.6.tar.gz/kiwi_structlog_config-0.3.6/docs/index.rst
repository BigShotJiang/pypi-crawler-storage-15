.. kw_structlog documentation master file, created by
   sphinx-quickstart on Fri Jan 13 12:59:16 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to kw_structlog's documentation!
===================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   kw/kw



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
