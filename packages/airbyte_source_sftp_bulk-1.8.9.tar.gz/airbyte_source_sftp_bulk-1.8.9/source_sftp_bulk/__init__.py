#
# Copyright (c) 2023 Airbyte, Inc., all rights reserved.
#


from .source import SourceSFTPBulk

__all__ = ["SourceSFTPBulk"]
