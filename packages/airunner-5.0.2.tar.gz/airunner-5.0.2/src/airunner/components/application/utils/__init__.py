# Application utilities
