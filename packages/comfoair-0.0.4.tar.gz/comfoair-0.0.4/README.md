# pycomfoair2
Python library to monitor and control Zehnder ComfoAir 350 units

This repository is a fork of the excellent library at https://github.com/mtdcr/pycomfoair .
Various changes are applied to facilitate the integration in Home Assistant.
