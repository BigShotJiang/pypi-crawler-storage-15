from ragang.core.bases.abstracts.base_container import BaseContainer


class RAGContainer(BaseContainer):
    pass