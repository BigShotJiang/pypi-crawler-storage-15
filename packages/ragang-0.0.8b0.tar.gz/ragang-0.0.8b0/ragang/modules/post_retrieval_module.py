from ragang.core.bases.abstracts.base_module import BaseModule


class PostRetrievalModule(BaseModule):
    pass