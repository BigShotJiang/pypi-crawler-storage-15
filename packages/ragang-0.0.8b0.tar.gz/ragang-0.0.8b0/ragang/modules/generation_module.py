from ragang.core.bases.abstracts.base_module import BaseModule


class GenerationModule(BaseModule):
    pass