from ragang.core.bases.abstracts.base_module import BaseModule


class CustomModule(BaseModule):
    pass