class RagangLoadError(Exception):
    pass