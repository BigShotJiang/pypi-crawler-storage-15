from .owsservice import OwsService
from .restservice import RestService

__all__ = [
    "OwsService",
    "RestService",
]
