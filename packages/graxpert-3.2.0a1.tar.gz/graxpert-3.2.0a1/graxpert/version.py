release = "fix smoothing typo"
version = "3.2.0a1"
