def test_throughput():
    assert True
