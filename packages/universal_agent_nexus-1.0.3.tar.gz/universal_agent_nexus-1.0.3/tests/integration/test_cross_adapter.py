def test_cross_adapter():
    assert True
