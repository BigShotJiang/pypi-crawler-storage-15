def test_aws_contract():
    assert True
