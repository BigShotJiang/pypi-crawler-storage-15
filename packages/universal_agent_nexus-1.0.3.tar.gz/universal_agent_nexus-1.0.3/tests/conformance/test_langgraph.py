def test_langgraph_contract():
    assert True
