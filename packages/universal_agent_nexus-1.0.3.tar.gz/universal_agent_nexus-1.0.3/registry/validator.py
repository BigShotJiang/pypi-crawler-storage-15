"""Adapter contract verification."""

def validate(manifest: dict) -> None:
    raise NotImplementedError("validate is not implemented yet")
