"""Dynamic adapter loader."""

def load_adapter(name: str):
    raise NotImplementedError("load_adapter is not implemented yet")
