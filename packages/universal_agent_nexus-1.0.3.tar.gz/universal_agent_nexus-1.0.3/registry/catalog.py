"""Catalog of available adapters."""

def list_adapters() -> list:
    raise NotImplementedError("list_adapters is not implemented yet")
