# AWS adapter

TODO: document AWS adapter.
