# MCP adapter

TODO: document MCP adapter.
