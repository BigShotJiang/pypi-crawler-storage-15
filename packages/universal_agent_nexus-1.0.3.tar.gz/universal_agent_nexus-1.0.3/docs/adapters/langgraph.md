# LangGraph adapter

TODO: describe LangGraph integration.
