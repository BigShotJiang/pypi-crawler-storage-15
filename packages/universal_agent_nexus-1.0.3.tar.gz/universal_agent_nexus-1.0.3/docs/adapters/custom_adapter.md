# Custom adapter

TODO: document custom adapters.
