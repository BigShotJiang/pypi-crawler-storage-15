"""SQS-based event bus."""

def publish_event(event: dict) -> None:
    raise NotImplementedError("publish_event is not implemented yet")
