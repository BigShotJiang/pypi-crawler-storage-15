"""Translate UAA graphs into Step Functions ASL."""

def compile_asl(manifest: dict) -> dict:
    raise NotImplementedError("compile_asl is not implemented yet")
