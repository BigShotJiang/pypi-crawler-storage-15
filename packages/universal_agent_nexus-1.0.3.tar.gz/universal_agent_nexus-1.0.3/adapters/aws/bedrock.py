"""Model routing for Bedrock."""

def select_model(request: dict) -> str:
    raise NotImplementedError("select_model is not implemented yet")
