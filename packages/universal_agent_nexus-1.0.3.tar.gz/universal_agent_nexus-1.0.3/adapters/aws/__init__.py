"""AWS Step Functions + Bedrock adapter."""
