"""DynamoDB-backed task store implementation."""

def upsert_task(task: dict) -> None:
    raise NotImplementedError("upsert_task is not implemented yet")
