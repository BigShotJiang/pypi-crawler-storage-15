"""OpenAI Assistants adapter."""
