"""Function calling translation."""

def to_functions(tools: list) -> list:
    raise NotImplementedError("to_functions is not implemented yet")
