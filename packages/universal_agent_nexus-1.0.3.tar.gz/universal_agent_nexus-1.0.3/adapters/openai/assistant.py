"""Assistant definition helpers."""

def build_assistant(manifest: dict):
    raise NotImplementedError("build_assistant is not implemented yet")
