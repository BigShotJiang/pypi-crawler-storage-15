"""Tool conversion utilities."""

def to_langgraph_tools(tools: list) -> list:
    raise NotImplementedError("to_langgraph_tools is not implemented yet")
