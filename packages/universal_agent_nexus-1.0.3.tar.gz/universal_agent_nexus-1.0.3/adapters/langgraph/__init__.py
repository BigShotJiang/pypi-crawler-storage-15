"""LangGraph adapter."""
