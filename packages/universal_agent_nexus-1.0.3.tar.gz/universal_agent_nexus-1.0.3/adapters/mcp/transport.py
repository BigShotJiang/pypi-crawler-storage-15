"""Transport implementations for MCP."""

def open_transport(config: dict):
    raise NotImplementedError("open_transport is not implemented yet")
