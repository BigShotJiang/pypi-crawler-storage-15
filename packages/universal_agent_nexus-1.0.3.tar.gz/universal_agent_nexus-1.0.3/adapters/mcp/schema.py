"""Schema translation between UAA and MCP."""

def translate(message: dict) -> dict:
    raise NotImplementedError("translate is not implemented yet")
