"""Client helpers for consuming MCP tools."""

def build_client(tools: list) -> object:
    raise NotImplementedError("build_client is not implemented yet")
