"""Protocol adapters package."""
