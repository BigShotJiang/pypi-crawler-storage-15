"""Temporal worker bootstrap."""

def start_worker():
    raise NotImplementedError("start_worker is not implemented yet")
