"""Activities bound to UAA tasks."""

def register_activities():
    raise NotImplementedError("register_activities is not implemented yet")
