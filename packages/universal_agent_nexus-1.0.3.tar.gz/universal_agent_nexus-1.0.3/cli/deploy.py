"""Deploy adapter to target platform."""

def main():
    raise NotImplementedError("deploy CLI not implemented yet")


if __name__ == "__main__":
    main()
