"""Migrate between adapters."""

def main():
    raise NotImplementedError("migrate CLI not implemented yet")


if __name__ == "__main__":
    main()
