#!/usr/bin/env bash
echo "Deploying AWS production stack"
