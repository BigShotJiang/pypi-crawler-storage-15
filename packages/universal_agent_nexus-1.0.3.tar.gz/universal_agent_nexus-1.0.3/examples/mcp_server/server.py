def main():
    raise NotImplementedError("mcp_server example not implemented yet")


if __name__ == "__main__":
    main()
