# MCP server example

Placeholder server guide.
