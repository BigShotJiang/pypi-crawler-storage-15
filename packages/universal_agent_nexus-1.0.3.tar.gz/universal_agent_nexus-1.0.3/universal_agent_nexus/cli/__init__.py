"""CLI entrypoints for Universal Agent Nexus."""

