"""Adapter interfaces and implementations for Universal Agent Nexus."""

