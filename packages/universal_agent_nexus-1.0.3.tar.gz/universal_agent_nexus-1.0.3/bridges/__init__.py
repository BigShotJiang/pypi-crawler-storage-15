"""Cross-adapter translation helpers."""
