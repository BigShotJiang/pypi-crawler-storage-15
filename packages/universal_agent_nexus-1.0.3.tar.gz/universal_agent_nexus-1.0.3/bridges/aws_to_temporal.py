"""Migrate Step Functions state to Temporal."""

def migrate(state: dict) -> dict:
    raise NotImplementedError("migrate is not implemented yet")
