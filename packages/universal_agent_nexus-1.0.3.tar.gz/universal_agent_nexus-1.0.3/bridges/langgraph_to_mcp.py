"""Convert LangGraph checkpoints to MCP state."""

def convert(checkpoint: dict) -> dict:
    raise NotImplementedError("convert is not implemented yet")
