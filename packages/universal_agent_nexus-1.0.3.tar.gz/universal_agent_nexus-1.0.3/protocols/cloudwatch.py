"""CloudWatch metrics stub."""

def emit_metric(name: str, value: float) -> None:
    raise NotImplementedError("emit_metric is not implemented yet")
