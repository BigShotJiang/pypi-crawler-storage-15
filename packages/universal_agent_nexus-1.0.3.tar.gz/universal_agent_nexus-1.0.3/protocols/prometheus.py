"""Prometheus metrics export stub."""

def start_exporter(port: int) -> None:
    raise NotImplementedError("start_exporter is not implemented yet")
