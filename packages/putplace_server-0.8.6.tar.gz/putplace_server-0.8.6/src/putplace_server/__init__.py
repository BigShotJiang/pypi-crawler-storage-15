"""PutPlace Server - FastAPI server for file metadata storage."""

from .version import __version__

__all__ = ["__version__"]
