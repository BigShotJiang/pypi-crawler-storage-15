from .base import OCR
from .zerox_ocr import ZeroxOCR

__all__ = ["OCR", "ZeroxOCR"]
