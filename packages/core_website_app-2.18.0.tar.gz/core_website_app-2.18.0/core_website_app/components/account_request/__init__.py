""" Object storing data about the user account requests.
    A user requests an account through the designated web page.
    The requests is then send to the admin who can accept or deny it.
"""
