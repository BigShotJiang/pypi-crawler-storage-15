""" Contact messages object
"""
