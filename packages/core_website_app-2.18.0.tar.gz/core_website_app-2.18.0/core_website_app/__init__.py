""" Core website app package
"""

default_app_config = "core_website_app.apps.CoreWebsiteAppConfig"
