"""
This package is planned to be deleted in future versions.
"""
