class InvalidMeasureUnitsException(Exception):
    pass
