__version__ = '0.5.4'  # Must be at the top of module

from rogii_solo.client import SoloClient

__all__ = [
    '__version__',
    'SoloClient',
]
