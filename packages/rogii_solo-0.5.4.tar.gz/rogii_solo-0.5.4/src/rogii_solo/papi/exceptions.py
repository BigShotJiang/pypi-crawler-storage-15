class BasePapiClientException(Exception):
    pass


class AccessTokenFailureException(BasePapiClientException):
    pass
