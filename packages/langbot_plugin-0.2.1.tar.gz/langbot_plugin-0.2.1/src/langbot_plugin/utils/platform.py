
import sys


def get_platform() -> str:
    """Get the platform of the current system."""

    return sys.platform
