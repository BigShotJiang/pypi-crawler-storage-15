<div align="center">
<img src="https://docs.langbot.app/langbot-plugin-social.png" alt="LangBot Plugin SDK" />
</div>

## LangBot Plugin Infra

This repository contains the Runtime / SDK / CLI for LangBot Plugins. More details about usage, principles, and tutorials can be found in the [LangBot Plugin Documentation](https://docs.langbot.app/zh/plugin/dev/tutor.html)

此仓库是 LangBot 插件的运行时、SDK 和 CLI。更多关于使用、原理和教程的信息，请参阅 [LangBot 插件文档](https://docs.langbot.app/zh/plugin/dev/tutor.html)。