---
title: Simplify PR metadata
type: change
authors:
- codex
created: 2025-10-24
---

Removes the legacy `pr` field from changelog exports and relies solely on the `prs` list.
