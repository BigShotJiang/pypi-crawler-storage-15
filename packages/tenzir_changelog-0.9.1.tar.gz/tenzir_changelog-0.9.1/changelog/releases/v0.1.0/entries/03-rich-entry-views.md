---
title: Browse entries in rich terminal views
type: feature
authors:
- codex
created: 2025-10-21
---

Add `list` and `show` commands that render changelog entries in a Rich-powered table, support filtering by project or release, and output Markdown or JSON for downstream tooling.
