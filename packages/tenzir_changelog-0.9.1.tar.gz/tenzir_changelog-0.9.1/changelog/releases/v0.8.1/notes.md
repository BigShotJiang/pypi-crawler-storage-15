Patch release to stabilize GitHub context inference tests.

## 🐞 Bug fixes

### Stabilize gh context tests

Ensure CI test invocations clear GitHub actor environment variables so mocked gh responses win consistently.

*By @codex.*
