"""Tests for patterndb-yaml."""
