import{_ as a,cx as s}from"./index-rZUS0c3q.js";const c=a(s,[["__scopeId","data-v-565bc716"]]);export{c as M};
