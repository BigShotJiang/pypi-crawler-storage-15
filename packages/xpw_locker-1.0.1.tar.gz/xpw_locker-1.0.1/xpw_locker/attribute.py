# coding:utf-8

__project__ = "xpw-locker"
__version__ = "1.0.1"
__urlhome__ = "https://github.com/checkeys/locker/"
__description__ = "Access authentication"
__official_name__ = "Locker"

# author
__author__ = "Mingzhe Zou"
__author_email__ = "zoumingzhe@outlook.com"
