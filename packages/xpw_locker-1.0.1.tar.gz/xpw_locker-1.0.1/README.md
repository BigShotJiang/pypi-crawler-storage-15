# locker

> Access authentication

## Usage

```bash
curl -u "demo:xpw123" http://localhost:3000/
```
