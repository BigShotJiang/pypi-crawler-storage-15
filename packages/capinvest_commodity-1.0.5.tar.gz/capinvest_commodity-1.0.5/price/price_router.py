"""Price Router."""

# pylint: disable=unused-argument

from capinvest_core.app.model.command_context import CommandContext
from capinvest_core.app.model.example import APIEx
from capinvest_core.app.model.obbject import OBBject
from capinvest_core.app.provider_interface import (
    ExtraParams,
    ProviderChoices,
    StandardParams,
)
from capinvest_core.app.query import Query
from capinvest_core.app.router import Router

router = Router(prefix="/price")


@router.command(
    model="CommoditySpotPrices",
    examples=[
        APIEx(parameters={"provider": "fred"}),
        APIEx(parameters={"provider": "fred", "commodity": "wti"}),
    ],
)
async def spot(
    cc: CommandContext,
    provider_choices: ProviderChoices,
    standard_params: StandardParams,
    extra_params: ExtraParams,
) -> OBBject:
    """Commodity Spot Prices."""
    return await OBBject.from_query(Query(**locals()))
