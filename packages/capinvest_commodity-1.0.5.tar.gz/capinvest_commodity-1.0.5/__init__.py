"""CapInvest Commodity Extension."""
