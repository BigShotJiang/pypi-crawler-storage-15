__version__ = "3.12.2"
__array_api_version__ = "2024.12"
