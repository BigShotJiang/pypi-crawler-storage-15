# ResourceKind


## Enum

* `PLATFORM` (value: `'platform'`)

* `ORGANIZATION` (value: `'organization'`)

* `WORKSPACE` (value: `'workspace'`)

* `PROJECT` (value: `'project'`)

* `MODEL` (value: `'model'`)

* `CONNECTOR` (value: `'connector'`)

* `AVAILABLE_DATASET` (value: `'available_dataset'`)

* `DATASET` (value: `'dataset'`)

* `ROLE_BINDING` (value: `'role_binding'`)

* `ROLE` (value: `'role'`)

* `USER` (value: `'user'`)

* `GROUP` (value: `'group'`)

* `DATA_PLANE_ASSOCIATION` (value: `'data_plane_association'`)

* `DATA_PLANE` (value: `'data_plane'`)

* `ALERT_RULE` (value: `'alert_rule'`)

* `WEBHOOK` (value: `'webhook'`)

* `CUSTOM_AGGREGATION` (value: `'custom_aggregation'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


