def start_hud() -> None:
    pass
