pub mod a_simple_case;
pub mod b_more_than_one_window;
pub mod c_windows_in_more_than_one_wall;
pub mod common;
pub mod d_compartment_with_core;
