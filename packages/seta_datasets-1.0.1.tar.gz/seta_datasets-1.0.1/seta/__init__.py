from .core import (
    get_seta,
    get_recent_seta,
    get_seta_by_version,
    get_seta_instance
)

__version__ = "1.0.1"