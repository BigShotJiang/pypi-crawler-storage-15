# SETA Datasets Loader

A high-performance CLI tool and library for downloading datasets from the SETA Protocol.

## Installation

```bash
pip install seta-datasets