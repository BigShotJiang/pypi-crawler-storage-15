Advanced
==========

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   notebooks/modes.ipynb
   notebooks/simulate_lossy_material.ipynb


More guides will follow shortly!
