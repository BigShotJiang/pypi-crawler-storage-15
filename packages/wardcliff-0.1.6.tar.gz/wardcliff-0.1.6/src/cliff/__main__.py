"""Allow running as: python -m cliff"""

from cliff.cli.app import app

if __name__ == "__main__":
    app()
