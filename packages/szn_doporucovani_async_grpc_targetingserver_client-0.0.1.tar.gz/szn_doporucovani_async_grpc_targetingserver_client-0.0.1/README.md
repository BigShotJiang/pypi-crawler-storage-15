# szn-doporucovani-async-grpc-targetingserver-client

This is a security placeholder package created to prevent dependency confusion attacks.