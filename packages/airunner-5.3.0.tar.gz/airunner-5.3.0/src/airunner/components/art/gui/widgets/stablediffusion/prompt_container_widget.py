from typing import Dict
from PySide6.QtCore import Slot

from airunner.components.application.gui.widgets.base_widget import BaseWidget
from airunner.components.art.gui.widgets.stablediffusion.templates.prompt_container_ui import (
    Ui_prompt_container_widget,
)
from airunner.enums import SignalCode


class PromptContainerWidget(BaseWidget):
    widget_class_ = Ui_prompt_container_widget
    prompt_id: int = None
    icons = (("trash-2", "delete_prompt_button"),)

    def __init__(self, *args, **kwargs):
        self.signal_handlers = {
            SignalCode.WIDGET_ELEMENT_CHANGED: self.on_widget_element_changed,
        }
        super().__init__(*args, **kwargs)
        self._sd_version: str = self.generator_settings.version
        # Note: SDXL support deprecated, secondary prompt feature removed

    @Slot()
    def on_delete_prompt_button_clicked(self):
        self.api.delete_prompt(self.prompt_id)

    def on_widget_element_changed(self, data: Dict):
        if data.get("element") in ("sd_version",):
            self._sd_version = data.get("version")

    def get_prompt(self):
        """Get the current prompt text from the widget."""
        return self.ui.prompt.toPlainText()

    def set_prompt(self, text):
        """Set the prompt text in the widget."""
        self.ui.prompt.setPlainText(text)

    def get_prompt_secondary(self):
        """Get the current secondary prompt text from the widget."""
        return self.ui.secondary_prompt.toPlainText()

    def set_prompt_secondary(self, text):
        """Set the secondary prompt text in the widget."""
        self.ui.secondary_prompt.setPlainText(text)
