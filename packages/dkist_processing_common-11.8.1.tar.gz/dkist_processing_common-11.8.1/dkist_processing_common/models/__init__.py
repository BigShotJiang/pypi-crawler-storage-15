"""Package supporting the data models used in dkist-processing-common."""
