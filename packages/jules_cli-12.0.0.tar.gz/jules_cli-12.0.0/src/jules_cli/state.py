# State
_state = {
    "current_session": None,   # last created session dict
    "last_result": None,       # {"type":"patch"/"pr", ...}
    "repo_source": None,       # source object used
    "repo_owner": None,
    "repo_name": None
}
