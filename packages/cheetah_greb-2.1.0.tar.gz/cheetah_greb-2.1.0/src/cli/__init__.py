from __future__ import annotations

from .main import main

__all__ = ["main"]