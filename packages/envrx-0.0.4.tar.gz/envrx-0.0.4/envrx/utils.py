# Copyright (C) 2023-present by StarkGang@Github, < https://github.com/StarkGang >.
#
# This file is part of < https://github.com/StarkGang/Envrx > project,
# and is released under the "GNU v3.0 License Agreement".
# Please see < https://github.com/StarkGang/Envrx/blob/main/LICENSE >
#
# All rights reserved.
import sqlite3

def check_if_package_installed(package_name: str) -> bool:
    """Check if a package is installed."""
    import importlib

    try:
        importlib.import_module(package_name)
        return True
    except ImportError:
        return False


if is_motor_installed := check_if_package_installed("pymongo"):
    from pymongo import AsyncMongoClient, MongoClient

if is_aioredis_installed := check_if_package_installed("redis.asyncio"):
    import redis

if is_asyncpg_installed := check_if_package_installed("asyncpg"):
    import asyncpg

if is_aiosqlite_installed := check_if_package_installed("aiosqlite"):
    import aiosqlite

if is_psycopg2_installed := check_if_package_installed("psycopg2"):
    import psycopg2

def guess_which_database_from(url: str) -> str:
    """Guess which database is being used from the url."""
    if isinstance(url, AsyncMongoClient) or isinstance(url, MongoClient):
        return "mongo"
    elif isinstance(url, asyncpg.Connection) or isinstance(url, psycopg2.extensions.connection) or isinstance(url, sqlite3.Connection):
        return "sql"
    elif isinstance(url, redis.asyncio.Redis) or isinstance(url, redis.Redis):
        return "redis"
    elif url.startswith("mongodb"):
        return "mongo"
    elif url.endswith(".db"):
        return "sqlite"
    elif url.startswith("postgresql"):
        return "sql"
    elif url.startswith("redis"):
        return "redis"
    else:
        return None
