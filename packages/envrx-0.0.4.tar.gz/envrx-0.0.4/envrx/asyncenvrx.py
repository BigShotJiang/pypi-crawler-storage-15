# Copyright (C) 2023-present by StarkGang@Github, < https://github.com/StarkGang >.
#
# This file is part of < https://github.com/StarkGang/Envrx > project,
# and is released under the "GNU v3.0 License Agreement".
# Please see < https://github.com/StarkGang/Envrx/blob/main/LICENSE >
#
# All rights reserved.

import asyncio
import json
import logging
import os
import re
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse
import yaml
from envrx.exceptions import *
from envrx.utils import *

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())

if is_motor_installed := check_if_package_installed("pymongo"):
    log.debug("pymongo is installed.")
    from pymongo import AsyncMongoClient

if is_aioredis_installed := check_if_package_installed("redis.asyncio"):
    log.debug("redis.asyncio is installed.")
    from redis import asyncio as aioredis

if is_asyncpg_installed := check_if_package_installed("asyncpg"):
    log.debug("asyncpg is installed.")
    import asyncpg

if is_aiosqlite_installed := check_if_package_installed("aiosqlite"):
    log.debug("aiosqlite is installed.")
    import aiosqlite


class AsyncENVRX:
    """Async ENVRX is a class to manage environment variables asynchronously."""

    def __init__(
        self,
        env_file: str = None,
        database: str = None,
        collection_or_table_name: str = None,
        max_workers: int = 4,
    ) -> None:
        """Initialize the AsyncENVRX class.

        Parameters:
            env_file (str): Path to the environment file.
            database (str): Database url or database object.
            collection_or_table_name (str): Name of the collection or table in the database.
            max_workers (int): Maximum number of workers for ThreadPoolExecutor.
        Returns:
            None"""
        self.database = database
        self.collection_or_table_name = collection_or_table_name
        self.env_file = env_file
        self.client = None
        self.databasename = None
        self.executor = ThreadPoolExecutor(max_workers=max_workers)
        
        if self.database and (not self.collection_or_table_name):
            raise InvalidCollectionOrTableName(
                "No database/table name given. Please provide a database/table name."
            )
        
        if self.collection_or_table_name:
            self.collection_or_table_name = self.collection_or_table_name.strip()
            if " " in self.collection_or_table_name:
                raise ValueError(
                    "Collection/table name cannot contain spaces. Please provide a valid collection/table name."
                )

    async def start(self) -> None:
        """Initialize the AsyncENVRX class.

        Parameters:
            None
        Returns:
            None"""
        if self.database:
            log.debug("Database url provided.")
            self.databasename = guess_which_database_from(self.database)
            
            if self.databasename == "mongo":
                await self._setup_mongo()
            elif self.databasename in ["sql", "sqlite"]:
                await self._setup_sql()
            elif self.databasename == "redis":
                await self._setup_redis()
            else:
                log.error("Invalid database url provided.")
                raise InvalidDatabaseUrl(
                    "Invalid database url. Please check the url and try again."
                )
            
            await self.load_from_database()
        
        if self.env_file:
            log.debug("Environment file provided.")
            if not await self._file_exists(self.env_file):
                log.error("Environment file not found.")
                raise FileNotFoundError(
                    "Environment file not found. Please check the file path and try again."
                )
            await self.load_env_from_file()

    async def _setup_mongo(self):
        """Setup MongoDB connection."""
        log.debug("MongoDB database url provided.")
        if not is_motor_installed:
            raise ImportError(
                "motor is not installed. Please install it using pip install motor."
            )
        
        if isinstance(self.database, AsyncMongoClient):
            self.client = self.database
        else:
            self.client = AsyncMongoClient(self.database)
            try:
                await self.client.server_info()
            except Exception as e:
                log.error(
                    "MongoDB database url is invalid. Unable to connect to the database."
                )
                raise InvalidDatabaseUrl(
                    "Invalid database url. Please check the url and try again.",
                    e,
                ) from e

    async def _setup_sql(self):
        """Setup SQL/SQLite connection."""
        log.debug("SQL database url provided.")
        try:
            if self.databasename == "sqlite":
                if not is_aiosqlite_installed:
                    raise ImportError(
                        "aiosqlite is not installed. Please install it using pip install aiosqlite."
                    )
                if isinstance(self.database, aiosqlite.Connection):
                    self.client = self.database
                else:
                    self.client = await aiosqlite.connect(self.database)
            elif isinstance(self.database, asyncpg.Connection):
                self.client = self.database
            else:
                if not is_asyncpg_installed:
                    raise ImportError(
                        "asyncpg is not installed. Please install it using pip install asyncpg."
                    )
                url = urlparse(self.database)
                self.client = await asyncpg.connect(
                    database=url.path[1:],
                    user=url.username,
                    password=url.password,
                    host=url.hostname,
                    port=url.port,
                )
        except Exception as e:
            log.error(
                "SQL database url is invalid. Unable to connect to the database."
            )
            raise InvalidDatabaseUrl(
                "Invalid database url. Please check the url and try again.",
                e,
            ) from e
        
        await self.create_sql_table_if_not_exists()

    async def _setup_redis(self):
        """Setup Redis connection."""
        log.debug("Redis database url provided.")
        if not is_aioredis_installed:
            raise ImportError(
                "redis is not installed. Please install it using pip install redis[asyncio]."
            )
        
        if isinstance(self.database, aioredis.Redis):
            self.client = self.database
        else:
            try:
                self.client = aioredis.from_url(self.database)
                await self.client.ping()
            except Exception as e:
                log.error(
                    "Redis database url is invalid. Unable to connect to the database."
                )
                raise InvalidDatabaseUrl(
                    "Invalid database url. Please check the url and try again.",
                    e,
                ) from e

    async def _file_exists(self, path: str) -> bool:
        """Check if file exists asynchronously."""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(self.executor, os.path.exists, path)

    async def _read_file(self, path: str) -> str:
        """Read file asynchronously."""
        loop = asyncio.get_event_loop()
        abs_path = os.path.abspath(path)
        
        def _read():
            with open(abs_path, "r") as file:
                return file.read()
        
        return await loop.run_in_executor(self.executor, _read)

    async def create_sql_table_if_not_exists(self):
        """Create SQL table if not exists.

        Parameters:
            None
        Returns:
            None"""
        if self.databasename not in ["sql", "sqlite"]:
            raise NoDatabaseUrlSupplied(
                "No database url supplied. Please supply a database url."
            )
        
        log.debug("Creating SQL table if not exists.")
        
        if self.databasename == "sqlite":
            await self.client.execute(
                f"CREATE TABLE IF NOT EXISTS {self.collection_or_table_name} (key TEXT PRIMARY KEY, value TEXT)"
            )
            await self.client.commit()
        else:  # PostgreSQL with asyncpg
            await self.client.execute(
                f"CREATE TABLE IF NOT EXISTS {self.collection_or_table_name} (key TEXT PRIMARY KEY, value TEXT)"
            )

    async def load_env_from_file(self):
        """Load environment variables from file.

        Parameters:
            None
        Returns:
            None"""
        if not self.env_file:
            raise FileNotFoundError(
                "No environment file supplied. Please supply an environment file."
            )
        
        if self.env_file.endswith(".env"):
            await self.load_env_from_env_file()
        elif self.env_file.endswith(".json"):
            await self.load_env_from_json_file()
        elif self.env_file.endswith(".yaml"):
            await self.load_env_from_yaml_file()
        else:
            log.error("Invalid environment file provided.")
            raise InvalidEnvFile(
                "Invalid environment file. Please check the file and try again."
            )

    async def load_env_from_json_file(self):
        """Load environment variables from json file.

        Parameters:
            None
        Returns:
            None"""
        log.debug("Loading environment variables from json file.")
        
        try:
            content = await self._read_file(self.env_file)
            json_content = json.loads(content)
            
            for key, value in json_content.items():
                os.environ[key.upper()] = str(value)
        except Exception as e:
            raise InvalidEnvFile(
                "Invalid environment file. Please check the file and try again.", e
            ) from e

    async def load_env_from_yaml_file(self):
        """Load environment variables from yaml file.

        Parameters:
            None
        Returns:
            None"""
        log.debug("Loading environment variables from yaml file.")
        
        try:
            content = await self._read_file(self.env_file)
            
            loop = asyncio.get_event_loop()
            yaml_content = await loop.run_in_executor(
                self.executor, yaml.safe_load, content
            )
            
            for key, value in yaml_content.items():
                os.environ[key.upper()] = str(value)
        except Exception as e:
            raise InvalidEnvFile(
                "Invalid environment file. Please check the file and try again.", e
            ) from e

    async def load_env_from_env_file(self):
        """Load environment variables from .env file.

        Parameters:
            None
        Returns:
            None"""
        log.debug("Loading environment variables from .env file.")
        
        pattern = re.compile(r'(\w+)\s*=\s*(?:"(.*?)"|([^"\n]+))', re.DOTALL)
        
        try:
            content = await self._read_file(self.env_file)
            matches = pattern.findall(content)
            
            for key, quoted_value, unquoted_value in matches:
                value = quoted_value or unquoted_value
                os.environ[key.upper()] = value.replace("\n", "")
        except Exception as e:
            raise InvalidEnvFile(
                "Invalid environment file. Please check the file and try again.", e
            ) from e

    async def load_from_database(self):
        """Load environment variables from database.

        Parameters:
            None
        Returns:
            None"""
        if not self.database:
            raise NoDatabaseUrlSupplied(
                "No database url supplied. Please supply a database url."
            )
        
        log.debug("Loading environment variables from database.")
        
        if self.databasename == "mongo":
            log.debug("Loading environment variables from MongoDB database.")
            db = self.client.envrx
            collection = db[self.collection_or_table_name]
            
            async for doc in collection.find():
                os.environ[doc["key"].upper()] = doc["value"]
        
        elif self.databasename == "sqlite":
            log.debug("Loading environment variables from SQLite database.")
            async with self.client.execute(
                f"SELECT * FROM {self.collection_or_table_name}"
            ) as cursor:
                async for row in cursor:
                    os.environ[row[0].upper()] = row[1]
        
        elif self.databasename == "sql":
            log.debug("Loading environment variables from PostgreSQL database.")
            rows = await self.client.fetch(
                f"SELECT * FROM {self.collection_or_table_name}"
            )
            for row in rows:
                os.environ[row["key"].upper()] = row["value"]
        
        elif self.databasename == "redis":
            log.debug("Loading environment variables from Redis database.")
            keys = await self.client.keys("*")
            
            for key in keys:
                value = await self.client.get(key)
                if value:
                    os.environ[key.decode("utf-8").upper()] = value.decode("utf-8")

    async def get_env_from_database(self, key: str):
        """Get environment variable from database.

        Parameters:
            key (str): Environment variable key.
        Returns:
            str: Environment variable value."""
        self._validate_key(key)
        
        log.debug(f"Getting environment variable {key} from database.")
        
        if self.databasename == "mongo":
            db = self.client.envrx
            collection = db[self.collection_or_table_name]
            result = await collection.find_one({"key": key})
            return result["value"] if result else None
        
        elif self.databasename == "sqlite":
            async with self.client.execute(
                f"SELECT value FROM {self.collection_or_table_name} WHERE key=?",
                (key,)
            ) as cursor:
                row = await cursor.fetchone()
                return row[0] if row else None
        
        elif self.databasename == "sql":
            row = await self.client.fetchrow(
                f"SELECT value FROM {self.collection_or_table_name} WHERE key=$1",
                key
            )
            return row["value"] if row else None
        
        elif self.databasename == "redis":
            result = await self.client.get(key)
            return result.decode("utf-8") if result else None

    async def get_all_env_from_database(self):
        """Get all environment variables from database.

        Parameters:
            None
        Returns:
            dict/list: Environment variables."""
        if not self.database:
            raise NoDatabaseUrlSupplied(
                "No database url supplied. Please supply a database url."
            )
        
        log.debug("Getting all environment variables from database.")
        
        if self.databasename == "mongo":
            db = self.client.envrx
            collection = db[self.collection_or_table_name]
            return [doc async for doc in collection.find()]
        
        elif self.databasename == "sqlite":
            async with self.client.execute(
                f"SELECT * FROM {self.collection_or_table_name}"
            ) as cursor:
                return await cursor.fetchall()
        
        elif self.databasename == "sql":
            return await self.client.fetch(
                f"SELECT * FROM {self.collection_or_table_name}"
            )
        
        elif self.databasename == "redis":
            keys = await self.client.keys("*")
            result = {}
            for key in keys:
                value = await self.client.get(key)
                if value:
                    result[key.decode("utf-8")] = value.decode("utf-8")
            return result

    async def load_env_to_database(self, key: str, value: str):
        """Load environment variable to database.

        Parameters:
            key (str): Environment variable key.
            value (str): Environment variable value.
        Returns:
            None"""
        self._validate_key(key)
        
        if self.databasename == "mongo":
            log.debug(
                f"Loading environment variable {key}={value} to MongoDB database."
            )
            db = self.client.envrx
            collection = db[self.collection_or_table_name]
            await collection.insert_one({"key": key, "value": value})
        
        elif self.databasename == "sqlite":
            log.debug(f"Loading environment variable {key}={value} to SQLite database.")
            await self.client.execute(
                f"INSERT OR REPLACE INTO {self.collection_or_table_name} (key, value) VALUES (?, ?)",
                (key, value),
            )
            await self.client.commit()
        
        elif self.databasename == "sql":
            log.debug(f"Loading environment variable {key}={value} to PostgreSQL database.")
            await self.client.execute(
                f"INSERT INTO {self.collection_or_table_name} (key, value) VALUES ($1, $2) "
                f"ON CONFLICT (key) DO UPDATE SET value=$2",
                key, value
            )
        
        elif self.databasename == "redis":
            log.debug(f"Loading environment variable {key}={value} to Redis database.")
            await self.client.set(key, value)
        
        os.environ[key.upper()] = value

    async def delete_env_from_database(self, key: str):
        """Delete environment variable from database.

        Parameters:
            key (str): Environment variable key.
        Returns:
            None"""
        self._validate_key(key)
        
        log.debug(f"Deleting environment variable {key} from database.")
        
        if self.databasename == "mongo":
            db = self.client.envrx
            collection = db[self.collection_or_table_name]
            await collection.delete_one({"key": key})
        
        elif self.databasename == "sqlite":
            async with self.client.execute(
                f"SELECT * FROM {self.collection_or_table_name} WHERE key=?",
                (key,)
            ) as cursor:
                if not await cursor.fetchone():
                    raise KeyError(f"Key {key} not found in the database.")
            
            await self.client.execute(
                f"DELETE FROM {self.collection_or_table_name} WHERE key=?",
                (key,)
            )
            await self.client.commit()
        
        elif self.databasename == "sql":
            result = await self.client.fetchrow(
                f"SELECT * FROM {self.collection_or_table_name} WHERE key=$1",
                key
            )
            if not result:
                raise KeyError(f"Key {key} not found in the database.")
            
            await self.client.execute(
                f"DELETE FROM {self.collection_or_table_name} WHERE key=$1",
                key
            )
        
        elif self.databasename == "redis":
            await self.client.delete(key)
        
        if key.upper() in os.environ:
            del os.environ[key.upper()]

    async def update_env_in_database(self, key: str, value: str):
        """Update environment variable in database.

        Parameters:
            key (str): Environment variable key.
            value (str): Environment variable value.
        Returns:
            None"""
        self._validate_key(key)
        
        if self.databasename == "mongo":
            db = self.client.envrx
            collection = db[self.collection_or_table_name]
            result = await collection.update_one(
                {"key": key}, 
                {"$set": {"value": value}},
                upsert=True
            )
        
        elif self.databasename == "sqlite":
            async with self.client.execute(
                f"SELECT * FROM {self.collection_or_table_name} WHERE key=?",
                (key,)
            ) as cursor:
                if not await cursor.fetchone():
                    await self.load_env_to_database(key, value)
                else:
                    await self.client.execute(
                        f"UPDATE {self.collection_or_table_name} SET value=? WHERE key=?",
                        (value, key),
                    )
                    await self.client.commit()
        
        elif self.databasename == "sql":
            await self.client.execute(
                f"INSERT INTO {self.collection_or_table_name} (key, value) VALUES ($1, $2) "
                f"ON CONFLICT (key) DO UPDATE SET value=$2",
                key, value
            )
        
        elif self.databasename == "redis":
            await self.client.set(key, value)
        
        os.environ[key.upper()] = value

    def _validate_key(self, key: str):
        """Validate environment variable key.

        Parameters:
            key (str): Environment variable key.
        Returns:
            None"""
        if not self.database:
            raise NoDatabaseUrlSupplied(
                "No database url supplied. Please supply a database url."
            )
        if not isinstance(key, str):
            raise TypeError("Invalid key type. Please provide a valid key.")
        if " " in key:
            raise ValueError("Keys cannot contain spaces. Please provide a valid key.")

    async def close(self):
        """Close database connections and executor.

        Parameters:
            None
        Returns:
            None"""
        if self.client:
            if self.databasename == "mongo":
                self.client.close()
            elif self.databasename == "sqlite":
                await self.client.close()
            elif self.databasename == "sql":
                await self.client.close()
            elif self.databasename == "redis":
                await self.client.close()
        
        self.executor.shutdown(wait=True)

    async def __aenter__(self):
        """Async context manager entry."""
        await self.start()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.close()