"""
Code parsing and extraction utilities.

This module provides utilities for extracting code from projects,
generating directory trees, and creating markdown documentation from code.
"""

from .code import (
    lang_map,
    read_gitignore,
    adjust_gitignore_patterns,
    should_ignore,
    generate_tree,
    generate_markdown,
    extract_to_md,
)

__all__ = [
    "lang_map",
    "read_gitignore",
    "adjust_gitignore_patterns",
    "should_ignore",
    "generate_tree",
    "generate_markdown",
    "extract_to_md",
]
