"""
Parsing utilities for various file formats and content types.

This module provides parsers for:
- Code: Extract and document code from projects
- PDF: PDF parsing utilities (planned)
- Media: Audio, image, and video parsing utilities (planned)
"""

# Code parser
from .code import (
    extract_to_md,
    generate_markdown,
    generate_tree,
    read_gitignore,
    should_ignore,
    lang_map,
)

__all__ = [
    # Code parsing
    "extract_to_md",
    "generate_markdown",
    "generate_tree",
    "read_gitignore",
    "should_ignore",
    "lang_map",
]
