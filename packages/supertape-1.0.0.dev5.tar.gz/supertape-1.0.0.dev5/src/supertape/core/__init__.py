"""
Supertape Core Library

This module contains the core functionality for audio modulation/demodulation,
file format handling, BASIC/assembly processing, and data persistence.
"""
