"""NoStage - Protect files from being accidentally committed to Git."""

__version__ = "0.1.0"
