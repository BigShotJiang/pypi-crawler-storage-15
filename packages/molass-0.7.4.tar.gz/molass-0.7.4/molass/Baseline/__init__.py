"""
    Baseline.__init__.py

    Copyright (c) 2025, SAXS Team, KEK-PF
"""

from .Baseline2D import Baseline2D