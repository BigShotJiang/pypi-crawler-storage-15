"""
    Mapping.__init__.py
"""