"""
    SAXS.Models.__init__.py
"""