"""
    SAXS.__init__.py
"""