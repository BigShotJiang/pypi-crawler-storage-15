"""
    Except.__init__.py
"""