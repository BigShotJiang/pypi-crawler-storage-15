"""
    ScipyUtils.__init__.py
"""