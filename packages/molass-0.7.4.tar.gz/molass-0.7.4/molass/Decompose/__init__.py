"""
    Decompose.__init__.py
"""