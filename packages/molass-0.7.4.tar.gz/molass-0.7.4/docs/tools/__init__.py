"""
This sript is required to make the scripts in the docs/tools directory recognized as modules.
"""