from snaptrade_client.paths.accounts_account_id_trading_instruments_cryptocurrency_pairs.get import ApiForget


class AccountsAccountIdTradingInstrumentsCryptocurrencyPairs(
    ApiForget,
):
    pass
