from snaptrade_client.paths.root.get import ApiForget


class Root(
    ApiForget,
):
    pass
