from snaptrade_client.paths.currencies_rates_currency_pair.get import ApiForget


class CurrenciesRatesCurrencyPair(
    ApiForget,
):
    pass
