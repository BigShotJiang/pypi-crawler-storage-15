from snaptrade_client.paths.accounts_account_id_options_chain.get import ApiForget


class AccountsAccountIdOptionsChain(
    ApiForget,
):
    pass
