from snaptrade_client.paths.snap_trade_reset_user_secret.post import ApiForpost


class SnapTradeResetUserSecret(
    ApiForpost,
):
    pass
