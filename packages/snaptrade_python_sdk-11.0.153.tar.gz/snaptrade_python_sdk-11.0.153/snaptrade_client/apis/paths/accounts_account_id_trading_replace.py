from snaptrade_client.paths.accounts_account_id_trading_replace.post import ApiForpost


class AccountsAccountIdTradingReplace(
    ApiForpost,
):
    pass
