from snaptrade_client.paths.brokerages_slug_instruments.get import ApiForget


class BrokeragesSlugInstruments(
    ApiForget,
):
    pass
