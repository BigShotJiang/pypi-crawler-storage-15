from snaptrade_client.paths.snap_trade_login.post import ApiForpost


class SnapTradeLogin(
    ApiForpost,
):
    pass
