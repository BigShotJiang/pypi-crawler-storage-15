from snaptrade_client.paths.accounts_account_id_orders_cancel.post import ApiForpost


class AccountsAccountIdOrdersCancel(
    ApiForpost,
):
    pass
