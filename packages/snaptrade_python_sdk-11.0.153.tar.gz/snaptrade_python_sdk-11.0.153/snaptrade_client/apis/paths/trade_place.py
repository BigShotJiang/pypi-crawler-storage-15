from snaptrade_client.paths.trade_place.post import ApiForpost


class TradePlace(
    ApiForpost,
):
    pass
