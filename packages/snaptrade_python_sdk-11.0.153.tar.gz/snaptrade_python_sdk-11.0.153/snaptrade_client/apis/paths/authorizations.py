from snaptrade_client.paths.authorizations.get import ApiForget


class Authorizations(
    ApiForget,
):
    pass
