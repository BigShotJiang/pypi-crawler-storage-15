# coding: utf-8

from snaptrade_client.apis.tags.options_api_generated import OptionsApiGenerated

class OptionsApi(OptionsApiGenerated):
    pass
