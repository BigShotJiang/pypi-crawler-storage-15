# coding: utf-8

from snaptrade_client.apis.tags.reference_data_api_generated import ReferenceDataApiGenerated

class ReferenceDataApi(ReferenceDataApiGenerated):
    pass
