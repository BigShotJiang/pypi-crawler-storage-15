# -*- coding: UTF-8 -*-
"""
Created on 26.04.23

:author:     Martin Dočekal
"""

from .configurable import *
