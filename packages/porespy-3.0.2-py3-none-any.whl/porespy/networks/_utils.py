

__all__ = [
    "_net_dict",
]


class _net_dict(dict):
    pass
