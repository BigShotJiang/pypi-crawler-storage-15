from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
import functools
import re
import time

from adam.commands.cql.cql_utils import cassandra_table_names, run_cql, table_spec
from adam.commands.export.importer import Importer
from adam.commands.export.importer_athena import AthenaImporter
from adam.commands.export.importer_sqlite import SqliteImporter
from adam.commands.export.utils_export import ExportSpec, ExportStatus, ExportTableSpec, ImporterType, find_files, ing
from adam.config import Config
from adam.pod_exec_result import PodExecResult
from adam.repl_state import ReplState
from adam.utils import elapsed_time, log2
from adam.utils_k8s.cassandra_nodes import CassandraNodes
from adam.utils_k8s.statefulsets import StatefulSets

class Exporter:
    def export_tables(args: list[str], state: ReplState, export_state: str, max_workers = 0) -> tuple[list[str], ExportSpec]:
        spec = ExportSpec.parse_specs(' '.join(args))
        return Exporter._export_tables(spec, state, max_workers, export_state)

    def import_session(args: list[str], state: ReplState, max_workers = 0) -> tuple[list[str], ExportSpec]:
        status_in_whole = 'done'

        tables = []
        for s in ExportStatus.get_copy_status(state.sts, state.pod, state.namespace, state.export_session, True):
            status: ExportStatus = s
            tables.append(ExportTableSpec(status.keyspace, status.table, target_table=status.table))
            if status.status != 'done':
                status_in_whole = status.status

        if status_in_whole == 'done':
            log2(f'The session has been completely done - no more csv files are found.')
            return [], ExportSpec(None, None, importer=Importer.importer_from_session(state.export_session), tables=[])

        # need only the importer from arguments
        importer = Importer.importer_from_session(state.export_session)
        if spec := ExportSpec.parse_specs(' '.join(args)):
            if spec.importer:
                importer = spec.importer

        spec = ExportSpec(None, None, importer=importer, tables=tables)

        return Exporter._export_tables(spec, state, max_workers)

    def _export_tables(spec: ExportSpec, state: ReplState, max_workers = 0, export_state = None) -> tuple[list[str], ExportSpec]:
        if not spec.keyspace:
            spec.keyspace = f'{state.namespace}_db'

        if not spec.tables:
            spec.tables = [ExportTableSpec.parse(t) for t in cassandra_table_names(state, keyspace=spec.keyspace)]

        if not max_workers:
            max_workers = Config().action_workers(f'exporter.{spec.importer}', 8)

        if max_workers > 1 and len(spec.tables) > 1:
            log2(f'Executing on {len(spec.tables)} Cassandra tables in parallel...')
            start_time = time.time()
            try:
                with ThreadPoolExecutor(max_workers=max_workers) as executor:
                    futures = [executor.submit(Exporter.export_table, table, state, spec.importer, True, consistency=spec.consistency, export_state=export_state) for table in spec.tables]
                    if len(futures) == 0:
                        return [], spec

                return [future.result() for future in as_completed(futures)], spec
            finally:
                log2(f"{len(spec.tables)} parallel table export elapsed time: {elapsed_time(start_time)} with {max_workers} workers")
        else:
            return [Exporter.export_table(table, state, spec.importer, multi_tables=len(spec.tables) > 1, consistency=spec.consistency, export_state=export_state) for table in spec.tables], spec

    def export_table(spec: ExportTableSpec, state: ReplState, importer: str, multi_tables = True, consistency: str = None, export_state=None):
        s: str = None

        table, target_table, columns = Exporter.resove_table_n_columns(spec, state, include_ks_in_target=False, importer=importer)
        log_file = f'/tmp/qing-{state.export_session}_{spec.keyspace}.{target_table}.log'
        create_db = not state.export_session
        if not state.export_session:
            prefix = Importer.session_prefix(importer)

            state.export_session = f'{prefix}{datetime.now().strftime("%Y%m%d%H%M%S")[3:]}'

        if export_state == 'init':
            Exporter.create_table_log(spec, state, table, target_table, multi_tables=multi_tables)
        else:
            if export_state == 'pending_export':
                Exporter.export_to_csv(spec, state, table, target_table, columns, multi_tables=multi_tables, consistency=consistency)

            log_files: list[str] = find_files(state.pod, state.namespace, f'{log_file}*')
            if not log_files:
                return s

            log_file = log_files[0]

            s, keyspace, table = ExportStatus.get_status_from_log_file(state.pod, state.namespace, state.export_session, log_file, multi_tables=multi_tables)
            while s != 'done':
                if s == 'export_in_pregress':
                    time.sleep(1)
                elif s == 'exported':
                    log_file = Exporter.rename_to_pending_import(spec, state, target_table, multi_tables=multi_tables)
                    if importer == ImporterType.CSV:
                        return s
                elif s == 'pending_import':
                    log_file, session = Exporter.import_from_csv(spec, state, importer, table, target_table, columns, multi_tables=multi_tables, create_db=create_db)
                    state.export_session = session

                s, keyspace, table = ExportStatus.get_status_from_log_file(state.pod, state.namespace, state.export_session, log_file, multi_tables=multi_tables)

        return s

    def create_table_log(spec: ExportTableSpec, state: ReplState, table: str, target_table: str, multi_tables = True):
        log_file = f'/tmp/qing-{state.export_session}_{spec.keyspace}.{target_table}.log'

        CassandraNodes.exec(state.pod, state.namespace, f'rm -f {log_file}* && touch {log_file}', show_out=Config().is_debug(), shell='bash')

        return table

    def export_to_csv(spec: ExportTableSpec, state: ReplState, table: str, target_table: str, columns: str, multi_tables = True, consistency: str = None):
        temp_dir = Config().get('copy.temp_dir', '/c3/cassandra/tmp')
        db = f'{state.export_session}_{target_table}'

        CassandraNodes.exec(state.pod, state.namespace, f'mkdir -p {temp_dir}/{db}', show_out=Config().is_debug(), shell='bash')
        csv_file = f'{temp_dir}/{db}/{table}.csv'
        log_file = f'/tmp/qing-{state.export_session}_{spec.keyspace}.{target_table}.log'

        suppress_ing_log = Config().is_debug() or multi_tables
        queries = []
        if consistency:
            queries.append(f'CONSISTENCY {consistency}')
        queries.append(f"COPY {spec.keyspace}.{table}({columns}) TO '{csv_file}' WITH HEADER = TRUE")
        r: PodExecResult = ing(f'Dumping table {spec.keyspace}.{table}{f" with consistency {consistency}" if consistency else ""}',
            lambda: run_cql(state, ';'.join(queries), show_out=Config().is_debug(), background=True, log_file=log_file),
            suppress_log=suppress_ing_log)

        return log_file

    def rename_to_pending_import(spec: ExportTableSpec, state: ReplState, target_table: str, multi_tables = True):
        log_file = f'/tmp/qing-{state.export_session}_{spec.keyspace}.{target_table}.log'
        to = f'{log_file}.pending_import'

        CassandraNodes.exec(state.pod, state.namespace, f'mv {log_file} {to}', show_out=Config().is_debug(), shell='bash')

        return to

    def import_from_csv(spec: ExportTableSpec, state: ReplState, importer: str, table: str, target_table: str, columns: str, multi_tables = True, create_db = False):
        im = AthenaImporter() if importer == ImporterType.ATHENA else SqliteImporter()
        return im.import_from_csv(state.pod, state.namespace, state.export_session, spec.keyspace, table, target_table, columns, multi_tables, create_db)

    def clear_export_session_cache():
        Exporter.find_export_sessions.cache_clear()
        Exporter.export_session_names.cache_clear()

    @functools.lru_cache()
    def export_session_names(sts: str, pod: str, namespace: str, importer: str = None, export_state = None):
        if not sts or not namespace:
            return []

        if not pod:
            pod = StatefulSets.pod_names(sts, namespace)[0]

        if not pod:
            return []

        return [session for session, state in Exporter.find_export_sessions(pod, namespace, importer).items() if not export_state or state == export_state]

    @functools.lru_cache()
    def find_export_sessions(pod: str, namespace: str, importer: str = None, limit = 100, multi_tables = True):
        sessions: dict[str, str] = {}

        prefix = Importer.session_prefix(importer)

        log_files: list[str] = find_files(pod, namespace, f'/tmp/qing-{prefix}*_*.log*')

        if not log_files:
            return {}

        for log_file in log_files[:100]:
            m = re.match(f'/tmp/qing-(.*?)_.*\.log?(.*)', log_file)
            if m:
                s = m.group(1)
                state = m.group(2) # '', '.pending_import', '.done'
                if state:
                    state = state.strip('.')
                else:
                    state = 'in_export'

                if s not in sessions:
                    sessions[s] = state
                elif sessions[s] == 'done' and state != 'done':
                    sessions[s] = state

        return sessions

    def rm_all_export_sessions(sts: str, pod: str, namespace: str, max_workers = 0):
        sessions = Exporter.export_session_names(sts, pod, namespace)
        if not sessions:
            log2('No export sessions found.')
            return []

        if not max_workers:
            max_workers = Config().action_workers('export_session', 8)

        if max_workers > 1 and len(sessions) > 1:
            log2(f'Executing on {len(sessions)} export session clean ups in parallel...')
            start_time = time.time()
            try:
                with ThreadPoolExecutor(max_workers=max_workers) as executor:
                    futures = [executor.submit(Exporter.rm_export_session, sts, pod, namespace, session, True) for session in sessions]
                    if len(futures) == 0:
                        return []

                return [future.result() for future in as_completed(futures)]
            finally:
                log2(f"{len(sessions)} parallel session clean ups elapsed time: {elapsed_time(start_time)} with {max_workers} workers")
        else:
            return [Exporter.rm_export_session(sts, pod, namespace, session) for session in sessions]

    def rm_export_session(sts: str, pod: str, namespace: str, copy_session: str, multi_tables = True):
        if not sts or not namespace:
            return 0, 0

        if not pod:
            pod = StatefulSets.pod_names(sts, namespace)[0]

        if not pod:
            return 0, 0

        csv_cnt = 0
        log_cnt = 0

        log_files: list[str] = find_files(pod, namespace, f'/tmp/qing-{copy_session}_*.log*')

        temp_dir = Config().get('copy.temp_dir', '/c3/cassandra/tmp')

        for log_file in log_files:
            m = re.match(f'/tmp/qing-{copy_session}_(.*?)\.(.*?)\.log.*', log_file)
            if m:
                table = m.group(2)

                db = f'{copy_session}_{table}'
                CassandraNodes.exec(pod, namespace, f'rm -rf {temp_dir}/{db}', show_out=not multi_tables, shell='bash')
                csv_cnt += 1

                CassandraNodes.exec(pod, namespace, f'rm -rf {log_file}', show_out=not multi_tables, shell='bash')
                log_cnt += 1

        return csv_cnt, log_cnt

    def resove_table_n_columns(spec: ExportTableSpec, state: ReplState, include_ks_in_target = False, importer = ImporterType.SQLITE):
        table = spec.table
        columns = spec.columns
        if not columns:
            columns = Config().get(f'export.{importer}.columns', f'<keys>')

        keyspaced_table = f'{spec.keyspace}.{spec.table}'
        if columns == '<keys>':
            columns = ','.join(table_spec(state, keyspaced_table, on_any=True).keys())
        elif columns == '<row-key>':
            columns = table_spec(state, keyspaced_table, on_any=True).row_key()
        elif columns == '*':
            columns = ','.join([c.name for c in table_spec(state, keyspaced_table, on_any=True).columns])

        if not columns:
            log2(f'ERROR: Empty columns on {table}.')
            return table, None, None

        target_table = spec.target_table if spec.target_table else table
        if not include_ks_in_target and '.' in target_table:
            target_table = target_table.split('.')[-1]

        return table, target_table, columns