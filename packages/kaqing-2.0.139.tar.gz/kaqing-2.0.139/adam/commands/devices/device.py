from abc import abstractmethod
from adam.commands.command import Command
from adam.repl_state import ReplState

class Device:
    @abstractmethod
    def ls(self, cmd: str, state: ReplState):
        pass

    def ls_completion(self, cmd: str, state: ReplState, default: dict = {}):
        return default

    def cd(self, dir: str, state: ReplState):
        pass

    def cd_completion(self, cmd: str, state: ReplState, default: dict = {}):
        return default

    @abstractmethod
    def pwd(self, state: ReplState):
        pass

    def try_fallback_action(self, chain: Command, state: ReplState, cmd: str):
        return False, None

    def enter(state: ReplState):
        pass
