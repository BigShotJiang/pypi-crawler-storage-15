Django Agent Gate 🏦

Monetize your Django API in minutes with the Agent Economy.

django-agent-gate is a middleware that instantly turns your API into a metered, paid service for AI Agents and developers.

It acts as a connector to the Agent Bank protocol, handling authentication, credit checks, and automated billing per request.

🚀 Features

Smart Paywall: Automatically protects any route starting with /api/ while keeping your home page, docs, and login pages free.

Metered Billing: Deduct 1 (or more) credits per request automatically.

Marketplace Ready: Identifies who is calling (The Customer) and who is serving (You), ensuring credits are transferred correctly.

Agent-Native: Returns standardized 402 Payment Required errors with structured JSON, allowing AI agents to autonomously fund their wallets.

📦 Installation

pip install django-agent-gate


⚙️ Configuration

Add to Middleware:
Open settings.py and add AgentGateMiddleware. It must be placed after SecurityMiddleware but before your URL configurations.

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    # ...
    'django_agent_gate.middleware.AgentGateMiddleware', # <--- Add this line
    # ...
]


Configure Variables:
Add these settings to the bottom of your settings.py:

# 1. The URL of the Central Bank (The Ledger)
AGENT_GATE_BANK_URL = "[https://agent-bank-production.onrender.com](https://agent-bank-production.onrender.com)"

# 2. YOUR Merchant API Key (Get this from your Agent Bank Dashboard)
# This ensures the credits spent by users go into YOUR account.
AGENT_GATE_API_KEY = "your-merchant-uuid-here"

# 3. Price per Request (Optional, defaults to 1)
AGENT_GATE_PRICE = 1


🛡️ How it Works (What gets blocked?)

The middleware uses a "Safe-by-Default" policy.

Protected URLs (/api/...): Any URL path starting with /api/ will trigger the credit check. If the user does not provide a valid API Key with sufficient credits, they are blocked (402 Error).

Public URLs (Home, Login, etc.): Any URL not starting with /api/ is ignored by the middleware and loads normally.

🛠️ Usage

For Your Users (The Consumers)

To access your protected API, users must include their Agent Bank API Key in the header of every request:

curl -H "X-Api-Key: their-customer-uuid" [https://your-site.com/api/cool-data/](https://your-site.com/api/cool-data/)


Error Responses

If a user runs out of credits, the middleware returns a 402 Payment Required response:

{
    "error": "Insufficient Credits",
    "balance": 0,
    "top_up_url": "[https://agent-bank-production.onrender.com/](https://agent-bank-production.onrender.com/)"
}


🏗️ Architecture

This library operates as a Spoke in a Hub-and-Spoke financial model.

The Hub: The Agent Bank (Ledger, Stripe Processing, User Accounts).

The Spoke: Your Django App (Product, Logic, Value).

When a request comes in, this middleware pings the Hub to verify funds and transfer credits from the Consumer to the Merchant.