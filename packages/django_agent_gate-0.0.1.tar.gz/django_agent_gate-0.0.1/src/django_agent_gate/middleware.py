import requests
from django.http import JsonResponse
from django.conf import settings

class AgentGateMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response
        
        # CONFIGURATION
        self.bank_url = getattr(settings, 'AGENT_GATE_BANK_URL', 'http://127.0.0.1:8000')
        
        # YOUR IDENTITY (The Merchant)
        self.api_key = getattr(settings, 'AGENT_GATE_API_KEY', None)
        
        # How many credits to deduct per request
        self.price = getattr(settings, 'AGENT_GATE_PRICE', 1) 

        if not self.api_key:
            print("WARNING: Agent Gate is missing AGENT_GATE_API_KEY. You won't get paid for these requests!")

    def __call__(self, request):
        # 1. FILTER: Only protect routes starting with /api/
        if not request.path.startswith("/api/"):
             return self.get_response(request)

        # 2. CHECK FOR VISITOR KEY (The Customer)
        visitor_key = request.headers.get("X-Api-Key")
        
        if not visitor_key:
            return JsonResponse({
                "error": "Missing API Key. Please provide header 'X-Api-Key'",
                "portal_url": f"{self.bank_url}"
            }, status=401)

        # 3. EXECUTE TRANSFER (Call the Bank)
        try:
            response = requests.post(
                f"{self.bank_url}/api/spend/",
                json={'amount': self.price},
                headers={
                    'X-Customer-Key': visitor_key, # Who pays
                    'X-Merchant-Key': self.api_key # Who gets paid (YOU)
                },
                timeout=3.0
            )
            
            if response.status_code == 200:
                # Success! Payment accepted.
                return self.get_response(request)
            
            elif response.status_code == 402:
                # Insufficient Funds
                data = response.json()
                return JsonResponse({
                    "error": "Insufficient Credits",
                    "balance": data.get('balance'),
                    "top_up_url": data.get('portal_url')
                }, status=402)
                
            else:
                return JsonResponse({"error": "Payment Bank Error"}, status=502)

        except requests.exceptions.RequestException:
             return JsonResponse({"error": "Payment System Unavailable"}, status=503)