""" Core main registry app package
"""

default_app_config = "core_main_registry_app.apps.InitApp"
