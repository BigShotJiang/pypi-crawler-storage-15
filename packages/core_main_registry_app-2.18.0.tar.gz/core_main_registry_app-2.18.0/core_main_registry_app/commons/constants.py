""" all constants for the core_main_registry_app
"""


class DataStatus:
    """Data Status"""

    ACTIVE = "active"
    INACTIVE = "inactive"
    DELETED = "deleted"
