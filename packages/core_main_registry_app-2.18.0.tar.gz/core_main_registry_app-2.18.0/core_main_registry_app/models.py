""" App model to manage refinements. Mandatory for make migrations command.
"""
