from fluidattacks_gitlab_sdk.users.core import UserObj

__all__ = [
    "UserObj",
]
