from .AXUV import AXUV_dict
from .GaAsP import GaAsP_dict

__all__ = ["AXUV_dict", "GaAsP_dict"]
