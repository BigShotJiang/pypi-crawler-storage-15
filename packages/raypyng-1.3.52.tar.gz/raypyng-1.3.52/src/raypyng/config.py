# this is shared configuration space

"""ray_path contains default path to the ray installation
"""
ray_path = None

"""ray_binary contains name of the default binary or shell script
"""
ray_binary = "rayui.sh"
