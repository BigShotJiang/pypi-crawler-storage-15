"""Management commands for the Telegram app."""
