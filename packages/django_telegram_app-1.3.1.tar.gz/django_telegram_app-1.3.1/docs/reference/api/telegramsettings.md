# AbstractTelegramSettings
::: django_telegram_app.models.AbstractTelegramSettings

# TelegramSettings
::: django_telegram_app.models.TelegramSettings