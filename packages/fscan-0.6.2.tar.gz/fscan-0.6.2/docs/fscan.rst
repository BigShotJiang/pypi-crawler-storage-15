Supporting command line programs
--------------------------------

Fscan command line programs are run during the workflow.
In some cases, however, it may be useful to use the program independently of the full workflow, e.g., for debugging purposes.

.. toctree::
    :maxdepth: 1

    clean
    html
    post
    status
