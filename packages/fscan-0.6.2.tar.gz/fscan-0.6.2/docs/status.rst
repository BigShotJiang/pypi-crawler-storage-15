AnalysisSummary
---------------

Can be run from the command line using

.. code-block:: bash

    AnalysisSummary <mode> <arguments>

This has several modes of operation to monitor for Fscan running status and completion of Fscan over a history.

.. automodule:: fscan.status
   :members:
   :show-inheritance:
