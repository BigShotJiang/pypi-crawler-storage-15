fscan.process.lineobjects module
--------------------------------

This module contains classes used for handling line, comb, and spectrum objects.

API
^^^

.. automodule:: fscan.process.lineobjects
   :members:
   :show-inheritance:
