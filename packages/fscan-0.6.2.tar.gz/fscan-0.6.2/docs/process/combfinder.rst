fscan.process.combfinder module
-------------------------------

This module enables finding comb features in frequency-domain spectral data.
The input data must be the peaks found in data, not the raw spectral data.

API
^^^

.. automodule:: fscan.process.combfinder
   :members:
   :show-inheritance:
