fscan.process.spectlinetools module
-----------------------------------

This module contains utility functions to handle peak finding, tagging, etc.

API
^^^

.. automodule:: fscan.process.spectlinetools
   :members:
   :show-inheritance:
