fscan.process.history module
----------------------------

Can be run from the command line using

.. code-block:: bash

    FscanCompileHistory <arguments>

The output will be a ``npz`` file of the line count history statistics

API
^^^

.. automodule:: fscan.process.history
   :members:
   :show-inheritance:
