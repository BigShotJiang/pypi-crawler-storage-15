fscan.plot.static module
------------------------

Can be run from the command line using

.. code-block:: bash

    FscanStaticPlot <arguments>

The output will be a static plot showing spectra, spectrogram, coherence, or persistency.

API
^^^

.. automodule:: fscan.plot.static
   :members:
   :show-inheritance:
