fscan.utils.config module
-------------------------

This module contains classes and functions for handling configuration files and command line argument parsing.

API
^^^

.. automodule:: fscan.utils.config
   :members:
   :show-inheritance:
