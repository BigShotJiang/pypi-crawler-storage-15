HTCondor workflow
-----------------

The ``fscan.batch`` module creates the HTCondor workflow for running Fscan on LIGO Computing resources at LHO, LLO, or CIT.

API
^^^

.. automodule:: fscan.batch
   :members:
   :show-inheritance:
