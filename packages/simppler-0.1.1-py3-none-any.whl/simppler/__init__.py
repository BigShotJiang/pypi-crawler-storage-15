# redundant alias to silence linter
from simppler._version import __version__ as __version__
